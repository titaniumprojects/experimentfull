/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package lombok;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Target(value={ElementType.TYPE})
@Retention(value=RetentionPolicy.SOURCE)
@Environment(value=EnvType.CLIENT)
public @interface Data {
    public String staticConstructor() default "";
}

