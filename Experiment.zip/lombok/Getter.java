/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package lombok;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import lombok.AccessLevel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Target(value={ElementType.FIELD, ElementType.TYPE})
@Retention(value=RetentionPolicy.SOURCE)
@Environment(value=EnvType.CLIENT)
public @interface Getter {
    public AccessLevel value() default AccessLevel.PUBLIC;

    public AnyAnnotation[] onMethod() default {};

    public boolean lazy() default false;

    @Deprecated
    @Retention(value=RetentionPolicy.SOURCE)
    @Target(value={})
    @Environment(value=EnvType.CLIENT)
    public static @interface AnyAnnotation {
    }
}

