/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.waypoints;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public class WayPointsManager {
    private final Map<String, class_243> waypoints = new HashMap<String, class_243>();

    public void add(String name, int x, int y, int z) {
        class_243 pos = new class_243((double)x, (double)y, (double)z);
        if (this.waypoints.containsKey(name)) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("modules.waypoints.exists", name)));
            return;
        }
        this.waypoints.put(name, pos);
        MessageUtility.info(class_2561.method_30163((String)Localizator.translate("modules.waypoints.added", name, x, y, z)));
    }

    public void del(String name) {
        if (this.waypoints.remove(name) != null) {
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("modules.waypoints.deleted", name)));
        } else {
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("modules.waypoints.not_found", name)));
        }
    }

    public void clear() {
        this.waypoints.clear();
        MessageUtility.info(class_2561.method_30163((String)Localizator.translate("modules.waypoints.cleared")));
    }

    public boolean contains(String name) {
        return this.waypoints.containsKey(name);
    }

    public Set<Map.Entry<String, class_243>> getEntries() {
        return this.waypoints.entrySet();
    }
}

