/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.localization;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum Language {
    EN_US("en_us"),
    RU_RU("ru_ru"),
    UK_UA("uk_ua"),
    PL_PL("pl_pl");

    private final String code;

    private Language(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}

