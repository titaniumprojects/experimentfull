/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2960
 */
package micronix.experiment.systems.poshalko;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;

@Environment(value=EnvType.CLIENT)
public class PoshalkoHandler
implements IMinecraft {
    private static final Animation animation = new Animation(1000L, Easing.CUBIC_IN_OUT);
    private static boolean removing = true;
    private static boolean Z_PRESSED = false;
    private static boolean V_PRESSED = false;
    private final EventListener<KeyPressEvent> onKeyPress = event -> {
        int key = event.getKey();
        int action = event.getAction();
        if (key == 90) {
            Z_PRESSED = action != 0;
        } else if (key == 86) {
            V_PRESSED = action != 0;
            boolean bl = V_PRESSED;
        }
        if (Z_PRESSED && V_PRESSED) {
            removing = false;
            animation.update(1.0f);
        }
    };
    private final EventListener<PreHudRenderEvent> onPreHudRender = event -> {
        if ((double)animation.getValue() == 1.0 && !removing) {
            removing = true;
        }
        animation.update(removing ? 0.0f : 1.0f);
        if (animation.getValue() == 0.0f && removing) {
            return;
        }
        float textureScale = 200.0f;
        float textureX = ((float)mc.method_22683().method_4486() - textureScale) / 2.0f;
        float textureY = ((float)mc.method_22683().method_4502() - textureScale) / 2.0f;
        class_2960 poshalkoTexture = Experiment.id("icons/poshalko.png");
        event.getContext().drawTexture(poshalkoTexture, textureX, textureY, textureScale, textureScale, Colors.WHITE.withAlpha(255.0f * animation.getValue()));
    };

    public PoshalkoHandler() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }
}

