/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.theme;

import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.theme.Theme;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ThemeManager {
    private Theme currentTheme = Theme.DARK;

    public void switchTheme() {
        this.currentTheme = this.currentTheme == Theme.DARK ? Theme.LIGHT : Theme.DARK;
    }

    public Theme getCurrentTheme() {
        if (Interface.glassSelected()) {
            return Theme.DARK;
        }
        return this.currentTheme;
    }

    public void setCurrentTheme(Theme currentTheme) {
        this.currentTheme = currentTheme;
    }
}

