/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.theme;

import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum Theme {
    DARK(new ColorRGBA(255.0f, 255.0f, 255.0f), new ColorRGBA(12.0f, 12.0f, 12.0f), new ColorRGBA(24.0f, 24.0f, 27.0f), new ColorRGBA(32.0f, 32.0f, 32.0f), ColorRGBA.BLACK),
    LIGHT(new ColorRGBA(54.0f, 49.0f, 55.0f), new ColorRGBA(255.0f, 255.0f, 255.0f), new ColorRGBA(189.0f, 189.0f, 189.0f), new ColorRGBA(32.0f, 32.0f, 32.0f), ColorRGBA.WHITE);

    private final ColorRGBA textColor;
    private final ColorRGBA backgroundColor;
    private final ColorRGBA additionalColor;
    private final ColorRGBA outlineColor;
    private final ColorRGBA flatColor;

    public ColorRGBA getTextColor() {
        return this.textColor;
    }

    public ColorRGBA getBackgroundColor() {
        return this.backgroundColor;
    }

    public ColorRGBA getAdditionalColor() {
        return this.additionalColor;
    }

    public ColorRGBA getOutlineColor() {
        return this.outlineColor;
    }

    public ColorRGBA getFlatColor() {
        return this.flatColor;
    }

    private Theme(ColorRGBA textColor, ColorRGBA backgroundColor, ColorRGBA additionalColor, ColorRGBA outlineColor, ColorRGBA flatColor) {
        this.textColor = textColor;
        this.backgroundColor = backgroundColor;
        this.additionalColor = additionalColor;
        this.outlineColor = outlineColor;
        this.flatColor = flatColor;
    }
}

