/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands;

import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public sealed interface ValidationResult {
    public static <T> Ok<T> ok(T value) {
        return new Ok<T>(value);
    }

    public static Error error(String msg) {
        MessageUtility.error(class_2561.method_30163((String)msg));
        return new Error(msg);
    }

    @Environment(value=EnvType.CLIENT)
    public record Ok<T>(T value) implements ValidationResult
    {
    }

    @Environment(value=EnvType.CLIENT)
    public record Error(String message) implements ValidationResult
    {
    }
}

