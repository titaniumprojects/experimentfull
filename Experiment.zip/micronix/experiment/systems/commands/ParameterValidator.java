/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.commands;

import java.util.Collections;
import java.util.List;
import micronix.experiment.systems.commands.ValidationResult;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FunctionalInterface
@Environment(value=EnvType.CLIENT)
public interface ParameterValidator<T> {
    public ValidationResult validate(String var1);

    default public List<String> suggestions(String partial) {
        return Collections.emptyList();
    }
}

