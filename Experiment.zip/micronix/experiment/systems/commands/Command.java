/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.commands;

import java.util.List;
import micronix.experiment.systems.commands.CommandHandler;
import micronix.experiment.systems.commands.Parameter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface Command {
    public List<String> names();

    public String description();

    public List<Parameter<?>> parameters();

    public List<Command> subcommands();

    public boolean executable();

    public CommandHandler handler();
}

