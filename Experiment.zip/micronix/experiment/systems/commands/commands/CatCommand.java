/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1043
 *  net.minecraft.class_1044
 *  net.minecraft.class_2960
 */
package micronix.experiment.systems.commands.commands;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import javax.imageio.ImageIO;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.WebUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;

@Environment(value=EnvType.CLIENT)
public class CatCommand
implements IMinecraft {
    private final Animation animation = new Animation(1000L, Easing.CUBIC_IN_OUT);
    private boolean removing = false;
    private class_2960 catTexture = null;
    private boolean loading = false;
    private final EventListener<PreHudRenderEvent> onPreHudRender = event -> {
        if (this.catTexture == null) {
            return;
        }
        if ((double)this.animation.getValue() == 1.0 && !this.removing) {
            this.removing = true;
        }
        this.animation.update(this.removing ? 0.0f : 1.0f);
        if (this.animation.getValue() == 0.0f && this.removing) {
            return;
        }
        float textureScale = 200.0f;
        float textureX = ((float)mc.method_22683().method_4486() - textureScale) / 2.0f;
        float textureY = ((float)mc.method_22683().method_4502() - textureScale) / 2.0f;
        event.getContext().drawTexture(this.catTexture, textureX, textureY, textureScale, textureScale, Colors.WHITE.withAlpha(255.0f * this.animation.getValue()));
    };

    public CatCommand() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public Command command() {
        return CommandBuilder.begin("cat", b -> b.aliases("kitty").desc("commands.cat.description").handler(ctx -> this.loadRandomCatImage())).build();
    }

    private void loadRandomCatImage() {
        if (this.loading) {
            return;
        }
        this.loading = true;
        CompletableFuture.supplyAsync(() -> {
            try {
                String json = WebUtility.fetchJson("https://api.thecatapi.com/v1/images/search");
                String imageUrl = WebUtility.extractImageUrl(json);
                if (imageUrl == null) {
                    return null;
                }
                BufferedImage bufferedImage = ImageIO.read(new URL(imageUrl));
                if (bufferedImage == null) {
                    return null;
                }
                return WebUtility.bufferedImageToNativeImage(bufferedImage, false);
            }
            catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }).thenAccept(nativeImage -> mc.execute(() -> {
            if (nativeImage != null) {
                if (this.catTexture != null) {
                    mc.method_1531().method_4615(this.catTexture);
                }
                class_2960 id = Experiment.id("temp/cat/" + String.valueOf(UUID.randomUUID()));
                mc.method_1531().method_4616(id, (class_1044)new class_1043(nativeImage));
                this.catTexture = id;
                this.animation.update(1.0f);
                this.removing = false;
            }
            this.loading = false;
        }));
    }
}

