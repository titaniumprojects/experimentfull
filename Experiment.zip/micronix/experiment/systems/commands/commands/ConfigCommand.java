/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.ParameterValidator;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.config.ConfigFile;
import micronix.experiment.systems.config.ConfigManager;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public final class ConfigCommand {
    private static final ParameterValidator<String> CONFIG_NAME = ValidationResult::ok;

    @Compile
    public Command command() {
        List<String> configNames = Experiment.getInstance().getConfigManager().getConfigFiles().stream().map(ConfigFile::getFileName).toList();
        return CommandBuilder.begin("config", b -> b.aliases("cfg", "\u043a\u0444\u0433", "\u043a\u043e\u043d\u0444\u0438\u0433").desc("commands.config.description").param("action", p -> p.validator(text -> Action.from(text).map(action -> ValidationResult.ok(action)).orElseGet(() -> ValidationResult.error(Localizator.translate("commands.config.invalid_action")))).suggests(Action.allNames())).param("id", p -> p.optional().validator(CONFIG_NAME).suggests(configNames)).handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        Action action = (Action)((Object)ctx.arguments().get(0));
        String id = (String)ctx.arguments().get(1);
        action.createHandler().accept(id);
    }

    @Environment(value=EnvType.CLIENT)
    private static enum Action {
        SAVE("save", "create", "add", "\u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c", "\u044b\u0444\u043c\u0443"),
        REMOVE("delete", "remove", "del", "\u0443\u0434\u0430\u043b\u0438\u0442\u044c", "\u0432\u0443\u0434\u0443\u0435\u0443"),
        LIST("list", "\u0434\u0448\u044b\u0435"),
        LOAD("load", "use", "\u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c", "\u0434\u0449\u0444\u0432"),
        DIR("dir", "direction");

        private final List<String> names;

        private Action(String ... names) {
            this.names = Arrays.stream(names).map(String::toLowerCase).collect(Collectors.toList());
        }

        @Compile
        private Consumer<String> createHandler() {
            return switch (this.ordinal()) {
                default -> throw new MatchException(null, null);
                case 0 -> this::saveConfig;
                case 1 -> s -> {
                    if (s != null) {
                        Experiment.getInstance().getConfigManager().getConfig((String)s).delete();
                    }
                };
                case 3 -> s -> {
                    Experiment.getInstance().getConfigManager().refresh();
                    if (s != null && Experiment.getInstance().getConfigManager().getConfig((String)s) != null) {
                        Experiment.getInstance().getConfigManager().getConfig((String)s).load();
                    }
                };
                case 2 -> s -> Experiment.getInstance().getConfigManager().listConfigs();
                case 4 -> s -> Experiment.getInstance().getConfigManager().directionConfig();
            };
        }

        @Compile
        private void saveConfig(String configName) {
            if (configName == null) {
                return;
            }
            ConfigManager configManager = Experiment.getInstance().getConfigManager();
            configManager.createConfig(configName);
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.config.saved", configName)));
        }

        @Compile
        static Optional<Action> from(String input) {
            String key = input.toLowerCase();
            return Arrays.stream(Action.values()).filter(a -> a.names.contains(key)).findFirst();
        }

        @Compile
        static List<String> allNames() {
            return Arrays.stream(Action.values()).map(a -> a.names.getFirst()).collect(Collectors.toList());
        }
    }
}

