/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_241
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_290
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package micronix.experiment.systems.commands.commands;

import java.util.Map;
import micronix.experiment.Experiment;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.waypoints.WayPointsManager;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.Utils;
import micronix.experiment.utility.render.batching.Batching;
import micronix.experiment.utility.render.batching.impl.FontBatching;
import micronix.experiment.utility.render.batching.impl.RectBatching;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

@Environment(value=EnvType.CLIENT)
public class WaypointsCommand
implements IMinecraft,
IScaledResolution {
    private final EventListener<HudRenderEvent> onHudRenderEvent = event -> {
        class_4587 matrices = event.getContext().method_51448();
        RectBatching rect = new RectBatching(class_290.field_1576, event.getContext().method_51448());
        this.renderBack((HudRenderEvent)event, matrices);
        ((Batching)rect).draw();
        FontBatching batching = new FontBatching(class_290.field_1575, Fonts.MEDIUM);
        this.renderText((HudRenderEvent)event, matrices);
        batching.draw();
    };

    public WaypointsCommand() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public Command command() {
        return CommandBuilder.begin("waypoint").aliases("way").desc("\u041c\u0435\u0442\u043a\u0438").param("action", p -> p.literal("add", "del", "clear")).param("name", p -> p.optional().validator(ValidationResult::ok)).param("x", p -> p.optional().validator(this::verifyCoordinate)).param("y", p -> p.optional().validator(this::verifyCoordinate)).param("z", p -> p.optional().validator(this::verifyCoordinate)).handler(this::handle).build();
    }

    private ValidationResult verifyCoordinate(String input) {
        try {
            Integer.parseInt(input);
            return ValidationResult.ok(input);
        }
        catch (NumberFormatException e) {
            return ValidationResult.error("\u041d\u0435 \u043f\u0440\u0430\u0432\u0438\u043b\u044c\u043d\u043e\u0435 \u0447\u0438\u0441\u043b\u043e");
        }
    }

    private void handle(CommandContext ctx) {
        String action = (String)ctx.arguments().get(0);
        String name = (String)ctx.arguments().get(1);
        String x = (String)ctx.arguments().get(2);
        String y = (String)ctx.arguments().get(3);
        String z = (String)ctx.arguments().get(4);
        WayPointsManager wayPointsManager = Experiment.getInstance().getWayPointsManager();
        switch (action.toLowerCase()) {
            case "add": {
                if (name == null || x == null || y == null || z == null) {
                    MessageUtility.error(class_2561.method_30163((String)"\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0438 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b (.way add \"\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435\" x y z)"));
                    return;
                }
                try {
                    wayPointsManager.add(name, Integer.parseInt(x), Integer.parseInt(y), Integer.parseInt(z));
                }
                catch (NumberFormatException e) {
                    MessageUtility.error(class_2561.method_30163((String)"\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0434\u043e\u043b\u0436\u043d\u044b \u0431\u044b\u0442\u044c \u0447\u0438\u0441\u043b\u0430\u043c\u0438"));
                }
                break;
            }
            case "del": {
                if (name == null) {
                    MessageUtility.error(class_2561.method_30163((String)"\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (.way del \"\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435\")"));
                    return;
                }
                wayPointsManager.del(name);
                break;
            }
            case "clear": {
                wayPointsManager.clear();
            }
        }
    }

    private void renderBack(HudRenderEvent event, class_4587 matrices) {
        for (Map.Entry<String, class_243> entry : Experiment.getInstance().getWayPointsManager().getEntries()) {
            String name = entry.getKey();
            class_243 pos = entry.getValue();
            class_243 renderPos = pos.method_1031(0.0, 0.5, 0.0);
            class_241 screenPos = Utils.worldToScreen(renderPos);
            if (screenPos == null) continue;
            float distance = (float)WaypointsCommand.mc.field_1724.method_19538().method_1022(pos.method_1031(0.5, 0.5, 0.5));
            float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
            matrices.method_22905(scale, scale, 1.0f);
            int textWidth = (int)Fonts.MEDIUM.getFont(11.0f).width(name + " " + String.format("%.1f", WaypointsCommand.mc.field_1724.method_19538().method_1022(pos)) + "m");
            int x = -textWidth / 2;
            int y = 5;
            event.getContext().drawRect(x - 3, y - 3, textWidth + 8, Fonts.MEDIUM.getFont(11.0f).height() + 6.0f, new ColorRGBA(0.0f, 0.0f, 0.0f, 100.0f));
            matrices.method_22909();
        }
    }

    private void renderText(HudRenderEvent event, class_4587 matrices) {
        for (Map.Entry<String, class_243> entry : Experiment.getInstance().getWayPointsManager().getEntries()) {
            String name = entry.getKey();
            class_243 pos = entry.getValue();
            class_243 renderPos = pos.method_1031(0.0, 0.5, 0.0);
            class_241 screenPos = Utils.worldToScreen(renderPos);
            if (screenPos == null) continue;
            float distance = (float)WaypointsCommand.mc.field_1724.method_19538().method_1022(pos.method_1031(0.5, 0.5, 0.5));
            float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
            matrices.method_22905(scale, scale, 1.0f);
            int textWidth = (int)Fonts.MEDIUM.getFont(11.0f).width(name + " " + String.format("%.1f", WaypointsCommand.mc.field_1724.method_19538().method_1022(pos)) + "m");
            int x = -textWidth / 2;
            int y = 5;
            event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), name + " " + String.format("%.1f", WaypointsCommand.mc.field_1724.method_19538().method_1022(pos)) + "m", x, y, ColorRGBA.WHITE);
            matrices.method_22909();
        }
    }
}

