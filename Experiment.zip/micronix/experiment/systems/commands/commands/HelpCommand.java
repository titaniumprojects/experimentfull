/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import java.util.ArrayList;
import java.util.Comparator;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class HelpCommand {
    @Compile
    public Command command() {
        return CommandBuilder.begin("help", b -> b.aliases("\u043f\u043e\u043c\u043e\u0449\u044c", "\u043a\u043e\u043c\u0430\u043d\u0434\u044b", "commands", "helpme").desc("commands.help.description").handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        ArrayList<Command> list = new ArrayList<Command>(Experiment.getInstance().getCommandManager().commands());
        list.sort(Comparator.comparing(c -> c.names().getFirst(), String.CASE_INSENSITIVE_ORDER));
        ArrayList<String> infos = new ArrayList<String>();
        int counter = 1;
        for (Command command : list) {
            infos.add(String.format("%d) %s%s - %s", counter++, Experiment.getInstance().getCommandManager().getPrefix(), command.names().getFirst(), Localizator.translate(command.description())));
        }
        MessageUtility.info(class_2561.method_30163((String)("\u0414\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u044b:\n" + String.join((CharSequence)"\n", infos))));
    }
}

