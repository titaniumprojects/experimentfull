/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1313
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_243
 *  net.minecraft.class_2602
 *  net.minecraft.class_2663
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 *  net.minecraft.class_745
 */
package micronix.experiment.systems.commands.commands;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2602;
import net.minecraft.class_2663;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_745;

@Environment(value=EnvType.CLIENT)
public class FakePlayerCommand
implements IMinecraft {
    private class_745 fakePlayer;
    private boolean immortal = true;
    private float moveForward = 0.0f;
    private float moveStrafe = 0.0f;
    private final EventListener<AttackEvent> onAttackEvent = event -> {
        if (this.fakePlayer != null && event.getEntity() == this.fakePlayer && this.fakePlayer.field_6235 == 0 && !this.immortal) {
            FakePlayerCommand.mc.field_1687.method_43128((class_1657)FakePlayerCommand.mc.field_1724, this.fakePlayer.method_23317(), this.fakePlayer.method_23318(), this.fakePlayer.method_23321(), class_3417.field_15115, class_3419.field_15248, 1.0f, 1.0f);
            if (FakePlayerCommand.mc.field_1724.field_6017 > 0.0f) {
                FakePlayerCommand.mc.field_1687.method_43128((class_1657)FakePlayerCommand.mc.field_1724, this.fakePlayer.method_23317(), this.fakePlayer.method_23318(), this.fakePlayer.method_23321(), class_3417.field_15016, class_3419.field_15248, 1.0f, 1.0f);
            } else {
                FakePlayerCommand.mc.field_1687.method_43128((class_1657)FakePlayerCommand.mc.field_1724, this.fakePlayer.method_23317(), this.fakePlayer.method_23318(), this.fakePlayer.method_23321(), class_3417.field_14706, class_3419.field_15248, 1.0f, 1.0f);
            }
            this.fakePlayer.method_48922(FakePlayerCommand.mc.field_1687.method_48963().method_48830());
            this.fakePlayer.method_6033(this.fakePlayer.method_6032() + this.fakePlayer.method_6067() - 1.0f);
            if (this.fakePlayer.method_29504()) {
                this.fakePlayer.method_6033(10.0f);
                new class_2663((class_1297)this.fakePlayer, 35).method_11471((class_2602)FakePlayerCommand.mc.field_1724.field_3944);
            }
        }
    };
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
        if (this.fakePlayer != null && FakePlayerCommand.mc.field_1755 == null) {
            int key = event.getKey();
            int action = event.getAction();
            if (key == 265) {
                this.moveForward = action != 1 && action != 2 ? 0.0f : 1.0f;
            } else if (key == 264) {
                this.moveForward = action != 1 && action != 2 ? 0.0f : -1.0f;
            } else if (key == 263) {
                this.moveStrafe = action != 1 && action != 2 ? 0.0f : 1.0f;
            } else if (key == 262) {
                this.moveStrafe = action != 1 && action != 2 ? 0.0f : -1.0f;
            }
        }
    };
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
        if (this.fakePlayer != null && FakePlayerCommand.mc.field_1724 != null) {
            if (this.moveForward == 0.0f && this.moveStrafe == 0.0f) {
                this.fakePlayer.method_5728(false);
                this.fakePlayer.method_18800(0.0, this.fakePlayer.method_18798().field_1351, 0.0);
                this.fakePlayer.field_42108.method_48567(0.0f);
            } else {
                float yaw = FakePlayerCommand.mc.field_1724.method_36454();
                double speed = 0.2;
                double motionX = (double)this.moveStrafe * Math.cos(Math.toRadians(yaw)) - (double)this.moveForward * Math.sin(Math.toRadians(yaw));
                double motionZ = (double)this.moveForward * Math.cos(Math.toRadians(yaw)) + (double)this.moveStrafe * Math.sin(Math.toRadians(yaw));
                class_243 velocity = new class_243(motionX * speed, this.fakePlayer.method_18798().field_1351, motionZ * speed);
                this.fakePlayer.method_18799(velocity);
                this.fakePlayer.method_5784(class_1313.field_6308, velocity);
                this.fakePlayer.method_5728(true);
            }
        }
    };

    public FakePlayerCommand() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public Command command() {
        return CommandBuilder.begin("fakeplayer").aliases("fp").desc("commands.fakeplayer.description").param("action", p -> p.literal("add", "del")).handler(this::handle).build();
    }

    private void handle(CommandContext ctx) {
        String var3;
        String action = (String)ctx.arguments().getFirst();
        switch (var3 = action.toLowerCase()) {
            case "add": {
                this.add();
                break;
            }
            case "del": {
                this.del();
            }
        }
    }

    public void add() {
        if (this.fakePlayer != null) {
            this.fakePlayer.method_31472();
            this.fakePlayer = null;
        }
        this.fakePlayer = new class_745(FakePlayerCommand.mc.field_1687, new GameProfile(UUID.fromString("66123666-6666-6666-6666-666666666600"), "FakePlayer"));
        this.fakePlayer.method_5719((class_1297)FakePlayerCommand.mc.field_1724);
        this.fakePlayer.method_6122(class_1268.field_5808, FakePlayerCommand.mc.field_1724.method_6047().method_7972());
        this.fakePlayer.method_6122(class_1268.field_5810, FakePlayerCommand.mc.field_1724.method_6079().method_7972());
        this.fakePlayer.method_6092(new class_1293(class_1294.field_5924, 9999, 2));
        this.fakePlayer.method_6092(new class_1293(class_1294.field_5898, 9999, 4));
        this.fakePlayer.method_6092(new class_1293(class_1294.field_5907, 9999, 1));
        FakePlayerCommand.mc.field_1687.method_53875((class_1297)this.fakePlayer);
        Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, Localizator.translate("commands.fakeplayer.success"), Localizator.translate("commands.fakeplayer.added"));
    }

    public void del() {
        if (this.fakePlayer == null) {
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.ERROR, Localizator.translate("commands.fakeplayer.error"), Localizator.translate("commands.fakeplayer.not_exists"));
        } else {
            this.fakePlayer.method_31472();
            this.fakePlayer = null;
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, Localizator.translate("commands.fakeplayer.success"), Localizator.translate("commands.fakeplayer.removed"));
        }
    }

    public class_745 getFakePlayer() {
        return this.fakePlayer;
    }

    public boolean isImmortal() {
        return this.immortal;
    }

    public void setImmortal(boolean immortal) {
        this.immortal = immortal;
        if (this.fakePlayer != null) {
            if (immortal) {
                this.fakePlayer.method_6122(class_1268.field_5810, FakePlayerCommand.mc.field_1724.method_6079().method_7972());
            } else {
                this.fakePlayer.method_6122(class_1268.field_5810, class_1799.field_8037);
            }
        }
    }
}

