/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1267
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1267;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public class ReHubCommand
implements IMinecraft {
    private boolean processing;
    private final Timer timer = new Timer();
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (!this.processing || ReHubCommand.mc.field_1687 == null || ReHubCommand.mc.field_1724 == null) {
            return;
        }
        if ((ServerUtility.isFT() || ServerUtility.isFT()) && ReHubCommand.mc.field_1687.method_8407() == class_1267.field_5805 && this.timer.finished(1000L)) {
            ReHubCommand.mc.field_1724.field_3944.method_45730("an" + ServerUtility.ftAn);
            this.timer.reset();
            this.processing = false;
        }
    };

    public ReHubCommand() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public Command command() {
        return CommandBuilder.begin("rct").aliases("reconnect").desc("commands.rehub.description").handler(this::handle).build();
    }

    private void handle(CommandContext ctx) {
        if (ReHubCommand.mc.field_1724 == null || ReHubCommand.mc.field_1687 == null) {
            return;
        }
        if (ServerUtility.hasCT) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands_rehub.ct")));
            return;
        }
        this.timer.reset();
        ReHubCommand.mc.field_1724.field_3944.method_45730("hub");
        this.processing = true;
    }
}

