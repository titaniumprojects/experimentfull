/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_2338
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_2886
 *  net.minecraft.class_2902$class_2903
 */
package micronix.experiment.systems.commands.commands;

import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2886;
import net.minecraft.class_2902;

@Environment(value=EnvType.CLIENT)
public class AutoPilotCommand
implements IMinecraft {
    private final Timer timer = new Timer();
    private class_243 target;
    private boolean active;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (!this.active || AutoPilotCommand.mc.field_1724 == null || AutoPilotCommand.mc.field_1687 == null) {
            return;
        }
        class_243 currentTarget = this.target;
        if (currentTarget == null) {
            return;
        }
        if (AutoPilotCommand.mc.field_1724.method_6128()) {
            class_243 vec = currentTarget.method_1020(AutoPilotCommand.mc.field_1724.method_33571()).method_1029();
            float rawYaw = (float)Math.toDegrees(Math.atan2(-vec.field_1352, vec.field_1350));
            int highestY = (int)AutoPilotCommand.mc.field_1724.method_23318();
            int highestX = (int)currentTarget.field_1352;
            int highestZ = (int)currentTarget.field_1350;
            int iterations = 80;
            for (int x = -iterations; x < iterations; ++x) {
                for (int z = -iterations; z < iterations; ++z) {
                    int height = AutoPilotCommand.mc.field_1687.method_8624(class_2902.class_2903.field_13202, (int)(AutoPilotCommand.mc.field_1724.method_23317() + (double)x), (int)(AutoPilotCommand.mc.field_1724.method_23321() + (double)z)) + 5;
                    if (height <= highestY || !((double)height > AutoPilotCommand.mc.field_1724.method_23318())) continue;
                    highestY = height;
                    highestX = (int)(AutoPilotCommand.mc.field_1724.method_23317() + (double)x);
                    highestZ = (int)(AutoPilotCommand.mc.field_1724.method_23321() + (double)z);
                }
            }
            AutoPilotCommand.mc.field_1690.field_1867.method_23481(true);
            AutoPilotCommand.mc.field_1690.field_1894.method_23481(true);
            if (EntityUtility.getVelocity() < 1.46 && this.timer.finished(1700L)) {
                AutoPilotCommand.mc.field_1761.method_41931(AutoPilotCommand.mc.field_1687, sequence -> new class_2886(class_1268.field_5810, sequence, Experiment.getInstance().getRotationHandler().getServerRotation().getYaw(), Experiment.getInstance().getRotationHandler().getServerRotation().getPitch()));
                this.timer.reset();
            }
            class_243 vecHeight = new class_243((double)highestX, (double)(highestY + 23), (double)highestZ).method_1020(AutoPilotCommand.mc.field_1724.method_33571()).method_1029();
            float rawPitch = (float)Math.clamp(Math.toDegrees(Math.asin(-vecHeight.field_1351)), -89.0, 89.0);
            int i = AutoPilotCommand.mc.field_1687.method_8624(class_2902.class_2903.field_13202, (int)AutoPilotCommand.mc.field_1724.method_23317(), (int)AutoPilotCommand.mc.field_1724.method_23321()) - 10;
            while ((double)i < AutoPilotCommand.mc.field_1724.method_23318()) {
                if (!AutoPilotCommand.mc.field_1687.method_8320(new class_2338((int)AutoPilotCommand.mc.field_1724.method_23317(), i, (int)AutoPilotCommand.mc.field_1724.method_23321())).method_26227().method_15769() && AutoPilotCommand.mc.field_1724.method_23318() - (double)i < 5.0) {
                    rawPitch -= 11.0f;
                    break;
                }
                ++i;
            }
            if (AutoPilotCommand.mc.field_1724.method_19538().method_1025(currentTarget) < 20.0) {
                MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.autopilot.stopped")));
                this.stopAutoPilot();
            }
            RotationHandler rotationHandler = Experiment.INSTANCE.getRotationHandler();
            Rotation targetRotation = new Rotation(rawYaw, rawPitch + 13.0f);
            rotationHandler.rotate(targetRotation);
        }
    };

    private void initialize() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public AutoPilotCommand() {
        this.initialize();
    }

    public Command command() {
        return CommandBuilder.begin("autopilot").aliases("ap", "pilot", "\u0430\u0432\u0442\u043e\u043f\u0438\u043b\u043e\u0442", "\u043f\u0438\u043b\u043e\u0442").desc("commands.autopilot.description").param("x", p -> p.optional().validator(AutoPilotCommand::verifyCoordinate)).param("y", p -> p.optional().validator(AutoPilotCommand::verifyCoordinate)).param("z", p -> p.optional().validator(AutoPilotCommand::verifyCoordinate)).handler(this::handle).build();
    }

    private static ValidationResult verifyCoordinate(String input) {
        try {
            Double.parseDouble(input);
            return ValidationResult.ok(input);
        }
        catch (NumberFormatException e) {
            return ValidationResult.error(Localizator.translate("commands.autopilot.invalid"));
        }
    }

    private void handle(CommandContext ctx) {
        String x = (String)ctx.arguments().get(0);
        String y = (String)ctx.arguments().get(1);
        String z = (String)ctx.arguments().get(2);
        if (x == null || y == null || z == null) {
            if (this.active) {
                this.stopAutoPilot();
                MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.autopilot.stopping")));
            } else {
                MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.autopilot.not_active")));
            }
            return;
        }
        try {
            this.target = new class_243(Double.parseDouble(x), Double.parseDouble(y), Double.parseDouble(z));
            this.active = true;
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.autopilot.start", this.target.method_10216(), this.target.method_10214(), this.target.method_10215())));
        }
        catch (NumberFormatException e) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.autopilot.invalid")));
        }
    }

    private void stopAutoPilot() {
        this.active = false;
        this.target = null;
        Experiment.getInstance().getEventManager().unsubscribe(this);
        AutoPilotCommand.mc.field_1690.field_1867.method_23481(false);
        AutoPilotCommand.mc.field_1690.field_1894.method_23481(false);
    }
}

