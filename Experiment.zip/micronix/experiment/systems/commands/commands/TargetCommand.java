/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.commands.commands;

import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.target.TargetManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class TargetCommand {
    @Compile
    public Command command() {
        return CommandBuilder.begin("target", b -> b.aliases("targets").desc("\u0423\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u0441\u043f\u0438\u0441\u043a\u043e\u043c \u0442\u0430\u0440\u0433\u0435\u0442\u043e\u0432").param("action", p -> p.literal("add", "remove", "del", "delete", "clear", "list")).param("id", p -> p.optional().validator(ValidationResult::ok)).handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        String action = (String)ctx.arguments().get(0);
        String id = (String)ctx.arguments().get(1);
        TargetManager tm = Experiment.getInstance().getTargetManager();
        switch (action.toLowerCase()) {
            case "add": {
                tm.addTarget(id);
                break;
            }
            case "remove": 
            case "del": 
            case "delete": {
                tm.removeTarget(id);
                break;
            }
            case "clear": {
                tm.clearTarget();
                break;
            }
            case "list": {
                tm.listTarget();
            }
        }
    }
}

