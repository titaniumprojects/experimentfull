/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 */
package micronix.experiment.systems.commands.commands;

import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_310;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class VclipCommand
implements IMinecraft {
    private class_243 target;

    @Compile
    public Command command() {
        return CommandBuilder.begin("vclip", b -> b.aliases("v", "verticalclip").desc("commands.vclip.description").param("distance", p -> p.validator(text -> {
            try {
                return ValidationResult.ok(Double.parseDouble(text));
            }
            catch (NumberFormatException e) {
                return ValidationResult.error(Localizator.translate("commands.vclip.invalid"));
            }
        })).handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        double distance = (Double)ctx.arguments().getFirst();
        class_310 mc = class_310.method_1551();
        class_243 pos = mc.field_1724.method_19538();
        mc.field_1724.method_33574(pos.method_1031(0.0, distance, 0.0));
    }
}

