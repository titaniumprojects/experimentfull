/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.friends.FriendManager;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class FriendCommand {
    @Compile
    public Command command() {
        return CommandBuilder.begin("friend", b -> b.aliases("friends").desc("commands.friends.description").param("action", p -> p.literal("add", "remove", "del", "delete", "clear", "list")).param("id", p -> p.optional().validator(ValidationResult::ok)).handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        String action = (String)ctx.arguments().get(0);
        String id = (String)ctx.arguments().get(1);
        FriendManager fm = Experiment.getInstance().getFriendManager();
        switch (action.toLowerCase()) {
            case "add": {
                fm.add(id);
                break;
            }
            case "remove": 
            case "del": 
            case "delete": {
                fm.remove(id);
                break;
            }
            case "clear": {
                fm.clear();
                break;
            }
            case "list": {
                this.printList();
            }
        }
    }

    @Compile
    private void printList() {
        List<String> friends = Experiment.getInstance().getFriendManager().listFriends();
        if (friends.isEmpty()) {
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.friends.empty")));
            return;
        }
        MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.friends.list")));
        for (int i = 0; i < friends.size(); ++i) {
            MessageUtility.info(class_2561.method_30163((String)("[" + (i + 1) + "] " + friends.get(i))));
        }
    }
}

