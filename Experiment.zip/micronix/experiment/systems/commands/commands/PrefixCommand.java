/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.commands.CommandRegistry;
import micronix.experiment.systems.commands.ValidationResult;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class PrefixCommand {
    @Compile
    public Command command() {
        return CommandBuilder.begin("prefix", b -> b.desc("commands.prefix.description").param("action", p -> p.optional().literal("list", "clear", "default", "set", "create")).param("new", p -> p.optional().validator(text -> text.length() > 1 ? ValidationResult.error(Localizator.translate("commands.prefix.invalid_length")) : ValidationResult.ok(text))).handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        String action = (String)ctx.arguments().get(0);
        String newPrefix = (String)ctx.arguments().get(1);
        CommandRegistry registry = Experiment.getInstance().getCommandManager();
        String current = registry.getPrefix();
        if (action == null) {
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.prefix.current", current)));
            return;
        }
        switch (action.toLowerCase()) {
            case "list": {
                MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.prefix.current", current)));
                break;
            }
            case "clear": 
            case "default": 
            case "reset": {
                registry.setPrefix(".");
                MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.prefix.reset")));
                break;
            }
            case "set": 
            case "create": {
                if (newPrefix == null || newPrefix.isEmpty()) {
                    MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.prefix.empty")));
                    return;
                }
                registry.setPrefix(newPrefix);
                MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.prefix.set", newPrefix)));
            }
        }
    }
}

