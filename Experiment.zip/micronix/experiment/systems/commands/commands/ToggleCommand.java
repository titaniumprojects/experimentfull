/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.ParameterBuilder;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class ToggleCommand {
    @Compile
    public Command command() {
        List<String> moduleNames = Experiment.getInstance().getModuleManager().getModules().stream().map(module -> module.getName().replace(" ", "")).toList();
        return CommandBuilder.begin("toggle").aliases("t").desc("commands.toggle.description").param("module", p -> p.validator(ParameterBuilder.MODULE).suggests(moduleNames)).handler(context -> {
            Module module = (Module)context.arguments().getFirst();
            module.toggle();
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.toggle." + (module.isEnabled() ? "enabled" : "disabled"), module.getName())));
        }).build();
    }
}

