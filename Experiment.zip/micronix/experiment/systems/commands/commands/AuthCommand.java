/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.commands.commands;

import java.util.Map;
import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.Command;
import micronix.experiment.systems.commands.CommandBuilder;
import micronix.experiment.systems.commands.CommandContext;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.modules.other.AutoAuth;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class AuthCommand {
    @Compile
    public Command command() {
        return CommandBuilder.begin("auth", b -> b.aliases("autoAuth", "\u043f\u0430\u0440\u043e\u043b\u0438", "passwords").desc("commands.auth.description").handler(this::handle)).build();
    }

    @Compile
    private void handle(CommandContext ctx) {
        Map<String, String> map = Experiment.getInstance().getModuleManager().getModule(AutoAuth.class).listPassword();
        int counter = 1;
        if (map.isEmpty()) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.auth.empty")));
            return;
        }
        MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.auth.passwords")));
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String nickname = entry.getKey();
            String password = entry.getValue();
            MessageUtility.info(class_2561.method_30163((String)(counter++ + ") \u041d\u0438\u043a: " + nickname + " | \u041f\u0430\u0440\u043e\u043b\u044c: " + password)));
        }
    }
}

