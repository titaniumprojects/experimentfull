/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_320
 *  net.minecraft.class_320$class_321
 */
package micronix.experiment.systems.file.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;
import micronix.experiment.Experiment;
import micronix.experiment.systems.config.ConfigFile;
import micronix.experiment.systems.file.ClientFile;
import micronix.experiment.systems.file.FileManager;
import micronix.experiment.systems.file.api.FileInfo;
import micronix.experiment.systems.modules.constructions.swinganim.SwingManager;
import micronix.experiment.systems.modules.constructions.swinganim.SwingPhase;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPreset;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPresetFile;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPresetManager;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.components.ColorPicker;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_320;

@FileInfo(name="client")
@Environment(value=EnvType.CLIENT)
public class ClientDataFile
extends ClientFile
implements IMinecraft {
    private String lastConfigName = null;

    public String getLastConfigName() {
        return this.lastConfigName;
    }

    @Override
    public void write() {
        JsonObject json = new JsonObject();
        json.addProperty("username", mc.method_1548().method_1676());
        json.addProperty("theme", Experiment.getInstance().getThemeManager().getCurrentTheme().name());
        json.addProperty("swing", Experiment.getInstance().getSwingManager().getCurrent());
        json.add("hudElements", (JsonElement)this.getHudElementsJsonArray());
        json.add("friends", (JsonElement)this.getFriendsJsonArray());
        json.add("colorPickerPresets", (JsonElement)this.getColorPickerPresetsJsonArray());
        ConfigFile currentConfig = Experiment.getInstance().getConfigManager().getCurrent();
        if (currentConfig != null) {
            json.addProperty("lastConfig", currentConfig.getFileName());
        }
        try (FileWriter writer = new FileWriter(this.file);){
            writer.write(FileManager.GSON.toJson((JsonElement)json));
        }
        catch (Exception var81) {
            var81.printStackTrace();
        }
    }

    @Override
    public void read() {
        try (FileReader reader = new FileReader(this.getFile());){
            JsonObject object = (JsonObject)FileManager.GSON.fromJson((Reader)reader, JsonObject.class);
            if (object.has("username")) {
                String username = object.get("username").getAsString();
                new class_320(username, UUID.randomUUID(), "", Optional.empty(), Optional.empty(), class_320.class_321.field_1988);
            }
            if (object.has("swing")) {
                SwingPresetFile customPreset;
                String swing = object.get("swing").getAsString();
                SwingManager swingManager = Experiment.getInstance().getSwingManager();
                SwingPresetManager manager = Experiment.getInstance().getSwingPresetManager();
                boolean foundBuiltIn = false;
                for (SwingPreset value : Experiment.getInstance().getSwingManager().getPresets()) {
                    if (!value.getName().equals(swing)) continue;
                    swingManager.getBezier().start(value.getBezierStart()).end(value.getBezierEnd());
                    swingManager.getBack().enabled(value.isSwingBack());
                    swingManager.getSpeed().setCurrentValue(value.getSpeed());
                    SwingPhase start = swingManager.getStartPhase();
                    start.getAnchorX().setCurrentValue(value.getFrom().getAnchorX());
                    start.getAnchorY().setCurrentValue(value.getFrom().getAnchorY());
                    start.getAnchorZ().setCurrentValue(value.getFrom().getAnchorZ());
                    start.getMoveX().setCurrentValue(value.getFrom().getMoveX());
                    start.getMoveY().setCurrentValue(value.getFrom().getMoveY());
                    start.getMoveZ().setCurrentValue(value.getFrom().getMoveZ());
                    start.getRotateX().setCurrentValue(value.getFrom().getRotateX());
                    start.getRotateY().setCurrentValue(value.getFrom().getRotateY());
                    start.getRotateZ().setCurrentValue(value.getFrom().getRotateZ());
                    SwingPhase end = swingManager.getEndPhase();
                    end.getAnchorX().setCurrentValue(value.getTo().getAnchorX());
                    end.getAnchorY().setCurrentValue(value.getTo().getAnchorY());
                    end.getAnchorZ().setCurrentValue(value.getTo().getAnchorZ());
                    end.getMoveX().setCurrentValue(value.getTo().getMoveX());
                    end.getMoveY().setCurrentValue(value.getTo().getMoveY());
                    end.getMoveZ().setCurrentValue(value.getTo().getMoveZ());
                    end.getRotateX().setCurrentValue(value.getTo().getRotateX());
                    end.getRotateY().setCurrentValue(value.getTo().getRotateY());
                    end.getRotateZ().setCurrentValue(value.getTo().getRotateZ());
                    swingManager.setCurrent(swing);
                    foundBuiltIn = true;
                    break;
                }
                if (!foundBuiltIn && (customPreset = manager.getPreset(swing)) != null) {
                    manager.setCurrent(customPreset);
                    swingManager.setCurrent(swing);
                    customPreset.load();
                }
            }
            if (object.has("theme")) {
                String themeName = object.get("theme").getAsString();
                try {
                    Theme theme = Theme.valueOf(themeName);
                    Experiment.getInstance().getThemeManager().setCurrentTheme(theme);
                }
                catch (IllegalArgumentException var15) {
                    Experiment.getInstance().getThemeManager().setCurrentTheme(Theme.DARK);
                }
            }
            if (object.has("friends")) {
                JsonArray friendsArray = object.getAsJsonArray("friends");
                Experiment.getInstance().getFriendManager().clear();
                for (JsonElement friendElement : friendsArray) {
                    Experiment.getInstance().getFriendManager().add(friendElement.getAsString());
                }
            }
            if (object.has("colorPickerPresets")) {
                this.loadColorPickerPresets(object.getAsJsonArray("colorPickerPresets"));
            }
            if (object.has("hudElements")) {
                for (JsonElement elemObj : object.getAsJsonArray("hudElements")) {
                    JsonObject elementObject = elemObj.getAsJsonObject();
                    String name = elementObject.get("name").getAsString();
                    float x = elementObject.get("x").getAsFloat();
                    float y = elementObject.get("y").getAsFloat();
                    boolean showing = elementObject.get("showing").getAsBoolean();
                    Object element = Experiment.getInstance().getHud().getElementByName(name);
                    if (element == null) continue;
                    ((HudElement)element).setX(x);
                    ((HudElement)element).setY(y);
                    ((HudElement)element).setShowing(showing);
                    if (!elementObject.has("settings")) continue;
                    JsonObject settingsObject = elementObject.getAsJsonObject("settings");
                    for (Setting setting : ((HudElement)element).getSettings()) {
                        if (!settingsObject.has(setting.getName())) continue;
                        setting.load(settingsObject.get(setting.getName()));
                    }
                }
            }
            if (object.has("lastConfig")) {
                this.lastConfigName = object.get("lastConfig").getAsString();
                Experiment.LOGGER.info("Found lastConfig in client.exper: {}", (Object)this.lastConfigName);
            }
        }
        catch (Exception var17) {
            var17.printStackTrace();
        }
    }

    private JsonArray getHudElementsJsonArray() {
        JsonArray hudElementsArray = new JsonArray();
        for (HudElement element : Experiment.getInstance().getHud().getElements()) {
            JsonObject elementObject = new JsonObject();
            elementObject.addProperty("name", element.getName());
            elementObject.addProperty("x", (Number)Float.valueOf(element.getX()));
            elementObject.addProperty("y", (Number)Float.valueOf(element.getY()));
            elementObject.addProperty("showing", Boolean.valueOf(element.isShowing()));
            elementObject.add("settings", (JsonElement)this.getSettingsJsonObject(element));
            hudElementsArray.add((JsonElement)elementObject);
        }
        return hudElementsArray;
    }

    private JsonObject getSettingsJsonObject(HudElement element) {
        JsonObject settingsObject = new JsonObject();
        for (Setting setting : element.getSettings()) {
            settingsObject.add(setting.getName(), setting.save());
        }
        return settingsObject;
    }

    private JsonArray getFriendsJsonArray() {
        JsonArray friendsJsonArray = new JsonArray();
        for (String friendsName : Experiment.getInstance().getFriendManager().listFriends()) {
            friendsJsonArray.add(friendsName);
        }
        return friendsJsonArray;
    }

    private JsonArray getColorPickerPresetsJsonArray() {
        JsonArray presetsArray = new JsonArray();
        for (ColorPicker.Preset preset : ColorPicker.COLOR_PRESETS) {
            if (!preset.isShowing()) continue;
            JsonObject presetObject = new JsonObject();
            ColorRGBA color = preset.getColor();
            presetObject.addProperty("red", (Number)Float.valueOf(color.getRed()));
            presetObject.addProperty("green", (Number)Float.valueOf(color.getGreen()));
            presetObject.addProperty("blue", (Number)Float.valueOf(color.getBlue()));
            presetObject.addProperty("alpha", (Number)Float.valueOf(color.getAlpha()));
            presetsArray.add((JsonElement)presetObject);
        }
        return presetsArray;
    }

    private void loadColorPickerPresets(JsonArray presetsArray) {
        ArrayList<ColorPicker.Preset> loadedPresets = new ArrayList<ColorPicker.Preset>();
        for (JsonElement presetElement : presetsArray) {
            JsonObject presetObject = presetElement.getAsJsonObject();
            float red = presetObject.get("red").getAsFloat();
            float green = presetObject.get("green").getAsFloat();
            float blue = presetObject.get("blue").getAsFloat();
            float alpha = presetObject.get("alpha").getAsFloat();
            ColorRGBA color = new ColorRGBA(red, green, blue, alpha);
            loadedPresets.add(new ColorPicker.Preset(color));
        }
        ColorPicker.setColorPresets(loadedPresets);
    }
}

