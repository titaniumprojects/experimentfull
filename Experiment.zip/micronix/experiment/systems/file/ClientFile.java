/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.file;

import java.io.File;
import micronix.experiment.systems.file.FileManager;
import micronix.experiment.systems.file.api.FileInfo;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public abstract class ClientFile {
    public final FileInfo infoAnnotation = this.getClass().getAnnotation(FileInfo.class);
    public final File file = new File(FileManager.DIRECTORY, this.infoAnnotation.name() + "." + this.infoAnnotation.fileType());

    public abstract void write();

    public abstract void read();

    public FileInfo getInfoAnnotation() {
        return this.infoAnnotation;
    }

    public File getFile() {
        return this.file;
    }
}

