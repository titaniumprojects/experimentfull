/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.friends;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class FriendManager
implements IMinecraft {
    private final List<String> friends = new ArrayList<String>();

    public void add(String name) {
        if (Experiment.getInstance().getTargetManager().getTarget().contains(name)) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.friends.target")));
            return;
        }
        if (this.friends.contains(name)) {
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.friends.exists", name)));
            return;
        }
        if (name.equalsIgnoreCase(mc.method_1548().method_1676())) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.friends.self")));
            return;
        }
        this.friends.add(name);
        MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.friends.added", name)));
        if (EntityUtility.isInGame()) {
            Experiment.getInstance().getFileManager().writeFile("client");
        }
    }

    public void remove(String name) {
        if (this.friends.contains(name)) {
            this.friends.remove(name);
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.friends.removed", name)));
        } else {
            MessageUtility.info(class_2561.method_30163((String)Localizator.translate("commands.friends.not_exists", name)));
        }
        Experiment.getInstance().getFileManager().writeFile("client");
    }

    @Compile
    public void clear() {
        if (this.friends.isEmpty()) {
            MessageUtility.error(class_2561.method_30163((String)Localizator.translate("commands.friends.empty")));
        } else {
            this.friends.clear();
            MessageUtility.info(class_2561.method_30163((String)"\u0421\u043f\u0438\u0441\u043e\u043a \u0434\u0440\u0443\u0437\u0435\u0439 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043e\u0447\u0438\u0449\u0435\u043d!"));
            Experiment.getInstance().getFileManager().writeFile("client");
        }
    }

    public List<String> listFriends() {
        return Collections.unmodifiableList(this.friends);
    }

    public boolean isFriend(String name) {
        return this.friends.contains(name);
    }
}

