/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.notifications;

import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum NotificationType {
    SUCCESS("success", ColorRGBA.GREEN),
    ERROR("error", ColorRGBA.RED),
    INFO("info", new ColorRGBA(234.0f, 179.0f, 8.0f));

    private final String name;
    private final ColorRGBA color;

    public static NotificationType get(String name) {
        for (NotificationType type : NotificationType.values()) {
            if (!type.getName().equalsIgnoreCase(name)) continue;
            return type;
        }
        return INFO;
    }

    public String getName() {
        return this.name;
    }

    public ColorRGBA getColor() {
        return this.color;
    }

    private NotificationType(String name, ColorRGBA color) {
        this.name = name;
        this.color = color;
    }
}

