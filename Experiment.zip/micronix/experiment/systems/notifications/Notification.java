/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.notifications;

import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class Notification {
    private final NotificationType type;
    private final String text;
    private final Timer timer = new Timer();
    private final long duration;
    private final Animation animation = new Animation(300L, Easing.EXPO_OUT);
    private final Animation showing = new Animation(300L, Easing.BAKEK_SIZE);

    public Notification(NotificationType type, String text) {
        this.type = type;
        this.text = text;
        this.duration = 1000L;
    }

    public void update() {
        this.animation.update(this.timer.finished(this.duration) ? 0.0f : 1.0f);
    }

    public boolean isFinished() {
        return this.animation.getValue() == 0.0f && this.timer.finished(this.duration);
    }

    public NotificationType getType() {
        return this.type;
    }

    public String getText() {
        return this.text;
    }

    public Timer getTimer() {
        return this.timer;
    }

    public long getDuration() {
        return this.duration;
    }

    public Animation getAnimation() {
        return this.animation;
    }

    public Animation getShowing() {
        return this.showing;
    }
}

