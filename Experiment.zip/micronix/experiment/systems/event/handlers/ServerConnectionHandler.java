/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.event.handlers;

import com.viaversion.viafabricplus.ViaFabricPlus;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ServerConnectionEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public class ServerConnectionHandler
implements IMinecraft {
    private boolean messageSent = false;
    private boolean connected;
    private final EventListener<ServerConnectionEvent> onServerConnection = event -> {
        this.connected = true;
        this.messageSent = false;
    };
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTick = event -> {
        if (this.connected && !this.messageSent && ServerConnectionHandler.mc.field_1724 != null && ServerConnectionHandler.mc.field_1724.field_6012 > 100 && mc.method_1558() != null && FabricLoader.getInstance().isModLoaded("viafabricplus")) {
            String warning = Localizator.translate("chat.connection_warning", ServerConnectionHandler.mc.method_1558().field_3761, ViaFabricPlus.getImpl().getTargetVersion());
            MessageUtility.info(class_2561.method_30163((String)warning));
            this.messageSent = true;
        }
    };

    public ServerConnectionHandler() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }
}

