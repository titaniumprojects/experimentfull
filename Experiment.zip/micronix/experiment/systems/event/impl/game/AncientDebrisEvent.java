/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2338
 *  net.minecraft.class_243
 */
package micronix.experiment.systems.event.impl.game;

import java.util.Collections;
import java.util.List;
import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_243;

@Environment(value=EnvType.CLIENT)
public class AncientDebrisEvent
extends Event {
    private final List<class_2338> positions;
    private final class_243 explosionCenter;

    public AncientDebrisEvent(List<class_2338> positions, class_243 center) {
        this.positions = Collections.unmodifiableList(positions);
        this.explosionCenter = center;
    }

    public List<class_2338> getPositions() {
        return this.positions;
    }

    public class_243 getExplosionCenter() {
        return this.explosionCenter;
    }
}

