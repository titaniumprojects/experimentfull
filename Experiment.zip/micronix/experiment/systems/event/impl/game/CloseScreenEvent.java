/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_437
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_437;

@Environment(value=EnvType.CLIENT)
public class CloseScreenEvent
extends Event {
    private final class_437 screen;

    public class_437 getScreen() {
        return this.screen;
    }

    public CloseScreenEvent(class_437 screen) {
        this.screen = screen;
    }
}

