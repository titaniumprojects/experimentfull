/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.EventCancellable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(value=EnvType.CLIENT)
public class InternalAttackEvent
extends EventCancellable {
    private final class_1297 entity;

    public class_1297 getEntity() {
        return this.entity;
    }

    public InternalAttackEvent(class_1297 entity) {
        this.entity = entity;
    }
}

