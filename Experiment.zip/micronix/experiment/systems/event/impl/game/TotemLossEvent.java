/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class TotemLossEvent
extends Event {
    private final class_1657 player;
    private final class_1799 totemStack;
    private final boolean wasEnchanted;

    public TotemLossEvent(class_1657 player, class_1799 totemStack, boolean wasEnchanted) {
        this.player = player;
        this.totemStack = totemStack;
        this.wasEnchanted = wasEnchanted;
    }

    public class_1657 getPlayer() {
        return this.player;
    }

    public class_1799 getTotemStack() {
        return this.totemStack;
    }

    public boolean wasEnchanted() {
        return this.wasEnchanted;
    }
}

