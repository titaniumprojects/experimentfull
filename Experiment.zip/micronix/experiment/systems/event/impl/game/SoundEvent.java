/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1113
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1113;

@Environment(value=EnvType.CLIENT)
public class SoundEvent
extends Event {
    public class_1113 sound;

    public SoundEvent(class_1113 sound) {
        this.sound = sound;
    }

    public class_1113 getSound() {
        return this.sound;
    }
}

