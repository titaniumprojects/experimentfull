/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1309
 *  net.minecraft.class_1671
 *  net.minecraft.class_243
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;

@Environment(value=EnvType.CLIENT)
public class FireworkEvent
extends Event {
    private final class_1309 entity;
    private class_243 velocity;
    private final class_1671 rocketEntity;

    public class_1309 getEntity() {
        return this.entity;
    }

    public class_243 getVelocity() {
        return this.velocity;
    }

    public class_1671 getRocketEntity() {
        return this.rocketEntity;
    }

    public void setVelocity(class_243 velocity) {
        this.velocity = velocity;
    }

    public FireworkEvent(class_1309 entity, class_243 velocity, class_1671 rocketEntity) {
        this.entity = entity;
        this.velocity = velocity;
        this.rocketEntity = rocketEntity;
    }
}

