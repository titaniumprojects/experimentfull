/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2338
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.EventCancellable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;

@Environment(value=EnvType.CLIENT)
public class CollisionShapeEvent
extends EventCancellable {
    private final class_2680 state;
    private final class_2338 pos;
    private class_265 shape;

    public CollisionShapeEvent(class_2680 state, class_2338 pos, class_265 shape) {
        this.state = state;
        this.pos = pos;
        this.shape = shape;
    }

    public class_2680 getState() {
        return this.state;
    }

    public class_2338 getPos() {
        return this.pos;
    }

    public class_265 getShape() {
        return this.shape;
    }

    public void setShape(class_265 shape) {
        this.shape = shape;
    }
}

