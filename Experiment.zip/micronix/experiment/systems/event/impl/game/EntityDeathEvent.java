/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1282
 *  net.minecraft.class_1309
 *  org.jetbrains.annotations.Nullable
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class EntityDeathEvent
extends Event {
    private final class_1309 entity;
    private final class_1282 source;

    public EntityDeathEvent(class_1309 entity, class_1282 source) {
        this.entity = entity;
        this.source = source;
    }

    @Nullable
    public class_1309 getKillerEntity() {
        return this.entity.method_6124();
    }

    public class_1309 getEntity() {
        return this.entity;
    }

    public class_1282 getSource() {
        return this.source;
    }
}

