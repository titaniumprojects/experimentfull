/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class PickupEvent
extends Event {
    public class_1799 itemStack;
    public int count;

    public PickupEvent(class_1799 itemStack, int count) {
        this.itemStack = itemStack;
        this.count = count;
    }

    public class_1799 getItemStack() {
        return this.itemStack;
    }

    public int getCount() {
        return this.count;
    }
}

