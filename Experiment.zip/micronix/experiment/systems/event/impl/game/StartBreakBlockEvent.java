/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2338
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.EventCancellable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;

@Environment(value=EnvType.CLIENT)
public class StartBreakBlockEvent
extends EventCancellable {
    private final class_2338 blockPos;

    public StartBreakBlockEvent(class_2338 blockPos) {
        this.blockPos = blockPos;
    }

    public class_2338 getBlockPos() {
        return this.blockPos;
    }
}

