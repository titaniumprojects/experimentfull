/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1309
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.EventCancellable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;

@Environment(value=EnvType.CLIENT)
public class EntityJumpEvent
extends EventCancellable {
    private final class_1309 entity;

    public class_1309 getEntity() {
        return this.entity;
    }

    public EntityJumpEvent(class_1309 entity) {
        this.entity = entity;
    }
}

