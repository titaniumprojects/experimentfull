/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 */
package micronix.experiment.systems.event.impl.game;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class FinishEatEvent
extends Event {
    private final class_1657 user;
    private final class_1799 stack;

    public class_1657 getUser() {
        return this.user;
    }

    public class_1799 getStack() {
        return this.stack;
    }

    public FinishEatEvent(class_1657 user, class_1799 stack) {
        this.user = user;
        this.stack = stack;
    }
}

