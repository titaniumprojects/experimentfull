/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_639
 *  net.minecraft.class_642
 *  net.minecraft.class_9112
 */
package micronix.experiment.systems.event.impl.network;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;

@Environment(value=EnvType.CLIENT)
public class ServerConnectionEvent
extends Event {
    private final class_639 address;
    private final class_642 info;
    private final class_9112 cookieStorage;

    public class_639 getAddress() {
        return this.address;
    }

    public class_642 getInfo() {
        return this.info;
    }

    public class_9112 getCookieStorage() {
        return this.cookieStorage;
    }

    public ServerConnectionEvent(class_639 address, class_642 info, class_9112 cookieStorage) {
        this.address = address;
        this.info = info;
        this.cookieStorage = cookieStorage;
    }
}

