/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2596
 */
package micronix.experiment.systems.event.impl.network;

import micronix.experiment.systems.event.EventCancellable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;

@Environment(value=EnvType.CLIENT)
public class ReceivePacketEvent
extends EventCancellable {
    private final class_2596<?> packet;

    public class_2596<?> getPacket() {
        return this.packet;
    }

    public ReceivePacketEvent(class_2596<?> packet) {
        this.packet = packet;
    }
}

