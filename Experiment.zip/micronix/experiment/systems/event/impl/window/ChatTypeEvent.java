/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.event.impl.window;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ChatTypeEvent
extends Event {
    private final char text;
    private final int modifiers;

    public char getText() {
        return this.text;
    }

    public int getModifiers() {
        return this.modifiers;
    }

    public ChatTypeEvent(char text, int modifiers) {
        this.text = text;
        this.modifiers = modifiers;
    }
}

