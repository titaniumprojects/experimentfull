/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.event.impl.window;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class KeyPressEvent
extends Event {
    private final int action;
    private final int key;

    public int getAction() {
        return this.action;
    }

    public int getKey() {
        return this.key;
    }

    public KeyPressEvent(int action, int key) {
        this.action = action;
        this.key = key;
    }
}

