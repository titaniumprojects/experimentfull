/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.event.impl.window;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class MouseScrollEvent
extends Event {
    private final double verticalAmount;

    public double getVerticalAmount() {
        return this.verticalAmount;
    }

    public MouseScrollEvent(double verticalAmount) {
        this.verticalAmount = verticalAmount;
    }
}

