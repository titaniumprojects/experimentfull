/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.event.impl.window;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ContainerClickEvent
extends Event {
    private final float x;
    private final float y;
    private final int button;

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public int getButton() {
        return this.button;
    }

    public ContainerClickEvent(float x, float y, int button) {
        this.x = x;
        this.y = y;
        this.button = button;
    }
}

