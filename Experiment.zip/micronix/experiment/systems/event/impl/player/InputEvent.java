/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_3532
 */
package micronix.experiment.systems.event.impl.player;

import micronix.experiment.systems.event.Event;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;

@Environment(value=EnvType.CLIENT)
public class InputEvent
extends Event
implements IMinecraft {
    private float forward;
    private float strafe;
    private boolean jump;
    private boolean sneak;
    private boolean sprint;
    private double sneakSlowDownMultiplier;

    public InputEvent(float moveForward, float moveStrafe, boolean jump, boolean sneak, boolean sprint) {
        this.forward = moveForward;
        this.strafe = moveStrafe;
        this.jump = jump;
        this.sneak = sneak;
        this.sprint = sprint;
        this.sneakSlowDownMultiplier = 0.3;
    }

    public void setYaw(float yaw, float direction) {
        float forward = this.getForward();
        float strafe = this.getStrafe();
        double angle = class_3532.method_15338((double)Math.toDegrees(EntityUtility.direction(direction, forward, strafe)));
        if (forward == 0.0f && strafe == 0.0f) {
            return;
        }
        float closestForward = 0.0f;
        float closestStrafe = 0.0f;
        float closestDifference = Float.MAX_VALUE;
        for (float predictedForward = -1.0f; predictedForward <= 1.0f; predictedForward += 1.0f) {
            for (float predictedStrafe = -1.0f; predictedStrafe <= 1.0f; predictedStrafe += 1.0f) {
                double predictedAngle;
                double difference;
                if (predictedStrafe == 0.0f && predictedForward == 0.0f || !((difference = Math.abs(angle - (predictedAngle = class_3532.method_15338((double)Math.toDegrees(EntityUtility.direction(yaw, predictedForward, predictedStrafe)))))) < (double)closestDifference)) continue;
                closestDifference = (float)difference;
                closestForward = predictedForward;
                closestStrafe = predictedStrafe;
            }
        }
        this.setForward(closestForward);
        this.setStrafe(closestStrafe);
    }

    public void setYaw(float yaw) {
        if (InputEvent.mc.field_1724 == null) {
            return;
        }
        this.setYaw(yaw, InputEvent.mc.field_1724.method_36454());
    }

    public float getForward() {
        return this.forward;
    }

    public float getStrafe() {
        return this.strafe;
    }

    public boolean isJump() {
        return this.jump;
    }

    public boolean isSneak() {
        return this.sneak;
    }

    public boolean isSprint() {
        return this.sprint;
    }

    public double getSneakSlowDownMultiplier() {
        return this.sneakSlowDownMultiplier;
    }

    public void setForward(float forward) {
        this.forward = forward;
    }

    public void setStrafe(float strafe) {
        this.strafe = strafe;
    }

    public void setJump(boolean jump) {
        this.jump = jump;
    }

    public void setSneak(boolean sneak) {
        this.sneak = sneak;
    }

    public void setSprint(boolean sprint) {
        this.sprint = sprint;
    }

    public void setSneakSlowDownMultiplier(double sneakSlowDownMultiplier) {
        this.sneakSlowDownMultiplier = sneakSlowDownMultiplier;
    }
}

