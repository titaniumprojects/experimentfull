/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.event.impl.render;

import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ChatRenderEvent
extends Event {
    private final CustomDrawContext context;
    private final float tickDelta;

    public CustomDrawContext getContext() {
        return this.context;
    }

    public float getTickDelta() {
        return this.tickDelta;
    }

    public ChatRenderEvent(CustomDrawContext context, float tickDelta) {
        this.context = context;
        this.tickDelta = tickDelta;
    }
}

