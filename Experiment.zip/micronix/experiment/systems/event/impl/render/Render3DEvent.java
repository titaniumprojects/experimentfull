/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  org.joml.Matrix4f
 */
package micronix.experiment.systems.event.impl.render;

import micronix.experiment.systems.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

@Environment(value=EnvType.CLIENT)
public class Render3DEvent
extends Event {
    private final class_4587 matrices;
    private final Matrix4f positionMatrix;
    private final Matrix4f projectionMatrix;
    private final class_4184 camera;
    private final float tickDelta;

    public class_4587 getMatrices() {
        return this.matrices;
    }

    public Matrix4f getPositionMatrix() {
        return this.positionMatrix;
    }

    public Matrix4f getProjectionMatrix() {
        return this.projectionMatrix;
    }

    public class_4184 getCamera() {
        return this.camera;
    }

    public float getTickDelta() {
        return this.tickDelta;
    }

    public Render3DEvent(class_4587 matrices, Matrix4f positionMatrix, Matrix4f projectionMatrix, class_4184 camera, float tickDelta) {
        this.matrices = matrices;
        this.positionMatrix = positionMatrix;
        this.projectionMatrix = projectionMatrix;
        this.camera = camera;
        this.tickDelta = tickDelta;
    }
}

