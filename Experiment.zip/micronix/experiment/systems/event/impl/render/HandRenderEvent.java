/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1306
 *  net.minecraft.class_1799
 *  net.minecraft.class_4587
 */
package micronix.experiment.systems.event.impl.render;

import micronix.experiment.systems.event.EventCancellable;
import micronix.experiment.systems.modules.constructions.swinganim.SwingTransformations;
import micronix.experiment.systems.modules.constructions.viewmodel.ViewModelTransformations;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;

@Environment(value=EnvType.CLIENT)
public class HandRenderEvent
extends EventCancellable {
    private final class_1306 arm;
    private final class_1268 hand;
    private final float swingProgress;
    private final class_1799 itemStack;
    private final float equipProgress;
    private final class_4587 matrices;
    private SwingTransformations customTransformations;
    private ViewModelTransformations viewModelTransformations;

    public class_1306 getArm() {
        return this.arm;
    }

    public class_1268 getHand() {
        return this.hand;
    }

    public float getSwingProgress() {
        return this.swingProgress;
    }

    public class_1799 getItemStack() {
        return this.itemStack;
    }

    public float getEquipProgress() {
        return this.equipProgress;
    }

    public class_4587 getMatrices() {
        return this.matrices;
    }

    public SwingTransformations getCustomTransformations() {
        return this.customTransformations;
    }

    public void setCustomTransformations(SwingTransformations customTransformations) {
        this.customTransformations = customTransformations;
    }

    public ViewModelTransformations getViewModelTransformations() {
        return this.viewModelTransformations;
    }

    public void setViewModelTransformations(ViewModelTransformations viewModelTransformations) {
        this.viewModelTransformations = viewModelTransformations;
    }

    public HandRenderEvent(class_1306 arm, class_1268 hand, float swingProgress, class_1799 itemStack, float equipProgress, class_4587 matrices) {
        this.arm = arm;
        this.hand = hand;
        this.swingProgress = swingProgress;
        this.itemStack = itemStack;
        this.equipProgress = equipProgress;
        this.matrices = matrices;
        this.customTransformations = null;
        this.viewModelTransformations = null;
    }
}

