/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.bridge;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.GameTickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pw.lucent.bridge.client.core.Network;

@Environment(value=EnvType.CLIENT)
public class NetworkListener {
    private final EventListener<GameTickEvent> onTick = event -> Network.getInstance().onTick();

    public NetworkListener() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }
}

