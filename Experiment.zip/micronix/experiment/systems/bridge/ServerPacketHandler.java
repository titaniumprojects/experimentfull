/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 */
package micronix.experiment.systems.bridge;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import pw.lucent.bridge.client.handler.PacketHandler;
import pw.lucent.bridge.shared.packet.impl.server.community.S2CPacketIRCMessage;

@Environment(value=EnvType.CLIENT)
public class ServerPacketHandler
extends PacketHandler {
    public void handle(S2CPacketIRCMessage packet) {
        class_310.method_1551().field_1724.method_7353(class_2561.method_30163((String)(String.valueOf(class_124.field_1079) + "[IRC] " + String.valueOf(class_124.field_1068) + packet.getUserInfo().getUsername() + ": " + String.valueOf(class_124.field_1080) + packet.getMessage())), false);
    }
}

