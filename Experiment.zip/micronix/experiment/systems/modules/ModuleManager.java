/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 */
package micronix.experiment.systems.modules;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.exception.UnknownModuleException;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.AimBot;
import micronix.experiment.systems.modules.modules.combat.AntiBot;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.modules.modules.combat.AutoArmor;
import micronix.experiment.systems.modules.modules.combat.AutoExplosion;
import micronix.experiment.systems.modules.modules.combat.AutoGapple;
import micronix.experiment.systems.modules.modules.combat.AutoPotion;
import micronix.experiment.systems.modules.modules.combat.AutoSoup;
import micronix.experiment.systems.modules.modules.combat.AutoTotem;
import micronix.experiment.systems.modules.modules.combat.BackTrack;
import micronix.experiment.systems.modules.modules.combat.Criticals;
import micronix.experiment.systems.modules.modules.combat.Hitboxes;
import micronix.experiment.systems.modules.modules.combat.ItemRadius;
import micronix.experiment.systems.modules.modules.combat.PvPSafe;
import micronix.experiment.systems.modules.modules.combat.RotatingHitbox;
import micronix.experiment.systems.modules.modules.combat.ShiftTap;
import micronix.experiment.systems.modules.modules.combat.SwapTest;
import micronix.experiment.systems.modules.modules.combat.TotemTracker;
import micronix.experiment.systems.modules.modules.combat.TriggerBot;
import micronix.experiment.systems.modules.modules.combat.Velocity;
import micronix.experiment.systems.modules.modules.movement.AutoSprint;
import micronix.experiment.systems.modules.modules.movement.ElytraStrafe;
import micronix.experiment.systems.modules.modules.movement.Flight;
import micronix.experiment.systems.modules.modules.movement.NoClip;
import micronix.experiment.systems.modules.modules.movement.NoSlow;
import micronix.experiment.systems.modules.modules.movement.Speed;
import micronix.experiment.systems.modules.modules.movement.Spider;
import micronix.experiment.systems.modules.modules.movement.TargetStrafe;
import micronix.experiment.systems.modules.modules.movement.Timer;
import micronix.experiment.systems.modules.modules.movement.WindHop;
import micronix.experiment.systems.modules.modules.other.AppleFarm;
import micronix.experiment.systems.modules.modules.other.Assist;
import micronix.experiment.systems.modules.modules.other.Auction;
import micronix.experiment.systems.modules.modules.other.AutoAccept;
import micronix.experiment.systems.modules.modules.other.AutoAuth;
import micronix.experiment.systems.modules.modules.other.AutoDuels;
import micronix.experiment.systems.modules.modules.other.AutoJoin;
import micronix.experiment.systems.modules.modules.other.AutoResell;
import micronix.experiment.systems.modules.modules.other.CoordInvite;
import micronix.experiment.systems.modules.modules.other.DeathCords;
import micronix.experiment.systems.modules.modules.other.EffectRemover;
import micronix.experiment.systems.modules.modules.other.FastItemUse;
import micronix.experiment.systems.modules.modules.other.InventoryCleaner;
import micronix.experiment.systems.modules.modules.other.ItemPickup;
import micronix.experiment.systems.modules.modules.other.NameProtect;
import micronix.experiment.systems.modules.modules.other.Panic;
import micronix.experiment.systems.modules.modules.other.RoflMod;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.modules.modules.other.SpecBind;
import micronix.experiment.systems.modules.modules.player.AutoBrew;
import micronix.experiment.systems.modules.modules.player.AutoEat;
import micronix.experiment.systems.modules.modules.player.AutoFarm;
import micronix.experiment.systems.modules.modules.player.AutoInvisible;
import micronix.experiment.systems.modules.modules.player.AutoLeave;
import micronix.experiment.systems.modules.modules.player.AutoSwap;
import micronix.experiment.systems.modules.modules.player.Blink;
import micronix.experiment.systems.modules.modules.player.CreeperFarm;
import micronix.experiment.systems.modules.modules.player.ElytraUtils;
import micronix.experiment.systems.modules.modules.player.FakePlayer;
import micronix.experiment.systems.modules.modules.player.FreeCam;
import micronix.experiment.systems.modules.modules.player.GuiMove;
import micronix.experiment.systems.modules.modules.player.InvUtils;
import micronix.experiment.systems.modules.modules.player.MiddleClick;
import micronix.experiment.systems.modules.modules.player.MineHelper;
import micronix.experiment.systems.modules.modules.player.NoDelay;
import micronix.experiment.systems.modules.modules.player.NoFall;
import micronix.experiment.systems.modules.modules.player.NoInteract;
import micronix.experiment.systems.modules.modules.player.NoPush;
import micronix.experiment.systems.modules.modules.player.NoRotate;
import micronix.experiment.systems.modules.modules.player.Nuker;
import micronix.experiment.systems.modules.modules.player.PlayerUtils;
import micronix.experiment.systems.modules.modules.player.Scaffold;
import micronix.experiment.systems.modules.modules.player.Stealer;
import micronix.experiment.systems.modules.modules.player.TapeMouse;
import micronix.experiment.systems.modules.modules.player.TargetPearl;
import micronix.experiment.systems.modules.modules.player.WardenHelper;
import micronix.experiment.systems.modules.modules.visuals.Ambience;
import micronix.experiment.systems.modules.modules.visuals.AntiInvisible;
import micronix.experiment.systems.modules.modules.visuals.Arrows;
import micronix.experiment.systems.modules.modules.visuals.BlockOverlay;
import micronix.experiment.systems.modules.modules.visuals.ChinahatModule;
import micronix.experiment.systems.modules.modules.visuals.CustomFog;
import micronix.experiment.systems.modules.modules.visuals.FriendMarkers;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.modules.modules.visuals.ItemPhysics;
import micronix.experiment.systems.modules.modules.visuals.JumpCircle;
import micronix.experiment.systems.modules.modules.visuals.KillEffects;
import micronix.experiment.systems.modules.modules.visuals.MenuModule;
import micronix.experiment.systems.modules.modules.visuals.Nametags;
import micronix.experiment.systems.modules.modules.visuals.ObjectInfo;
import micronix.experiment.systems.modules.modules.visuals.ParticleEffects;
import micronix.experiment.systems.modules.modules.visuals.Prediction;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import micronix.experiment.systems.modules.modules.visuals.SoundESP;
import micronix.experiment.systems.modules.modules.visuals.StorageESP;
import micronix.experiment.systems.modules.modules.visuals.SwingAnimation;
import micronix.experiment.systems.modules.modules.visuals.TNTTimer;
import micronix.experiment.systems.modules.modules.visuals.TargetESP;
import micronix.experiment.systems.modules.modules.visuals.TrapESP;
import micronix.experiment.systems.modules.modules.visuals.ViewModel;
import micronix.experiment.systems.modules.modules.visuals.XRay;
import micronix.experiment.systems.modules.modules.visuals.Zoom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import ru.kotopushka.compiler.sdk.annotations.CompileBytecode;

@Environment(value=EnvType.CLIENT)
public class ModuleManager {
    private final List<Module> modules = new ArrayList<Module>();
    private final EventListener<ClientPlayerTickEvent> tickListener;
    private final EventListener<HudRenderEvent> moduleWidgetRenderer;
    private final EventListener<KeyPressEvent> onKeyPress = event -> {
        if (class_310.method_1551().field_1755 != null) {
            return;
        }
        for (Module module : this.getModules()) {
            if (module.getKey() != event.getKey() || module.getKey() == -1 || event.getAction() != 1) continue;
            module.toggle();
        }
    };
    private final EventListener<MouseEvent> onMouseButtonPress = event -> {
        if (class_310.method_1551().field_1755 != null) {
            return;
        }
        for (Module module : this.getModules()) {
            if (module.getKey() != event.getButton() || module.getKey() == -1 || event.getAction() != 1) continue;
            module.toggle();
        }
    };

    public ModuleManager(EventListener<ClientPlayerTickEvent> tickListener, EventListener<HudRenderEvent> moduleWidgetRenderer) {
        this.tickListener = tickListener;
        this.moduleWidgetRenderer = moduleWidgetRenderer;
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    @CompileBytecode
    public void registerModules() {
        this.register(new Aura());
        this.register(new AutoTotem());
        this.register(new TriggerBot());
        this.register(new AutoGapple());
        this.register(new AppleFarm());
        this.register(new AimBot());
        this.register(new WardenHelper());
        this.register(new AutoPotion());
        this.register(new AntiBot());
        this.register(new Velocity());
        this.register(new AutoArmor());
        this.register(new AutoExplosion());
        this.register(new BackTrack());
        this.register(new Hitboxes());
        this.register(new Criticals());
        this.register(new AutoSoup());
        this.register(new AutoSprint());
        this.register(new WindHop());
        this.register(new Flight());
        this.register(new Speed());
        this.register(new Timer());
        this.register(new NoSlow());
        this.register(new Spider());
        this.register(new ElytraStrafe());
        this.register(new Nametags());
        this.register(new Removals());
        this.register(new Ambience());
        this.register(new SwingAnimation());
        this.register(new SoundESP());
        this.register(new FriendMarkers());
        this.register(new Arrows());
        this.register(new TNTTimer());
        this.register(new ViewModel());
        this.register(new TrapESP());
        this.register(new Blink());
        this.register(new Interface());
        this.register(new TargetESP());
        this.register(new StorageESP());
        this.register(new XRay());
        this.register(new AntiInvisible());
        this.register(new KillEffects());
        this.register(new InventoryCleaner());
        this.register(new AutoInvisible());
        this.register(new MineHelper());
        this.register(new TargetPearl());
        this.register(new Stealer());
        this.register(new MiddleClick());
        this.register(new AutoBrew());
        this.register(new AutoFarm());
        this.register(new AutoEat());
        this.register(new FreeCam());
        this.register(new NoDelay());
        this.register(new PlayerUtils());
        this.register(new NoPush());
        this.register(new Scaffold());
        this.register(new ObjectInfo());
        this.register(new CreeperFarm());
        this.register(new Nuker());
        this.register(new NoRotate());
        this.register(new NoInteract());
        this.register(new NoFall());
        this.register(new EffectRemover());
        this.register(new NameProtect());
        this.register(new ElytraUtils());
        this.register(new FastItemUse());
        this.register(new AutoResell());
        this.register(new Panic());
        this.register(new Auction());
        this.register(new DeathCords());
        this.register(new AutoLeave());
        this.register(new AutoSwap());
        this.register(new AutoDuels());
        this.register(new AutoAuth());
        this.register(new AutoJoin());
        this.register(new GuiMove());
        this.register(new Assist());
        this.register(new TotemTracker());
        this.register(new MenuModule());
        this.register(new ItemRadius());
        this.register(new JumpCircle());
        this.register(new CustomFog());
        this.register(new Zoom());
        this.register(new RotatingHitbox());
        this.register(new Prediction());
        this.register(new ShiftTap());
        this.register(new InvUtils());
        this.register(new ItemPickup());
        this.register(new TapeMouse());
        this.register(new AutoAccept());
        this.register(new Sounds());
        this.register(new CoordInvite());
        this.register(new SpecBind());
        this.register(new BlockOverlay());
        this.register(new ItemPhysics());
        this.register(new ParticleEffects());
        this.register(new ChinahatModule());
        this.register(new TargetStrafe());
        this.register(new PvPSafe());
        this.register(new NoClip());
        this.register(new SwapTest());
        this.register(new RoflMod());
        this.register(new FakePlayer());
    }

    @CompileBytecode
    public void enableModules() {
        for (Module module : this.modules) {
            if (!module.getInfo().enabledByDefault()) continue;
            module.enable();
        }
    }

    public void register(BaseModule module) {
        this.modules.add(module);
    }

    public <T extends Module> T getModule(String name) {
        return (T)this.modules.stream().filter(module -> module.getName().replace(" ", "").equalsIgnoreCase(name) || module.getName().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new UnknownModuleException(name));
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        return (T)this.modules.stream().filter(module -> module.getClass().equals(clazz)).findFirst().orElseThrow(() -> new UnknownModuleException(clazz.getSimpleName()));
    }

    public List<Module> getModules() {
        return this.modules;
    }

    public EventListener<ClientPlayerTickEvent> getTickListener() {
        return this.tickListener;
    }

    public EventListener<HudRenderEvent> getModuleWidgetRenderer() {
        return this.moduleWidgetRenderer;
    }

    public EventListener<KeyPressEvent> getOnKeyPress() {
        return this.onKeyPress;
    }

    public EventListener<MouseEvent> getOnMouseButtonPress() {
        return this.onMouseButtonPress;
    }
}

