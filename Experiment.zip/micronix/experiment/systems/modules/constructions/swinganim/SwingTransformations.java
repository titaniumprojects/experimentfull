/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.constructions.swinganim;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class SwingTransformations {
    private final float anchorX;
    private final float anchorY;
    private final float anchorZ;
    private final float moveX;
    private final float moveY;
    private final float moveZ;
    private final float rotateX;
    private final float rotateY;
    private final float rotateZ;

    public SwingTransformations(float anchorX, float anchorY, float anchorZ, float moveX, float moveY, float moveZ, float rotateX, float rotateY, float rotateZ) {
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.anchorZ = anchorZ;
        this.moveX = moveX;
        this.moveY = moveY;
        this.moveZ = moveZ;
        this.rotateX = rotateX;
        this.rotateY = rotateY;
        this.rotateZ = rotateZ;
    }

    public float getAnchorX() {
        return this.anchorX;
    }

    public float getAnchorY() {
        return this.anchorY;
    }

    public float getAnchorZ() {
        return this.anchorZ;
    }

    public float getMoveX() {
        return this.moveX;
    }

    public float getMoveY() {
        return this.moveY;
    }

    public float getMoveZ() {
        return this.moveZ;
    }

    public float getRotateX() {
        return this.rotateX;
    }

    public float getRotateY() {
        return this.rotateY;
    }

    public float getRotateZ() {
        return this.rotateZ;
    }
}

