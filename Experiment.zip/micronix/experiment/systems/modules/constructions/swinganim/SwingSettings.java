/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.constructions.swinganim;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.systems.setting.SettingsContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class SwingSettings
implements SettingsContainer {
    protected final List<Setting> settings = new ArrayList<Setting>();

    @Override
    public List<Setting> getSettings() {
        return this.settings;
    }
}

