/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 */
package micronix.experiment.systems.modules.constructions.swinganim;

import java.util.Collection;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomScreen;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.modules.constructions.swinganim.PopupEvent;
import micronix.experiment.systems.modules.constructions.swinganim.SwingManager;
import micronix.experiment.systems.modules.constructions.swinganim.SwingPhase;
import micronix.experiment.systems.modules.constructions.swinganim.presets.PresetComponent;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPreset;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPresetFile;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPresetManager;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.ui.components.popup.Popup;
import micronix.experiment.ui.components.textfield.TextField;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_332;
import net.minecraft.class_437;

@Environment(value=EnvType.CLIENT)
public class SwingAnimScreen
extends CustomScreen
implements IScaledResolution,
IMinecraft {
    private final Popup presets = new Popup(100.0f, 100.0f).title("presets");
    private final Popup shared = new Popup(100.0f, 100.0f).title("shared");
    private final Popup start = new Popup(300.0f, 100.0f).title("anim_from");
    private final Popup end = new Popup(500.0f, 100.0f).title("anim_to");

    public SwingAnimScreen() {
        boolean isCustomPreset;
        SwingManager manager = Experiment.getInstance().getSwingManager();
        Experiment.getInstance().getSwingPresetManager().refresh();
        this.presets.add(new PresetComponent());
        this.applySettings(manager.getSharedSettings().settings, this.shared);
        this.applySettings(manager.getStartPhase().settings, this.start);
        this.applySettings(manager.getEndPhase().settings, this.end);
        SwingManager swingManager = Experiment.getInstance().getSwingManager();
        SwingPresetManager presetManager = Experiment.getInstance().getSwingPresetManager();
        String swing = swingManager.getCurrent();
        SwingPresetFile customPreset = presetManager.getPreset(swing);
        boolean bl = isCustomPreset = customPreset != null;
        if (!isCustomPreset) {
            for (SwingPreset value : Experiment.getInstance().getSwingManager().getPresets()) {
                if (!value.getName().equals(swing)) continue;
                swingManager.getBezier().start(value.getBezierStart()).end(value.getBezierEnd());
                swingManager.getBack().enabled(value.isSwingBack());
                swingManager.getSpeed().setCurrentValue(value.getSpeed());
                SwingPhase start = swingManager.getStartPhase();
                start.getAnchorX().setCurrentValue(value.getFrom().getAnchorX());
                start.getAnchorY().setCurrentValue(value.getFrom().getAnchorY());
                start.getAnchorZ().setCurrentValue(value.getFrom().getAnchorZ());
                start.getMoveX().setCurrentValue(value.getFrom().getMoveX());
                start.getMoveY().setCurrentValue(value.getFrom().getMoveY());
                start.getMoveZ().setCurrentValue(value.getFrom().getMoveZ());
                start.getRotateX().setCurrentValue(value.getFrom().getRotateX());
                start.getRotateY().setCurrentValue(value.getFrom().getRotateY());
                start.getRotateZ().setCurrentValue(value.getFrom().getRotateZ());
                SwingPhase end = swingManager.getEndPhase();
                end.getAnchorX().setCurrentValue(value.getTo().getAnchorX());
                end.getAnchorY().setCurrentValue(value.getTo().getAnchorY());
                end.getAnchorZ().setCurrentValue(value.getTo().getAnchorZ());
                end.getMoveX().setCurrentValue(value.getTo().getMoveX());
                end.getMoveY().setCurrentValue(value.getTo().getMoveY());
                end.getMoveZ().setCurrentValue(value.getTo().getMoveZ());
                end.getRotateX().setCurrentValue(value.getTo().getRotateX());
                end.getRotateY().setCurrentValue(value.getTo().getRotateY());
                end.getRotateZ().setCurrentValue(value.getTo().getRotateZ());
                swingManager.setCurrent(swing);
                break;
            }
        }
    }

    @Override
    public void render(UIContext context) {
        float startX = IScaledResolution.sr.getScaledWidth() / 2.0f - 360.0f + 4.0f;
        this.presets.setX(startX);
        this.shared.setX(startX += 180.0f);
        this.start.setX(startX += 180.0f);
        this.end.setX(startX += 180.0f);
        this.popupEvent(popup -> popup.render(context));
        this.popupEvent(popup -> popup.setY(sr.getScaledHeight() / 2.0f - this.end.getHeight() / 2.0f));
        this.popupEvent(popup -> popup.setWidth(170.0f));
        if (SwingAnimScreen.mc.field_1724.field_6012 % 20 == 0) {
            SwingAnimScreen.mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        this.popupEvent(popup -> popup.onMouseClicked(mouseX, mouseY, button));
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        this.popupEvent(popup -> popup.onMouseReleased(mouseX, mouseY, button));
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.popupEvent(popup -> popup.onScroll(mouseX, mouseY, horizontalAmount, verticalAmount));
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        this.popupEvent(popup -> popup.onKeyPressed(keyCode, scanCode, modifiers));
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25400(char chr, int modifiers) {
        this.popupEvent(popup -> popup.charTyped(chr, modifiers));
        return super.method_25400(chr, modifiers);
    }

    private void applySettings(Collection<Setting> settings, Popup target) {
        for (Setting setting : settings) {
            target.setting(setting);
        }
    }

    private void popupEvent(PopupEvent event) {
        event.call(this.presets);
        event.call(this.shared);
        event.call(this.start);
        event.call(this.end);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    public void method_25419() {
        SwingPresetManager manager = Experiment.getInstance().getSwingPresetManager();
        if (manager.getCurrent() != null) {
            manager.getCurrent().save();
        }
        if (TextField.LAST_FIELD != null) {
            TextField.LAST_FIELD.setFocused(false);
        }
        super.method_25419();
        mc.method_1507((class_437)Experiment.getInstance().getMenuScreen());
    }
}

