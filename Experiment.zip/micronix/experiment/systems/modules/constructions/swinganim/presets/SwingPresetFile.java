/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.constructions.swinganim.presets;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import micronix.experiment.Experiment;
import micronix.experiment.systems.file.FileManager;
import micronix.experiment.systems.modules.constructions.swinganim.SwingManager;
import micronix.experiment.systems.modules.constructions.swinganim.SwingPhase;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class SwingPresetFile
implements IMinecraft {
    private final File file;
    private final String fileName;
    private final Animation hoverAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation activeAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);

    public SwingPresetFile(String fileName) {
        this.fileName = fileName;
        File presetsFolder = new File(SwingPresetFile.mc.field_1697, "Experiment/presets/swing");
        if (!presetsFolder.exists()) {
            presetsFolder.mkdirs();
        }
        this.file = new File(presetsFolder, fileName + ".exper");
    }

    public void load() {
        if (this.file.exists()) {
            try (FileReader reader = new FileReader(this.file);){
                JsonObject json = (JsonObject)FileManager.GSON.fromJson((Reader)reader, JsonObject.class);
                SwingManager manager = Experiment.getInstance().getSwingManager();
                if (json.has("bezier")) {
                    manager.getBezier().load(json.get("bezier"));
                }
                if (json.has("swingBack")) {
                    manager.getBack().enabled(json.get("swingBack").getAsBoolean());
                }
                if (json.has("speed")) {
                    manager.getSpeed().setCurrentValue(json.get("speed").getAsFloat());
                }
                if (json.has("startPhase")) {
                    JsonObject startPhase = json.getAsJsonObject("startPhase");
                    SwingPhase start = manager.getStartPhase();
                    if (startPhase.has("anchorX")) {
                        start.getAnchorX().setCurrentValue(startPhase.get("anchorX").getAsFloat());
                    }
                    if (startPhase.has("anchorY")) {
                        start.getAnchorY().setCurrentValue(startPhase.get("anchorY").getAsFloat());
                    }
                    if (startPhase.has("anchorZ")) {
                        start.getAnchorZ().setCurrentValue(startPhase.get("anchorZ").getAsFloat());
                    }
                    if (startPhase.has("moveX")) {
                        start.getMoveX().setCurrentValue(startPhase.get("moveX").getAsFloat());
                    }
                    if (startPhase.has("moveY")) {
                        start.getMoveY().setCurrentValue(startPhase.get("moveY").getAsFloat());
                    }
                    if (startPhase.has("moveZ")) {
                        start.getMoveZ().setCurrentValue(startPhase.get("moveZ").getAsFloat());
                    }
                    if (startPhase.has("rotateX")) {
                        start.getRotateX().setCurrentValue(startPhase.get("rotateX").getAsFloat());
                    }
                    if (startPhase.has("rotateY")) {
                        start.getRotateY().setCurrentValue(startPhase.get("rotateY").getAsFloat());
                    }
                    if (startPhase.has("rotateZ")) {
                        start.getRotateZ().setCurrentValue(startPhase.get("rotateZ").getAsFloat());
                    }
                }
                if (json.has("endPhase")) {
                    JsonObject endPhase = json.getAsJsonObject("endPhase");
                    SwingPhase end = manager.getEndPhase();
                    if (endPhase.has("anchorX")) {
                        end.getAnchorX().setCurrentValue(endPhase.get("anchorX").getAsFloat());
                    }
                    if (endPhase.has("anchorY")) {
                        end.getAnchorY().setCurrentValue(endPhase.get("anchorY").getAsFloat());
                    }
                    if (endPhase.has("anchorZ")) {
                        end.getAnchorZ().setCurrentValue(endPhase.get("anchorZ").getAsFloat());
                    }
                    if (endPhase.has("moveX")) {
                        end.getMoveX().setCurrentValue(endPhase.get("moveX").getAsFloat());
                    }
                    if (endPhase.has("moveY")) {
                        end.getMoveY().setCurrentValue(endPhase.get("moveY").getAsFloat());
                    }
                    if (endPhase.has("moveZ")) {
                        end.getMoveZ().setCurrentValue(endPhase.get("moveZ").getAsFloat());
                    }
                    if (endPhase.has("rotateX")) {
                        end.getRotateX().setCurrentValue(endPhase.get("rotateX").getAsFloat());
                    }
                    if (endPhase.has("rotateY")) {
                        end.getRotateY().setCurrentValue(endPhase.get("rotateY").getAsFloat());
                    }
                    if (endPhase.has("rotateZ")) {
                        end.getRotateZ().setCurrentValue(endPhase.get("rotateZ").getAsFloat());
                    }
                }
            }
            catch (Exception var8) {
                var8.printStackTrace();
            }
        }
    }

    public void save() {
        try {
            if (!this.file.exists()) {
                this.file.createNewFile();
            }
            SwingManager manager = Experiment.getInstance().getSwingManager();
            JsonObject json = new JsonObject();
            json.add("bezier", manager.getBezier().save());
            json.addProperty("swingBack", Boolean.valueOf(manager.getBack().isEnabled()));
            json.addProperty("speed", (Number)Float.valueOf(manager.getSpeed().getCurrentValue()));
            JsonObject startPhase = new JsonObject();
            SwingPhase start = manager.getStartPhase();
            startPhase.addProperty("anchorX", (Number)Float.valueOf(start.getAnchorX().getCurrentValue()));
            startPhase.addProperty("anchorY", (Number)Float.valueOf(start.getAnchorY().getCurrentValue()));
            startPhase.addProperty("anchorZ", (Number)Float.valueOf(start.getAnchorZ().getCurrentValue()));
            startPhase.addProperty("moveX", (Number)Float.valueOf(start.getMoveX().getCurrentValue()));
            startPhase.addProperty("moveY", (Number)Float.valueOf(start.getMoveY().getCurrentValue()));
            startPhase.addProperty("moveZ", (Number)Float.valueOf(start.getMoveZ().getCurrentValue()));
            startPhase.addProperty("rotateX", (Number)Float.valueOf(start.getRotateX().getCurrentValue()));
            startPhase.addProperty("rotateY", (Number)Float.valueOf(start.getRotateY().getCurrentValue()));
            startPhase.addProperty("rotateZ", (Number)Float.valueOf(start.getRotateZ().getCurrentValue()));
            json.add("startPhase", (JsonElement)startPhase);
            JsonObject endPhase = new JsonObject();
            SwingPhase end = manager.getEndPhase();
            endPhase.addProperty("anchorX", (Number)Float.valueOf(end.getAnchorX().getCurrentValue()));
            endPhase.addProperty("anchorY", (Number)Float.valueOf(end.getAnchorY().getCurrentValue()));
            endPhase.addProperty("anchorZ", (Number)Float.valueOf(end.getAnchorZ().getCurrentValue()));
            endPhase.addProperty("moveX", (Number)Float.valueOf(end.getMoveX().getCurrentValue()));
            endPhase.addProperty("moveY", (Number)Float.valueOf(end.getMoveY().getCurrentValue()));
            endPhase.addProperty("moveZ", (Number)Float.valueOf(end.getMoveZ().getCurrentValue()));
            endPhase.addProperty("rotateX", (Number)Float.valueOf(end.getRotateX().getCurrentValue()));
            endPhase.addProperty("rotateY", (Number)Float.valueOf(end.getRotateY().getCurrentValue()));
            endPhase.addProperty("rotateZ", (Number)Float.valueOf(end.getRotateZ().getCurrentValue()));
            json.add("endPhase", (JsonElement)endPhase);
            try (FileWriter writer = new FileWriter(this.file);){
                writer.write(FileManager.GSON.toJson((JsonElement)json));
            }
        }
        catch (Exception var12) {
            var12.printStackTrace();
        }
    }

    public void delete() {
        if (this.file.exists()) {
            this.file.delete();
        }
    }

    public String getFileName() {
        return this.fileName;
    }

    public File getFile() {
        return this.file;
    }

    public Animation getHoverAnimation() {
        return this.hoverAnimation;
    }

    public Animation getActiveAnimation() {
        return this.activeAnimation;
    }
}

