/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.constructions.swinganim.presets;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPresetFile;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class SwingPresetManager
implements IMinecraft {
    private final List<SwingPresetFile> swingPresetFiles = new ArrayList<SwingPresetFile>();
    private SwingPresetFile current;

    public void handle() {
        this.refresh();
        if (this.getAutoSavePreset() == null) {
            SwingPresetFile autosave = new SwingPresetFile("autosave");
            this.swingPresetFiles.add(autosave);
            this.current = autosave;
        }
    }

    public void refresh() {
        File presetsFolder = new File(SwingPresetManager.mc.field_1697, "Experiment/presets/swing");
        if (!presetsFolder.exists()) {
            presetsFolder.mkdirs();
        } else {
            File[] files = presetsFolder.listFiles((dir, name) -> name.endsWith(".exper"));
            if (files != null) {
                for (File file : files) {
                    String fileName = file.getName().replace(".exper", "");
                    boolean exists = this.swingPresetFiles.stream().anyMatch(presetx -> presetx.getFileName().equals(fileName));
                    if (exists) continue;
                    SwingPresetFile preset = new SwingPresetFile(fileName);
                    this.swingPresetFiles.add(preset);
                }
            }
        }
    }

    public void createPreset(String name) {
        SwingPresetFile preset = new SwingPresetFile(name);
        this.swingPresetFiles.add(preset);
        preset.save();
    }

    public SwingPresetFile getPreset(String name) {
        return this.swingPresetFiles.stream().filter(preset -> preset.getFileName().equals(name)).findFirst().orElse(null);
    }

    public SwingPresetFile getAutoSavePreset() {
        return this.current != null ? this.current : (SwingPresetFile)this.swingPresetFiles.stream().filter(preset -> preset.getFileName().equals("autosave")).findFirst().orElse(null);
    }

    public List<SwingPresetFile> getSwingPresetFiles() {
        return this.swingPresetFiles;
    }

    public SwingPresetFile getCurrent() {
        return this.current;
    }

    public void setCurrent(SwingPresetFile current) {
        this.current = current;
    }
}

