/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_241
 */
package micronix.experiment.systems.modules.constructions.swinganim.presets;

import micronix.experiment.systems.modules.constructions.swinganim.SwingTransformations;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_241;

@Environment(value=EnvType.CLIENT)
public final class SwingPreset {
    private final String name;
    private final class_241 bezierStart;
    private final class_241 bezierEnd;
    private final boolean swingBack;
    private final float speed;
    private final SwingTransformations from;
    private final SwingTransformations to;
    private final Animation hoverAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation activeAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);

    public SwingPreset(String name, class_241 bezierStart, class_241 bezierEnd, boolean swingBack, float speed, SwingTransformations from, SwingTransformations to) {
        this.name = name;
        this.bezierStart = bezierStart;
        this.bezierEnd = bezierEnd;
        this.swingBack = swingBack;
        this.speed = speed;
        this.from = from;
        this.to = to;
    }

    public String getName() {
        return this.name;
    }

    public class_241 getBezierStart() {
        return this.bezierStart;
    }

    public class_241 getBezierEnd() {
        return this.bezierEnd;
    }

    public boolean isSwingBack() {
        return this.swingBack;
    }

    public float getSpeed() {
        return this.speed;
    }

    public SwingTransformations getFrom() {
        return this.from;
    }

    public SwingTransformations getTo() {
        return this.to;
    }

    public Animation getHoverAnimation() {
        return this.hoverAnimation;
    }

    public Animation getActiveAnimation() {
        return this.activeAnimation;
    }
}

