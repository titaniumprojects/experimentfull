/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_3532
 *  org.jetbrains.annotations.NotNull
 */
package micronix.experiment.systems.modules.constructions.swinganim;

import micronix.experiment.systems.modules.constructions.swinganim.SwingSettings;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;

@Environment(value=EnvType.CLIENT)
public class SwingPhase
extends SwingSettings {
    private final SliderSetting anchorX = new PhaseSlider(this, "swing.anchorX").step(0.05f).min(-5.0f).max(5.0f).currentValue(0.0f);
    private final SliderSetting anchorY = new PhaseSlider(this, "swing.anchorY").step(0.05f).min(-5.0f).max(5.0f).currentValue(0.0f);
    private final SliderSetting anchorZ = new PhaseSlider(this, "swing.anchorZ").step(0.05f).min(-5.0f).max(5.0f).currentValue(0.0f);
    private final SliderSetting moveX = new PhaseSlider(this, "swing.moveX").step(0.05f).min(-5.0f).max(5.0f).currentValue(0.0f);
    private final SliderSetting moveY = new PhaseSlider(this, "swing.moveY").step(0.05f).min(-5.0f).max(5.0f).currentValue(0.0f);
    private final SliderSetting moveZ = new PhaseSlider(this, "swing.moveZ").step(0.05f).min(-3.0f).max(3.0f).currentValue(0.0f);
    private final SliderSetting rotateX = new PhaseSlider(this, "swing.rotateX").step(15.0f).min(-360.0f).max(360.0f).currentValue(0.0f);
    private final SliderSetting rotateY = new PhaseSlider(this, "swing.rotateY").step(15.0f).min(-360.0f).max(360.0f).currentValue(0.0f);
    private final SliderSetting rotateZ = new PhaseSlider(this, "swing.rotateZ").step(15.0f).min(-360.0f).max(360.0f).currentValue(0.0f);

    public SliderSetting getAnchorX() {
        return this.anchorX;
    }

    public SliderSetting getAnchorY() {
        return this.anchorY;
    }

    public SliderSetting getAnchorZ() {
        return this.anchorZ;
    }

    public SliderSetting getMoveX() {
        return this.moveX;
    }

    public SliderSetting getMoveY() {
        return this.moveY;
    }

    public SliderSetting getMoveZ() {
        return this.moveZ;
    }

    public SliderSetting getRotateX() {
        return this.rotateX;
    }

    public SliderSetting getRotateY() {
        return this.rotateY;
    }

    public SliderSetting getRotateZ() {
        return this.rotateZ;
    }

    @Environment(value=EnvType.CLIENT)
    public static class PhaseSlider
    extends SliderSetting {
        public PhaseSlider(@NotNull SettingsContainer parent, String name) {
            super(parent, name);
        }

        @Override
        public void setCurrentValue(float currentValue) {
            super.setCurrentValue(currentValue);
        }

        private void silentSet(float value) {
            this.currentValue = class_3532.method_15363((float)((float)((double)Math.round((double)value * (1.0 / (double)this.step)) / (1.0 / (double)this.step))), (float)this.min, (float)this.max);
        }
    }
}

