/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.impl;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.localization.Language;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.modules.modules.visuals.MenuModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public abstract class BaseModule
implements Module {
    private final ModuleInfo info = this.getClass().getAnnotation(ModuleInfo.class);
    private int key;
    private ModuleCategory category;
    private boolean enabled;
    private boolean hidden;
    private String name;
    private List<Setting> settings = new ArrayList<Setting>();
    private final Animation keybindsAnimation = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);

    public BaseModule() {
        this.name = this.info.name();
        this.category = this.info.category();
        this.key = this.info.key();
    }

    @Override
    public void toggle() {
        this.setEnabled(!this.enabled, false);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void tick() {
    }

    @Override
    public void disable() {
        this.setEnabled(false, false);
    }

    @Override
    public void enable() {
        this.setEnabled(true, false);
    }

    @Override
    public void setEnabled(boolean newState, boolean silent) {
        if (this.enabled == newState) {
            return;
        }
        this.enabled = newState;
        if (!(this instanceof MenuModule) && Experiment.getInstance().getModuleManager().getModule(Sounds.class).isEnabled() && !silent) {
            ClientSounds.MODULE.play(Experiment.getInstance().getModuleManager().getModule(Sounds.class).getVolume().getCurrentValue(), this.enabled ? 1.1f : 1.0f);
        }
        if (this.enabled) {
            Experiment.getInstance().getEventManager().subscribe(this);
            if (!silent) {
                Experiment.getInstance().getNotificationManager().addNotification(NotificationType.SUCCESS, this.name.replace(" ", "") + " " + Localizator.translate("enabled") + (Localizator.getCurrentLanguage() == Language.RU_RU ? TextUtility.makeGender(this.name) : ""));
            }
            this.onEnable();
        } else {
            Experiment.getInstance().getEventManager().unsubscribe(this);
            if (!silent) {
                Experiment.getInstance().getNotificationManager().addNotification(NotificationType.ERROR, this.name.replace(" ", "") + " " + Localizator.translate("disabled") + (Localizator.getCurrentLanguage() == Language.RU_RU ? TextUtility.makeGender(this.name) : ""));
            }
            this.onDisable();
        }
    }

    public String getSettingName(String key) {
        return "modules.settings." + this.getName().toLowerCase().replace(" ", "_") + "." + key;
    }

    @Override
    public ModuleInfo getInfo() {
        return this.info;
    }

    @Override
    public int getKey() {
        return this.key;
    }

    @Override
    public ModuleCategory getCategory() {
        return this.category;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public boolean isHidden() {
        return this.hidden;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public List<Setting> getSettings() {
        return this.settings;
    }

    @Override
    public Animation getKeybindsAnimation() {
        return this.keybindsAnimation;
    }

    @Override
    public void setKey(int key) {
        this.key = key;
    }

    public void setCategory(ModuleCategory category) {
        this.category = category;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSettings(List<Setting> settings) {
        this.settings = settings;
    }
}

