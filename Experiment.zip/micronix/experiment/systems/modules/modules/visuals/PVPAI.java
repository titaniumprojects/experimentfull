/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1893
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_327
 *  net.minecraft.class_327$class_6415
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_6880
 *  net.minecraft.class_9304
 *  net.minecraft.class_9334
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

@ModuleInfo(name="PVP AI", category=ModuleCategory.VISUALS, desc="modules.descriptions.pvp_ai")
@Environment(value=EnvType.CLIENT)
public class PVPAI
extends BaseModule
implements IMinecraft,
IScaledResolution {
    private final Map<class_1657, Float> playerWinChances = new HashMap<class_1657, Float>();
    private float ourWinChance = 50.0f;
    private final BooleanSetting damageIndicator = new BooleanSetting(this, "modules.settings.pvp_ai.damage_indicator").enable();
    private final SliderSetting damageSize = new SliderSetting((SettingsContainer)this, "modules.settings.pvp_ai.damage_size", () -> !this.damageIndicator.isEnabled()).min(0.5f).max(2.0f).step(0.1f).currentValue(1.0f);
    private final ColorSetting damageColor = new ColorSetting(this, "modules.settings.pvp_ai.damage_color", () -> !this.damageIndicator.isEnabled()).color(new ColorRGBA(255.0f, 85.0f, 85.0f, 255.0f));
    private final List<DamageNumber> damageNumbers = new ArrayList<DamageNumber>();
    private final Map<class_1309, Float> entityHealthMap = new HashMap<class_1309, Float>();
    private final EventListener<ClientPlayerTickEvent> onTickEvent = event -> {
        if (this.isEnabled() && this.damageIndicator.isEnabled() && PVPAI.mc.field_1724 != null && PVPAI.mc.field_1687 != null) {
            for (class_1297 entity : PVPAI.mc.field_1687.method_18112()) {
                float previousHealth;
                float damage;
                class_1309 living;
                if (!(entity instanceof class_1309) || (living = (class_1309)entity) == PVPAI.mc.field_1724 || living.method_31481()) continue;
                float currentHealth = living.method_6032() + living.method_6067();
                if (this.entityHealthMap.containsKey(living) && (damage = (previousHealth = this.entityHealthMap.get(living).floatValue()) - currentHealth) > 0.01f) {
                    class_243 pos = living.method_19538().method_1031(0.0, (double)living.method_17682() + 0.3, 0.0);
                    this.damageNumbers.add(new DamageNumber(pos, damage));
                }
                this.entityHealthMap.put(living, Float.valueOf(currentHealth));
            }
            this.entityHealthMap.entrySet().removeIf(entry -> ((class_1309)entry.getKey()).method_31481());
        }
    };
    private final EventListener<HudRenderEvent> on2DRender = event -> {
        if (PVPAI.mc.field_1724 != null && PVPAI.mc.field_1687 != null) {
            float ourPower = this.calculatePlayerPower((class_1657)PVPAI.mc.field_1724);
            float totalEnemyPower = 0.0f;
            int visibleEnemies = 0;
            for (class_1657 player : PVPAI.mc.field_1687.method_18456()) {
                if (player == PVPAI.mc.field_1724 || player.method_5767() || player.method_29504() || PVPAI.mc.field_1724.method_5739((class_1297)player) > 50.0f) continue;
                float enemyPower = this.calculatePlayerPower(player);
                this.playerWinChances.put(player, Float.valueOf(this.calculateWinChance(ourPower, enemyPower)));
                totalEnemyPower += enemyPower;
                ++visibleEnemies;
            }
            this.ourWinChance = visibleEnemies > 0 ? this.calculateWinChance(ourPower, totalEnemyPower / (float)visibleEnemies) : 50.0f;
            int screenWidth = (int)sr.getScaledWidth();
            int screenHeight = (int)sr.getScaledHeight();
            String ourText = "\u0412\u0430\u0448 \u043f\u0440\u043e\u0446\u0435\u043d\u0442: " + (int)this.ourWinChance + "%";
            class_327 font = PVPAI.mc.field_1772;
            int textWidth = font.method_1727(ourText);
            int textX = (screenWidth - textWidth) / 2;
            int textY = screenHeight - 70;
            event.getContext().method_51433(font, ourText, textX, textY, 0xFFFFFF, true);
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (PVPAI.mc.field_1724 != null && PVPAI.mc.field_1687 != null) {
            class_4587 matrices = event.getMatrices();
            class_243 cameraPos = PVPAI.mc.field_1773.method_19418().method_19326();
            if (this.damageIndicator.isEnabled() && !this.damageNumbers.isEmpty()) {
                Iterator<DamageNumber> iterator = this.damageNumbers.iterator();
                while (iterator.hasNext()) {
                    DamageNumber dmg = iterator.next();
                    dmg.update();
                    if (dmg.shouldRemove()) {
                        iterator.remove();
                        continue;
                    }
                    class_243 renderPos = dmg.getPosition();
                    double x = renderPos.field_1352 - cameraPos.field_1352;
                    double y = renderPos.field_1351 - cameraPos.field_1351;
                    double z = renderPos.field_1350 - cameraPos.field_1350;
                    matrices.method_22903();
                    matrices.method_22904(x, y, z);
                    matrices.method_22907(mc.method_1561().method_24197());
                    matrices.method_22905(-0.025f, -0.025f, 0.025f);
                    String damageText = this.formatDamage(dmg.damage);
                    float textWidth = PVPAI.mc.field_1772.method_1727(damageText);
                    float alpha = dmg.getAlpha();
                    float scale = dmg.getScale() * this.damageSize.getCurrentValue();
                    matrices.method_22905(scale, scale, 1.0f);
                    ColorRGBA damageColorValue = this.damageColor.getColor();
                    int color = damageColorValue.withAlpha(alpha).getRGB();
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    class_4597.class_4598 immediate = mc.method_22940().method_23000();
                    PVPAI.mc.field_1772.method_27521(damageText, -textWidth / 2.0f, 0.0f, color, true, matrices.method_23760().method_23761(), (class_4597)immediate, class_327.class_6415.field_33994, 0, 0xF000F0);
                    immediate.method_22993();
                    RenderSystem.disableBlend();
                    matrices.method_22909();
                }
            }
            for (class_1657 player : PVPAI.mc.field_1687.method_18456()) {
                double distance;
                if (player == PVPAI.mc.field_1724 || player.method_5767() || player.method_29504() || !this.playerWinChances.containsKey(player) || (distance = (double)PVPAI.mc.field_1724.method_5739((class_1297)player)) > 32.0) continue;
                float enemyWinChance = 100.0f - this.ourWinChance;
                class_243 playerPos = player.method_19538();
                double x = playerPos.field_1352 - cameraPos.field_1352;
                double y = playerPos.field_1351 + (double)player.method_17682() + 0.6 - cameraPos.field_1351;
                double z = playerPos.field_1350 - cameraPos.field_1350;
                matrices.method_22903();
                matrices.method_22904(x, y, z);
                matrices.method_22907(mc.method_1561().method_24197());
                matrices.method_22905(0.025f, -0.025f, 0.025f);
                String text = (int)enemyWinChance + "%";
                class_327 font = PVPAI.mc.field_1772;
                int textWidth = font.method_1727(text);
                int bgWidth = textWidth + 4;
                int bgHeight = 10;
                Matrix4f matrix = matrices.method_23760().method_23761();
                class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
                buffer.method_22918(matrix, (float)(-bgWidth) / 2.0f - 1.0f, -1.0f, 0.0f).method_1336(0, 0, 0, 64);
                buffer.method_22918(matrix, (float)(-bgWidth) / 2.0f - 1.0f, (float)(bgHeight - 1), 0.0f).method_1336(0, 0, 0, 64);
                buffer.method_22918(matrix, (float)bgWidth / 2.0f + 1.0f, (float)(bgHeight - 1), 0.0f).method_1336(0, 0, 0, 64);
                buffer.method_22918(matrix, (float)bgWidth / 2.0f + 1.0f, -1.0f, 0.0f).method_1336(0, 0, 0, 64);
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.setShader((class_10156)class_10142.field_53876);
                class_286.method_43433((class_9801)buffer.method_60800());
                int color = enemyWinChance > 50.0f ? 0xFF5555 : 0x55FF55;
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                class_4597.class_4598 immediate = mc.method_22940().method_23000();
                PVPAI.mc.field_1772.method_27521(text, (float)(-textWidth) / 2.0f, 0.0f, color, true, matrices.method_23760().method_23761(), (class_4597)immediate, class_327.class_6415.field_33993, 0, 0xF000F0);
                immediate.method_22993();
                RenderSystem.disableBlend();
                matrices.method_22909();
            }
        }
    };

    private float calculatePlayerPower(class_1657 player) {
        float power = 0.0f;
        float healthPercent = player.method_6032() / player.method_6063();
        power += healthPercent * 20.0f;
        power += (float)player.method_7344().method_7586() / 2.0f;
        float totalArmorValue = 0.0f;
        float armorDurabilityFactor = 0.0f;
        int armorCount = 0;
        for (class_1799 armor : player.method_5661()) {
            if (armor.method_7960()) continue;
            totalArmorValue += this.getArmorValue(armor);
            totalArmorValue += this.getEnchantmentPower(armor);
            if (!armor.method_7963()) continue;
            int maxDamage = armor.method_7936();
            int damage = armor.method_7919();
            float durabilityPercent = 1.0f - (float)damage / (float)maxDamage;
            armorDurabilityFactor += durabilityPercent;
            ++armorCount;
        }
        if (armorCount > 0) {
            float avgDurability = armorDurabilityFactor / (float)armorCount;
            power += totalArmorValue * avgDurability;
        } else {
            power += totalArmorValue;
        }
        class_1799 mainHand = player.method_6047();
        if (!mainHand.method_7960()) {
            power += this.getWeaponDamage(mainHand);
            power += this.getEnchantmentPower(mainHand);
        }
        if (player.method_6059(class_1294.field_5910)) {
            int amplifier = player.method_6112(class_1294.field_5910).method_5578() + 1;
            power += (float)(amplifier * 5);
        }
        if (player.method_6059(class_1294.field_5907)) {
            int amplifier = player.method_6112(class_1294.field_5907).method_5578() + 1;
            power += (float)(amplifier * 5);
        }
        if (player.method_6059(class_1294.field_5904)) {
            int amplifier = player.method_6112(class_1294.field_5904).method_5578() + 1;
            power += (float)(amplifier * 3);
        }
        if (player.method_6059(class_1294.field_5924)) {
            int amplifier = player.method_6112(class_1294.field_5924).method_5578() + 1;
            power += (float)(amplifier * 4);
        }
        if (player.method_6059(class_1294.field_5911)) {
            int amplifier = player.method_6112(class_1294.field_5911).method_5578() + 1;
            power -= (float)(amplifier * 3);
        }
        if (player.method_6059(class_1294.field_5909)) {
            int amplifier = player.method_6112(class_1294.field_5909).method_5578() + 1;
            power -= (float)(amplifier * 2);
        }
        return Math.max(1.0f, power);
    }

    private float getArmorValue(class_1799 armor) {
        String itemName = armor.method_7909().toString().toLowerCase();
        if (itemName.contains("diamond")) {
            return 3.0f;
        }
        if (itemName.contains("netherite")) {
            return 4.0f;
        }
        if (itemName.contains("iron")) {
            return 2.0f;
        }
        if (itemName.contains("gold")) {
            return 1.5f;
        }
        if (itemName.contains("chain")) {
            return 1.5f;
        }
        return itemName.contains("leather") ? 1.0f : 0.5f;
    }

    private float getWeaponDamage(class_1799 weapon) {
        String itemName = weapon.method_7909().toString().toLowerCase();
        if (itemName.contains("netherite_sword")) {
            return 10.0f;
        }
        if (itemName.contains("diamond_sword")) {
            return 9.0f;
        }
        if (itemName.contains("iron_sword")) {
            return 7.0f;
        }
        if (itemName.contains("gold_sword")) {
            return 5.0f;
        }
        if (itemName.contains("stone_sword")) {
            return 6.0f;
        }
        if (itemName.contains("wood_sword")) {
            return 5.0f;
        }
        if (itemName.contains("netherite_axe")) {
            return 12.0f;
        }
        if (itemName.contains("diamond_axe")) {
            return 11.0f;
        }
        if (itemName.contains("iron_axe")) {
            return 9.0f;
        }
        return itemName.contains("trident") ? 10.0f : 2.0f;
    }

    private float getEnchantmentPower(class_1799 item) {
        float power = 0.0f;
        class_9304 enchantments = (class_9304)item.method_57824(class_9334.field_49633);
        if (enchantments == null) {
            return 0.0f;
        }
        for (class_6880 entry : enchantments.method_57534()) {
            int level = enchantments.method_57536(entry);
            if (entry.method_40225(class_1893.field_9111)) {
                power += (float)(level * 2);
                continue;
            }
            if (entry.method_40225(class_1893.field_9118)) {
                power += (float)level * 2.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9124)) {
                power += (float)level * 1.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9121)) {
                power += (float)level * 1.0f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9097)) {
                power += (float)level * 1.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9107)) {
                power += (float)level * 1.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9096)) {
                power += (float)level * 1.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9095)) {
                power += (float)level * 1.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9129)) {
                power += (float)level * 0.5f;
                continue;
            }
            if (entry.method_40225(class_1893.field_9119)) {
                power += (float)level * 0.5f;
                continue;
            }
            power += (float)level * 0.5f;
        }
        return power;
    }

    private float calculateWinChance(float ourPower, float enemyPower) {
        float total = ourPower + enemyPower;
        if (total == 0.0f) {
            return 50.0f;
        }
        float rawChance = ourPower / total * 100.0f;
        return class_3532.method_15363((float)rawChance, (float)5.0f, (float)95.0f);
    }

    private String formatDamage(float damage) {
        int wholePart = (int)damage;
        int decimalPart = Math.round((damage - (float)wholePart) * 10.0f);
        if (decimalPart == 10) {
            ++wholePart;
            decimalPart = 0;
        }
        return wholePart + "." + decimalPart;
    }

    @Environment(value=EnvType.CLIENT)
    private static class DamageNumber {
        private final class_243 startPos;
        private final float damage;
        private final Animation animation;
        private final long startTime;
        private static final long DURATION = 2000L;

        public DamageNumber(class_243 pos, float damage) {
            this.startPos = pos;
            this.damage = damage;
            this.animation = new Animation(2000L, Easing.CUBIC_OUT);
            this.startTime = System.currentTimeMillis();
        }

        public void update() {
            long elapsed = System.currentTimeMillis() - this.startTime;
            float progress = Math.min(1.0f, (float)elapsed / 2000.0f);
            this.animation.setValue(progress);
        }

        public class_243 getPosition() {
            float progress = this.animation.getValue();
            double yOffset = (double)progress * 1.5;
            return this.startPos.method_1031(0.0, yOffset, 0.0);
        }

        public float getAlpha() {
            float progress = this.animation.getValue();
            return progress > 0.7f ? 1.0f - (progress - 0.7f) / 0.3f : 1.0f;
        }

        public float getScale() {
            float progress = this.animation.getValue();
            return progress < 0.2f ? 0.8f + progress / 0.2f * 0.4f : 1.2f;
        }

        public boolean shouldRemove() {
            return System.currentTimeMillis() - this.startTime >= 2000L;
        }
    }
}

