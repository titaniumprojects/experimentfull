/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.Quaternionf
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.Utils;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Quaternionf;

@ModuleInfo(name="CubeParticle", category=ModuleCategory.VISUALS, desc="\u041a\u0440\u0430\u0441\u0438\u0432\u044b\u0435 \u043a\u0443\u0431\u0438\u043a\u0438, \u043b\u0435\u0442\u0430\u044e\u0449\u0438\u0435 \u043f\u043e \u043c\u0438\u0440\u0443")
@Environment(value=EnvType.CLIENT)
public class World
extends BaseModule {
    private final List<Particle> particles = new ArrayList<Particle>();
    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.world.color_mode");
    private final ModeSetting.Value clientColor = new ModeSetting.Value(this.colorMode, "modules.settings.world.color_mode.client").select();
    private final ModeSetting.Value customColor = new ModeSetting.Value(this.colorMode, "modules.settings.world.color_mode.custom");
    private final ColorSetting color = new ColorSetting(this, "color", () -> !this.customColor.isSelected()).color(Colors.getAccentColor());
    private final EventListener<Render3DEvent> on3DRender = event -> {
        class_4587 ms = event.getMatrices();
        class_4184 camera = World.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        ms.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask((boolean)false);
        class_2960 id = Experiment.id("textures/bloom.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)id);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (Particle particle : this.particles) {
            class_243 pos = Utils.getInterpolatedPos(particle.prev, particle.pos, event.getTickDelta());
            float bigSize = 4.0f * particle.size;
            ms.method_22903();
            RenderUtility.prepareMatrices(ms, pos);
            ms.method_22907(camera.method_23767());
            DrawUtility.drawImage(ms, builder, (double)(-bigSize / 2.0f), (double)(-bigSize / 2.0f), 0.0, (double)bigSize, (double)bigSize, this.getColorValue().withAlpha(255.0f * particle.alpha.getValue() * 0.4f));
            ms.method_22909();
        }
        class_9801 builtLinesBuffer1 = builder.method_60794();
        if (builtLinesBuffer1 != null) {
            class_286.method_43433((class_9801)builtLinesBuffer1);
        }
        RenderSystem.depthMask((boolean)true);
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.disableDepthTest();
        ms.method_22909();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (Particle particle : this.particles) {
            particle.alpha.update(!particle.timer.finished(particle.liveTicks));
            class_243 pos = Utils.getInterpolatedPos(particle.prev, particle.pos, event.getTickDelta());
            class_243 rot = Utils.getInterpolatedPos(particle.prevRot, particle.rotate, event.getTickDelta());
            ms.method_22903();
            ms.method_61958(pos.method_1031(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215()));
            ms.method_22907(new Quaternionf().rotationXYZ((float)rot.field_1352, (float)rot.field_1351, (float)rot.field_1350));
            ms.method_22905(particle.size, particle.size, particle.size);
            Draw3DUtility.renderBoxInternalDiagonals(ms, linesBuffer, new class_238(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5), this.getColorValue().withAlpha(255.0f * particle.alpha.getValue() * 0.4f));
            Draw3DUtility.renderOutlinedBox(ms, linesBuffer, new class_238(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5), this.getColorValue().withAlpha(205.0f * particle.alpha.getValue()));
            ms.method_22909();
        }
        class_9801 builtLinesBuffer = linesBuffer.method_60794();
        if (builtLinesBuffer != null) {
            class_286.method_43433((class_9801)builtLinesBuffer);
        }
        RenderSystem.depthMask((boolean)true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    };

    @Override
    public void tick() {
        this.particles.removeIf(particlex -> particlex.alpha.getValue() == 0.0f && particlex.timer.finished(particlex.liveTicks));
        for (Particle particle : this.particles) {
            particle.tick();
        }
        if (this.particles.size() < 100) {
            this.particles.add(new Particle(World.mc.field_1724.method_19538().method_1031((double)MathUtility.random(-20.0, 20.0), (double)MathUtility.random(0.0, 5.0), (double)MathUtility.random(-20.0, 20.0)), class_243.field_1353, new class_243((double)MathUtility.random(-1.0, 1.0), (double)MathUtility.random(0.0, 2.0), (double)MathUtility.random(-1.0, 1.0)), new class_243((double)MathUtility.random(-1.0, 1.0), (double)MathUtility.random(-1.0, 1.0), (double)MathUtility.random(-1.0, 1.0)), (long)MathUtility.random(1500.0, 4500.0), MathUtility.random(0.1f, 0.3f)));
        }
    }

    private ColorRGBA getColorValue() {
        return this.clientColor.isSelected() ? Colors.getAccentColor() : this.color.getColor();
    }

    @Environment(value=EnvType.CLIENT)
    static class Particle {
        class_243 prev;
        class_243 prevRot;
        class_243 pos;
        class_243 rotate;
        class_243 motion;
        class_243 rotateMotion;
        final long liveTicks;
        float size;
        final Timer timer = new Timer();
        final Animation alpha = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);

        public Particle(class_243 pos, class_243 rotate, class_243 motion, class_243 rotateMotion, long liveTicks, float size) {
            this.pos = pos;
            this.rotate = rotate;
            this.motion = motion.method_1021((double)0.04f);
            this.rotateMotion = rotateMotion.method_1021((double)0.04f);
            this.liveTicks = liveTicks;
            this.size = size;
            this.prevRot = rotate;
            this.prev = pos;
            this.alpha.setDuration(1000L);
        }

        void tick() {
            this.prev = this.pos;
            this.prevRot = this.rotate;
            this.pos = this.pos.method_1019(this.motion);
            this.rotate = this.rotate.method_1019(this.rotateMotion);
            this.motion = this.motion.method_1021(0.98);
            this.rotateMotion = this.rotateMotion.method_1021(0.98);
        }
    }
}

