/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1306
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1839
 *  net.minecraft.class_437
 *  net.minecraft.class_4587
 *  org.joml.Quaternionf
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HandRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.constructions.swinganim.SwingAnimScreen;
import micronix.experiment.systems.modules.constructions.swinganim.SwingTransformations;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ButtonSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1306;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.joml.Quaternionf;

@ModuleInfo(name="Swing Animation", category=ModuleCategory.VISUALS, desc="\u0418\u0437\u043c\u0435\u043d\u044f\u0435\u0442 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438 \u0440\u0443\u043a \u043f\u0440\u0438 \u0432\u0437\u043c\u0430\u0445\u0435")
@Environment(value=EnvType.CLIENT)
public class SwingAnimation
extends BaseModule {
    private final ButtonSetting button = new ButtonSetting(this, "swing.open_menu").action(() -> mc.method_1507((class_437)new SwingAnimScreen()));
    private final EventListener<HandRenderEvent> onHandRender = event -> {
        if (this.isEnabled() && event.getArm() == class_1306.field_6183) {
            class_1799 itemStack = event.getItemStack();
            if (!this.shouldApplyAnimation(itemStack)) {
                return;
            }
            class_4587 matrices = event.getMatrices();
            float swingProgress = event.getSwingProgress();
            SwingTransformations trans = Experiment.getInstance().getSwingManager().transformations(swingProgress);
            matrices.method_46416(trans.getAnchorX(), trans.getAnchorY(), trans.getAnchorZ());
            matrices.method_46416(trans.getMoveX(), trans.getMoveY(), trans.getMoveZ());
            matrices.method_22907(new Quaternionf().rotationXYZ((float)Math.toRadians(trans.getRotateX()), (float)Math.toRadians(trans.getRotateY()), (float)Math.toRadians(trans.getRotateZ())));
            matrices.method_46416(-trans.getAnchorX(), -trans.getAnchorY(), -trans.getAnchorZ());
            event.cancel();
        }
    };

    public boolean shouldApplyAnimation(class_1799 itemStack) {
        class_1792 item = itemStack.method_7909();
        return item != class_1802.field_8162 && item != class_1802.field_8204 && item != class_1802.field_8399 && item != class_1802.field_8102 && item != class_1802.field_8547 && item.method_7853(itemStack) != class_1839.field_8946 && item.method_7853(itemStack) != class_1839.field_8950;
    }
}

