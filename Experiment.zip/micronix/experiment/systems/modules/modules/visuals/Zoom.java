/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Zoom", category=ModuleCategory.VISUALS, desc="modules.descriptions.zoom")
@Environment(value=EnvType.CLIENT)
public class Zoom
extends BaseModule {
    private final BindSetting zoomKey = new BindSetting(this, "modules.settings.zoom.key");
    private final SliderSetting zoomLevel = new SliderSetting(this, "modules.settings.zoom.level").step(0.1f).min(1.0f).max(10.0f).currentValue(4.0f);
    private final BooleanSetting smooth = new BooleanSetting(this, "modules.settings.zoom.smooth").enabled(true);
    private final SliderSetting smoothSpeed = new SliderSetting((SettingsContainer)this, "modules.settings.zoom.smooth_speed", () -> !this.smooth.isEnabled()).step(50.0f).min(100.0f).max(1000.0f).currentValue(300.0f);
    private boolean isZooming = false;
    private final Animation zoomAnimation = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final EventListener<KeyPressEvent> onKeyPress = event -> {
        if (this.zoomKey.isKey(event.getKey()) && Zoom.mc.field_1755 == null) {
            if (event.getAction() == 1) {
                this.isZooming = true;
            } else if (event.getAction() == 0) {
                this.isZooming = false;
            }
        }
    };

    @Override
    public void onEnable() {
        super.onEnable();
        this.zoomAnimation.setDuration((long)this.smoothSpeed.getCurrentValue());
    }

    public void updateZoom() {
        if (this.smooth.isEnabled()) {
            this.zoomAnimation.setDuration((long)this.smoothSpeed.getCurrentValue());
            this.zoomAnimation.update(this.isZooming);
        }
    }

    public float getZoomMultiplier() {
        if (!this.isEnabled()) {
            return 1.0f;
        }
        if (this.smooth.isEnabled()) {
            float progress = this.zoomAnimation.getValue();
            return 1.0f + (this.zoomLevel.getCurrentValue() - 1.0f) * progress;
        }
        return this.isZooming ? this.zoomLevel.getCurrentValue() : 1.0f;
    }

    public boolean isZooming() {
        return this.isZooming;
    }
}

