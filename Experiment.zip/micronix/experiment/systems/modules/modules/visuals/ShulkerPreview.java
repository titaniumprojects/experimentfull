/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_2248
 *  net.minecraft.class_241
 *  net.minecraft.class_243
 *  net.minecraft.class_2480
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_9288
 *  net.minecraft.class_9334
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.Utils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

@ModuleInfo(name="Shulker Preview", category=ModuleCategory.VISUALS, desc="\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0435 \u0448\u0430\u043b\u043a\u0435\u0440\u043e\u0432")
@Environment(value=EnvType.CLIENT)
public class ShulkerPreview
extends BaseModule {
    private final SliderSetting scale = new SliderSetting(this, "\u0420\u0430\u0437\u043c\u0435\u0440").min(0.5f).max(2.0f).step(0.1f).currentValue(1.0f);
    private final SliderSetting maxDistance = new SliderSetting(this, "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f").min(10.0f).max(100.0f).step(5.0f).currentValue(50.0f);
    private final EventListener<PreHudRenderEvent> onHudRender = event -> {
        if (event.getContext() != null && ShulkerPreview.mc.field_1724 != null && ShulkerPreview.mc.field_1687 != null) {
            int totalEntities = 0;
            int shulkerCount = 0;
            int renderedCount = 0;
            int itemEntities = 0;
            int playerEntities = 0;
            for (class_1297 entity : ShulkerPreview.mc.field_1687.method_18112()) {
                class_1799 stack;
                double distance;
                ++totalEntities;
                if (entity instanceof class_1542) {
                    class_1542 itemEntity = (class_1542)entity;
                    ++itemEntities;
                    class_1799 stack2 = itemEntity.method_6983();
                    if (!(class_2248.method_9503((class_1792)stack2.method_7909()) instanceof class_2480)) continue;
                    ++shulkerCount;
                    double distance2 = ShulkerPreview.mc.field_1724.method_19538().method_1022(itemEntity.method_19538());
                    if (!(distance2 <= (double)this.maxDistance.getCurrentValue()) || !this.shouldRenderShulker(stack2)) continue;
                    this.renderDroppedShulkerPreview((PreHudRenderEvent)event, itemEntity, stack2, event.getTickDelta());
                    ++renderedCount;
                    continue;
                }
                if (!(entity instanceof class_1657)) continue;
                class_1657 player = (class_1657)entity;
                ++playerEntities;
                if (player == ShulkerPreview.mc.field_1724 && ShulkerPreview.mc.field_1690.method_31044().method_31034() || (distance = ShulkerPreview.mc.field_1724.method_19538().method_1022(player.method_19538())) > (double)this.maxDistance.getCurrentValue() || !(class_2248.method_9503((class_1792)(stack = player.method_6047()).method_7909()) instanceof class_2480)) continue;
                ++shulkerCount;
                if (!this.shouldRenderShulker(stack)) continue;
                this.renderShulkerPreview((PreHudRenderEvent)event, player, stack, event.getTickDelta());
                ++renderedCount;
            }
        }
    };

    private boolean shouldRenderShulker(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }
        if (!(class_2248.method_9503((class_1792)stack.method_7909()) instanceof class_2480)) {
            return false;
        }
        class_9288 container = (class_9288)stack.method_57824(class_9334.field_49622);
        if (container != null) {
            return container.method_57489().anyMatch(s -> !s.method_7960());
        }
        return stack.method_57826(class_9334.field_49611) ? true : true;
    }

    private void renderShulkerPreview(PreHudRenderEvent event, class_1657 player, class_1799 stack, float tickDelta) {
        double z;
        double y;
        double x = this.interpolate(player.field_6014, player.method_23317(), tickDelta);
        class_241 screenPos = Utils.worldToScreen(new class_243(x, y = this.interpolate(player.field_6036, player.method_23318(), tickDelta) + (double)player.method_17682() + 0.5, z = this.interpolate(player.field_5969, player.method_23321(), tickDelta)));
        if (screenPos != null) {
            this.renderShulkerInventory(event, stack, screenPos.field_1343, screenPos.field_1342, player.method_19538());
        }
    }

    private void renderDroppedShulkerPreview(PreHudRenderEvent event, class_1542 itemEntity, class_1799 stack, float tickDelta) {
        double z;
        double y;
        double x = this.interpolate(itemEntity.field_6014, itemEntity.method_23317(), tickDelta);
        class_241 screenPos = Utils.worldToScreen(new class_243(x, y = this.interpolate(itemEntity.field_6036, itemEntity.method_23318(), tickDelta) + 0.5, z = this.interpolate(itemEntity.field_5969, itemEntity.method_23321(), tickDelta)));
        if (screenPos != null) {
            this.renderShulkerInventory(event, stack, screenPos.field_1343, screenPos.field_1342, itemEntity.method_19538());
        }
    }

    private void renderShulkerInventory(PreHudRenderEvent event, class_1799 shulkerStack, float screenX, float screenY, class_243 entityPos) {
        class_9288 container = (class_9288)shulkerStack.method_57824(class_9334.field_49622);
        List<Object> items = new ArrayList();
        if (container != null) {
            items = container.method_57489().toList();
        }
        while (items.size() < 27) {
            items.add(class_1799.field_8037);
        }
        double distance = ShulkerPreview.mc.field_1724.method_19538().method_1022(entityPos);
        double distanceScale = class_3532.method_15350((double)(1.0 - distance / (double)this.maxDistance.getCurrentValue()), (double)0.3, (double)1.0);
        float finalScale = (float)(distanceScale * (double)this.scale.getCurrentValue());
        float itemSize = 13.0f;
        float gap = 2.0f;
        float paddingX = 7.0f;
        float paddingY = 7.0f;
        int cols = 9;
        int rows = 3;
        float guiWidth = (float)cols * itemSize + (float)(cols - 1) * gap + paddingX * 2.0f;
        float guiHeight = (float)rows * itemSize + (float)(rows - 1) * gap + paddingY * 2.0f;
        float scaledWidth = guiWidth * finalScale;
        float scaledHeight = guiHeight * finalScale;
        float x = screenX - scaledWidth / 2.0f;
        class_4587 matrices = event.getContext().method_51448();
        matrices.method_22903();
        matrices.method_46416(x, screenY, 0.0f);
        matrices.method_22905(finalScale, finalScale, 1.0f);
        ColorRGBA shulkerColor = this.getShulkerColor(shulkerStack);
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        ColorRGBA bgColor = shulkerColor.withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
        float prev = RenderSystem.getShaderColor()[3];
        event.getContext().drawShadow(-5.0f, -5.0f, guiWidth + 10.0f, guiHeight + 10.0f, 15.0f, BorderRadius.all(6.0f), ColorRGBA.BLACK.withAlpha(63.75f));
        if (Interface.showMinimalizm()) {
            ColorRGBA liquidGlassColor = Colors.getLiquidGlassColor();
            ColorRGBA minimColor = liquidGlassColor.mix(shulkerColor, 0.3f);
            event.getContext().drawBlurredRect(0.0f, 0.0f, guiWidth, guiHeight, 11.25f, 7.0f, BorderRadius.all(6.0f), minimColor.withAlpha(255.0f * Interface.minimalizm()));
        }
        if (Interface.showGlass()) {
            event.getContext().drawLiquidGlass(0.0f, 0.0f, guiWidth, guiHeight, 7.0f, Interface.getDistortion(), BorderRadius.all(6.0f), shulkerColor.withAlpha(255.0f * Interface.glass()));
        }
        event.getContext().drawSquircle(0.0f, 0.0f, guiWidth, guiHeight, 7.0f, BorderRadius.all(6.0f), bgColor);
        float startX = paddingX;
        float startY = paddingY;
        for (int index = 0; index < 27; ++index) {
            int row = index / 9;
            int col = index % 9;
            float itemX = startX + (float)col * (itemSize + gap);
            float itemY = startY + (float)row * (itemSize + gap);
            class_1799 item = index < items.size() ? (class_1799)items.get(index) : class_1799.field_8037;
            boolean hasItem = !item.method_7960();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
            event.getContext().drawBlurredRect(itemX, itemY, itemSize, itemSize, 1.25f, BorderRadius.all(1.5f), ColorRGBA.WHITE.withAlpha(255.0f));
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
            ColorRGBA slotBgColor = hasItem ? shulkerColor : shulkerColor.mix(ColorRGBA.BLACK, 0.5f);
            event.getContext().drawRoundedRect(itemX, itemY, itemSize, itemSize, BorderRadius.all(1.5f), slotBgColor);
            event.getContext().drawRoundedBorder(itemX, itemY, itemSize, itemSize, 0.3f, BorderRadius.all(1.5f), shulkerColor.mix(ColorRGBA.WHITE, 0.3f).withAlpha(80.0f));
            if (!hasItem) continue;
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
            event.getContext().drawItem(item, itemX - 11.0f + itemSize / 2.0f + 5.5f, itemY, 0.7f);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
            if (item.method_7947() <= 1) continue;
            String count = String.valueOf(item.method_7947());
            Font countFont = Fonts.REGULAR.getFont(6.0f);
            event.getContext().drawRightText(countFont, count, itemX + itemSize - 2.0f, itemY + itemSize - countFont.height() - 1.0f, Colors.WHITE);
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        matrices.method_22909();
    }

    private double interpolate(double prev, double current, float delta) {
        return prev + (current - prev) * (double)delta;
    }

    private ColorRGBA getShulkerColor(class_1799 shulkerStack) {
        class_2248 block = class_2248.method_9503((class_1792)shulkerStack.method_7909());
        if (block instanceof class_2480) {
            class_2480 shulkerBox = (class_2480)block;
            String blockName = block.method_63499();
            if (blockName.contains("white")) {
                return new ColorRGBA(240.0f, 240.0f, 240.0f, 255.0f);
            }
            if (blockName.contains("orange")) {
                return new ColorRGBA(240.0f, 140.0f, 70.0f, 255.0f);
            }
            if (blockName.contains("magenta")) {
                return new ColorRGBA(190.0f, 80.0f, 190.0f, 255.0f);
            }
            if (blockName.contains("light_blue")) {
                return new ColorRGBA(100.0f, 150.0f, 210.0f, 255.0f);
            }
            if (blockName.contains("yellow")) {
                return new ColorRGBA(240.0f, 220.0f, 60.0f, 255.0f);
            }
            if (blockName.contains("lime")) {
                return new ColorRGBA(110.0f, 190.0f, 30.0f, 255.0f);
            }
            if (blockName.contains("pink")) {
                return new ColorRGBA(240.0f, 160.0f, 180.0f, 255.0f);
            }
            if (blockName.contains("gray")) {
                return new ColorRGBA(70.0f, 70.0f, 70.0f, 255.0f);
            }
            if (blockName.contains("light_gray")) {
                return new ColorRGBA(150.0f, 150.0f, 150.0f, 255.0f);
            }
            if (blockName.contains("cyan")) {
                return new ColorRGBA(40.0f, 120.0f, 140.0f, 255.0f);
            }
            if (blockName.contains("purple")) {
                return new ColorRGBA(130.0f, 50.0f, 180.0f, 255.0f);
            }
            if (blockName.contains("blue")) {
                return new ColorRGBA(50.0f, 60.0f, 170.0f, 255.0f);
            }
            if (blockName.contains("brown")) {
                return new ColorRGBA(120.0f, 80.0f, 50.0f, 255.0f);
            }
            if (blockName.contains("green")) {
                return new ColorRGBA(80.0f, 100.0f, 30.0f, 255.0f);
            }
            if (blockName.contains("red")) {
                return new ColorRGBA(160.0f, 40.0f, 40.0f, 255.0f);
            }
            return blockName.contains("black") ? new ColorRGBA(30.0f, 30.0f, 30.0f, 255.0f) : new ColorRGBA(140.0f, 90.0f, 140.0f, 255.0f);
        }
        return Colors.getBackgroundColor();
    }
}

