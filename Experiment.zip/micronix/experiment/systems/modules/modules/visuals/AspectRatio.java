/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Aspect Ratio", category=ModuleCategory.VISUALS, desc="modules.descriptions.aspect_ratio")
@Environment(value=EnvType.CLIENT)
public class AspectRatio
extends BaseModule {
    private final SliderSetting ratio = new SliderSetting(this, "modules.settings.aspect_ratio.ratio").step(0.001f).min(0.5f).max(5.0f).currentValue(1.7777f);
    private static final ThreadLocal<Boolean> renderingHands = ThreadLocal.withInitial(() -> false);

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    public float getRatio() {
        return this.ratio.getCurrentValue();
    }

    public static void setRenderingHands(boolean rendering) {
        renderingHands.set(rendering);
    }

    public static boolean isRenderingHands() {
        return renderingHands.get();
    }
}

