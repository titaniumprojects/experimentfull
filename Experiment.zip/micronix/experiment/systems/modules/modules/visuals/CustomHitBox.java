/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_3966
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.visuals;

import java.util.HashMap;
import java.util.Map;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.Hitboxes;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.render.Utils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_9801;

@ModuleInfo(name="Custom HitBox", category=ModuleCategory.VISUALS, desc="modules.descriptions.custom_hitbox")
@Environment(value=EnvType.CLIENT)
public class CustomHitBox
extends BaseModule {
    private final BooleanSetting animation = new BooleanSetting(this, "\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f").enable();
    private final BooleanSetting removeExtra = new BooleanSetting(this, "\u0423\u0431\u0440\u0430\u0442\u044c \u043b\u0438\u0448\u043d\u0435\u0435");
    private final ColorSetting friendColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u0434\u0440\u0443\u0433\u0430").color(new ColorRGBA(0.0f, 255.0f, 0.0f, 255.0f));
    private final ColorSetting playerColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u0438\u0433\u0440\u043e\u043a\u0430").color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f));
    private final BooleanSetting hoverHighlight = new BooleanSetting(this, "\u041f\u043e\u0434\u0441\u0432\u0435\u0442\u043a\u0430 \u043f\u0440\u0438 \u043d\u0430\u0432\u043e\u0434\u043a\u0435");
    private final ColorSetting hoverColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u043d\u0430\u0432\u043e\u0434\u043a\u0438", () -> !this.hoverHighlight.isEnabled()).color(new ColorRGBA(0.0f, 255.0f, 255.0f, 255.0f));
    private final BooleanSetting hitAnimation = new BooleanSetting(this, "\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f \u043f\u0440\u0438 \u0443\u0434\u0430\u0440\u0435").enable();
    private final ColorSetting hitColorPicker = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u0443\u0434\u0430\u0440\u0430", () -> !this.hitAnimation.isEnabled()).color(new ColorRGBA(255.0f, 0.0f, 0.0f, 255.0f));
    private final SliderSetting hitTime = new SliderSetting((SettingsContainer)this, "\u0412\u0440\u0435\u043c\u044f \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438", () -> !this.hitAnimation.isEnabled()).min(200.0f).max(2000.0f).step(50.0f).currentValue(800.0f);
    private final SliderSetting fadeStart = new SliderSetting((SettingsContainer)this, "\u041d\u0430\u0447\u0430\u043b\u043e \u0437\u0430\u0442\u0443\u0445\u0430\u043d\u0438\u044f", () -> !this.hitAnimation.isEnabled()).min(20.0f).max(80.0f).step(5.0f).currentValue(50.0f);
    private final BooleanSetting outlineEnabled = new BooleanSetting(this, "\u041e\u0431\u0432\u043e\u0434\u043a\u0430").enable();
    private final ColorSetting outlineColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u043e\u0431\u0432\u043e\u0434\u043a\u0438", () -> !this.outlineEnabled.isEnabled()).color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f));
    private final BooleanSetting fillEnabled = new BooleanSetting(this, "\u0417\u0430\u043b\u0438\u0432\u043a\u0430");
    private final ColorSetting fillColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u0437\u0430\u043b\u0438\u0432\u043a\u0438", () -> !this.fillEnabled.isEnabled()).color(new ColorRGBA(255.0f, 255.0f, 255.0f, 100.0f));
    private final SliderSetting fillAlpha = new SliderSetting((SettingsContainer)this, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u0437\u0430\u043b\u0438\u0432\u043a\u0438", () -> !this.fillEnabled.isEnabled()).min(0.0f).max(255.0f).step(1.0f).currentValue(100.0f);
    private final Map<class_1297, Animation> scaleAnimations = new HashMap<class_1297, Animation>();
    private final Map<class_1297, HitAnimationData> hitAnimations = new HashMap<class_1297, HitAnimationData>();
    private final Map<class_1297, Animation> hoverAnimations = new HashMap<class_1297, Animation>();
    private class_1297 hoveredEntity = null;
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (CustomHitBox.mc.field_1724 == null || CustomHitBox.mc.field_1687 == null) {
            return;
        }
        Hitboxes hitboxModule = Experiment.getInstance().getModuleManager().getModule(Hitboxes.class);
        if (hitboxModule == null || !hitboxModule.isEnabled()) {
            return;
        }
        this.updateHoveredEntity();
        class_4587 matrices = event.getMatrices();
        for (class_1297 entity2 : CustomHitBox.mc.field_1687.method_18112()) {
            HitAnimationData hitData;
            class_1309 livingEntity;
            if (!(entity2 instanceof class_1309) || !hitboxModule.shouldModifyHitbox(livingEntity = (class_1309)entity2) || entity2.method_5628() == CustomHitBox.mc.field_1724.method_5628()) continue;
            Animation scaleAnim = this.scaleAnimations.computeIfAbsent(entity2, e -> {
                Animation anim = new Animation(300L, Easing.CUBIC_OUT);
                anim.setValue(0.0f);
                return anim;
            });
            if (this.animation.isEnabled()) {
                scaleAnim.update(1.0f);
            } else {
                scaleAnim.setValue(1.0f);
            }
            Animation hoverAnim = this.hoverAnimations.computeIfAbsent(entity2, e -> new Animation(200L, Easing.CUBIC_OUT));
            if (this.hoverHighlight.isEnabled() && entity2 == this.hoveredEntity) {
                hoverAnim.update(1.0f);
            } else {
                hoverAnim.update(0.0f);
            }
            float scale = hitboxModule.getScale().getCurrentValue();
            float animatedScale = scale * scaleAnim.getValue();
            class_238 originalBox = entity2.method_5829();
            class_238 expandedBox = new class_238(originalBox.field_1323 - (double)animatedScale, originalBox.field_1322, originalBox.field_1321 - (double)animatedScale, originalBox.field_1320 + (double)animatedScale, originalBox.field_1325, originalBox.field_1324 + (double)animatedScale);
            class_243 pos = Utils.getInterpolatedPos(entity2, event.getTickDelta());
            class_243 cameraPos = CustomHitBox.mc.field_1773.method_19418().method_19326();
            matrices.method_22903();
            matrices.method_22904(pos.field_1352 - entity2.method_23317() - cameraPos.field_1352, pos.field_1351 - entity2.method_23318() - cameraPos.field_1351, pos.field_1350 - entity2.method_23321() - cameraPos.field_1350);
            ColorRGBA baseColor = this.getEntityColor(entity2);
            if (hoverAnim.getValue() > 0.0f) {
                baseColor = this.mixColors(baseColor, this.hoverColor.getColor(), hoverAnim.getValue());
            }
            if ((hitData = this.hitAnimations.get(entity2)) != null && hitData.isActive()) {
                float hitAlpha = hitData.getAlpha();
                baseColor = this.mixColors(baseColor, this.hitColorPicker.getColor(), hitAlpha);
            }
            if (this.fillEnabled.isEnabled()) {
                ColorRGBA fillCol = this.fillColor.getColor();
                ColorRGBA fillWithAlpha = new ColorRGBA((int)fillCol.getRed(), (int)fillCol.getGreen(), (int)fillCol.getBlue(), (int)this.fillAlpha.getCurrentValue());
                if (hitData != null && hitData.isActive()) {
                    float hitAlpha = hitData.getAlpha();
                    fillWithAlpha = this.mixColors(fillWithAlpha, this.hitColorPicker.getColor(), hitAlpha * 0.5f);
                }
                class_287 fillBuffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
                Draw3DUtility.renderFilledBox(matrices, fillBuffer, expandedBox, fillWithAlpha);
                class_286.method_43433((class_9801)fillBuffer.method_60800());
            }
            if (this.outlineEnabled.isEnabled()) {
                class_287 lineBuffer = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
                Draw3DUtility.renderOutlinedBox(matrices, lineBuffer, expandedBox, baseColor);
                class_286.method_43433((class_9801)lineBuffer.method_60800());
            }
            matrices.method_22909();
        }
        this.scaleAnimations.keySet().removeIf(class_1297::method_31481);
        this.hitAnimations.keySet().removeIf(entity -> entity.method_31481() || !this.hitAnimations.get(entity).isActive());
        this.hoverAnimations.keySet().removeIf(class_1297::method_31481);
    };
    private final EventListener<AttackEvent> onAttack = event -> {
        if (!this.hitAnimation.isEnabled()) {
            return;
        }
        class_1297 target = event.getEntity();
        if (target != null) {
            long duration = (long)this.hitTime.getCurrentValue();
            float fadeStart = this.fadeStart.getCurrentValue();
            this.hitAnimations.put(target, new HitAnimationData(duration, fadeStart));
        }
    };

    private void updateHoveredEntity() {
        this.hoveredEntity = null;
        if (!this.hoverHighlight.isEnabled()) {
            return;
        }
        class_239 class_2392 = CustomHitBox.mc.field_1765;
        if (class_2392 instanceof class_3966) {
            class_3966 entityHit = (class_3966)class_2392;
            this.hoveredEntity = entityHit.method_17782();
        }
    }

    private ColorRGBA getEntityColor(class_1297 entity) {
        if (!(entity instanceof class_1657)) {
            return this.outlineEnabled.isEnabled() ? this.outlineColor.getColor() : Colors.ACCENT;
        }
        String playerName = entity.method_5477().getString();
        boolean isFriend = Experiment.getInstance().getFriendManager().isFriend(playerName);
        return isFriend ? this.friendColor.getColor() : this.playerColor.getColor();
    }

    private ColorRGBA mixColors(ColorRGBA color1, ColorRGBA color2, float factor) {
        factor = Math.max(0.0f, Math.min(1.0f, factor));
        return new ColorRGBA((int)(color1.getRed() * (1.0f - factor) + color2.getRed() * factor), (int)(color1.getGreen() * (1.0f - factor) + color2.getGreen() * factor), (int)(color1.getBlue() * (1.0f - factor) + color2.getBlue() * factor), (int)(color1.getAlpha() * (1.0f - factor) + color2.getAlpha() * factor));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.scaleAnimations.clear();
        this.hitAnimations.clear();
        this.hoverAnimations.clear();
        this.hoveredEntity = null;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.scaleAnimations.clear();
        this.hitAnimations.clear();
        this.hoverAnimations.clear();
        this.hoveredEntity = null;
    }

    public BooleanSetting getAnimation() {
        return this.animation;
    }

    public BooleanSetting getRemoveExtra() {
        return this.removeExtra;
    }

    public ColorSetting getFriendColor() {
        return this.friendColor;
    }

    public ColorSetting getPlayerColor() {
        return this.playerColor;
    }

    public BooleanSetting getHoverHighlight() {
        return this.hoverHighlight;
    }

    public ColorSetting getHoverColor() {
        return this.hoverColor;
    }

    public BooleanSetting getHitAnimation() {
        return this.hitAnimation;
    }

    public ColorSetting getHitColorPicker() {
        return this.hitColorPicker;
    }

    public SliderSetting getHitTime() {
        return this.hitTime;
    }

    public SliderSetting getFadeStart() {
        return this.fadeStart;
    }

    public BooleanSetting getOutlineEnabled() {
        return this.outlineEnabled;
    }

    public ColorSetting getOutlineColor() {
        return this.outlineColor;
    }

    public BooleanSetting getFillEnabled() {
        return this.fillEnabled;
    }

    public ColorSetting getFillColor() {
        return this.fillColor;
    }

    public SliderSetting getFillAlpha() {
        return this.fillAlpha;
    }

    @Environment(value=EnvType.CLIENT)
    private static class HitAnimationData {
        long startTime = System.currentTimeMillis();
        long duration;
        float fadeStartPercent;

        HitAnimationData(long duration, float fadeStartPercent) {
            this.duration = duration;
            this.fadeStartPercent = fadeStartPercent;
        }

        boolean isActive() {
            return System.currentTimeMillis() - this.startTime < this.duration;
        }

        float getProgress() {
            long elapsed = System.currentTimeMillis() - this.startTime;
            return Math.min(1.0f, (float)elapsed / (float)this.duration);
        }

        float getAlpha() {
            float fadeStartPoint;
            float progress = this.getProgress();
            if (progress < (fadeStartPoint = this.fadeStartPercent / 100.0f)) {
                return 1.0f;
            }
            float fadeProgress = (progress - fadeStartPoint) / (1.0f - fadeStartPoint);
            return 1.0f - fadeProgress;
        }
    }
}

