/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_2338
 *  net.minecraft.class_2374
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.GameTickEvent;
import micronix.experiment.systems.event.impl.game.TotemLossEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.render.Draw3DUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;

@ModuleInfo(name="Jump Circle", category=ModuleCategory.VISUALS, desc="modules.descriptions.jumpcircle")
@Environment(value=EnvType.CLIENT)
public class JumpCircle
extends BaseModule {
    private final List<WaveEffect> waves = new ArrayList<WaveEffect>();
    private final BooleanSetting syncWithTheme = new BooleanSetting(this, "modules.settings.jumpcircle.sync_with_theme").enabled(true);
    private final ColorSetting color = new ColorSetting(this, "modules.settings.jumpcircle.color", () -> this.syncWithTheme.isEnabled()).color(Colors.getAccentColor()).alpha(true);
    private final ColorSetting totemColor = new ColorSetting(this, "modules.settings.jumpcircle.totem_color", () -> this.syncWithTheme.isEnabled()).color(new ColorRGBA(255.0f, 215.0f, 0.0f, 255.0f)).alpha(true);
    private boolean wasOnGround = true;
    private final EventListener<GameTickEvent> onTick = event -> {
        if (JumpCircle.mc.field_1724 == null) {
            return;
        }
        boolean onGround = JumpCircle.mc.field_1724.method_24828();
        if (this.wasOnGround && !onGround && JumpCircle.mc.field_1724.method_18798().field_1351 > 0.0) {
            class_243 pos = JumpCircle.mc.field_1724.method_19538();
            ColorRGBA effectColor = this.syncWithTheme.isEnabled() ? Colors.getAccentColor() : this.color.getColor();
            this.waves.add(new WaveEffect(pos, effectColor));
        }
        this.wasOnGround = onGround;
    };
    private final EventListener<TotemLossEvent> onTotemLoss = event -> {
        if (event.getPlayer() != null) {
            class_243 pos = event.getPlayer().method_19538();
            ColorRGBA effectColor = this.syncWithTheme.isEnabled() ? Colors.getAccentColor() : this.totemColor.getColor();
            this.waves.add(new WaveEffect(pos, effectColor));
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (!this.waves.isEmpty()) {
            class_4587 ms = event.getMatrices();
            class_4184 camera = JumpCircle.mc.field_1773.method_19418();
            class_243 cameraPos = camera.method_19326();
            ms.method_22903();
            ms.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.enableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            class_287 fillBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
            for (WaveEffect wave : this.waves) {
                wave.renderFill(fillBuffer, ms);
            }
            class_9801 fillBuilt = fillBuffer.method_60794();
            if (fillBuilt != null) {
                class_286.method_43433((class_9801)fillBuilt);
            }
            class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
            for (WaveEffect wave : this.waves) {
                wave.renderOutline(linesBuffer, ms);
            }
            class_9801 linesBuilt = linesBuffer.method_60794();
            if (linesBuilt != null) {
                class_286.method_43433((class_9801)linesBuilt);
            }
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
            ms.method_22909();
            this.waves.removeIf(wavex -> wavex.animation.getValue() >= 1.0f);
        }
    };

    @Override
    public void onDisable() {
        this.waves.clear();
    }

    @Environment(value=EnvType.CLIENT)
    static class WaveEffect {
        final class_243 centerPos;
        final ColorRGBA color;
        final Animation animation = new Animation(1200L, 0.0f, Easing.LINEAR);
        final List<BlockOutline> blocks = new ArrayList<BlockOutline>();
        final int maxRadius = 15;

        public WaveEffect(class_243 pos, ColorRGBA color) {
            this.centerPos = pos;
            this.color = color;
            this.animation.update(true);
            class_2338 centerBlock = class_2338.method_49638((class_2374)pos);
            for (int x = -15; x <= 15; ++x) {
                for (int z = -15; z <= 15; ++z) {
                    double distance = Math.sqrt(x * x + z * z);
                    if (!(distance <= 15.0) || !(distance >= 1.0)) continue;
                    class_2338 foundPos = null;
                    for (int y = 3; y >= -10; --y) {
                        class_2338 checkPos = centerBlock.method_10069(x, y, z);
                        if (IMinecraft.mc.field_1687 == null || IMinecraft.mc.field_1687.method_8320(checkPos).method_26215()) continue;
                        foundPos = checkPos;
                        break;
                    }
                    if (foundPos == null) continue;
                    this.blocks.add(new BlockOutline(foundPos, distance));
                }
            }
        }

        void renderFill(class_287 builder, class_4587 ms) {
            this.animation.update(true);
            float progress = this.animation.getValue();
            float currentRadius = progress * 15.0f;
            float waveThickness = 1.0f;
            for (BlockOutline block : this.blocks) {
                float distDiff = Math.abs((float)block.distance - currentRadius);
                if (distDiff > waveThickness) continue;
                float alpha = 1.0f - distDiff / waveThickness;
                alpha = (float)Math.pow(alpha, 0.5);
                float fadeOut = 1.0f;
                if (progress > 0.7f) {
                    fadeOut = 1.0f - (progress - 0.7f) / 0.3f;
                }
                if ((alpha *= fadeOut) <= 0.05f) continue;
                float scale = 1.0f;
                if (progress > 0.7f) {
                    scale = 0.5f + 0.5f * fadeOut;
                }
                class_243 center = block.pos.method_46558();
                double halfSize = 0.5 * (double)scale;
                class_238 box = new class_238(center.field_1352 - halfSize, center.field_1351 - halfSize, center.field_1350 - halfSize, center.field_1352 + halfSize, center.field_1351 + halfSize, center.field_1350 + halfSize);
                Draw3DUtility.renderFilledBox(ms, builder, box, this.color.withAlpha(alpha * 40.0f));
            }
        }

        void renderOutline(class_287 builder, class_4587 ms) {
            this.animation.update(true);
            float progress = this.animation.getValue();
            float currentRadius = progress * 15.0f;
            float waveThickness = 1.0f;
            for (BlockOutline block : this.blocks) {
                float distDiff = Math.abs((float)block.distance - currentRadius);
                if (distDiff > waveThickness) continue;
                float alpha = 1.0f - distDiff / waveThickness;
                alpha = (float)Math.pow(alpha, 0.5);
                float fadeOut = 1.0f;
                if (progress > 0.7f) {
                    fadeOut = 1.0f - (progress - 0.7f) / 0.3f;
                }
                if ((alpha *= fadeOut) <= 0.05f) continue;
                float scale = 1.0f;
                if (progress > 0.7f) {
                    scale = 0.5f + 0.5f * fadeOut;
                }
                class_243 center = block.pos.method_46558();
                double halfSize = 0.5 * (double)scale;
                class_238 box = new class_238(center.field_1352 - halfSize, center.field_1351 - halfSize, center.field_1350 - halfSize, center.field_1352 + halfSize, center.field_1351 + halfSize, center.field_1350 + halfSize);
                Draw3DUtility.renderOutlinedBox(ms, builder, box, this.color.withAlpha(alpha * 255.0f));
            }
        }
    }

    @Environment(value=EnvType.CLIENT)
    static class BlockOutline {
        final class_2338 pos;
        final double distance;

        public BlockOutline(class_2338 pos, double distance) {
            this.pos = pos;
            this.distance = distance;
        }
    }
}

