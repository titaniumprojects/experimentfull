/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1309
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.Chinahat;
import micronix.experiment.utility.render.RenderUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;

@ModuleInfo(name="China Hat", desc="modules.descriptions.chinahat", category=ModuleCategory.VISUALS)
@Environment(value=EnvType.CLIENT)
public class ChinahatModule
extends BaseModule {
    private final SliderSetting heightOffset = new SliderSetting(this, "modules.settings.chinahat.height_offset").min(-0.5f).max(0.5f).step(0.05f).currentValue(0.1f);
    private final SliderSetting width = new SliderSetting(this, "modules.settings.chinahat.width").min(0.2f).max(3.0f).step(0.1f).currentValue(0.7f);
    private final SliderSetting height = new SliderSetting(this, "modules.settings.chinahat.height").min(0.05f).max(0.8f).step(0.05f).currentValue(0.25f);
    private final BooleanSetting syncWithTheme = new BooleanSetting(this, "modules.settings.chinahat.sync_with_theme").enabled(true);
    private final ColorSetting color = new ColorSetting(this, "modules.settings.chinahat.color", () -> this.syncWithTheme.isEnabled()).color(new ColorRGBA(100.0f, 150.0f, 200.0f, 255.0f)).alpha(true);
    private final SliderSetting alpha = new SliderSetting(this, "modules.settings.chinahat.alpha").min(0.0f).max(1.0f).step(0.05f).currentValue(0.85f);
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (ChinahatModule.mc.field_1687 != null && ChinahatModule.mc.field_1724 != null) {
            RenderUtility.setupRender3D(true);
            Chinahat.render((class_1309)ChinahatModule.mc.field_1724, event.getMatrices(), ChinahatModule.mc.field_1773.method_19418(), event.getTickDelta(), this.width.getCurrentValue(), this.height.getCurrentValue(), this.syncWithTheme.isEnabled() ? Colors.getAccentColor() : this.color.getColor(), 0.3f + this.alpha.getCurrentValue() * 0.7f, true, this.heightOffset.getCurrentValue());
            RenderUtility.endRender3D();
        }
    };

    public SliderSetting getWidth() {
        return this.width;
    }

    public SliderSetting getHeight() {
        return this.height;
    }

    public ColorSetting getColor() {
        return this.color;
    }

    public SliderSetting getAlpha() {
        return this.alpha;
    }

    public SliderSetting getHeightOffset() {
        return this.heightOffset;
    }
}

