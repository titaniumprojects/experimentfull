/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_4184
 *  net.minecraft.class_5636
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.RangeSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_5636;

@ModuleInfo(name="Custom Fog", category=ModuleCategory.VISUALS)
@Environment(value=EnvType.CLIENT)
public class CustomFog
extends BaseModule {
    private final RangeSetting distance = new RangeSetting(this, "modules.settings.custom_fog.distance").min(1.0f).max(100.0f).step(1.0f).firstValue(10.0f).secondValue(50.0f);
    private final BooleanSetting syncWithTheme = new BooleanSetting(this, "modules.settings.custom_fog.sync_with_theme").enabled(true);
    private final ColorSetting fogColor = new ColorSetting(this, "modules.settings.custom_fog.color", () -> this.syncWithTheme.isEnabled()).color(Colors.getAccentColor()).alpha(true);

    public boolean shouldModifyFog(class_4184 camera) {
        if (this.isEnabled() && CustomFog.mc.field_1687 != null && CustomFog.mc.field_1724 != null) {
            class_1297 entity = camera.method_19331();
            if (camera.method_19334() == class_5636.field_27886) {
                return false;
            }
            if (camera.method_19334() == class_5636.field_27885) {
                return false;
            }
            if (camera.method_19334() == class_5636.field_27887) {
                return false;
            }
            if (entity instanceof class_1309) {
                class_1309 livingEntity = (class_1309)entity;
                if (livingEntity.method_6059(class_1294.field_5919)) {
                    return false;
                }
                if (livingEntity.method_6059(class_1294.field_5925)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public RangeSetting getDistance() {
        return this.distance;
    }

    public ColorSetting getFogColor() {
        return this.fogColor;
    }

    public ColorRGBA getFogColorValue() {
        return this.syncWithTheme.isEnabled() ? Colors.getAccentColor() : this.fogColor.getColor();
    }
}

