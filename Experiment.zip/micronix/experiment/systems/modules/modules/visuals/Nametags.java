/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.Message
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1309
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_241
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_290
 *  net.minecraft.class_308
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_408
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.brigadier.Message;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.ChatRenderEvent;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.event.impl.window.ChatClickEvent;
import micronix.experiment.systems.friends.FriendManager;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.other.NameProtect;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.target.TargetManager;
import micronix.experiment.ui.components.popup.Popup;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.ItemUtility;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.render.Utils;
import micronix.experiment.utility.render.batching.Batching;
import micronix.experiment.utility.render.batching.impl.FontBatching;
import micronix.experiment.utility.render.batching.impl.RectBatching;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_290;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_5250;

@ModuleInfo(name="Name Tags", category=ModuleCategory.VISUALS, enabledByDefault=true, desc="\u0422\u0435\u0433\u0438, \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u044e\u0449\u0438\u0435 \u0438\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044e \u043e \u0441\u0443\u0449\u043d\u043e\u0441\u0442\u044f\u0445")
@Environment(value=EnvType.CLIENT)
public class Nametags
extends BaseModule {
    private final List<class_1297> entityList = new ArrayList<class_1297>();
    private final BooleanSetting armor = new BooleanSetting(this, "modules.settings.name_tags.armor");
    private final BooleanSetting offFriends = new BooleanSetting(this, "modules.settings.name_tags.offFriends");
    private final BooleanSetting items = new BooleanSetting(this, "modules.settings.name_tags.items");
    private final BooleanSetting backItems = new BooleanSetting((SettingsContainer)this, "modules.settings.name_tags.background", () -> !this.items.isEnabled());
    private final EventListener<PreHudRenderEvent> onHudRenderEvent = event -> {
        class_241 screenPos;
        class_243 pos;
        class_241 screenPos2;
        class_243 pos2;
        class_4587 matrices = event.getContext().method_51448();
        float tickDelta = event.getTickDelta();
        class_243 cameraPos = Nametags.mc.field_1773.method_19418().method_19326();
        this.entityList.clear();
        for (class_1297 entity : Nametags.mc.field_1687.method_18112()) {
            if (entity == Nametags.mc.field_1724 || entity.method_5864() != class_1299.field_6097 && entity.method_5864() != class_1299.field_6052) continue;
            if (entity instanceof class_1657) {
                class_1657 player = (class_1657)entity;
                if (Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString()) && this.offFriends.isEnabled()) continue;
            }
            this.entityList.add(entity);
        }
        LinkedList<List<class_1542>> itemGroups = new LinkedList<List<class_1542>>();
        HashSet<class_1542> processedItems = new HashSet<class_1542>();
        for (class_1297 class_12972 : this.entityList) {
            class_1542 item;
            if (!(class_12972 instanceof class_1542) || processedItems.contains(item = (class_1542)class_12972)) continue;
            List<class_1542> group = new LinkedList<class_1542>();
            for (class_1297 other : this.entityList) {
                class_1542 otherItem;
                if (!(other instanceof class_1542) || processedItems.contains(otherItem = (class_1542)other) || !(item.method_5858((class_1297)otherItem) < 1.0)) continue;
                group.add(otherItem);
                processedItems.add(otherItem);
            }
            itemGroups.add(group);
        }
        RectBatching rect = new RectBatching(class_290.field_1576, event.getContext().method_51448());
        this.drawBack((PreHudRenderEvent)event, (List<List<class_1542>>)itemGroups, tickDelta);
        ((Batching)rect).draw();
        for (class_1297 entity : this.entityList) {
            pos2 = Utils.getInterpolatedPos(entity, tickDelta).method_1031(0.0, entity.method_5829().method_17940() + 0.5, 0.0);
            screenPos2 = Utils.worldToScreen(pos2);
            if (screenPos2 == null || entity.method_5864() != class_1299.field_6097 || !this.armor.isEnabled()) continue;
            this.renderArmorPlayer((PreHudRenderEvent)event, matrices, (class_1657)entity, screenPos2);
        }
        for (class_1297 entity : this.entityList) {
            pos2 = Utils.getInterpolatedPos(entity, tickDelta).method_1031(0.0, entity.method_5829().method_17940() + 0.5, 0.0);
            screenPos2 = Utils.worldToScreen(pos2);
            if (screenPos2 == null || entity.method_5864() != class_1299.field_6052) continue;
            this.renderShulkerDisplay((PreHudRenderEvent)event, matrices, (class_1542)entity, screenPos2);
        }
        class_308.method_24210();
        event.getContext().method_51452();
        FontBatching fontBatching = new FontBatching(class_290.field_1575, Fonts.MEDIUM);
        for (class_1297 entity : this.entityList) {
            pos = Utils.getInterpolatedPos(entity, tickDelta).method_1031(0.0, entity.method_5829().method_17940() + 0.5, 0.0);
            screenPos = Utils.worldToScreen(pos);
            if (screenPos == null || entity.method_5864() != class_1299.field_6097) continue;
            this.renderNametagPlayer((PreHudRenderEvent)event, matrices, entity, screenPos);
        }
        for (List<class_1542> group : itemGroups) {
            class_1542 first = (class_1542)group.getFirst();
            class_243 pos3 = Utils.getInterpolatedPos((class_1297)first, tickDelta).method_1031(0.0, first.method_5829().method_17940() + 0.5, 0.0);
            class_241 screenPos3 = Utils.worldToScreen(pos3);
            if (screenPos3 == null || !this.items.isEnabled()) continue;
            if (group.size() > 1) {
                this.renderItemsText((PreHudRenderEvent)event, matrices, group, screenPos3);
                continue;
            }
            this.renderItemText((PreHudRenderEvent)event, matrices, first, screenPos3);
        }
        for (class_1297 entity : this.entityList) {
            pos = Utils.getInterpolatedPos(entity, tickDelta).method_1031(0.0, entity.method_5829().method_17940() + 0.5, 0.0);
            screenPos = Utils.worldToScreen(pos);
            if (screenPos == null || entity.method_5864() != class_1299.field_6052) continue;
            this.renderShulkerText((PreHudRenderEvent)event, matrices, (class_1542)entity, screenPos);
        }
        fontBatching.draw();
        if (!(Nametags.mc.field_1755 instanceof class_408)) {
            this.active = null;
        }
    };
    private Popup active;
    private final EventListener<ChatRenderEvent> onRender = event -> {
        UIContext context = UIContext.of(event.getContext(), Nametags.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32118(), Nametags.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32119(), class_310.method_1551().method_61966().method_60637(false));
        if (this.active != null) {
            this.active.render(context);
        }
    };
    private final EventListener<ChatClickEvent> onClick = event -> {
        if (this.active != null) {
            this.active.onMouseClicked(event.getX(), event.getY(), MouseButton.fromButtonIndex(event.getButton()));
            if (this.active.isHovered(event.getX(), event.getY())) {
                return;
            }
            this.active.setShowing(false);
        }
        for (class_1297 entity : this.entityList) {
            class_243 pos = Utils.getInterpolatedPos(entity, 1.0f).method_1031(0.0, entity.method_5829().method_17940() + 0.5, 0.0);
            class_241 screenPos = Utils.worldToScreen(pos);
            if (screenPos == null || entity.method_5864() != class_1299.field_6097) continue;
            this.handleClick((ChatClickEvent)event, entity, screenPos);
        }
    };

    private void drawBack(PreHudRenderEvent event, List<List<class_1542>> itemGroups, float tickDelta) {
        class_241 screenPos;
        class_243 pos;
        class_4587 matrices = event.getContext().method_51448();
        for (class_1297 class_12972 : this.entityList) {
            pos = Utils.getInterpolatedPos(class_12972, tickDelta).method_1031(0.0, class_12972.method_5829().method_17940() + 0.5, 0.0);
            screenPos = Utils.worldToScreen(pos);
            if (screenPos == null || class_12972.method_5864() != class_1299.field_6097) continue;
            this.renderBack(event, matrices, class_12972, screenPos);
        }
        for (List list : itemGroups) {
            class_1542 first = (class_1542)list.getFirst();
            class_243 pos2 = Utils.getInterpolatedPos((class_1297)first, tickDelta).method_1031(0.0, first.method_5829().method_17940() + 0.5, 0.0);
            class_241 screenPos2 = Utils.worldToScreen(pos2);
            if (screenPos2 == null || !this.backItems.isEnabled() || !this.items.isEnabled()) continue;
            if (list.size() > 1) {
                this.renderItemsBack(event, matrices, list, screenPos2);
                continue;
            }
            this.renderItemBack(event, matrices, first, screenPos2);
        }
        for (class_1297 class_12973 : this.entityList) {
            pos = Utils.getInterpolatedPos(class_12973, tickDelta).method_1031(0.0, class_12973.method_5829().method_17940() + 0.5, 0.0);
            screenPos = Utils.worldToScreen(pos);
            if (screenPos == null || class_12973.method_5864() != class_1299.field_6052) continue;
            this.renderShulkerBack(event, matrices, (class_1542)class_12973, screenPos);
        }
    }

    private void renderItemBack(PreHudRenderEvent event, class_4587 matrices, class_1542 entity, class_241 screenPos) {
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        String text = entity.method_6983().method_7964().getString() + " " + entity.method_6983().method_7947() + "x";
        int textWidth = (int)Fonts.MEDIUM.getFont(11.0f).width(text);
        int x = -textWidth / 2;
        int y = 5;
        event.getContext().drawRect(x - 3, y - 3, textWidth + 6, Fonts.MEDIUM.getFont(11.0f).height() + 6.0f, new ColorRGBA(0.0f, 0.0f, 0.0f, 100.0f));
        matrices.method_22909();
    }

    private void renderItemText(PreHudRenderEvent event, class_4587 matrices, class_1542 entity, class_241 screenPos) {
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        class_5250 text = entity.method_6983().method_7964().method_27661().method_27693(" " + entity.method_6983().method_7947() + "x");
        int textWidth = (int)Fonts.MEDIUM.getFont(11.0f).width((class_2561)text);
        int x = -textWidth / 2;
        int y = 5;
        event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), (class_2561)text, x, y);
        matrices.method_22909();
    }

    private void renderItemsBack(PreHudRenderEvent event, class_4587 matrices, List<class_1542> items, class_241 screenPos) {
        if (items.isEmpty()) {
            return;
        }
        float distance = items.getFirst().method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        int maxWidth = 0;
        int textHeight = (int)Fonts.MEDIUM.getFont(11.0f).height();
        for (class_1542 item : items) {
            String text = item.method_6983().method_7964().getString() + " " + item.method_6983().method_7947() + "x";
            int w = (int)Fonts.MEDIUM.getFont(11.0f).width(text);
            if (w <= maxWidth) continue;
            maxWidth = w;
        }
        int boxWidth = maxWidth + 6;
        int boxHeight = items.size() * textHeight + (items.size() - 1) * 2 + 6;
        event.getContext().drawRect((float)(-maxWidth) / 2.0f - 3.0f, 2.0f, boxWidth, boxHeight, new ColorRGBA(0.0f, 0.0f, 0.0f, 100.0f));
        matrices.method_22909();
    }

    private void renderItemsText(PreHudRenderEvent event, class_4587 matrices, List<class_1542> items, class_241 screenPos) {
        if (items.isEmpty()) {
            return;
        }
        float distance = items.getFirst().method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        int textHeight = (int)Fonts.MEDIUM.getFont(11.0f).height();
        int maxWidth = 0;
        LinkedList<class_5250> lines = new LinkedList<class_5250>();
        for (class_1542 item : items) {
            class_5250 text = item.method_6983().method_7964().method_27661().method_27693(" " + item.method_6983().method_7947() + "x");
            lines.add(text);
            int w = (int)Fonts.MEDIUM.getFont(11.0f).width((class_2561)text);
            if (w <= maxWidth) continue;
            maxWidth = w;
        }
        int startX = -maxWidth / 2;
        for (int i = 0; i < lines.size(); ++i) {
            class_2561 line = (class_2561)lines.get(i);
            int lineWidth = (int)Fonts.MEDIUM.getFont(11.0f).width(line);
            int x = startX + (maxWidth - lineWidth) / 2;
            int y = 5 + i * (textHeight + 2);
            event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), class_2561.method_54155((Message)line), x, y);
        }
        matrices.method_22909();
    }

    private void renderBack(PreHudRenderEvent event, class_4587 matrices, class_1297 entity, class_241 screenPos) {
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
            matrices.method_22905(scale, scale, 1.0f);
            class_5250 displayName = entity.method_5476().method_27661().method_27693(" ").method_27693("[" + (int)EntityUtility.getHealth(player) + "]");
            int textWidth = (int)Fonts.MEDIUM.getFont(11.0f).width((class_2561)displayName);
            int x = -textWidth / 2;
            int y = 5;
            event.getContext().drawRect(x - 3, y - 3, textWidth + 5, Fonts.MEDIUM.getFont(11.0f).height() + 6.0f, Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString()) ? new ColorRGBA(0.0f, 125.0f, 0.0f, 100.0f) : new ColorRGBA(0.0f, 0.0f, 0.0f, 100.0f));
            matrices.method_22909();
        }
    }

    private void renderNametagPlayer(PreHudRenderEvent event, class_4587 matrices, class_1297 entity, class_241 screenPos) {
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
            matrices.method_22905(scale, scale, 1.0f);
            class_5250 displayName = entity.method_5476().method_27661().method_27693(" ").method_10852((class_2561)class_2561.method_30163((String)("[" + (int)EntityUtility.getHealth(player) + "]")).method_27661().method_54663(-2142128));
            int textWidth = (int)Fonts.MEDIUM.getFont(11.0f).width((class_2561)displayName);
            int x = -textWidth / 2;
            int y = 5;
            event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), (class_2561)displayName, x - 1, y);
            matrices.method_22909();
        }
    }

    private void renderArmorPlayer(PreHudRenderEvent event, class_4587 matrices, class_1657 entity, class_241 screenPos) {
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        LinkedList<class_1799> items = new LinkedList<class_1799>();
        items.add((class_1799)entity.method_31548().field_7548.get(3));
        items.add((class_1799)entity.method_31548().field_7548.get(2));
        items.add((class_1799)entity.method_31548().field_7548.get(1));
        items.add((class_1799)entity.method_31548().field_7548.get(0));
        items.add(entity.method_6047());
        items.add(entity.method_6079());
        items.removeIf(class_1799::method_7960);
        int count = items.size();
        if (count > 0) {
            float totalWidth = (float)(count - 1) * 18.0f + 16.0f;
            float startX = -totalWidth / 2.0f;
            for (int i = 0; i < count; ++i) {
                class_1799 item = (class_1799)items.get(i);
                int x = (int)(startX + (float)(i * 18));
                event.getContext().drawBatchItem(item, x, -14);
            }
        }
        matrices.method_22909();
    }

    private void renderShulkerBack(PreHudRenderEvent event, class_4587 matrices, class_1542 entity, class_241 screenPos) {
        List<class_1799> items = ItemUtility.getItemsInShulker(entity.method_6983());
        if (items.isEmpty()) {
            return;
        }
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        int columns = Math.min(items.size(), 9);
        int rows = (int)Math.ceil((float)items.size() / 9.0f);
        int boxWidth = columns * 18 + 4;
        int boxHeight = rows * 18 + 4;
        event.getContext().drawRect(-boxWidth / 2, -boxHeight / 2, boxWidth, boxHeight, new ColorRGBA(0.0f, 0.0f, 0.0f, 150.0f));
        matrices.method_22909();
    }

    private void renderShulkerDisplay(PreHudRenderEvent event, class_4587 matrices, class_1542 entity, class_241 screenPos) {
        List<class_1799> items = ItemUtility.getItemsInShulker(entity.method_6983());
        if (items.isEmpty()) {
            return;
        }
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        int columns = Math.min(items.size(), 9);
        int rows = (int)Math.ceil((float)items.size() / 9.0f);
        int boxWidth = columns * 18 + 4;
        int boxHeight = rows * 18 + 4;
        for (int i = 0; i < items.size(); ++i) {
            class_1799 item = items.get(i);
            int x = i % 9 * 18 - boxWidth / 2 + 3;
            int y = i / 9 * 18 - boxHeight / 2 + 3;
            event.getContext().drawBatchItem(item, x, y);
        }
        matrices.method_22909();
    }

    private void renderShulkerText(PreHudRenderEvent event, class_4587 matrices, class_1542 entity, class_241 screenPos) {
        List<class_1799> items = ItemUtility.getItemsInShulker(entity.method_6983());
        if (items.isEmpty()) {
            return;
        }
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        matrices.method_22903();
        matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        int columns = Math.min(items.size(), 9);
        int rows = (int)Math.ceil((float)items.size() / 9.0f);
        int boxWidth = columns * 18 + 4;
        int boxHeight = rows * 18 + 4;
        event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), entity.method_5476().getString(), (float)(-boxWidth / 2) + 0.5f, -boxHeight / 2 - 11, ColorRGBA.WHITE);
        for (int i = 0; i < items.size(); ++i) {
            class_1799 item = items.get(i);
            int x = i % 9 * 18 - boxWidth / 2 + 3;
            int y = i / 9 * 18 - boxHeight / 2 + 3;
            if (item.method_7947() <= 1) continue;
            String count = String.valueOf(item.method_7947());
            event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), count, (float)(x + 16) - Fonts.MEDIUM.getFont(11.0f).width(count), y + 9, ColorRGBA.WHITE);
        }
        matrices.method_22909();
    }

    public static class_2561 displayName(class_1297 entity) {
        float f;
        if (entity.method_5476() == null) {
            return class_2561.method_43473();
        }
        NameProtect nameProtectModule = Experiment.getInstance().getModuleManager().getModule(NameProtect.class);
        String displayName = nameProtectModule.isEnabled() ? nameProtectModule.patchName(entity.method_5476().getString()) : entity.method_5476().getString();
        class_5250 text = class_2561.method_30163((String)displayName).method_27661();
        if (!(entity instanceof class_1309)) {
            return text;
        }
        class_1309 living = (class_1309)entity;
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            f = EntityUtility.getHealth(player);
        } else {
            f = living.method_6032();
        }
        int health = (int)f;
        if (!text.getString().endsWith(" ")) {
            text.method_27693(" ");
        }
        return text.method_10852((class_2561)class_2561.method_30163((String)("[" + String.valueOf(health == 1000 ? "?" : Integer.valueOf(health)) + "]")).method_27661().method_54663(-2142128));
    }

    private void handleClick(ChatClickEvent event, class_1297 entity, class_241 screenPos) {
        float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
        class_2561 displayName = Nametags.displayName(entity);
        float textWidth = Fonts.MEDIUM.getFont(11.0f).width(displayName);
        float rectOffsetX = -textWidth / 2.0f - 3.0f;
        float scaledRectX = screenPos.field_1343 + rectOffsetX * scale;
        float rectOffsetY = 2.0f;
        float scaledRectY = screenPos.field_1342 + 2.0f * scale;
        float rectWidth = textWidth + 5.0f;
        float scaledRectWidth = rectWidth * scale;
        float textHeight = Fonts.MEDIUM.getFont(11.0f).height();
        float rectHeight = textHeight + 6.0f;
        float scaledRectHeight = rectHeight * scale;
        if (GuiUtility.isHovered((double)scaledRectX, (double)scaledRectY, (double)scaledRectWidth, (double)scaledRectHeight, event.getX(), event.getY())) {
            FriendManager friendManager = Experiment.getInstance().getFriendManager();
            TargetManager targetManager = Experiment.getInstance().getTargetManager();
            String name = entity.method_5477().getString();
            this.active = new Popup(event.getX(), event.getY(), 100.0f, 6.0f).title(name).separator().checkbox(Localizator.translate("friend"), friendManager.isFriend(name), toggled -> {
                if (toggled) {
                    friendManager.add(name);
                } else {
                    friendManager.remove(name);
                }
            }).checkbox(Localizator.translate("enemy"), targetManager.isTarget(name), toggled -> {
                if (toggled) {
                    targetManager.addTarget(name);
                } else {
                    targetManager.removeTarget(name);
                }
            }).button(Localizator.translate("copy"), "icons/hud/copy.png", popup -> {
                TextUtility.copyText(name);
                popup.setShowing(false);
            });
        }
    }

    @Override
    public void onDisable() {
        this.entityList.clear();
    }

    public List<class_1297> getEntityList() {
        return this.entityList;
    }

    public BooleanSetting getArmor() {
        return this.armor;
    }

    public BooleanSetting getOffFriends() {
        return this.offFriends;
    }

    public BooleanSetting getItems() {
        return this.items;
    }

    public BooleanSetting getBackItems() {
        return this.backItems;
    }

    public EventListener<PreHudRenderEvent> getOnHudRenderEvent() {
        return this.onHudRenderEvent;
    }

    public Popup getActive() {
        return this.active;
    }

    public EventListener<ChatRenderEvent> getOnRender() {
        return this.onRender;
    }

    public EventListener<ChatClickEvent> getOnClick() {
        return this.onClick;
    }
}

