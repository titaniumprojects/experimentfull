/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1309
 *  net.minecraft.class_1452
 *  net.minecraft.class_1657
 *  net.minecraft.class_1937
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3966
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_7833
 *  net.minecraft.class_898
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 *  org.joml.Quaternionf
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.CrystalRenderer;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1452;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_898;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector3fc;

@ModuleInfo(name="Target ESP", category=ModuleCategory.VISUALS, desc="\u041f\u043e\u043c\u0435\u0447\u0430\u0435\u0442 \u0430\u043a\u0442\u0438\u0432\u043d\u0443\u044e \u0446\u0435\u043b\u044c")
@Environment(value=EnvType.CLIENT)
public class TargetESP
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.target_esp.mode");
    private final ModeSetting.Value souls = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.souls");
    private final ModeSetting.Value crystals = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.crystals").select();
    private final ModeSetting.Value chains = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.chains");
    private final ModeSetting.Value circles = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.circles");
    private final ModeSetting.Value marker = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.marker");
    private final ModeSetting.Value ring = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.ring");
    private final ModeSetting.Value pigs = new ModeSetting.Value(this.mode, "modules.settings.target_esp.mode.pigs");
    private final ColorSetting colorTarget = new ColorSetting(this, "color").color(Colors.ACCENT);
    private final BooleanSetting changeColorOnDamage = new BooleanSetting(this, "modules.settings.target_esp.change_color_on_damage").enable();
    private final SliderSetting speed = new SliderSetting(this, "modules.settings.target_esp.speed").min(0.1f).max(5.0f).step(0.1f).currentValue(0.5f);
    private final SliderSetting size = new SliderSetting((SettingsContainer)this, "modules.settings.target_esp.size", () -> this.souls.isSelected() || this.crystals.isSelected() || this.ring.isSelected() || this.pigs.isSelected()).min(0.5f).max(3.0f).step(0.1f).currentValue(1.5f);
    private final SliderSetting particleCount = new SliderSetting((SettingsContainer)this, "modules.settings.target_esp.particle_count", () -> this.souls.isSelected() || this.crystals.isSelected() || this.ring.isSelected() || this.pigs.isSelected()).min(1.0f).max(50.0f).step(1.0f).currentValue(20.0f);
    private final SliderSetting particleThickness = new SliderSetting((SettingsContainer)this, "modules.settings.target_esp.particle_thickness", () -> this.souls.isSelected() || this.crystals.isSelected() || this.ring.isSelected() || this.pigs.isSelected()).min(0.1f).max(2.0f).step(0.1f).currentValue(1.0f);
    private final Animation animation = new Animation(300L, 0.0f, Easing.BOTH_CUBIC);
    private final Animation moving = new Animation(70L, 0.0f, Easing.LINEAR);
    private final Animation hurtAnimation = new Animation(200L, 0.0f, Easing.BOTH_CUBIC);
    private final Animation markerRotation = new Animation(50L, 0.0f, Easing.LINEAR);
    private class_1309 prevTarget;
    private float chainRotationAngle = 0.0f;
    private final Timer targetLostTimer = new Timer();
    private double ringStep = 0.0;
    private float ringDamageFlashIntensity = 0.0f;
    private long lastRingDamageTime = 0L;
    private static final long RING_DAMAGE_FLASH_DURATION = 300L;
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (EntityUtility.isInGame()) {
            double distance;
            class_1657 player;
            class_1309 living;
            class_3966 ehr;
            class_1297 patt0$temp;
            class_1309 target = null;
            class_239 hit = TargetESP.mc.field_1765;
            if (hit != null && hit.method_17783() == class_239.class_240.field_1331 && hit instanceof class_3966 && (patt0$temp = (ehr = (class_3966)hit).method_17782()) instanceof class_1309 && (living = (class_1309)patt0$temp) != TargetESP.mc.field_1724 && !living.method_5767() && (!(living instanceof class_1657) || !(player = (class_1657)living).method_5756((class_1657)TargetESP.mc.field_1724) && !player.method_7325()) && (distance = (double)TargetESP.mc.field_1724.method_5739((class_1297)living)) <= 3.0) {
                target = living;
            }
            if (target != null) {
                this.prevTarget = target;
                this.targetLostTimer.reset();
            }
            boolean shouldShow = target != null || !this.targetLostTimer.finished(1000L);
            this.animation.setEasing(Easing.FIGMA_EASE_IN_OUT);
            this.animation.update(shouldShow);
            float speedMultiplier = this.speed.getCurrentValue();
            this.moving.update(this.moving.getValue() + 10.0f * speedMultiplier + 50.0f * speedMultiplier);
            this.markerRotation.update(this.markerRotation.getValue() + 5.0f * speedMultiplier);
            this.chainRotationAngle += 3.0f * speedMultiplier;
            if (target != null && this.prevTarget == target) {
                boolean isHurt = target.field_6235 > 0;
                this.hurtAnimation.update(isHurt);
                if (isHurt && this.ring.isSelected()) {
                    this.lastRingDamageTime = System.currentTimeMillis();
                }
            } else {
                this.hurtAnimation.update(false);
            }
            if (this.prevTarget != null && this.animation.getValue() != 0.0f) {
                class_4587 ms = event.getMatrices();
                ms.method_22903();
                RenderSystem.enableBlend();
                RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
                RenderSystem.enableDepthTest();
                if (TargetESP.mc.field_1687.method_17742(new class_3959(TargetESP.mc.field_1773.method_19418().method_19326(), this.prevTarget.method_33571(), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)TargetESP.mc.field_1724)).method_17783() != class_239.class_240.field_1333) {
                    RenderSystem.disableDepthTest();
                }
                RenderSystem.disableCull();
                RenderSystem.depthMask((boolean)false);
                if (this.chains.isSelected()) {
                    this.drawChains(ms, this.prevTarget);
                } else if (this.circles.isSelected()) {
                    this.drawCircles(ms, this.prevTarget);
                } else if (this.marker.isSelected()) {
                    this.drawMarker(ms, this.prevTarget);
                } else if (this.crystals.isSelected()) {
                    this.drawCrystals(ms, this.prevTarget);
                } else if (this.ring.isSelected()) {
                    this.drawRing(ms, this.prevTarget);
                } else if (this.pigs.isSelected()) {
                    this.drawPigs(ms, this.prevTarget);
                } else {
                    this.drawGhosts(ms, this.prevTarget);
                }
                RenderSystem.depthMask((boolean)true);
                RenderSystem.setShaderTexture((int)0, (int)0);
                RenderSystem.disableBlend();
                RenderSystem.enableCull();
                RenderSystem.disableDepthTest();
                ms.method_22909();
            }
        }
    };

    private ColorRGBA getTargetColor() {
        float hitProgress = this.hurtAnimation.getValue();
        ColorRGBA baseColor = this.colorTarget.getColor();
        if (this.changeColorOnDamage.isEnabled() && hitProgress > 0.0f) {
            ColorRGBA redColor = new ColorRGBA(255.0f, 0.0f, 0.0f, 255.0f);
            return baseColor.mix(redColor, hitProgress);
        }
        return baseColor;
    }

    private void drawChains(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        class_243 targetPos = this.getRenderPos(target);
        double centerX = targetPos.field_1352;
        double centerY = targetPos.field_1351 + (double)(target.method_17682() / 2.0f);
        double centerZ = targetPos.field_1350;
        double renderX = centerX - camera.method_19326().method_10216();
        double renderY = centerY - camera.method_19326().method_10214();
        double renderZ = centerZ - camera.method_19326().method_10215();
        this.renderChainCylinder(ms, renderX, renderY, renderZ, 0.0f);
        this.renderChainCylinder(ms, renderX, renderY, renderZ, 90.0f);
    }

    private void renderChainCylinder(class_4587 stack, double x, double y, double z, float offsetAngle) {
        stack.method_22903();
        stack.method_22904(x, y, z);
        float currentAngle = this.chainRotationAngle;
        stack.method_22907(class_7833.field_40718.rotationDegrees(currentAngle + offsetAngle));
        stack.method_22907(class_7833.field_40714.rotationDegrees(currentAngle + offsetAngle));
        float radius = this.prevTarget.method_17681() * 1.5f * this.size.getCurrentValue();
        int segments = Math.max(10, (int)this.particleCount.getCurrentValue());
        ColorRGBA blendedColor = this.getTargetColor();
        int alpha = (int)(this.animation.getValue() * 255.0f);
        class_2960 chainTexture = Experiment.id("textures/chain.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)chainTexture);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        Matrix4f matrix = stack.method_23760().method_23761();
        class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        float textureRepeat = 4.0f * this.particleThickness.getCurrentValue();
        float chainHeight = this.prevTarget.method_17682() * 0.8f * this.size.getCurrentValue();
        float halfHeight = chainHeight / 2.0f;
        for (int i = 0; i < segments; ++i) {
            float angle1 = (float)(Math.PI * 2 * (double)i / (double)segments);
            float angle2 = (float)(Math.PI * 2 * (double)(i + 1) / (double)segments);
            float x1 = (float)(Math.cos(angle1) * (double)radius);
            float z1 = (float)(Math.sin(angle1) * (double)radius);
            float x2 = (float)(Math.cos(angle2) * (double)radius);
            float z2 = (float)(Math.sin(angle2) * (double)radius);
            float u1 = (float)i / (float)segments * textureRepeat;
            float u2 = (float)(i + 1) / (float)segments * textureRepeat;
            ColorRGBA color1 = blendedColor.withAlpha(alpha);
            ColorRGBA color2 = blendedColor.withAlpha(alpha);
            buffer.method_22918(matrix, x1, -halfHeight, z1).method_22913(u1, 1.0f).method_39415(color1.getRGB());
            buffer.method_22918(matrix, x2, -halfHeight, z2).method_22913(u2, 1.0f).method_39415(color2.getRGB());
            buffer.method_22918(matrix, x2, halfHeight, z2).method_22913(u2, 0.0f).method_39415(color2.getRGB());
            buffer.method_22918(matrix, x1, halfHeight, z1).method_22913(u1, 0.0f).method_39415(color1.getRGB());
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        stack.method_22909();
    }

    private void drawMarker(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        class_243 targetPos = this.getRenderPos(target);
        double entX = targetPos.field_1352 - camera.method_19326().method_10216();
        double entY = targetPos.field_1351 - camera.method_19326().method_10214() + (double)target.method_17682() / 2.0;
        double entZ = targetPos.field_1350 - camera.method_19326().method_10215();
        float size = 1.2f * this.size.getCurrentValue() * this.particleThickness.getCurrentValue();
        float rotationValue = this.markerRotation.getValue();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        ColorRGBA blendedColor = this.getTargetColor();
        ms.method_22903();
        ms.method_22904(entX, entY, entZ);
        ms.method_22907(camera.method_23767());
        ms.method_22907(class_7833.field_40718.rotationDegrees(rotationValue));
        int alpha = (int)(this.animation.getValue() * 255.0f * 0.7f);
        ColorRGBA color = blendedColor.withAlpha(alpha);
        class_2960 markerTexture = Experiment.id("textures/marker.png");
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        int layers = Math.max(1, (int)(this.particleCount.getCurrentValue() / 10.0f));
        for (int i = 0; i < layers; ++i) {
            float layerSize = size * (1.0f + (float)i * 0.1f);
            float layerAlpha = alpha / (i + 1);
            DrawUtility.drawImage(ms, markerTexture, (double)(-layerSize / 2.0f), (double)(-layerSize / 2.0f), 0.0, (double)layerSize, (double)layerSize, blendedColor.withAlpha((int)(layerAlpha * 0.3f)));
        }
        DrawUtility.drawImage(ms, markerTexture, (double)(-size / 2.0f), (double)(-size / 2.0f), 0.0, (double)size, (double)size, color);
        ms.method_22909();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private void drawCircles(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        class_243 targetPos = this.getRenderPos(target);
        double entX = targetPos.field_1352 - cameraPos.method_10216();
        double entY = targetPos.field_1351 - cameraPos.method_10214();
        double entZ = targetPos.field_1350 - cameraPos.method_10215();
        float movingValue = this.moving.getValue();
        float width = target.method_17681() * 1.45f * this.size.getCurrentValue();
        float baseVal = Math.max(0.5f, 0.7f - 0.1f * this.hurtAnimation.getValue() + 0.1f - 0.1f * this.animation.getValue());
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        ColorRGBA blendedColor = this.getTargetColor();
        class_2960 bloomTexture = Experiment.id("textures/bloom.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)bloomTexture);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        int step = Math.max(1, (int)(360.0f / this.particleCount.getCurrentValue()));
        float size = 0.4f * this.size.getCurrentValue() * this.particleThickness.getCurrentValue();
        float bigSize = 0.8f * this.size.getCurrentValue() * this.particleThickness.getCurrentValue();
        for (int i = 0; i < 360; i += step) {
            if ((int)((float)i / 45.0f) % 2 == 0) continue;
            double rad = Math.toRadians((float)i + movingValue);
            float sin = (float)(entX + Math.sin(rad) * (double)width * (double)baseVal);
            float cos = (float)(entZ + Math.cos(rad) * (double)width * (double)baseVal);
            double radAngle = Math.toRadians(movingValue);
            float waveValue = (float)((1.0 - Math.cos(radAngle)) / 2.0);
            float yPos = (float)(entY + (double)(target.method_17682() * waveValue));
            ms.method_22903();
            ms.method_46416(sin, yPos, cos);
            ms.method_22907(camera.method_23767());
            int alpha = (int)(this.animation.getValue() * 255.0f);
            ColorRGBA color = blendedColor.withAlpha(alpha);
            class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
            int bloomAlpha = (int)((float)alpha * 0.1f);
            ColorRGBA bloomColor = color.withAlpha(bloomAlpha);
            DrawUtility.drawImage(ms, buffer, (double)(-bigSize / 2.0f), (double)(-bigSize / 2.0f), 0.0, (double)bigSize, (double)bigSize, bloomColor);
            class_286.method_43433((class_9801)buffer.method_60800());
            buffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
            DrawUtility.drawImage(ms, buffer, (double)(-size / 2.0f), (double)(-size / 2.0f), 0.0, (double)size, (double)size, color);
            class_286.method_43433((class_9801)buffer.method_60800());
            ms.method_22909();
        }
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private void drawCrystals(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        ColorRGBA color = this.getTargetColor();
        float width = this.prevTarget.method_17681() * 1.5f;
        RenderUtility.prepareMatrices(ms, this.getRenderPos(this.prevTarget));
        class_287 builder = CrystalRenderer.createBuffer();
        for (int i = 0; i < 360; i += 20) {
            float val = 1.2f - 0.5f * this.animation.getValue();
            float sin = (float)(MathUtility.sin((float)Math.toRadians((float)i + this.moving.getValue() * 0.3f)) * (double)width * (double)val);
            float cos = (float)(MathUtility.cos((float)Math.toRadians((float)i + this.moving.getValue() * 0.3f)) * (double)width * (double)val);
            float size = 0.1f;
            ms.method_22903();
            ms.method_22904((double)sin, (double)0.1f + (double)target.method_17682() * Math.abs(MathUtility.sin(i)), (double)cos);
            class_243 crystalPos = this.getRenderPos(this.prevTarget).method_1031((double)sin, 1.0, (double)cos);
            class_243 targetPos = target.method_19538().method_1031(0.0, (double)target.method_17682() / 2.0, 0.0);
            Vector3f directionToTarget = new Vector3f((float)(targetPos.field_1352 - crystalPos.field_1352), (float)(targetPos.field_1351 - crystalPos.field_1351), (float)(targetPos.field_1350 - crystalPos.field_1350)).normalize();
            Vector3f initialDirection = new Vector3f(0.0f, 1.0f, 0.0f);
            Quaternionf rotation = new Quaternionf().rotationTo((Vector3fc)initialDirection, (Vector3fc)directionToTarget);
            ms.method_22907(rotation);
            CrystalRenderer.render(ms, builder, 0.0f, 0.0f, 0.0f, size, color.withAlpha(255.0f * this.animation.getValue()));
            ms.method_22909();
        }
        class_286.method_43433((class_9801)builder.method_60800());
        class_2960 id = Experiment.id("textures/bloom.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)id);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        float bigSize = 1.0f;
        for (int i = 0; i < 360; i += 20) {
            float val = 1.2f - 0.5f * this.animation.getValue();
            float sin = (float)(MathUtility.sin((float)Math.toRadians((float)i + this.moving.getValue() * 0.3f)) * (double)width * (double)val);
            float cos = (float)(MathUtility.cos((float)Math.toRadians((float)i + this.moving.getValue() * 0.3f)) * (double)width * (double)val);
            ms.method_22903();
            ms.method_22904((double)sin, (double)0.1f + (double)target.method_17682() * Math.abs(MathUtility.sin(i)), (double)cos);
            ms.method_22907(camera.method_23767());
            DrawUtility.drawImage(ms, buffer, (double)(-bigSize / 2.0f), (double)(-bigSize / 2.0f), 0.0, (double)bigSize, (double)bigSize, color.withAlpha(255.0f * this.animation.getValue() * 0.2f));
            ms.method_22909();
        }
        RenderUtility.buildBuffer(buffer);
    }

    private void drawGhosts(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        ColorRGBA color = this.getTargetColor();
        class_2960 id = Experiment.id("textures/bloom.png");
        float width = this.prevTarget.method_17681() * 1.5f;
        RenderSystem.setShaderTexture((int)0, (class_2960)id);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        RenderUtility.prepareMatrices(ms, this.getRenderPos(this.prevTarget));
        int step = 2;
        int wormTick = 0;
        int wormCD = 0;
        int wormCount = 0;
        for (int i = 0; i < 360; i += step) {
            float size = 0.13f + 0.005f * (float)wormTick;
            float bigSize = 0.7f + 0.005f * (float)wormTick;
            if (wormCD > 0) {
                wormCD -= step;
                continue;
            }
            if ((wormTick += step) > 50) {
                wormCD = 100;
                wormTick = 0;
                ++wormCount;
                continue;
            }
            float val = Math.max(0.5f, 1.2f - 0.5f * this.animation.getValue());
            float sin = (float)(MathUtility.sin((float)Math.toRadians((float)i + this.moving.getValue() * 1.0f)) * (double)width * (double)val);
            float cos = (float)(MathUtility.cos((float)Math.toRadians((float)i + this.moving.getValue() * 1.0f)) * (double)width * (double)val);
            ms.method_22903();
            ms.method_22904((double)sin, (double)(this.prevTarget.method_17682() / 1.5f) + (double)(this.prevTarget.method_17682() / 3.0f) * MathUtility.sin(Math.toRadians((float)i / 2.0f + this.moving.getValue() / 5.0f)), (double)cos);
            ms.method_22907(camera.method_23767());
            DrawUtility.drawImage(ms, builder, (double)(-bigSize / 2.0f), (double)(-bigSize / 2.0f), (double)(-size / 2.0f), (double)bigSize, (double)bigSize, color.withAlpha(color.getAlpha() * this.animation.getValue() * 0.05f));
            DrawUtility.drawImage(ms, builder, (double)(-size / 2.0f), (double)(-size / 2.0f), (double)(-size / 2.0f), (double)size, (double)size, color.withAlpha(color.getAlpha() * this.animation.getValue()));
            ms.method_22909();
        }
        class_286.method_43433((class_9801)builder.method_60800());
    }

    private class_243 getRenderPos(class_1309 target) {
        float tickDelta = class_310.method_1551().method_61966().method_60637(false);
        return new class_243(class_3532.method_16436((double)tickDelta, (double)target.field_6014, (double)target.method_23317()), class_3532.method_16436((double)tickDelta, (double)target.field_6036, (double)target.method_23318()), class_3532.method_16436((double)tickDelta, (double)target.field_5969, (double)target.method_23321()));
    }

    private void drawRing(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        class_243 targetPos = this.getRenderPos(target);
        class_243 cameraPos = camera.method_19326();
        float entityWidth = target.method_17681() * 0.7f;
        float entityHeight = target.method_17682();
        float animationAlpha = this.easeOutCubic(this.animation.getValue());
        double renderX = targetPos.field_1352 - cameraPos.method_10216();
        double renderY = targetPos.field_1351 - cameraPos.method_10214();
        double renderZ = targetPos.field_1350 - cameraPos.method_10215();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask((boolean)false);
        float ringSpeed = this.speed.getCurrentValue() * 0.02f;
        this.ringStep += (double)ringSpeed;
        double currentStep = this.ringStep;
        double headY = this.absSinAnimation(currentStep) * (double)entityHeight;
        double tailBaseY = this.absSinAnimation(currentStep - 0.4) * (double)entityHeight;
        float headSize = 0.2f * this.size.getCurrentValue() * this.particleThickness.getCurrentValue();
        float tailSize = 0.14f * this.size.getCurrentValue() * this.particleThickness.getCurrentValue();
        int totalPoints = Math.max(40, (int)this.particleCount.getCurrentValue() * 2);
        int tailSegments = 6;
        long currentTime = System.currentTimeMillis();
        class_2960 glowTexture = Experiment.id("textures/bloom.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)glowTexture);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (int i = 0; i < totalPoints; ++i) {
            double angleRadians = Math.PI * 2 * (double)i / (double)totalPoints;
            float xOffset = (float)(Math.cos(angleRadians) * (double)entityWidth);
            float zOffset = (float)(Math.sin(angleRadians) * (double)entityWidth);
            int baseColor = this.getThemeColorForRing(i * (360 / totalPoints), currentTime);
            ms.method_22903();
            ms.method_22904(renderX + (double)xOffset, renderY + headY, renderZ + (double)zOffset);
            ms.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            ColorRGBA coreColor = ColorRGBA.fromInt(baseColor).withAlpha(animationAlpha * 255.0f);
            DrawUtility.drawImage(ms, buffer, (double)(-headSize / 2.0f), (double)(-headSize / 2.0f), 0.0, (double)headSize, (double)headSize, coreColor);
            ms.method_22909();
            for (int t = 1; t <= tailSegments; ++t) {
                float tailProgress = (float)t / (float)(tailSegments + 1);
                double currentTailY = headY + (tailBaseY - headY) * (double)tailProgress;
                float currentTailAlpha = animationAlpha * (1.0f - tailProgress) * 200.0f;
                ms.method_22903();
                ms.method_22904(renderX + (double)xOffset, renderY + currentTailY, renderZ + (double)zOffset);
                ms.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                ColorRGBA tailColor = ColorRGBA.fromInt(baseColor).withAlpha(currentTailAlpha);
                DrawUtility.drawImage(ms, buffer, (double)(-tailSize / 2.0f), (double)(-tailSize / 2.0f), 0.0, (double)tailSize, (double)tailSize, tailColor);
                ms.method_22909();
            }
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private int getThemeColorForRing(int offsetAngle, long currentTime) {
        return this.applyRingDamageFlash(this.getTargetColor().getRGB());
    }

    private int applyRingDamageFlash(int color) {
        if (!this.changeColorOnDamage.isEnabled()) {
            return color;
        }
        float targetIntensity = 0.0f;
        long timeSinceDamage = System.currentTimeMillis() - this.lastRingDamageTime;
        if (timeSinceDamage < 300L) {
            float progress = (float)timeSinceDamage / 300.0f;
            targetIntensity = 1.0f - this.easeOutCubic(progress);
        }
        this.ringDamageFlashIntensity = class_3532.method_16439((float)1.0f, (float)this.ringDamageFlashIntensity, (float)targetIntensity);
        if (this.ringDamageFlashIntensity < 0.05f) {
            return color;
        }
        int alpha = color >> 24 & 0xFF;
        int red = color >> 16 & 0xFF;
        int green = color >> 8 & 0xFF;
        int blue = color & 0xFF;
        int finalRed = class_3532.method_48781((float)this.ringDamageFlashIntensity, (int)red, (int)255);
        int finalGreen = class_3532.method_48781((float)this.ringDamageFlashIntensity, (int)green, (int)50);
        int finalBlue = class_3532.method_48781((float)this.ringDamageFlashIntensity, (int)blue, (int)50);
        return alpha << 24 | finalRed << 16 | finalGreen << 8 | finalBlue;
    }

    private float easeOutCubic(float x) {
        return 1.0f - (float)Math.pow(1.0f - x, 3.0);
    }

    private double absSinAnimation(double step) {
        return Math.abs(Math.sin(step));
    }

    private void drawPigs(class_4587 ms, class_1309 target) {
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        class_243 targetPos = this.getRenderPos(target);
        class_243 cameraPos = camera.method_19326();
        double centerX = targetPos.field_1352 - cameraPos.method_10216();
        double centerY = targetPos.field_1351 - cameraPos.method_10214();
        double centerZ = targetPos.field_1350 - cameraPos.method_10215();
        float radius = 0.7f;
        float height = 1.0f;
        float speedMultiplier = 2.5E-4f * this.speed.getCurrentValue();
        long currentTime = System.currentTimeMillis();
        float timeRotation = (float)(-(currentTime % 1000000L)) * speedMultiplier;
        int pigCount = 8;
        double[] pigX = new double[pigCount];
        double[] pigY = new double[pigCount];
        double[] pigZ = new double[pigCount];
        float angleOffset = timeRotation * 360.0f;
        for (int i = 0; i < pigCount; ++i) {
            float angle = angleOffset + (float)i / (float)pigCount * 360.0f;
            double rad = Math.toRadians(angle);
            float yOffset = i % 2 == 0 ? 0.1f : -0.1f;
            double offsetX = Math.cos(rad) * (double)radius;
            double offsetZ = Math.sin(rad) * (double)radius;
            pigX[i] = centerX + offsetX;
            pigY[i] = centerY + (double)height + (double)yOffset - (double)0.2f;
            pigZ[i] = centerZ + offsetZ;
        }
        double centerPigX = centerX;
        double centerPigY = centerY + (double)2.2f;
        double centerPigZ = centerZ;
        float timeAnim = (float)(currentTime % 1000000L) * this.speed.getCurrentValue() * 0.001f;
        float yaw = timeAnim * 180.0f;
        float pitch = (float)(Math.sin((double)timeAnim * 1.5) * 120.0);
        float roll = (float)(Math.cos((double)timeAnim * 1.2) * 90.0);
        ColorRGBA targetColor = this.getTargetColor();
        float colorR = targetColor.getRed() / 255.0f;
        float colorG = targetColor.getGreen() / 255.0f;
        float colorB = targetColor.getBlue() / 255.0f;
        float colorA = this.animation.getValue();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShaderColor((float)colorR, (float)colorG, (float)colorB, (float)colorA);
        try {
            class_1452 pigEntity = new class_1452(class_1299.field_6093, (class_1937)TargetESP.mc.field_1687);
            pigEntity.field_6012 = 0;
            class_898 dispatcher = mc.method_1561();
            class_4597.class_4598 buffer = mc.method_22940().method_23000();
            for (int i = 0; i <= pigCount; ++i) {
                double nextWorldZ;
                double nextWorldY;
                double nextWorldX;
                double worldZ;
                double worldY;
                double worldX;
                if (i < pigCount) {
                    worldX = pigX[i];
                    worldY = pigY[i];
                    worldZ = pigZ[i];
                    int nextIndex = (i + 1) % pigCount;
                    nextWorldX = pigX[nextIndex];
                    nextWorldY = pigY[nextIndex];
                    nextWorldZ = pigZ[nextIndex];
                } else {
                    worldX = centerPigX;
                    worldY = centerPigY;
                    worldZ = centerPigZ;
                    nextWorldX = pigX[0];
                    nextWorldY = pigY[0];
                    nextWorldZ = pigZ[0];
                }
                ms.method_22903();
                ms.method_22904(worldX, worldY, worldZ);
                if (i == pigCount) {
                    ms.method_22907(class_7833.field_40716.rotationDegrees(yaw));
                    ms.method_22907(class_7833.field_40714.rotationDegrees(pitch));
                    ms.method_22907(class_7833.field_40718.rotationDegrees(roll));
                } else {
                    double dirX = nextWorldX - worldX;
                    double dirY = nextWorldY - worldY;
                    double dirZ = nextWorldZ - worldZ;
                    float pigYaw = (float)Math.toDegrees(Math.atan2(-dirZ, dirX)) - 95.0f;
                    ms.method_22907(class_7833.field_40716.rotationDegrees(pigYaw));
                }
                float scale = i == pigCount ? 0.4f * this.animation.getValue() * this.particleThickness.getCurrentValue() : 0.3f * this.animation.getValue() * this.particleThickness.getCurrentValue();
                ms.method_22905(scale, scale, scale);
                pigEntity.field_6283 = 0.0f;
                pigEntity.field_6220 = 0.0f;
                pigEntity.field_6241 = 0.0f;
                pigEntity.field_6259 = 0.0f;
                dispatcher.method_62424((class_1297)pigEntity, 0.0, 0.0, 0.0, mc.method_61966().method_60637(false), ms, (class_4597)buffer, 0xF000F0);
                ms.method_22909();
            }
            buffer.method_22993();
        }
        catch (Exception exception) {
            // empty catch block
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.depthMask((boolean)true);
    }

    @Override
    public void tick() {
        super.tick();
    }
}

