/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 */
package micronix.experiment.systems.modules.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.particle.ParticleUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;

@ModuleInfo(name="Particle Effects", category=ModuleCategory.VISUALS, desc="\u041a\u0430\u0441\u0442\u043e\u043c\u043d\u044b\u0435 \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u044b \u043f\u0440\u0438 \u0440\u0430\u0437\u043b\u0438\u0447\u043d\u044b\u0445 \u0441\u043e\u0431\u044b\u0442\u0438\u044f\u0445")
@Environment(value=EnvType.CLIENT)
public class ParticleEffects
extends BaseModule {
    private final List<ParticleUtil.Particle> particles = new ArrayList<ParticleUtil.Particle>();
    private final Random random = new Random();
    private final BooleanSetting onHit = new BooleanSetting((SettingsContainer)this, "\u041f\u0440\u0438 \u0443\u0434\u0430\u0440\u0435", "\u041f\u0430\u0440\u0442\u0438\u043a\u043b\u044b \u043f\u0440\u0438 \u0430\u0442\u0430\u043a\u0435").enable();
    private final BooleanSetting onMove = new BooleanSetting((SettingsContainer)this, "\u041f\u0440\u0438 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0438", "\u041f\u0430\u0440\u0442\u0438\u043a\u043b\u044b \u043f\u0440\u0438 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0438");
    private final BooleanSetting onJump = new BooleanSetting((SettingsContainer)this, "\u041f\u0440\u0438 \u043f\u0440\u044b\u0436\u043a\u0435", "\u041f\u0430\u0440\u0442\u0438\u043a\u043b\u044b \u043f\u0440\u0438 \u043f\u0440\u044b\u0436\u043a\u0435");
    private final BooleanSetting displayInWorld = new BooleanSetting((SettingsContainer)this, "\u0412 \u043c\u0438\u0440\u0435", "\u041f\u0430\u0440\u0442\u0438\u043a\u043b\u044b \u0432\u043e\u043a\u0440\u0443\u0433 \u0438\u0433\u0440\u043e\u043a\u0430 (\u043a\u0430\u043a \u0441\u043d\u0435\u0433)");
    private final ModeSetting particleType = new ModeSetting(this, "\u0422\u0438\u043f \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u0430");
    private final ModeSetting.Value heartMode = new ModeSetting.Value(this.particleType, "Heart");
    private final ModeSetting.Value starMode = new ModeSetting.Value(this.particleType, "Star").select();
    private final ModeSetting.Value snowMode = new ModeSetting.Value(this.particleType, "Snow");
    private final ModeSetting.Value bloomMode = new ModeSetting.Value(this.particleType, "Bloom");
    private final ModeSetting.Value dollarMode = new ModeSetting.Value(this.particleType, "Dollar");
    private final ModeSetting.Value triangleMode = new ModeSetting.Value(this.particleType, "Triangle");
    private final ModeSetting.Value sakuraMode = new ModeSetting.Value(this.particleType, "Sakura");
    private final ModeSetting.Value geminiMode = new ModeSetting.Value(this.particleType, "Gemini");
    private final ModeSetting.Value simsMode = new ModeSetting.Value(this.particleType, "Sims");
    private final ColorSetting particleColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u0430").color(Colors.getAccentColor());
    private final SliderSetting particleCount = new SliderSetting((SettingsContainer)this, "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e", "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u043e\u0432 \u0437\u0430 \u0440\u0430\u0437").min(1.0f).max(50.0f).step(1.0f).currentValue(10.0f);
    private final SliderSetting particleSize = new SliderSetting((SettingsContainer)this, "\u0420\u0430\u0437\u043c\u0435\u0440", "\u0420\u0430\u0437\u043c\u0435\u0440 \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u043e\u0432").min(0.1f).max(1.0f).step(0.05f).currentValue(0.3f);
    private final SliderSetting particleSpeed = new SliderSetting((SettingsContainer)this, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u043e\u0432").min(0.0f).max(2.0f).step(0.1f).currentValue(0.1f);
    private final SliderSetting worldRadius = new SliderSetting((SettingsContainer)this, "\u0420\u0430\u0434\u0438\u0443\u0441 \u043c\u0438\u0440\u0430", "\u0420\u0430\u0434\u0438\u0443\u0441 \u0441\u043f\u0430\u0432\u043d\u0430 \u043f\u0430\u0440\u0442\u0438\u043a\u043b\u043e\u0432 \u0432 \u043c\u0438\u0440\u0435").min(1.0f).max(20.0f).step(1.0f).currentValue(5.0f);
    private final SliderSetting fadeInTime = new SliderSetting((SettingsContainer)this, "\u0412\u0440\u0435\u043c\u044f \u043f\u043e\u044f\u0432\u043b\u0435\u043d\u0438\u044f", "\u0412\u0440\u0435\u043c\u044f \u043f\u043e\u044f\u0432\u043b\u0435\u043d\u0438\u044f \u0432 \u043c\u0441").min(100.0f).max(2000.0f).step(100.0f).currentValue(500.0f);
    private final SliderSetting fadeOutTime = new SliderSetting((SettingsContainer)this, "\u0412\u0440\u0435\u043c\u044f \u0436\u0438\u0437\u043d\u0438", "\u0412\u0440\u0435\u043c\u044f \u0434\u043e \u0438\u0441\u0447\u0435\u0437\u0430\u043d\u0438\u044f \u0432 \u043c\u0441").min(1000.0f).max(10000.0f).step(500.0f).currentValue(3000.0f);
    private class_243 lastPlayerPos = class_243.field_1353;
    private boolean wasOnGround = false;
    private int worldTick = 0;
    private final EventListener<AttackEvent> onAttack = event -> {
        if (ParticleEffects.mc.field_1724 != null && event.getEntity() != null && this.onHit.isEnabled()) {
            class_243 hitPos = event.getEntity().method_19538().method_1031(0.0, (double)(event.getEntity().method_17682() / 2.0f), 0.0);
            class_243 playerPos = ParticleEffects.mc.field_1724.method_19538().method_1031(0.0, (double)(ParticleEffects.mc.field_1724.method_17682() / 2.0f), 0.0);
            class_243 direction = hitPos.method_1020(playerPos).method_1029();
            this.spawnHitParticles(hitPos, direction, (int)this.particleCount.getCurrentValue());
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (ParticleEffects.mc.field_1724 != null && ParticleEffects.mc.field_1687 != null) {
            class_243 currentPos = ParticleEffects.mc.field_1724.method_19538();
            double distance = currentPos.method_1022(this.lastPlayerPos);
            boolean isOnGround = ParticleEffects.mc.field_1724.method_24828();
            if (this.onMove.isEnabled() && isOnGround && distance > 0.01 && distance > 0.1) {
                class_243 particlePos = currentPos.method_1031((this.random.nextDouble() - 0.5) * 0.5, 0.1, (this.random.nextDouble() - 0.5) * 0.5);
                this.spawnStaticParticles(particlePos, 1);
            }
            this.lastPlayerPos = currentPos;
            if (this.onJump.isEnabled()) {
                if (!isOnGround && this.wasOnGround) {
                    class_243 jumpPos = ParticleEffects.mc.field_1724.method_19538();
                    this.spawnParticles(jumpPos, (int)(this.particleCount.getCurrentValue() / 2.0f));
                }
                this.wasOnGround = isOnGround;
            }
            if (this.displayInWorld.isEnabled()) {
                ++this.worldTick;
                int spawnRate = Math.max(1, (int)(20.0f - this.particleCount.getCurrentValue() / 5.0f));
                if (this.worldTick >= spawnRate) {
                    this.worldTick = 0;
                    class_243 playerPos = ParticleEffects.mc.field_1724.method_19538();
                    double radius = this.worldRadius.getCurrentValue();
                    class_243 worldPos = playerPos.method_1031((this.random.nextDouble() - 0.5) * radius * 2.0, (this.random.nextDouble() - 0.3) * radius, (this.random.nextDouble() - 0.5) * radius * 2.0);
                    this.spawnStaticParticles(worldPos, 1);
                }
            }
            this.renderParticles((Render3DEvent)event);
        }
    };

    private void spawnParticles(class_243 position, int count) {
        ParticleUtil.ParticleType type = this.getParticleType();
        int color = this.particleColor.getColor().getRGB();
        float size = this.particleSize.getCurrentValue();
        double speed = this.particleSpeed.getCurrentValue();
        for (int i = 0; i < count; ++i) {
            class_243 velocity = new class_243((this.random.nextDouble() - 0.5) * 2.0, this.random.nextDouble() * 2.0, (this.random.nextDouble() - 0.5) * 2.0);
            ParticleUtil.Particle particle = new ParticleUtil.Particle(mc, type, position.method_1031((this.random.nextDouble() - 0.5) * 0.5, (this.random.nextDouble() - 0.5) * 0.5, (this.random.nextDouble() - 0.5) * 0.5), velocity, this.particles.size(), 0, color, size, speed);
            this.particles.add(particle);
        }
        while (this.particles.size() > 500) {
            this.particles.remove(0);
        }
    }

    private void spawnStaticParticles(class_243 position, int count) {
        ParticleUtil.ParticleType type = this.getParticleType();
        int color = this.particleColor.getColor().getRGB();
        float size = this.particleSize.getCurrentValue();
        double speed = this.particleSpeed.getCurrentValue();
        for (int i = 0; i < count; ++i) {
            class_243 velocity = class_243.field_1353;
            ParticleUtil.Particle particle = new ParticleUtil.Particle(mc, type, position.method_1031((this.random.nextDouble() - 0.5) * 0.5, (this.random.nextDouble() - 0.5) * 0.5, (this.random.nextDouble() - 0.5) * 0.5), velocity, this.particles.size(), 0, color, size, speed);
            this.particles.add(particle);
        }
        while (this.particles.size() > 500) {
            this.particles.remove(0);
        }
    }

    private void spawnHitParticles(class_243 position, class_243 direction, int count) {
        ParticleUtil.ParticleType type = this.getParticleType();
        int color = this.particleColor.getColor().getRGB();
        float size = this.particleSize.getCurrentValue();
        double speed = this.particleSpeed.getCurrentValue();
        for (int i = 0; i < count; ++i) {
            double theta = this.random.nextDouble() * Math.PI * 2.0;
            double phi = this.random.nextDouble() * Math.PI;
            double x = Math.sin(phi) * Math.cos(theta);
            double y = Math.sin(phi) * Math.sin(theta);
            double z = Math.cos(phi);
            double baseSpeed = 0.2 + this.random.nextDouble() * 0.3;
            class_243 velocity = new class_243(x, y, z).method_1029().method_1021(baseSpeed);
            ParticleUtil.Particle particle = new ParticleUtil.Particle(mc, type, position.method_1031((this.random.nextDouble() - 0.5) * 0.2, (this.random.nextDouble() - 0.5) * 0.2, (this.random.nextDouble() - 0.5) * 0.2), velocity, this.particles.size(), 0, color, size, speed);
            this.particles.add(particle);
        }
        while (this.particles.size() > 500) {
            this.particles.remove(0);
        }
    }

    private void renderParticles(Render3DEvent event) {
        if (!this.particles.isEmpty()) {
            class_243 cameraPos = ParticleEffects.mc.field_1773.method_19418().method_19326();
            ParticleUtil.renderParticles(event.getMatrices(), cameraPos, this.particles, (long)this.fadeInTime.getCurrentValue(), (long)this.fadeOutTime.getCurrentValue(), event.getTickDelta());
            long totalLifetime = (long)this.fadeOutTime.getCurrentValue() + 1000L;
            this.particles.removeIf(particle -> particle.time().finished(totalLifetime) && particle.animation().getValue() <= 0.0);
        }
    }

    private ParticleUtil.ParticleType getParticleType() {
        if (this.particleType.is(this.heartMode)) {
            return ParticleUtil.ParticleType.HEART;
        }
        if (this.particleType.is(this.starMode)) {
            return ParticleUtil.ParticleType.STAR;
        }
        if (this.particleType.is(this.snowMode)) {
            return ParticleUtil.ParticleType.SNOW;
        }
        if (this.particleType.is(this.bloomMode)) {
            return ParticleUtil.ParticleType.BLOOM;
        }
        if (this.particleType.is(this.dollarMode)) {
            return ParticleUtil.ParticleType.DOLLAR;
        }
        if (this.particleType.is(this.triangleMode)) {
            return ParticleUtil.ParticleType.TRIANGLE;
        }
        if (this.particleType.is(this.sakuraMode)) {
            return ParticleUtil.ParticleType.SAKURA;
        }
        if (this.particleType.is(this.geminiMode)) {
            return ParticleUtil.ParticleType.GEMINI;
        }
        return this.particleType.is(this.simsMode) ? ParticleUtil.ParticleType.SIMS : ParticleUtil.ParticleType.STAR;
    }

    @Override
    public void onEnable() {
        if (ParticleEffects.mc.field_1724 != null) {
            this.lastPlayerPos = ParticleEffects.mc.field_1724.method_19538();
            this.wasOnGround = ParticleEffects.mc.field_1724.method_24828();
        }
    }

    @Override
    public void onDisable() {
        this.particles.clear();
    }
}

