/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_243
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.target.TargetSettings;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.Utils;
import micronix.experiment.utility.render.batching.impl.IconBatching;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

@ModuleInfo(name="Arrows", category=ModuleCategory.VISUALS, desc="modules.descriptions.tracers")
@Environment(value=EnvType.CLIENT)
public class Arrows
extends BaseModule {
    private final BooleanSetting lines = new BooleanSetting(this, "lines");
    private final SelectSetting targets = new SelectSetting((SettingsContainer)this, "modules.settings.tracers.targets", "modules.settings.tracers.targets.description");
    private final SelectSetting.Value players = new SelectSetting.Value(this.targets, "modules.settings.tracers.targets.players").select();
    private final SelectSetting.Value animals = new SelectSetting.Value(this.targets, "modules.settings.tracers.targets.animals");
    private final SelectSetting.Value mobs = new SelectSetting.Value(this.targets, "modules.settings.tracers.targets.mobs");
    private final SelectSetting.Value invisibles = new SelectSetting.Value(this.targets, "modules.settings.tracers.targets.invisibles").select();
    private final SelectSetting.Value nakedPlayers = new SelectSetting.Value(this.targets, "modules.settings.tracers.targets.naked_players").select();
    private final SelectSetting.Value friends = new SelectSetting.Value(this.targets, "modules.settings.tracers.targets.friends").select();
    private final Map<class_1297, ArrowsAnimation> animations = new HashMap<class_1297, ArrowsAnimation>();
    private final EventListener<HudRenderEvent> onHud = event -> {
        class_1309 livingEntity;
        if (Arrows.mc.field_1724 == null || Arrows.mc.field_1687 == null || this.lines.isEnabled()) {
            return;
        }
        CustomDrawContext context = event.getContext();
        class_4587 ms = context.method_51448();
        TargetSettings targetSettings = new TargetSettings.Builder().targetPlayers(this.players.isSelected()).targetAnimals(this.animals.isSelected()).targetInvisibles(this.invisibles.isSelected()).targetFriends(this.friends.isSelected()).targetNakedPlayers(this.nakedPlayers.isSelected()).targetMobs(this.mobs.isSelected()).build();
        HashSet<class_1297> toRemove = new HashSet<class_1297>();
        for (Map.Entry<class_1297, ArrowsAnimation> entry : this.animations.entrySet()) {
            class_1297 entity = entry.getKey();
            ArrowsAnimation animation = entry.getValue();
            boolean shouldShow = Arrows.mc.field_1687.method_62145(entity) && entity instanceof class_1309 && targetSettings.isEntityValid((class_1297)(livingEntity = (class_1309)entity));
            animation.showing.update(shouldShow);
            animation.showing.setDuration(500L);
            if (animation.showing.getValue() != 0.0f || shouldShow) continue;
            toRemove.add(entity);
        }
        for (class_1297 entity : Arrows.mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309) || !targetSettings.isEntityValid((class_1297)(livingEntity = (class_1309)entity)) || this.animations.containsKey(entity)) continue;
            this.animations.put(entity, new ArrowsAnimation());
        }
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.disableCull();
        ms.method_22903();
        IconBatching iconBatching = new IconBatching(class_290.field_1575, context.method_51448());
        ms.method_46416(sr.getScaledWidth() / 2.0f, sr.getScaledHeight() / 2.0f, 0.0f);
        for (Map.Entry<class_1297, ArrowsAnimation> arrow : this.animations.entrySet()) {
            if (!(arrow.getValue().showing.getValue() > 0.0f)) continue;
            RenderUtility.rotate(ms, 0.0f, 0.0f, this.calculateAngle(arrow.getKey(), event.getTickDelta()));
            RenderUtility.scale(ms, 0.0f, 0.0f, 2.0f - arrow.getValue().showing.getValue());
            context.drawTexture(Experiment.id("textures/arrow.png"), -10.0f, 40.0f, 20.0f, 20.0f, (Experiment.getInstance().getFriendManager().isFriend(arrow.getKey().method_5477().getString()) ? Colors.GREEN : Colors.ACCENT).mulAlpha(arrow.getValue().showing.getValue()));
            RenderUtility.end(ms);
            RenderUtility.end(ms);
        }
        iconBatching.draw();
        for (class_1297 entity : toRemove) {
            this.animations.remove(entity);
        }
        ms.method_22909();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.disableDepthTest();
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (Arrows.mc.field_1724 == null || Arrows.mc.field_1687 == null || !this.lines.isEnabled()) {
            return;
        }
        class_4587 matrices = event.getMatrices();
        TargetSettings targetSettings = new TargetSettings.Builder().targetPlayers(this.players.isSelected()).targetAnimals(this.animals.isSelected()).targetInvisibles(this.invisibles.isSelected()).targetFriends(this.friends.isSelected()).targetNakedPlayers(this.nakedPlayers.isSelected()).targetMobs(this.mobs.isSelected()).build();
        RenderUtility.setupRender3D(false);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (class_1297 entity : Arrows.mc.field_1687.method_18112()) {
            class_1309 livingEntity;
            if (!(entity instanceof class_1309) || !targetSettings.isEntityValid((class_1297)(livingEntity = (class_1309)entity))) continue;
            class_243 entityPos = Utils.getInterpolatedPos((class_1297)livingEntity, event.getTickDelta());
            Draw3DUtility.renderLineFromPlayer(matrices, builder, entityPos.method_1031(0.0, (double)(livingEntity.method_17682() / 2.0f), 0.0), Colors.WHITE);
        }
        RenderUtility.buildBuffer(builder);
        RenderUtility.endRender3D();
    };

    private float calculateAngle(class_1297 entity, float partialTicks) {
        class_243 pos = Utils.getInterpolatedPos(entity, partialTicks).method_1020(Arrows.mc.field_1773.method_19418().method_19326());
        double cos = class_3532.method_15362((float)((float)((double)Arrows.mc.field_1773.method_19418().method_19330() * (Math.PI / 180))));
        double sin = class_3532.method_15374((float)((float)((double)Arrows.mc.field_1773.method_19418().method_19330() * (Math.PI / 180))));
        double rotY = -(pos.field_1350 * cos - pos.field_1352 * sin);
        double rotX = -(pos.field_1352 * cos + pos.field_1350 * sin);
        return (float)(Math.atan2(rotY, rotX) * 180.0 / Math.PI - 90.0);
    }

    @Environment(value=EnvType.CLIENT)
    static class ArrowsAnimation {
        Animation showing = new Animation(300L, Easing.BAKEK);
        Animation rotating = new Animation(300L, Easing.BAKEK);

        ArrowsAnimation() {
        }
    }
}

