/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10017
 *  net.minecraft.class_1297
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.mixins.EntityRenderStateAddition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_1297;

@ModuleInfo(name="Anti Invisible", category=ModuleCategory.VISUALS)
@Environment(value=EnvType.CLIENT)
public class AntiInvisible
extends BaseModule {
    private final SliderSetting opacity = new SliderSetting(this, "modules.settings.anti_invisible.opacity").min(10.0f).max(100.0f).step(1.0f).currentValue(50.0f).suffix(number -> "%");

    public boolean shouldModifyOpacity(class_10017 renderState) {
        class_1297 entity = ((EntityRenderStateAddition)renderState).experiment$getEntity();
        return entity.method_5767();
    }

    public SliderSetting getOpacity() {
        return this.opacity;
    }
}

