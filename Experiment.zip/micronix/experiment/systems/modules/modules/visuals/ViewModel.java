/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HandRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.constructions.viewmodel.ViewModelTransformations;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;

@ModuleInfo(name="View Model", category=ModuleCategory.VISUALS, desc="modules.descriptions.view_model")
@Environment(value=EnvType.CLIENT)
public class ViewModel
extends BaseModule {
    private final SliderSetting mainTranslateX = new SliderSetting(this, "modules.settings.view_model.main_translate_x").min(-2.0f).max(2.0f).currentValue(0.0f).step(0.05f);
    private final SliderSetting mainTranslateY = new SliderSetting(this, "modules.settings.view_model.main_translate_y").min(-2.0f).max(2.0f).currentValue(0.0f).step(0.05f);
    private final SliderSetting mainTranslateZ = new SliderSetting(this, "modules.settings.view_model.main_translate_z").min(-2.0f).max(2.0f).currentValue(0.0f).step(0.05f);
    private final SliderSetting mainRotateX = new SliderSetting(this, "modules.settings.view_model.main_rotate_x").min(-180.0f).max(180.0f).currentValue(0.0f).step(1.0f);
    private final SliderSetting mainRotateY = new SliderSetting(this, "modules.settings.view_model.main_rotate_y").min(-180.0f).max(180.0f).currentValue(0.0f).step(1.0f);
    private final SliderSetting mainRotateZ = new SliderSetting(this, "modules.settings.view_model.main_rotate_z").min(-180.0f).max(180.0f).currentValue(0.0f).step(1.0f);
    private final SliderSetting offTranslateX = new SliderSetting(this, "modules.settings.view_model.off_translate_x").min(-2.0f).max(2.0f).currentValue(0.0f).step(0.05f);
    private final SliderSetting offTranslateY = new SliderSetting(this, "modules.settings.view_model.off_translate_y").min(-2.0f).max(2.0f).currentValue(0.0f).step(0.05f);
    private final SliderSetting offTranslateZ = new SliderSetting(this, "modules.settings.view_model.off_translate_z").min(-2.0f).max(2.0f).currentValue(0.0f).step(0.05f);
    private final SliderSetting offRotateX = new SliderSetting(this, "modules.settings.view_model.off_rotate_x").min(-180.0f).max(180.0f).currentValue(0.0f).step(1.0f);
    private final SliderSetting offRotateY = new SliderSetting(this, "modules.settings.view_model.off_rotate_y").min(-180.0f).max(180.0f).currentValue(0.0f).step(1.0f);
    private final SliderSetting offRotateZ = new SliderSetting(this, "modules.settings.view_model.off_rotate_z").min(-180.0f).max(180.0f).currentValue(0.0f).step(1.0f);
    private final EventListener<HandRenderEvent> onHandRender = event -> {
        if (this.isEnabled()) {
            boolean hasTransformations;
            boolean isMain = event.getHand() == class_1268.field_5808;
            float translateX = isMain ? this.mainTranslateX.getCurrentValue() : this.offTranslateX.getCurrentValue();
            float translateY = isMain ? this.mainTranslateY.getCurrentValue() : this.offTranslateY.getCurrentValue();
            float translateZ = isMain ? this.mainTranslateZ.getCurrentValue() : this.offTranslateZ.getCurrentValue();
            float rotateX = isMain ? this.mainRotateX.getCurrentValue() : this.offRotateX.getCurrentValue();
            float rotateY = isMain ? this.mainRotateY.getCurrentValue() : this.offRotateY.getCurrentValue();
            float rotateZ = isMain ? this.mainRotateZ.getCurrentValue() : this.offRotateZ.getCurrentValue();
            boolean bl = hasTransformations = translateX != 0.0f || translateY != 0.0f || translateZ != 0.0f || rotateX != 0.0f || rotateY != 0.0f || rotateZ != 0.0f;
            if (hasTransformations) {
                ViewModelTransformations trans = new ViewModelTransformations(translateX, translateY, translateZ, rotateX, rotateY, rotateZ);
                event.setViewModelTransformations(trans);
            }
        }
    };
}

