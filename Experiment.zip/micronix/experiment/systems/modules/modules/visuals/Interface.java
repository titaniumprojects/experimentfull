/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.visuals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.localization.Language;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Interface", category=ModuleCategory.VISUALS, enabledByDefault=true)
@Environment(value=EnvType.CLIENT)
public class Interface
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.interface.mode");
    private final ModeSetting.Value liquidGlass = new ModeSetting.Value(this.mode, "modules.settings.interface.liquidGlass");
    private final ModeSetting.Value minimalism = new ModeSetting.Value(this.mode, "modules.settings.interface.minimalism").select();
    private final ModeSetting themeMode = new ModeSetting((SettingsContainer)this, "modules.settings.interface.themeMode", () -> this.liquidGlass.isSelected());
    public final ModeSetting.Value dark = new ModeSetting.Value(this.themeMode, "modules.settings.interface.dark");
    public final ModeSetting.Value light = new ModeSetting.Value(this.themeMode, "modules.settings.interface.light");
    private final ModeSetting language = new ModeSetting(this, "modules.settings.interface.language");
    private final Animation liquidGlassAnim = new Animation(500L, Easing.BOTH_CUBIC);
    public final ColorSetting minimalismMainColor = new ColorSetting(this, "modules.settings.interface.minimalism.mainColor", () -> !this.minimalism.isSelected()).color(new ColorRGBA(255.0f, 71.0f, 71.0f, 255.0f)).alpha(false);
    public final ColorSetting liquidGlassColor = new ColorSetting(this, "modules.settings.interface.liquidGlass.glassColor", () -> !this.liquidGlass.isSelected()).color(new ColorRGBA(200.0f, 220.0f, 255.0f, 100.0f)).alpha(true);
    public final ColorSetting liquidClientColor = new ColorSetting(this, "modules.settings.interface.liquidGlass.clientColor", () -> !this.liquidGlass.isSelected()).color(new ColorRGBA(255.0f, 71.0f, 71.0f, 255.0f)).alpha(true);
    public final SliderSetting liquidDistortion = new SliderSetting((SettingsContainer)this, "modules.settings.interface.liquidGlass.distortion", () -> !this.liquidGlass.isSelected()).min(-0.2f).max(0.2f).step(0.01f).currentValue(0.08f);
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Interface-Thread");
        t.setDaemon(true);
        return t;
    });
    private boolean languageAutoDetected;
    private int lastLang = 0;
    private final EventListener<HudRenderEvent> onHudRenderEvent = event -> {
        this.liquidGlassAnim.setEasing(Easing.FIGMA_EASE_IN_OUT);
        this.liquidGlassAnim.update(this.liquidGlass.isSelected());
        int lang = this.language.getValues().indexOf(this.language.getValue());
        if (lang != this.lastLang) {
            Localizator.setLanguage(lang == 0 ? Language.RU_RU : (lang == 1 ? Language.EN_US : (lang == 2 ? Language.UK_UA : Language.PL_PL)));
            this.languageAutoDetected = false;
        }
        this.lastLang = lang;
        Experiment.getInstance().getThemeManager().setCurrentTheme(this.dark.isSelected() ? Theme.DARK : Theme.LIGHT);
    };

    public Interface() {
        new ModeSetting.Value(this.language, "\u0420\u0443\u0441\u0441\u043a\u0438\u0439");
        new ModeSetting.Value(this.language, "English");
        new ModeSetting.Value(this.language, "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430");
        new ModeSetting.Value(this.language, "Polski");
    }

    private void detectLanguageByIP() {
        this.executor.submit(() -> {
            try {
                String countryCode = this.getCountryCodeByIP();
                if (countryCode != null) {
                    String var2;
                    switch (var2 = countryCode.toUpperCase()) {
                        case "UA": {
                            this.language.setValue(this.language.getValues().get(2));
                            Localizator.setLanguage(Language.UK_UA);
                            break;
                        }
                        case "PL": {
                            this.language.setValue(this.language.getValues().get(3));
                            Localizator.setLanguage(Language.PL_PL);
                            break;
                        }
                        default: {
                            this.language.setValue(this.language.getValues().getFirst());
                            Localizator.setLanguage(Language.RU_RU);
                        }
                    }
                    this.languageAutoDetected = true;
                    this.lastLang = this.language.getValues().indexOf(this.language.getValue());
                }
            }
            catch (Exception var5) {
                Experiment.LOGGER.error("Failed to detect language by IP", (Throwable)var5);
            }
        });
    }

    private String getCountryCodeByIP() throws IOException {
        URL url = new URL("http://ip-api.com/json/?fields=countryCode");
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();
        connection.setRequestMethod("GET");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));){
            String line;
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            String json = response.toString();
            int start = json.indexOf("countryCode\":\"") + 14;
            if (start >= 14) {
                int end = json.indexOf("\"", start);
                String string = json.substring(start, end);
                return string;
            }
        }
        return null;
    }

    public static boolean glassSelected() {
        return Experiment.getInstance().getModuleManager().getModule(Interface.class).liquidGlass.isSelected();
    }

    public static float glass() {
        return Experiment.getInstance().getModuleManager().getModule(Interface.class).liquidGlassAnim.getValue();
    }

    public static float minimalizm() {
        return 1.0f - Interface.glass();
    }

    public static boolean showGlass() {
        return Interface.glass() > 0.0f;
    }

    public static boolean showMinimalizm() {
        return Interface.glass() < 1.0f;
    }

    public static float getDistortion() {
        Interface module = Experiment.getInstance().getModuleManager().getModule(Interface.class);
        return module != null ? module.liquidDistortion.getCurrentValue() : 0.08f;
    }

    public ModeSetting getMode() {
        return this.mode;
    }

    public ModeSetting.Value getLiquidGlass() {
        return this.liquidGlass;
    }

    public ModeSetting.Value getMinimalism() {
        return this.minimalism;
    }

    public ModeSetting getThemeMode() {
        return this.themeMode;
    }

    public ModeSetting.Value getDark() {
        return this.dark;
    }

    public ModeSetting.Value getLight() {
        return this.light;
    }

    public ModeSetting getLanguage() {
        return this.language;
    }

    public Animation getLiquidGlassAnim() {
        return this.liquidGlassAnim;
    }

    public ExecutorService getExecutor() {
        return this.executor;
    }

    public boolean isLanguageAutoDetected() {
        return this.languageAutoDetected;
    }

    public int getLastLang() {
        return this.lastLang;
    }

    public EventListener<HudRenderEvent> getOnHudRenderEvent() {
        return this.onHudRenderEvent;
    }

    public ColorSetting getMinimalismMainColor() {
        return this.minimalismMainColor;
    }

    public ColorSetting getLiquidGlassColor() {
        return this.liquidGlassColor;
    }

    public ColorSetting getLiquidClientColor() {
        return this.liquidClientColor;
    }

    public SliderSetting getLiquidDistortion() {
        return this.liquidDistortion;
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (this.executor != null && !this.executor.isShutdown()) {
            this.executor.shutdownNow();
        }
    }
}

