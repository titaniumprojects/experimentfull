/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SelectSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Removals", category=ModuleCategory.VISUALS, enabledByDefault=true, desc="modules.descriptions.removals")
@Environment(value=EnvType.CLIENT)
public class Removals
extends BaseModule {
    private double oldFovEffectScale;
    private final SelectSetting effects = new SelectSetting(this, "modules.settings.removals.effects");
    private final SelectSetting.Value hurtCam = new SelectSetting.Value(this.effects, "modules.settings.removals.hurtCam").select();
    private final SelectSetting.Value scoreboard = new SelectSetting.Value(this.effects, "modules.settings.removals.scoreboard");
    private final SelectSetting.Value bossBar = new SelectSetting.Value(this.effects, "modules.settings.removals.bossBar");
    private final SelectSetting.Value portal = new SelectSetting.Value(this.effects, "modules.settings.removals.portal").select();
    private final SelectSetting.Value fire = new SelectSetting.Value(this.effects, "modules.settings.removals.fire").select();
    private final SelectSetting.Value clip = new SelectSetting.Value(this.effects, "modules.settings.removals.clip").select();
    private final SelectSetting.Value breakParticles = new SelectSetting.Value(this.effects, "modules.settings.removals.breakParticles");
    private final SelectSetting.Value water = new SelectSetting.Value(this.effects, "modules.settings.removals.water");
    private final SelectSetting.Value nausea = new SelectSetting.Value(this.effects, "modules.settings.removals.nausea").select();
    private final SelectSetting.Value blindness = new SelectSetting.Value(this.effects, "modules.settings.removals.blindness");
    private final SelectSetting.Value pumpkin = new SelectSetting.Value(this.effects, "modules.settings.removals.pumpkin");
    private final SelectSetting.Value fov = new SelectSetting.Value(this.effects, "modules.settings.removals.fov").select();
    private final SelectSetting.Value weather = new SelectSetting.Value(this.effects, "modules.settings.removals.weather");
    private final SelectSetting sounds = new SelectSetting(this, "modules.settings.removals.sounds");
    private final SelectSetting.Value beacon = new SelectSetting.Value(this.sounds, "modules.settings.removals.beacon");
    private final SelectSetting.Value phantoms = new SelectSetting.Value(this.sounds, "modules.settings.removals.phantoms");
    private final SelectSetting.Value weatherSound = new SelectSetting.Value(this.sounds, "modules.settings.removals.weatherSound");
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (this.fov.isSelected()) {
            Removals.mc.field_1690.method_42454().method_41748((Object)0.0);
        }
    };

    @Override
    public void onEnable() {
        this.oldFovEffectScale = (Double)Removals.mc.field_1690.method_42454().method_41753();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        Removals.mc.field_1690.method_42454().method_41748((Object)this.oldFovEffectScale);
        super.onDisable();
    }

    public double getOldFovEffectScale() {
        return this.oldFovEffectScale;
    }

    public SelectSetting getEffects() {
        return this.effects;
    }

    public SelectSetting.Value getHurtCam() {
        return this.hurtCam;
    }

    public SelectSetting.Value getScoreboard() {
        return this.scoreboard;
    }

    public SelectSetting.Value getBossBar() {
        return this.bossBar;
    }

    public SelectSetting.Value getPortal() {
        return this.portal;
    }

    public SelectSetting.Value getFire() {
        return this.fire;
    }

    public SelectSetting.Value getClip() {
        return this.clip;
    }

    public SelectSetting.Value getBreakParticles() {
        return this.breakParticles;
    }

    public SelectSetting.Value getWater() {
        return this.water;
    }

    public SelectSetting.Value getNausea() {
        return this.nausea;
    }

    public SelectSetting.Value getBlindness() {
        return this.blindness;
    }

    public SelectSetting.Value getPumpkin() {
        return this.pumpkin;
    }

    public SelectSetting.Value getFov() {
        return this.fov;
    }

    public SelectSetting.Value getWeather() {
        return this.weather;
    }

    public SelectSetting getSounds() {
        return this.sounds;
    }

    public SelectSetting.Value getBeacon() {
        return this.beacon;
    }

    public SelectSetting.Value getPhantoms() {
        return this.phantoms;
    }

    public SelectSetting.Value getWeatherSound() {
        return this.weatherSound;
    }

    public EventListener<ClientPlayerTickEvent> getOnUpdateEvent() {
        return this.onUpdateEvent;
    }
}

