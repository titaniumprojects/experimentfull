/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_2761
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.EntityUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2761;

@ModuleInfo(name="Ambience", category=ModuleCategory.VISUALS, desc="modules.descriptions.ambience")
@Environment(value=EnvType.CLIENT)
public class Ambience
extends BaseModule {
    public final BooleanSetting endSky = new BooleanSetting(this, "modules.settings.ambience.end_sky");
    private final BooleanSetting customTime = new BooleanSetting(this, "modules.settings.ambience.custom_time");
    private final SliderSetting time = new SliderSetting((SettingsContainer)this, "modules.settings.ambience.time", () -> !this.customTime.isEnabled()).step(1000.0f).min(0.0f).max(24000.0f).currentValue(12000.0f);
    public final BooleanSetting bright = new BooleanSetting(this, "modules.settings.ambience.bright").enable();
    private final BooleanSetting customSkyColor = new BooleanSetting(this, "\u041c\u0435\u043d\u044f\u0442\u044c \u0446\u0432\u0435\u0442 \u043d\u0435\u0431\u0430").enabled(false);
    private final ColorSetting skyColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442", () -> !this.customSkyColor.isEnabled()).color(new ColorRGBA(0.5f, 0.7f, 1.0f, 1.0f)).alpha(true);
    private long oldTime;
    private final EventListener<ReceivePacketEvent> onReceivePacket = event -> {
        if (event.getPacket() instanceof class_2761 && this.customTime.isEnabled()) {
            event.cancel();
        }
    };

    public class_243 getSkyColor(class_243 originalColor) {
        if (!this.customSkyColor.isEnabled()) {
            return originalColor;
        }
        ColorRGBA sky = this.skyColor.getColor();
        float r = sky.getRed() / 255.0f;
        float g = sky.getGreen() / 255.0f;
        float b = sky.getBlue() / 255.0f;
        return new class_243((double)r, (double)g, (double)b);
    }

    @Override
    public void tick() {
        if (Ambience.mc.field_1687 != null) {
            if (this.customTime.isEnabled()) {
                Ambience.mc.field_1687.method_28104().method_165((long)this.time.getCurrentValue());
            }
            super.tick();
        }
    }

    @Override
    public void onEnable() {
        if (EntityUtility.isInGame() && Ambience.mc.field_1687 != null) {
            this.oldTime = Ambience.mc.field_1687.method_8510();
            super.onEnable();
        }
    }

    @Override
    public void onDisable() {
        if (EntityUtility.isInGame() && Ambience.mc.field_1687 != null) {
            Ambience.mc.field_1687.method_28104().method_165(this.oldTime);
            super.onDisable();
        }
    }

    public BooleanSetting getEndSky() {
        return this.endSky;
    }

    public BooleanSetting getCustomTime() {
        return this.customTime;
    }

    public SliderSetting getTime() {
        return this.time;
    }

    public BooleanSetting getBright() {
        return this.bright;
    }

    public long getOldTime() {
        return this.oldTime;
    }

    public EventListener<ReceivePacketEvent> getOnReceivePacket() {
        return this.onReceivePacket;
    }

    public BooleanSetting getCustomSkyColor() {
        return this.customSkyColor;
    }

    public ColorSetting getSkyColor() {
        return this.skyColor;
    }
}

