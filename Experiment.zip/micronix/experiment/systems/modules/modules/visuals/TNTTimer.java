/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1541
 *  net.minecraft.class_1802
 *  net.minecraft.class_241
 *  net.minecraft.class_243
 *  net.minecraft.class_290
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.render.Utils;
import micronix.experiment.utility.render.batching.Batching;
import micronix.experiment.utility.render.batching.impl.FontBatching;
import micronix.experiment.utility.render.batching.impl.RectBatching;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1802;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

@ModuleInfo(name="TNT Timer", category=ModuleCategory.VISUALS, desc="modules.descriptions.tnt_timer")
@Environment(value=EnvType.CLIENT)
public class TNTTimer
extends BaseModule {
    private final EventListener<PreHudRenderEvent> onHudRenderEvent = event -> {
        class_4587 matrices = event.getContext().method_51448();
        RectBatching rect = new RectBatching(class_290.field_1576, event.getContext().method_51448());
        for (class_1297 entity : TNTTimer.mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1541)) continue;
            class_1541 tnt = (class_1541)entity;
            this.renderBack((PreHudRenderEvent)event, matrices, tnt);
        }
        ((Batching)rect).draw();
        FontBatching batching = new FontBatching(class_290.field_1575, Fonts.MEDIUM);
        for (class_1297 entityx : TNTTimer.mc.field_1687.method_18112()) {
            if (!(entityx instanceof class_1541)) continue;
            class_1541 tnt = (class_1541)entityx;
            this.renderText((PreHudRenderEvent)event, matrices, tnt);
        }
        batching.draw();
    };

    private void renderBack(PreHudRenderEvent event, class_4587 matrices, class_1541 entity) {
        int fuse = entity.method_6969();
        float seconds = (float)fuse / 20.0f;
        String text = Localizator.translate("modules.tnt_timer.format", Float.valueOf(seconds));
        class_243 renderPos = entity.method_30950(event.getTickDelta()).method_1031(0.0, 0.5, 0.0);
        class_241 screenPos = Utils.worldToScreen(renderPos);
        if (screenPos != null) {
            float distance = (float)TNTTimer.mc.field_1724.method_19538().method_1022(renderPos);
            float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343 - 6.0f, screenPos.field_1342, 0.0f);
            matrices.method_22905(scale, scale, 1.0f);
            int width = (int)Fonts.MEDIUM.getFont(11.0f).width(text);
            int x = -width / 2;
            event.getContext().drawRect(x - 3, 1.0f, width + 26, Fonts.MEDIUM.getFont(11.0f).height() + 8.0f, new ColorRGBA(0.0f, 0.0f, 0.0f, 100.0f));
            matrices.method_22909();
        }
    }

    private void renderText(PreHudRenderEvent event, class_4587 matrices, class_1541 entity) {
        int fuse = entity.method_6969();
        float seconds = (float)fuse / 20.0f;
        String text = Localizator.translate("modules.tnt_timer.format", Float.valueOf(seconds));
        class_243 renderPos = entity.method_30950(event.getTickDelta()).method_1031(0.0, 0.5, 0.0);
        class_241 screenPos = Utils.worldToScreen(renderPos);
        if (screenPos != null) {
            float distance = (float)TNTTimer.mc.field_1724.method_19538().method_1022(renderPos);
            float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
            matrices.method_22903();
            matrices.method_46416(screenPos.field_1343 - 6.0f, screenPos.field_1342, 0.0f);
            matrices.method_22905(scale, scale, 1.0f);
            int width = (int)Fonts.MEDIUM.getFont(11.0f).width(text);
            int x = -width / 2;
            event.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), text, x + 16, 5.0f, ColorRGBA.WHITE);
            event.getContext().drawItem(class_1802.field_8626, (float)x, 3.0f, 0.75f);
            matrices.method_22909();
        }
    }
}

