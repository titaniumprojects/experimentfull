/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1922
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_265
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_3965
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.render.RenderUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

@ModuleInfo(name="Block Overlay", category=ModuleCategory.VISUALS, desc="modules.descriptions.blockoverlay")
@Environment(value=EnvType.CLIENT)
public class BlockOverlay
extends BaseModule {
    private final BooleanSetting syncWithTheme = new BooleanSetting(this, "modules.settings.blockoverlay.sync_with_theme").enabled(true);
    private final ColorSetting color = new ColorSetting(this, "modules.settings.blockoverlay.color", () -> this.syncWithTheme.isEnabled()).color(new ColorRGBA(255.0f, 71.0f, 151.0f, 255.0f)).alpha(true);
    private final EventListener<Render3DEvent> onRender3D = event -> {
        class_3965 result;
        class_239 patt0$temp = BlockOverlay.mc.field_1765;
        if (patt0$temp instanceof class_3965 && (result = (class_3965)patt0$temp).method_17783().equals((Object)class_239.class_240.field_1332)) {
            class_2338 pos = result.method_17777();
            if (BlockOverlay.mc.field_1687 == null) {
                return;
            }
            class_4587 matrices = event.getMatrices();
            class_4184 camera = BlockOverlay.mc.field_1773.method_19418();
            class_243 cameraPos = camera.method_19326();
            class_265 shape = BlockOverlay.mc.field_1687.method_8320(pos).method_26218((class_1922)BlockOverlay.mc.field_1687, pos);
            class_238 box = shape.method_1110() ? new class_238(pos) : shape.method_1107().method_996(pos);
            ColorRGBA overlayColor = this.syncWithTheme.isEnabled() ? Colors.getAccentColor() : this.color.getColor();
            RenderSystem.enableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            class_287 quadsBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
            Draw3DUtility.renderFilledBox(matrices, quadsBuffer, box.method_989(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215()), overlayColor.withAlpha(50.0f));
            RenderUtility.buildBuffer(quadsBuffer);
            class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
            Draw3DUtility.renderOutlinedBox(matrices, linesBuffer, box.method_989(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215()), overlayColor.withAlpha(150.0f));
            RenderUtility.buildBuffer(linesBuffer);
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
        }
    };
}

