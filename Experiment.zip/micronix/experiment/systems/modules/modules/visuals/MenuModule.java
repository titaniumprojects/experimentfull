/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_437
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.ui.menu.api.MenuCloseListener;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_437;

@ModuleInfo(name="Menu", category=ModuleCategory.VISUALS, key=344, desc="modules.descriptions.menu")
@Environment(value=EnvType.CLIENT)
public class MenuModule
extends BaseModule {
    private static final MenuCloseListener menuCloseListener = new MenuCloseListener();
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.menu.mode");
    private final ModeSetting.Value dropdown = new ModeSetting.Value(this.mode, "modules.settings.menu.mode.dropdown");
    private final ModeSetting.Value modern = new ModeSetting.Value(this.mode, "modules.settings.menu.mode.modern");

    @Override
    public void onEnable() {
        if (MenuModule.mc.field_1755 instanceof MenuScreen) {
            return;
        }
        MenuScreen menuScreen = Experiment.getInstance().getMenuScreen();
        mc.method_1507((class_437)menuScreen);
        Sounds soundsModule = Experiment.getInstance().getModuleManager().getModule(Sounds.class);
        if (soundsModule.isEnabled()) {
            ClientSounds.CLICKGUI_OPEN.play(soundsModule.getVolume().getCurrentValue());
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (MenuModule.mc.field_1755 instanceof MenuScreen) {
            mc.method_1507(null);
            Experiment.getInstance().getMenuScreen().setClosing(true);
        }
        super.onDisable();
    }

    public ModeSetting.Value getModern() {
        return this.modern;
    }
}

