/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_742
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.visuals;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.render.CrystalRenderer;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.Utils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_9801;

@ModuleInfo(name="Friend Markers", desc="\u0412\u044b\u0434\u0435\u043b\u044f\u0435\u0442 \u0434\u0440\u0443\u0437\u0435\u0439", category=ModuleCategory.VISUALS)
@Environment(value=EnvType.CLIENT)
public class FriendMarkers
extends BaseModule {
    private final ModeSetting setting = new ModeSetting(this, "modules.settings.friends_markers.setting");
    private final ModeSetting.Value heads = new ModeSetting.Value(this.setting, "modules.settings.friends_markers.heads");
    private final ModeSetting.Value sims = new ModeSetting.Value(this.setting, "Sims");
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (!this.sims.isSelected()) {
            return;
        }
        RenderUtility.setupRender3D(true);
        class_4587 ms = event.getMatrices();
        class_4184 camera = FriendMarkers.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        ColorRGBA color = new ColorRGBA(52.0f, 199.0f, 89.0f);
        class_287 builder = CrystalRenderer.createBuffer();
        for (class_742 player : FriendMarkers.mc.field_1687.method_18456()) {
            if (!Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString())) continue;
            ms.method_22903();
            RenderUtility.prepareMatrices(ms, Utils.getInterpolatedPos((class_1297)player, event.getTickDelta()));
            float size = 0.1f;
            CrystalRenderer.render(ms, builder, 0.0f, player.method_17682() + 0.4f, 0.0f, size, color.withAlpha(255.0f));
            ms.method_22909();
        }
        class_9801 built = builder.method_60794();
        if (built != null) {
            class_286.method_43433((class_9801)built);
        }
        RenderUtility.endRender3D();
    };

    public ModeSetting.Value getHeads() {
        return this.heads;
    }
}

