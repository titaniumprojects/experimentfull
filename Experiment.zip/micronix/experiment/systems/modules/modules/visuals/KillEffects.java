/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.EntityDeathEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.sounds.ClientSoundInstance;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;

@ModuleInfo(name="Kill Effects", category=ModuleCategory.VISUALS, desc="modules.descriptions.kill_effects")
@Environment(value=EnvType.CLIENT)
public class KillEffects
extends BaseModule {
    private final List<Lightning> lightnings = new ArrayList<Lightning>();
    private final Random random = new Random();
    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.kill_effects.color_mode");
    private final ModeSetting.Value clientColor = new ModeSetting.Value(this.colorMode, "modules.settings.kill_effects.color_mode.client").select();
    private final ModeSetting.Value customColor = new ModeSetting.Value(this.colorMode, "modules.settings.kill_effects.color_mode.custom");
    private final ColorSetting color = new ColorSetting(this, "modules.settings.kill_effects.color", () -> !this.customColor.isSelected()).color(new ColorRGBA(151.0f, 71.0f, 255.0f, 255.0f));
    private final BooleanSetting playSound = new BooleanSetting(this, "modules.settings.kill_effects.play_sound").enabled(true);
    private final SliderSetting volume = new SliderSetting((SettingsContainer)this, "modules.settings.kill_effects.volume", () -> !this.playSound.isEnabled()).min(0.0f).max(100.0f).step(1.0f).currentValue(100.0f);
    private final BooleanSetting mobs = new BooleanSetting(this, "modules.settings.kill_effects.mobs").enabled(false);
    private final ModeSetting soundType = new ModeSetting((SettingsContainer)this, "modules.settings.kill_effects.sound_type", () -> !this.playSound.isEnabled());
    private final ModeSetting.Value kill1 = new ModeSetting.Value(this.soundType, "Kill1");
    private final ModeSetting.Value kill2 = new ModeSetting.Value(this.soundType, "Kill2");
    private final ModeSetting.Value kill3 = new ModeSetting.Value(this.soundType, "Kill3");
    private final ModeSetting.Value kill4 = new ModeSetting.Value(this.soundType, "Kill4");
    private final ModeSetting.Value kill5 = new ModeSetting.Value(this.soundType, "Kill5");
    private final ModeSetting.Value kill6 = new ModeSetting.Value(this.soundType, "Kill6");
    private final ModeSetting.Value randomMode = new ModeSetting.Value(this.soundType, "Random").select();
    private final EventListener<EntityDeathEvent> onEntityDeath = event -> {
        if (KillEffects.mc.field_1687 != null && KillEffects.mc.field_1724 != null && event.getEntity() instanceof class_1309) {
            boolean isPlayerKiller = false;
            if (event.getSource() != null && event.getSource().method_5529() != null && event.getSource().method_5529().method_5667().equals(KillEffects.mc.field_1724.method_5667())) {
                isPlayerKiller = true;
            }
            if (!isPlayerKiller) {
                return;
            }
            if ((this.mobs.isEnabled() || event.getEntity() instanceof class_1657) && event.getEntity() != KillEffects.mc.field_1724 && !event.getEntity().method_31481()) {
                ColorRGBA effectColor = this.clientColor.isSelected() ? Colors.getAccentColor() : this.color.getColor();
                this.lightnings.add(new Lightning(event.getEntity().method_19538(), effectColor));
                if (this.playSound.isEnabled()) {
                    ClientSoundInstance sound = this.getSelectedSound();
                    sound.play(this.volume.getCurrentValue() / 100.0f);
                }
            }
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        class_4587 ms = event.getMatrices();
        class_4184 camera = KillEffects.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        ms.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask((boolean)false);
        class_2960 id = Experiment.id("textures/bloom.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)id);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (Lightning lightning : this.lightnings) {
            lightning.render(builder, event.getMatrices(), camera);
            if (lightning.animation.getValue() != 1.0f) continue;
            lightning.showing = false;
        }
        class_9801 builtBuffer = builder.method_60794();
        if (builtBuffer != null) {
            class_286.method_43433((class_9801)builtBuffer);
        }
        RenderSystem.depthMask((boolean)true);
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.disableDepthTest();
        ms.method_22909();
        this.lightnings.removeIf(lightningx -> !lightningx.showing && lightningx.animation.getValue() == 0.0f);
    };

    private ClientSoundInstance getSelectedSound() {
        if (this.soundType.is(this.kill1)) {
            return ClientSounds.KILL1;
        }
        if (this.soundType.is(this.kill2)) {
            return ClientSounds.KILL2;
        }
        if (this.soundType.is(this.kill3)) {
            return ClientSounds.KILL3;
        }
        if (this.soundType.is(this.kill4)) {
            return ClientSounds.KILL4;
        }
        if (this.soundType.is(this.kill5)) {
            return ClientSounds.KILL5;
        }
        if (this.soundType.is(this.kill6)) {
            return ClientSounds.KILL6;
        }
        if (this.soundType.is(this.randomMode)) {
            ClientSoundInstance[] killSounds = new ClientSoundInstance[]{ClientSounds.KILL1, ClientSounds.KILL2, ClientSounds.KILL3, ClientSounds.KILL4, ClientSounds.KILL5, ClientSounds.KILL6};
            return killSounds[this.random.nextInt(killSounds.length)];
        }
        return ClientSounds.KILL1;
    }

    @Environment(value=EnvType.CLIENT)
    static class Lightning {
        final class_243 pos;
        final ColorRGBA color;
        boolean showing = true;
        final Animation animation = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
        final List<class_243> poses = new ArrayList<class_243>();

        public Lightning(class_243 pos, ColorRGBA color) {
            this.pos = pos;
            this.color = color;
            class_243 lastPos = pos;
            for (int i = 0; i < 200; ++i) {
                lastPos = lastPos.method_1031((double)MathUtility.random(-0.4f, 0.4f), 0.25, (double)MathUtility.random(-0.4f, 0.4f));
                this.poses.add(lastPos);
            }
        }

        void render(class_287 builder, class_4587 ms, class_4184 camera) {
            this.animation.setEasing(Easing.BOUNCE_IN);
            this.animation.setDuration(500L);
            this.animation.update(this.showing);
            for (class_243 pos : this.poses) {
                float size = (float)(2.0 + 5.0 * (pos.field_1351 - this.pos.field_1351) / 50.0);
                ms.method_22903();
                RenderUtility.prepareMatrices(ms, pos);
                ms.method_22907(camera.method_23767());
                DrawUtility.drawImage(ms, builder, (double)(-size / 2.0f), (double)(-size / 2.0f), 0.0, (double)size, (double)size, this.color.withAlpha(255.0f * this.animation.getValue() * 0.4f));
                ms.method_22909();
            }
        }
    }
}

