/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

@ModuleInfo(name="Hit Particles", category=ModuleCategory.VISUALS, desc="modules.descriptions.hit_particles")
@Environment(value=EnvType.CLIENT)
public class HitParticles
extends BaseModule
implements IMinecraft {
    private final ModeSetting particleType = new ModeSetting(this, "modules.settings.hit_particles.particle_type");
    private final ModeSetting.Value star = new ModeSetting.Value(this.particleType, "Star").select();
    private final ModeSetting.Value glow = new ModeSetting.Value(this.particleType, "Glow");
    private final ModeSetting.Value heart = new ModeSetting.Value(this.particleType, "Heart");
    private final ModeSetting.Value dollar = new ModeSetting.Value(this.particleType, "Dollar");
    private final ModeSetting.Value starNew = new ModeSetting.Value(this.particleType, "Star New");
    private final ModeSetting.Value random = new ModeSetting.Value(this.particleType, "Random");
    private final ModeSetting colorMode = new ModeSetting(this, "modules.settings.hit_particles.color_mode");
    private final ModeSetting.Value themeColor = new ModeSetting.Value(this.colorMode, "Theme").select();
    private final ModeSetting.Value rainbowColor = new ModeSetting.Value(this.colorMode, "Rainbow");
    private final SliderSetting speed = new SliderSetting(this, "modules.settings.hit_particles.speed").min(0.1f).max(3.0f).step(0.1f).currentValue(1.5f);
    private final SliderSetting size = new SliderSetting(this, "modules.settings.hit_particles.size").min(0.0f).max(3.0f).step(0.1f).currentValue(0.8f);
    private final SliderSetting count = new SliderSetting(this, "modules.settings.hit_particles.count").min(5.0f).max(50.0f).step(1.0f).currentValue(30.0f);
    private final List<Particle> particles = new ArrayList<Particle>();
    private final Random rand = new Random();
    private long lastUpdateTime = System.nanoTime();
    private final EventListener<AttackEvent> onAttack = event -> {
        class_1297 target = event.getEntity();
        if (target != null) {
            int i = 0;
            while ((float)i < this.count.getCurrentValue()) {
                class_2960 texture = this.getParticleTexture();
                class_243 position = new class_243(target.method_23317() + this.randomRange(-0.4, 0.4), target.method_23318() + this.randomRange(0.0, target.method_17682()), target.method_23321() + this.randomRange(-0.4, 0.4));
                class_243 velocity = new class_243(this.randomRange(-1.35, 1.35), this.randomRange(-1.25, 1.25), this.randomRange(-1.35, 1.35));
                ColorRGBA color = this.getThemeColor(i);
                this.particles.add(new Particle(this, texture, position, velocity, color, 0.15f + this.size.getCurrentValue() * 0.3f, this.speed.getCurrentValue()));
                ++i;
            }
        }
    };
    private final EventListener<ClientPlayerTickEvent> onTick = event -> this.particles.removeIf(particle -> particle.time > 1000L);
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (!this.particles.isEmpty()) {
            long now = System.nanoTime();
            double deltaTime = (double)(now - this.lastUpdateTime) / 1.0E9;
            this.lastUpdateTime = now;
            class_4587 matrix = event.getMatrices();
            this.setupRenderState();
            class_4184 camera = HitParticles.mc.field_1773.method_19418();
            class_243 cameraPos = camera.method_19326();
            for (Particle particle : this.particles) {
                particle.update(deltaTime);
                this.renderParticle(matrix, particle, cameraPos);
            }
            this.resetRenderState();
        }
    };

    @Override
    public void onEnable() {
        super.onEnable();
        this.particles.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.particles.clear();
    }

    private void setupRenderState() {
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE, (GlStateManager.class_4535)GlStateManager.class_4535.ONE, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask((boolean)false);
    }

    private void resetRenderState() {
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.disableBlend();
    }

    private void renderParticle(class_4587 matrix, Particle particle, class_243 cameraPos) {
        matrix.method_22903();
        class_243 pos = particle.position.method_1020(cameraPos);
        matrix.method_22904(pos.field_1352, pos.field_1351, pos.field_1350);
        matrix.method_22907(mc.method_1561().method_24197());
        RenderSystem.setShaderTexture((int)0, (class_2960)particle.texture);
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        Matrix4f m = matrix.method_23760().method_23761();
        float halfSize = particle.size / 2.0f;
        this.drawQuad(buffer, m, halfSize, particle.color.withAlpha((int)(particle.alpha * 255.0f)).getRGB());
        class_286.method_43433((class_9801)buffer.method_60800());
        matrix.method_22909();
    }

    private void drawQuad(class_287 buffer, Matrix4f matrix, float size, int color) {
        buffer.method_22918(matrix, -size, -size, 0.0f).method_22913(0.0f, 0.0f).method_39415(color);
        buffer.method_22918(matrix, size, -size, 0.0f).method_22913(1.0f, 0.0f).method_39415(color);
        buffer.method_22918(matrix, size, size, 0.0f).method_22913(1.0f, 1.0f).method_39415(color);
        buffer.method_22918(matrix, -size, size, 0.0f).method_22913(0.0f, 1.0f).method_39415(color);
    }

    private class_2960 getParticleTexture() {
        if (this.random.isSelected()) {
            class_2960[] textures = new class_2960[]{Experiment.id("textures/world/particles/dollar.png"), Experiment.id("textures/world/particles/heart.png"), Experiment.id("textures/world/particles/star.png"), Experiment.id("textures/world/particles/star.png")};
            return textures[this.rand.nextInt(textures.length)];
        }
        if (this.dollar.isSelected()) {
            return Experiment.id("textures/world/particles/dollar.png");
        }
        if (this.heart.isSelected()) {
            return Experiment.id("textures/world/particles/heart.png");
        }
        if (this.starNew.isSelected()) {
            return Experiment.id("textures/world/particles/star.png");
        }
        return this.glow.isSelected() ? Experiment.id("textures/bloom.png") : Experiment.id("textures/world/particles/star.png");
    }

    private ColorRGBA getThemeColor(int index) {
        if (this.rainbowColor.isSelected()) {
            float hue = (float)((System.currentTimeMillis() + (long)(index * 100)) % 3000L) / 3000.0f * 360.0f;
            return ColorRGBA.fromHSB(hue, 0.7f, 1.0f);
        }
        ColorRGBA themeCol = Experiment.getInstance().getThemeManager().getCurrentTheme().getAdditionalColor();
        return themeCol != null ? themeCol : new ColorRGBA(138.0f, 43.0f, 226.0f);
    }

    private double randomRange(double min, double max) {
        return min + (max - min) * this.rand.nextDouble();
    }

    @Environment(value=EnvType.CLIENT)
    private class Particle {
        private final class_2960 texture;
        private class_243 position;
        private class_243 velocity;
        private final ColorRGBA color;
        private final float size;
        private final float speedMultiplier;
        private long time = 0L;
        private float alpha = 1.0f;

        public Particle(HitParticles hitParticles, class_2960 texture, class_243 position, class_243 velocity, ColorRGBA color, float size, float speedMultiplier) {
            this.texture = texture;
            this.position = position;
            this.velocity = velocity.method_1021(0.05);
            this.color = color;
            this.size = size;
            this.speedMultiplier = speedMultiplier;
        }

        public void update(double deltaTime) {
            this.velocity = this.velocity.method_1021(Math.pow(0.999, deltaTime * 60.0));
            this.position = this.position.method_1019(this.velocity.method_1021(deltaTime * 60.0 * (double)this.speedMultiplier));
            this.time += (long)(deltaTime * 1000.0);
            if (this.time > 600L) {
                this.alpha = 1.0f - (float)(this.time - 600L) / 400.0f;
                this.alpha = Math.max(0.0f, Math.min(1.0f, this.alpha));
            }
        }
    }
}

