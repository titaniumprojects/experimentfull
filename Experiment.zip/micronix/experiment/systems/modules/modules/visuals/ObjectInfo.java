/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_241
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2767
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import java.util.Map;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.render.Utils;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2767;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;

@ModuleInfo(name="Object Info", category=ModuleCategory.PLAYER, desc="\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0438\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044e \u043e \u0442\u0440\u0430\u043f\u043a\u0430\u0445 \u0438 \u043f\u043b\u0430\u0441\u0442\u0430\u0445 \u0432 \u043c\u0438\u0440\u0435")
@Environment(value=EnvType.CLIENT)
public class ObjectInfo
extends BaseModule {
    private final Map<class_2338, Info> infos = new HashMap<class_2338, Info>();
    private final Timer timer = new Timer();
    private final EventListener<ReceivePacketEvent> onSoundInstanceEvent = event -> {
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_2767) {
            class_2338 pos;
            class_2767 sound = (class_2767)patt0$temp;
            String soundName = sound.method_11894().method_55840();
            if (soundName.contains("minecraft:block.piston.extend") || soundName.contains("minecraft:block.piston.contract")) {
                pos = new class_2338((int)sound.method_11890(), (int)sound.method_11889(), (int)sound.method_11893());
                if ((sound.method_11891() == 0.5f || sound.method_11891() == 0.7f) && sound.method_11892() == 0.5f) {
                    this.infos.put(pos, new Info(pos.method_10084().method_10069(0, 0, 0), ObjType.TRAP));
                }
                this.timer.reset();
            }
            if (soundName.contains("minecraft:block.anvil.place")) {
                pos = new class_2338((int)sound.method_11890(), (int)sound.method_11889(), (int)sound.method_11893());
                if (!(sound.method_11891() != 0.5f && sound.method_11891() != 0.7f || sound.method_11892() != 1.1f && sound.method_11892() != 0.5f)) {
                    this.infos.put(pos, new Info(pos.method_10084().method_10069(0, 0, 0), ObjType.PLAST));
                }
                this.timer.reset();
            }
            if (soundName.contains("entity.evoker_fangs.attack")) {
                new class_2338((int)sound.method_11890(), (int)sound.method_11889(), (int)sound.method_11893());
                if (sound.method_11891() != 0.5f && sound.method_11891() != 0.7f || sound.method_11892() == 0.85f || sound.method_11892() == 1.0f) {
                    // empty if block
                }
                this.timer.reset();
            }
        }
    };
    private final EventListener<PreHudRenderEvent> onRender2D = event -> {
        class_2338 toRemove = null;
        for (Map.Entry<class_2338, Info> entry : this.infos.entrySet()) {
            Info info = entry.getValue();
            info.draw((PreHudRenderEvent)event);
            if (!info.start.finished(info.getType().getTime())) continue;
            toRemove = entry.getKey();
        }
        if (toRemove != null) {
            this.infos.remove(toRemove);
        }
    };
    private final EventListener<Render3DEvent> onRender3D = event -> {
        class_2338 toRemove = null;
        for (Map.Entry<class_2338, Info> entry : this.infos.entrySet()) {
            Info info = entry.getValue();
            info.draw3D((Render3DEvent)event);
            if (!info.start.finished(info.getType().getTime())) continue;
            toRemove = entry.getKey();
        }
        if (toRemove != null) {
            this.infos.remove(toRemove);
        }
    };

    @Environment(value=EnvType.CLIENT)
    static class Info {
        final class_2338 pos;
        final ObjType type;
        Timer start = new Timer();

        void draw(PreHudRenderEvent e) {
            int remained = (int)((float)(this.type.getTime() - this.start.getElapsedTime()) / 1000.0f);
            class_4587 matrices = e.getContext().method_51448();
            class_2338 renderPos = this.pos;
            class_243 renderPosAdjusted = renderPos.method_10069(0, 1, 0).method_46558();
            class_241 screenPos = Utils.worldToScreen(renderPosAdjusted);
            if (screenPos != null) {
                float distance = (float)IMinecraft.mc.field_1724.method_19538().method_1022(class_243.method_24954((class_2382)renderPos));
                float scale = class_3532.method_15363((float)(1.0f - distance / 20.0f), (float)0.5f, (float)1.0f);
                matrices.method_22903();
                matrices.method_46416(screenPos.field_1343, screenPos.field_1342, 0.0f);
                matrices.method_22905(scale, scale, 1.0f);
                String text = this.type.getName() + " (" + remained + " sec)";
                int width = (int)Fonts.MEDIUM.getFont(11.0f).width(text);
                int x = -width / 2 - 9;
                e.getContext().drawRoundedRect((float)(x - 3), 2.0f, (float)(width + 24), Fonts.MEDIUM.getFont(11.0f).height() + 9.0f, BorderRadius.top(3.0f, 3.0f), new ColorRGBA(0.0f, 0.0f, 0.0f, 100.0f));
                e.getContext().drawRoundedRect((float)(x - 3), Fonts.MEDIUM.getFont(11.0f).height() + 9.0f, (float)(width + 24) * (1.0f - (float)this.start.getElapsedTime() / (float)this.type.getTime()), 2.0f, BorderRadius.bottom(0.1f, 0.1f), new ColorRGBA(255.0f, 0.0f, 0.0f));
                e.getContext().drawText(Fonts.MEDIUM.getFont(11.0f), text, x + 14, 5.0f, ColorRGBA.WHITE);
                e.getContext().drawItem(this.type.getItem(), (float)x, 3.0f, 0.75f);
                matrices.method_22909();
            }
        }

        void draw3D(Render3DEvent e) {
            if (IMinecraft.mc.field_1687 != null && IMinecraft.mc.field_1724 != null && this.type != ObjType.PLAST) {
                class_4587 matrices = e.getMatrices();
                class_4184 camera = IMinecraft.mc.field_1773.method_19418();
                class_243 cameraPos = camera.method_19326();
                matrices.method_22904(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215());
                RenderSystem.enableBlend();
                RenderSystem.disableDepthTest();
                RenderSystem.disableCull();
                RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
                RenderSystem.lineWidth((float)10.0f);
                RenderSystem.setShader((class_10156)class_10142.field_53876);
                class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
                int radius = 2;
                ColorRGBA color = ColorRGBA.RED.withAlpha(110.0f);
                switch (this.type.ordinal()) {
                    case 0: {
                        color = ColorRGBA.RED.withAlpha(110.0f);
                        break;
                    }
                    case 1: 
                    case 2: {
                        radius = 4;
                        color = ColorRGBA.YELLOW.withAlpha(150.0f);
                    }
                }
                class_2338 minPos = this.pos.method_10069(-radius, -radius, -radius);
                class_2338 maxPos = this.pos.method_10069(radius, radius, radius);
                Draw3DUtility.renderOutlinedBox(e.getMatrices(), buffer, new class_238((double)minPos.method_10263(), (double)minPos.method_10264(), (double)minPos.method_10260(), (double)(maxPos.method_10263() + 1), (double)(maxPos.method_10264() + 1), (double)(maxPos.method_10260() + 1)), color);
                class_9801 builtBuffer = buffer.method_60794();
                if (builtBuffer != null) {
                    class_286.method_43433((class_9801)builtBuffer);
                }
                RenderSystem.enableCull();
                RenderSystem.enableDepthTest();
                RenderSystem.disableBlend();
            }
        }

        public class_2338 getPos() {
            return this.pos;
        }

        public ObjType getType() {
            return this.type;
        }

        public Timer getStart() {
            return this.start;
        }

        public Info(class_2338 pos, ObjType type) {
            this.pos = pos;
            this.type = type;
        }
    }

    @Environment(value=EnvType.CLIENT)
    static enum ObjType {
        TRAP("\u0422\u0440\u0430\u043f\u043a\u0430", class_1802.field_22021, 15000L),
        DRAGON_FT("\u0414\u0440\u0430\u043a\u043e\u043d\u043a\u0430", class_1802.field_22021, 30000L),
        DRAGON_ST("\u0414\u0440\u0430\u043a\u043e\u043d\u043a\u0430", class_1802.field_22021, 60000L),
        PLAST("\u041f\u043b\u0430\u0441\u0442", class_1802.field_8551, 20000L);

        final String name;
        final class_1792 item;
        final long time;

        public String getName() {
            return this.name;
        }

        public class_1792 getItem() {
            return this.item;
        }

        public long getTime() {
            return this.time;
        }

        private ObjType(String name, class_1792 item, long time) {
            this.name = name;
            this.item = item;
            this.time = time;
        }
    }
}

