/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.target.TargetSettings;
import micronix.experiment.utility.game.CombatUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

@ModuleInfo(name="Trigger Bot", category=ModuleCategory.COMBAT, desc="modules.descriptions.trigger_bot")
@Environment(value=EnvType.CLIENT)
public class TriggerBot
extends BaseModule {
    private final Timer timer = new Timer();
    private final BooleanSetting onlyCrits = new BooleanSetting(this, "only_crits").enable();
    private final SelectSetting targets = new SelectSetting(this, "targets");
    private final SelectSetting.Value players = new SelectSetting.Value(this.targets, "players").select();
    private final SelectSetting.Value animals = new SelectSetting.Value(this.targets, "animals").select();
    private final SelectSetting.Value mobs = new SelectSetting.Value(this.targets, "mobs").select();
    private final SelectSetting.Value invisibles = new SelectSetting.Value(this.targets, "invisibles").select();
    private final SelectSetting.Value nakedPlayers = new SelectSetting.Value(this.targets, "nakedPlayers").select();
    private final SelectSetting.Value friends = new SelectSetting.Value(this.targets, "friends");

    @Override
    public void tick() {
        class_1309 livingEntity;
        if (TriggerBot.mc.field_1724 == null || TriggerBot.mc.field_1761 == null) {
            return;
        }
        TargetSettings settings = new TargetSettings.Builder().targetPlayers(this.players.isSelected()).targetAnimals(this.animals.isSelected()).targetMobs(this.mobs.isSelected()).targetInvisibles(this.invisibles.isSelected()).targetNakedPlayers(this.nakedPlayers.isSelected()).targetFriends(this.friends.isSelected()).requiredRange(3.0f).build();
        class_1297 entity = TriggerBot.mc.field_1692;
        if (entity instanceof class_1309 && settings.isEntityValid((class_1297)(livingEntity = (class_1309)entity)) && this.shouldAttack(livingEntity)) {
            TriggerBot.mc.field_1761.method_2918((class_1657)TriggerBot.mc.field_1724, TriggerBot.mc.field_1692);
            TriggerBot.mc.field_1724.method_6104(class_1268.field_5808);
            this.timer.reset();
        }
        super.tick();
    }

    private boolean shouldAttack(class_1309 entity) {
        if (TriggerBot.mc.field_1724 == null) {
            return false;
        }
        if (TriggerBot.mc.field_1724.method_7261(0.5f) <= 0.93f) {
            return false;
        }
        if (entity.method_5739((class_1297)TriggerBot.mc.field_1724) > 3.0f) {
            return false;
        }
        return !this.onlyCrits.isEnabled() || CombatUtility.canPerformCriticalHit(entity, false);
    }
}

