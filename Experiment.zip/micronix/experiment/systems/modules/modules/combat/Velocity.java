/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2664
 *  net.minecraft.class_2743
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.mixin.accessors.EntityVelocityUpdateAccessor;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2743;

@ModuleInfo(name="Velocity", category=ModuleCategory.COMBAT, desc="modules.descriptions.velocity")
@Environment(value=EnvType.CLIENT)
public class Velocity
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "mode");
    private final ModeSetting.Value cancel = new ModeSetting.Value(this.mode, "modules.settings.velocity.default");
    private final ModeSetting.Value compensation = new ModeSetting.Value(this.mode, "modules.settings.velocity.compensation");
    private final ModeSetting.Value modify = new ModeSetting.Value(this.mode, "modules.settings.velocity.modify");
    private final SliderSetting modifierX = new SliderSetting((SettingsContainer)this, "modules.settings.velocity.velocity_x", () -> !this.mode.is(this.modify)).suffix("%").currentValue(50.0f).min(0.0f).max(100.0f).step(1.0f);
    private final SliderSetting modifierY = new SliderSetting((SettingsContainer)this, "modules.settings.velocity.velocity_y", () -> !this.mode.is(this.modify)).suffix("%").currentValue(50.0f).min(0.0f).max(100.0f).step(1.0f);
    private final SliderSetting modifierZ = new SliderSetting((SettingsContainer)this, "modules.settings.velocity.velocity_z", () -> !this.mode.is(this.modify)).suffix("%").currentValue(50.0f).min(0.0f).max(100.0f).step(1.0f);
    private class_243 lastMotion = class_243.field_1353;
    private boolean gotVelocity;
    private boolean wasHurt;
    private boolean jumped;
    private final EventListener<ReceivePacketEvent> onVelocityPacket = event -> {
        class_2743 velocityPacket;
        if (Velocity.mc.field_1724 == null || Velocity.mc.field_1724.method_29504()) {
            return;
        }
        class_2596<?> packet = event.getPacket();
        boolean isVelocityPacket = packet instanceof class_2743 && (velocityPacket = (class_2743)packet).method_11818() == Velocity.mc.field_1724.method_5628();
        boolean isExplosionPacket = packet instanceof class_2664;
        if (isVelocityPacket || isExplosionPacket) {
            class_2743 velocityPacket2;
            class_2743 velocityPacket3;
            class_2743 velocityPacket4;
            if (this.mode.is(this.cancel) && packet instanceof class_2743 && (velocityPacket4 = (class_2743)packet).method_11818() == Velocity.mc.field_1724.method_5628()) {
                event.cancel();
            } else if (this.mode.is(this.modify) && packet instanceof class_2743 && (velocityPacket3 = (class_2743)packet).method_11818() == Velocity.mc.field_1724.method_5628()) {
                int velocityX = (int)(velocityPacket3.method_11815() * 8000.0 * (double)this.modifierX.getCurrentValue() / 100.0);
                int velocityY = (int)(velocityPacket3.method_11816() * 8000.0 * (double)this.modifierY.getCurrentValue() / 100.0);
                int velocityZ = (int)(velocityPacket3.method_11819() * 8000.0 * (double)this.modifierZ.getCurrentValue() / 100.0);
                EntityVelocityUpdateAccessor accessor = (EntityVelocityUpdateAccessor)velocityPacket3;
                accessor.setVelocityX(velocityX);
                accessor.setVelocityY(velocityY);
                accessor.setVelocityZ(velocityZ);
            } else if (this.mode.is(this.compensation) && packet instanceof class_2743 && (velocityPacket2 = (class_2743)packet).method_11818() == Velocity.mc.field_1724.method_5628()) {
                this.lastMotion = new class_243(velocityPacket2.method_11815() * 8000.0, velocityPacket2.method_11816() * 8000.0, velocityPacket2.method_11819() * 8000.0);
                this.gotVelocity = true;
            }
        }
    };

    @Override
    public void tick() {
        if (!this.mode.is(this.compensation) || !this.gotVelocity || Velocity.mc.field_1724 == null) {
            return;
        }
        if (Velocity.mc.field_1724.field_6235 > 0) {
            this.wasHurt = true;
        }
        if (this.wasHurt && Velocity.mc.field_1724.field_6235 == 0) {
            if (Velocity.mc.field_1724.method_24828()) {
                Velocity.mc.field_1724.method_6043();
                this.jumped = true;
            }
            class_243 moveDir = this.lastMotion.method_1029();
            class_243 updatedMotion = moveDir.method_1021((double)-0.2f);
            Velocity.mc.field_1724.method_18800(updatedMotion.field_1352, updatedMotion.field_1351, updatedMotion.field_1350);
            this.wasHurt = false;
            this.gotVelocity = false;
        }
        if (this.jumped && Velocity.mc.field_1724.method_24828()) {
            this.jumped = false;
        }
        super.tick();
    }
}

