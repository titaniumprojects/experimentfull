/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2374
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

@ModuleInfo(name="Auto Explosion", desc="modules.descriptions.auto_explosion", category=ModuleCategory.COMBAT)
@Environment(value=EnvType.CLIENT)
public class AutoExplosion
extends BaseModule {
    private final BindSetting bind = new BindSetting(this, "modules.settings.auto_explosion.bind");
    private final BooleanSetting attackOthers = new BooleanSetting(this, "modules.settings.auto_explosion.attack_others");
    private final BooleanSetting selfSave = new BooleanSetting(this, "modules.settings.auto_explosion.self_save");
    private final SliderSetting delay = new SliderSetting((SettingsContainer)this, "modules.settings.auto_explosion.delay", () -> this.bind.getKey() == -1).min(100.0f).max(1000.0f).step(50.0f).currentValue(500.0f);
    private int lastPlacedCrystalId = -1;
    private final Timer delayTimer = new Timer();
    private boolean pressed;
    private final EventListener<KeyPressEvent> keyPressEvent = event -> {
        if (this.bind.isKey(event.getKey())) {
            this.pressed = event.getAction() == 1;
        }
    };

    @Override
    public void tick() {
        if (this.bind.getKey() != -1 && !this.pressed) {
            return;
        }
        SlotGroup<HotbarSlot> search = SlotGroups.hotbar();
        HotbarSlot slot = search.findItem(class_1802.field_8301);
        class_2338 targetPos = this.findNearbyObsidian();
        if (slot == null || targetPos == null) {
            return;
        }
        int crystalSlot = slot.getIdForServer();
        class_243 targetVec = new class_243((double)targetPos.method_10263() + 0.5, (double)targetPos.method_10264(), (double)targetPos.method_10260() + 0.5);
        float[] rotations = this.calculateLookAngles(targetVec);
        Experiment.getInstance().getRotationHandler().rotate(new Rotation(rotations[0], rotations[1]));
        if (this.delayTimer.finished((long)this.delay.getCurrentValue() / 2L)) {
            AutoExplosion.mc.field_1724.method_31548().field_7545 = crystalSlot - 36;
            this.placeCrystal(targetPos.method_10074());
            if (!this.selfSave.isEnabled() || !this.isAboveCrystal(targetPos)) {
                this.attackNearbyCrystal(targetPos);
            }
            this.delayTimer.reset();
        }
        super.tick();
    }

    private class_2338 findNearbyObsidian() {
        int radius = 4;
        class_2338 playerPos = class_2338.method_49638((class_2374)AutoExplosion.mc.field_1724.method_19538());
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -radius; y <= radius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    class_2338 placePos;
                    class_2338 checkPos = playerPos.method_10069(x, y, z);
                    if (AutoExplosion.mc.field_1687.method_8320(checkPos).method_26204() != class_2246.field_10540 || !AutoExplosion.mc.field_1687.method_8320(placePos = checkPos.method_10084()).method_26215()) continue;
                    return placePos;
                }
            }
        }
        return null;
    }

    private void attackNearbyCrystal(class_2338 pos) {
        double range = 6.0;
        class_243 center = new class_243((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 1.0, (double)pos.method_10260() + 0.5);
        for (class_1297 entity : AutoExplosion.mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1511) || !(entity.method_19538().method_1025(center) <= range * range) || !this.attackOthers.isEnabled() && entity.method_5628() != this.lastPlacedCrystalId || this.selfSave.isEnabled() && AutoExplosion.mc.field_1724.method_23318() > entity.method_23318()) continue;
            AutoExplosion.mc.field_1761.method_2918((class_1657)AutoExplosion.mc.field_1724, entity);
            AutoExplosion.mc.field_1724.method_6104(class_1268.field_5808);
            break;
        }
    }

    private void placeCrystal(class_2338 obsidianBlockPos) {
        class_243 hitVec = new class_243((double)obsidianBlockPos.method_10263() + 0.5, (double)obsidianBlockPos.method_10264() + 1.0, (double)obsidianBlockPos.method_10260() + 0.5);
        class_3965 hitResult = new class_3965(hitVec, class_2350.field_11036, obsidianBlockPos, false);
        AutoExplosion.mc.field_1761.method_2896(AutoExplosion.mc.field_1724, class_1268.field_5808, hitResult);
        AutoExplosion.mc.field_1724.method_6104(class_1268.field_5808);
        mc.execute(() -> AutoExplosion.mc.field_1687.method_18112().forEach(entity -> {
            if (entity instanceof class_1511 && entity.method_5707(hitVec) < 1.0) {
                this.lastPlacedCrystalId = entity.method_5628();
            }
        }));
    }

    private float[] calculateLookAngles(class_243 target) {
        class_243 eyesPos = new class_243(AutoExplosion.mc.field_1724.method_23317(), AutoExplosion.mc.field_1724.method_23318() + (double)AutoExplosion.mc.field_1724.method_18381(AutoExplosion.mc.field_1724.method_18376()), AutoExplosion.mc.field_1724.method_23321());
        double diffX = target.field_1352 - eyesPos.field_1352;
        double diffY = target.field_1351 - eyesPos.field_1351;
        double diffZ = target.field_1350 - eyesPos.field_1350;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{AutoExplosion.mc.field_1724.method_36454() + class_3532.method_15393((float)(yaw - AutoExplosion.mc.field_1724.method_36454())), AutoExplosion.mc.field_1724.method_36455() + class_3532.method_15393((float)(pitch - AutoExplosion.mc.field_1724.method_36455()))};
    }

    private boolean isAboveCrystal(class_2338 crystalPos) {
        return AutoExplosion.mc.field_1724.method_23318() > (double)crystalPos.method_10264() + 1.0;
    }
}

