/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 */
package micronix.experiment.systems.modules.modules.combat;

import java.util.List;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

@ModuleInfo(name="Auto Soup", category=ModuleCategory.COMBAT)
@Environment(value=EnvType.CLIENT)
public class AutoSoup
extends BaseModule {
    int prevSlot = -1;
    int slot = -1;
    int soupTick = -1;
    private final SliderSetting health = new SliderSetting(this, "health").step(1.0f).min(1.0f).max(20.0f).currentValue(10.0f);
    private final Timer timer = new Timer();

    @Override
    public void tick() {
        if (this.soupTick >= 0) {
            if (this.soupTick == 2) {
                AutoSoup.mc.field_1724.method_31548().field_7545 = this.slot;
            } else if (this.soupTick == 1) {
                AutoSoup.mc.field_1761.method_2919((class_1657)AutoSoup.mc.field_1724, class_1268.field_5808);
            } else if (this.soupTick == 0) {
                AutoSoup.mc.field_1724.method_7290(true);
                AutoSoup.mc.field_1724.method_31548().field_7545 = this.prevSlot;
            }
            --this.soupTick;
            return;
        }
        if (AutoSoup.mc.field_1724.method_6032() >= this.health.getCurrentValue() || !this.timer.finished(300L)) {
            return;
        }
        HotbarSlot hotbarSlot = SlotGroups.hotbar().findItem(class_1802.field_8208);
        if (hotbarSlot != null) {
            this.prevSlot = AutoSoup.mc.field_1724.method_31548().field_7545;
            AutoSoup.mc.field_1724.method_31548().field_7545 = this.slot = hotbarSlot.getSlotId();
            this.soupTick = 1;
        } else {
            List<InventorySlot> inventorySlots = SlotGroups.inventory().findItems(class_1802.field_8208);
            List<HotbarSlot> emptySlots = SlotGroups.hotbar().findItems(class_1799::method_7960);
            if (!inventorySlots.isEmpty() && !emptySlots.isEmpty()) {
                int maxSoups = Math.min(inventorySlots.size(), emptySlots.size());
                maxSoups = Math.min(maxSoups, 8);
                for (int i = 0; i < maxSoups; ++i) {
                    InventorySlot soupSlot = inventorySlots.get(i);
                    HotbarSlot emptySlot = emptySlots.get(i);
                    InventoryUtility.hotbarSwap(soupSlot.getIdForServer(), emptySlot.getSlotId());
                }
                this.prevSlot = AutoSoup.mc.field_1724.method_31548().field_7545;
                this.slot = emptySlots.get(0).getSlotId();
                this.soupTick = 2;
            }
        }
        this.timer.reset();
    }
}

