/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2797
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2797;

@ModuleInfo(name="PvPSafe", category=ModuleCategory.COMBAT, desc="\u041d\u0435 \u0434\u0430\u0435\u0442 \u0432\u044b\u0439\u0442\u0438 \u0432\u043e \u0432\u0440\u0435\u043c\u044f PvP")
@Environment(value=EnvType.CLIENT)
public class PvPSafe
extends BaseModule {
    private final SliderSetting cooldown = new SliderSetting(this, "Cooldown").min(5.0f).max(60.0f).step(1.0f).currentValue(30.0f);
    private final BooleanSetting blockHub = new BooleanSetting(this, "Block /hub").enabled(true);
    private final BooleanSetting blockSpawn = new BooleanSetting(this, "Block /spawn").enabled(true);
    private final BooleanSetting blockRtp = new BooleanSetting(this, "Block /rtp").enabled(true);
    private final Timer pvpTimer = new Timer();
    private boolean inPvp = false;
    private final String[] blockedCommands = new String[]{"hub", "lobby", "spawn", "rtp", "wild", "home"};
    private final EventListener<SendPacketEvent> onSendPacket = event -> {
        class_2797 packet;
        String msg;
        if (!this.inPvp) {
            return;
        }
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_2797 && (msg = (packet = (class_2797)patt0$temp).comp_945()).startsWith("/")) {
            String cmd = msg.substring(1).toLowerCase().split(" ")[0];
            if (this.blockHub.isEnabled() && (cmd.equals("hub") || cmd.equals("lobby"))) {
                event.cancel();
                this.sendMessage("\u00a7c\u041d\u0435\u043b\u044c\u0437\u044f \u0432\u044b\u0439\u0442\u0438 \u0432 \u0445\u0430\u0431 \u0432\u043e \u0432\u0440\u0435\u043c\u044f PvP!");
                return;
            }
            if (this.blockSpawn.isEnabled() && cmd.equals("spawn")) {
                event.cancel();
                this.sendMessage("\u00a7c\u041d\u0435\u043b\u044c\u0437\u044f \u0432\u044b\u0439\u0442\u0438 \u043d\u0430 \u0441\u043f\u0430\u0432\u043d \u0432\u043e \u0432\u0440\u0435\u043c\u044f PvP!");
                return;
            }
            if (this.blockRtp.isEnabled() && cmd.equals("rtp")) {
                event.cancel();
                this.sendMessage("\u00a7c\u041d\u0435\u043b\u044c\u0437\u044f \u0441\u0434\u0435\u043b\u0430\u0442\u044c RTP \u0432\u043e \u0432\u0440\u0435\u043c\u044f PvP!");
                return;
            }
            for (String blocked : this.blockedCommands) {
                if (!cmd.equals(blocked)) continue;
                event.cancel();
                this.sendMessage("\u00a7c\u041d\u0435\u043b\u044c\u0437\u044f \u0432\u044b\u0439\u0442\u0438 \u0432\u043e \u0432\u0440\u0435\u043c\u044f PvP!");
                return;
            }
        }
    };
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (PvPSafe.mc.field_1724 == null || PvPSafe.mc.field_1687 == null) {
            return;
        }
        boolean wasInPvp = this.inPvp;
        this.inPvp = false;
        if (PvPSafe.mc.field_1724.field_6235 > 0) {
            this.inPvp = true;
            this.pvpTimer.reset();
        }
        for (class_1657 player : PvPSafe.mc.field_1687.method_18456()) {
            if (player == PvPSafe.mc.field_1724 || !((double)PvPSafe.mc.field_1724.method_5739((class_1297)player) < 15.0)) continue;
            this.inPvp = true;
            this.pvpTimer.reset();
            break;
        }
        if (!this.inPvp && wasInPvp) {
            if (this.pvpTimer.hasReached((int)(this.cooldown.getCurrentValue() * 1000.0f))) {
                this.sendMessage("\u00a7aPvP \u043a\u0443\u043b\u0434\u0430\u0443\u043d \u0437\u0430\u043a\u043e\u043d\u0447\u0438\u043b\u0441\u044f! \u0422\u0435\u043f\u0435\u0440\u044c \u043c\u043e\u0436\u043d\u043e \u0432\u044b\u0445\u043e\u0434\u0438\u0442\u044c");
            } else {
                this.inPvp = true;
            }
        }
    };

    private void sendMessage(String msg) {
        if (PvPSafe.mc.field_1724 != null) {
            PvPSafe.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)msg), false);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.pvpTimer.reset();
        this.inPvp = false;
    }
}

