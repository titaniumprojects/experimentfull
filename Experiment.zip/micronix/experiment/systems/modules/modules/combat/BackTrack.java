/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.combat;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.mixins.BacktrackableEntity;
import micronix.experiment.utility.render.Draw3DUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_9801;

@ModuleInfo(name="Back Track", desc="\u0417\u0430\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442 \u0445\u0438\u0442\u0431\u043e\u043a\u0441", category=ModuleCategory.COMBAT)
@Environment(value=EnvType.CLIENT)
public class BackTrack
extends BaseModule {
    private final BooleanSetting visual = new BooleanSetting(this, "\u0412\u0438\u0437\u0443\u0430\u043b\u0438\u0437\u0438\u0440\u043e\u0432\u0430\u0442\u044c");
    private final SliderSetting delay = new SliderSetting(this, "\u0432\u0440\u0435\u043c\u044f").min(50.0f).max(1000.0f).step(50.0f).currentValue(100.0f);
    private final EventListener<ClientPlayerTickEvent> updateEvent = event -> {
        for (class_1657 player : BackTrack.mc.field_1687.method_18456()) {
            BacktrackableEntity backtrackableEntity;
            if (player == BackTrack.mc.field_1724 || Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString()) || !(player instanceof BacktrackableEntity) || (backtrackableEntity = (BacktrackableEntity)player).experiment2_0$getBackTracks().size() <= 2) continue;
            backtrackableEntity.experiment2_0$getBackTracks().removeFirst();
        }
    };
    private final EventListener<Render3DEvent> event3d = e -> {
        if (!this.visual.isEnabled()) {
            return;
        }
        class_4587 ms = e.getMatrices();
        class_243 cameraPos = BackTrack.mc.field_1773.method_19418().method_19326();
        for (class_1657 player : BackTrack.mc.field_1687.method_18456()) {
            BacktrackableEntity backtrackable;
            List<Position> backTracks;
            if (player == BackTrack.mc.field_1724 || Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString()) || !(player instanceof BacktrackableEntity) || (backTracks = (backtrackable = (BacktrackableEntity)player).experiment2_0$getBackTracks()).isEmpty()) continue;
            long now = System.currentTimeMillis();
            backTracks.removeIf(pos -> (float)(now - pos.time()) > this.delay.getCurrentValue());
            Position last = backTracks.getLast();
            class_243 lastPos = last.pos();
            class_287 buffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
            ms.method_22903();
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            Draw3DUtility.renderOutlinedBox(ms, buffer, player.method_5829().method_997(lastPos.method_1020(player.method_19538())).method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350), ColorRGBA.WHITE.withAlpha(180.0f));
            class_9801 built = buffer.method_60794();
            if (built != null) {
                class_286.method_43433((class_9801)built);
            }
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            ms.method_22909();
        }
    };

    @Environment(value=EnvType.CLIENT)
    public record Position(class_243 pos, long time) {
    }
}

