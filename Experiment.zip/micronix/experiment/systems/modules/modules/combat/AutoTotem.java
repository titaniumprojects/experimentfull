/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1306
 *  net.minecraft.class_1511
 *  net.minecraft.class_1541
 *  net.minecraft.class_1657
 *  net.minecraft.class_1802
 *  net.minecraft.class_2561
 *  org.jetbrains.annotations.Nullable
 */
package micronix.experiment.systems.modules.modules.combat;

import java.util.Comparator;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.ItemUtility;
import micronix.experiment.utility.game.prediction.EntityPredictor;
import micronix.experiment.utility.game.prediction.FallPredictor;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Auto Totem", category=ModuleCategory.COMBAT, desc="modules.descriptions.auto_totem")
@Environment(value=EnvType.CLIENT)
public class AutoTotem
extends BaseModule {
    private final SliderSetting health = new SliderSetting(this, "modules.settings.auto_totem.health").min(1.0f).max(20.0f).step(0.5f).currentValue(6.0f);
    private final SliderSetting healthElytra = new SliderSetting(this, "modules.settings.auto_totem.elytra_health").min(1.0f).max(20.0f).step(0.5f).currentValue(6.0f);
    private final SelectSetting get = new SelectSetting(this, "modules.settings.auto_totem.select_with");
    private final SelectSetting.Value fall = new SelectSetting.Value(this.get, "modules.settings.auto_totem.select_with.fall");
    private final SelectSetting.Value crystal = new SelectSetting.Value(this.get, "modules.settings.auto_totem.select_with.crystal");
    private final SelectSetting.Value tnt = new SelectSetting.Value(this.get, "modules.settings.auto_totem.select_with.tnt");
    private final BooleanSetting deathTNT = new BooleanSetting((SettingsContainer)this, "modules.settings.auto_totem.death_tnt", () -> !this.tnt.isSelected());
    private int returnSlot = -1;
    private int totemCount = 0;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (AutoTotem.mc.field_1724 == null || AutoTotem.mc.field_1687 == null) {
            return;
        }
        this.updateTotemCount();
        boolean needsTotem = this.checkTotemCondition();
        boolean hasTotemInOffhand = this.findBestTotemSlot() != null && this.findBestTotemSlot().getIdForServer() == 45;
        boolean bl = hasTotemInOffhand;
        if (needsTotem && !hasTotemInOffhand) {
            this.equipTotem();
        }
        if (!needsTotem && this.returnSlot != -1) {
            this.returnPreviousItem();
        }
    };
    private final EventListener<HudRenderEvent> onHud = event -> {
        if (this.totemCount > 0) {
            CustomDrawContext ctx = event.getContext();
            Font font = Fonts.BOLD.getFont(7.0f);
            boolean isLeftHanded = AutoTotem.mc.field_1690.method_42552().method_41753() == class_1306.field_6182;
            float x = isLeftHanded ? sr.getScaledWidth() / 2.0f - 103.0f : sr.getScaledWidth() / 2.0f + 103.0f;
            float y = sr.getScaledHeight() - 21.5f;
            ctx.pushMatrix();
            ctx.drawText(font, class_2561.method_30163((String)String.valueOf(this.totemCount)), x - font.width(class_2561.method_30163((String)String.valueOf(this.totemCount))) / 2.0f + 8.1f, y + 15.3f);
            ctx.drawItem(class_1802.field_8288, x - 8.0f, y + 3.0f, 1.0f);
            ctx.popMatrix();
        }
    };

    private boolean checkTotemCondition() {
        float f2;
        if (AutoTotem.mc.field_1724 == null || AutoTotem.mc.field_1687 == null) {
            return false;
        }
        float f = AutoTotem.mc.field_1724.method_6032() + AutoTotem.mc.field_1724.method_6067();
        float f3 = f2 = AutoTotem.mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833 ? this.healthElytra.getCurrentValue() : this.health.getCurrentValue();
        if (f <= f2) {
            return true;
        }
        if (this.crystal.isSelected()) {
            float maxDmg = 0.0f;
            for (class_1511 c : AutoTotem.mc.field_1687.method_8390(class_1511.class, AutoTotem.mc.field_1724.method_5829().method_1014(6.0), e -> true)) {
                maxDmg = Math.max(maxDmg, EntityPredictor.predictDamage((class_1297)c, (class_1657)AutoTotem.mc.field_1724));
            }
            if (maxDmg >= AutoTotem.mc.field_1724.method_6032() + AutoTotem.mc.field_1724.method_6067()) {
                return true;
            }
        }
        if (this.tnt.isSelected()) {
            if (this.deathTNT.isEnabled()) {
                float maxDMG = 0.0f;
                for (class_1541 tntEntity : AutoTotem.mc.field_1687.method_8390(class_1541.class, AutoTotem.mc.field_1724.method_5829().method_1014(6.0), e -> true)) {
                    maxDMG = Math.max(maxDMG, EntityPredictor.predictDamage((class_1297)tntEntity, (class_1657)AutoTotem.mc.field_1724));
                }
                if (maxDMG >= AutoTotem.mc.field_1724.method_6032() + AutoTotem.mc.field_1724.method_6067()) {
                    return true;
                }
            } else {
                return !AutoTotem.mc.field_1687.method_8390(class_1541.class, AutoTotem.mc.field_1724.method_5829().method_1014(6.0), e -> true).isEmpty();
            }
        }
        if (this.fall.isSelected()) {
            float predicted = FallPredictor.predictFallDamage((class_1657)AutoTotem.mc.field_1724, 120);
            return predicted >= AutoTotem.mc.field_1724.method_6032() + AutoTotem.mc.field_1724.method_6067();
        }
        return false;
    }

    private void equipTotem() {
        ItemSlot totemSlot = this.findBestTotemSlot();
        if (totemSlot != null) {
            this.returnSlot = totemSlot.getIdForServer();
            InventoryUtility.hotbarSwap(this.returnSlot, 40);
        }
    }

    private void returnPreviousItem() {
        if (this.returnSlot != -1) {
            InventoryUtility.hotbarSwap(this.returnSlot, 40);
            this.returnSlot = -1;
        }
    }

    @Nullable
    private ItemSlot findBestTotemSlot() {
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.offhand().and(SlotGroups.inventory()).and(SlotGroups.hotbar());
        return slotsToSearch.findItems(class_1802.field_8288).stream().min(Comparator.comparingInt(s -> ItemUtility.totemFactor(s.itemStack()))).orElse(null);
    }

    private void updateTotemCount() {
        this.totemCount = SlotGroups.inventory().and(SlotGroups.hotbar()).and(SlotGroups.offhand()).and(SlotGroups.armor()).findItems(class_1802.field_8288).size();
    }
}

