/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.OffhandSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

@ModuleInfo(name="Auto GApple", category=ModuleCategory.COMBAT, desc="modules.descriptions.auto_gapple")
@Environment(value=EnvType.CLIENT)
public class AutoGapple
extends BaseModule {
    private boolean eating;
    private ItemSlot swappedSlot = null;
    private class_1799 savedOffhandItem = null;
    private final SliderSetting healthEat = new SliderSetting(this, "modules.settings.auto_gapple.health").step(1.0f).min(1.0f).max(20.0f).currentValue(15.0f);
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (AutoGapple.mc.field_1724 == null || AutoGapple.mc.field_1761 == null) {
            return;
        }
        float totalHealth = AutoGapple.mc.field_1724.method_6032() + AutoGapple.mc.field_1724.method_6067();
        boolean shouldEat = totalHealth <= this.healthEat.getCurrentValue();
        OffhandSlot offhand = InventoryUtility.getOffHandSlot();
        class_1799 offhandStack = offhand.itemStack();
        if (shouldEat && !AutoGapple.mc.field_1724.method_7357().method_7904(class_1802.field_8463.method_7854())) {
            if (this.isGoldenApple(offhandStack)) {
                this.startEating();
            } else {
                ItemSlot gappleSlot = this.findGappleSlot();
                if (gappleSlot != null) {
                    if (offhand.isEmpty()) {
                        InventoryUtility.moveToOffHand(gappleSlot);
                        this.startEating();
                    } else if (this.savedOffhandItem == null) {
                        this.savedOffhandItem = offhand.itemStack().method_7972();
                        this.swappedSlot = gappleSlot;
                        InventoryUtility.moveToOffHand(gappleSlot);
                        this.startEating();
                    }
                }
            }
        } else {
            this.stopEating();
            if (this.savedOffhandItem != null && this.swappedSlot != null) {
                InventoryUtility.moveToOffHand(this.swappedSlot);
                this.savedOffhandItem = null;
                this.swappedSlot = null;
            }
        }
    };

    private void startEating() {
        this.eating = true;
        AutoGapple.mc.field_1690.field_1904.method_23481(true);
    }

    private void stopEating() {
        if (this.eating) {
            AutoGapple.mc.field_1690.field_1904.method_23481(false);
            this.eating = false;
        }
    }

    private boolean isGoldenApple(class_1799 itemStack) {
        class_1792 item = itemStack.method_7909();
        return item == class_1802.field_8463 || item == class_1802.field_8367;
    }

    private ItemSlot findGappleSlot() {
        for (int i = 0; i < 9; ++i) {
            HotbarSlot slot = InventoryUtility.getHotbarSlot(i);
            if (!slot.contains(class_1802.field_8463) && !slot.contains(class_1802.field_8367)) continue;
            return slot;
        }
        return null;
    }

    @Override
    public void onDisable() {
        this.stopEating();
        if (this.savedOffhandItem != null && this.swappedSlot != null) {
            InventoryUtility.moveToOffHand(this.swappedSlot);
            this.savedOffhandItem = null;
            this.swappedSlot = null;
        }
        super.onDisable();
    }
}

