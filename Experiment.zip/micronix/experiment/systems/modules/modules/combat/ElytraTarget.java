/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1802
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2848
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_742
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.combat;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.game.PostAttackEvent;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.modules.modules.movement.ElytraStrafe;
import micronix.experiment.systems.modules.modules.player.Blink;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.CombatUtility;
import micronix.experiment.utility.game.ElytraUtility;
import micronix.experiment.utility.game.prediction.ElytraPredictionSystem;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_9801;

@ModuleInfo(name="Elytra Target", category=ModuleCategory.COMBAT, desc="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043f\u0440\u0435\u0441\u043b\u0435\u0434\u043e\u0432\u0430\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u043e\u0432 \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0435")
@Environment(value=EnvType.CLIENT)
public class ElytraTarget
extends BaseModule {
    private final SliderSetting fireworkSlot = new SliderSetting(this, "modules.settings.elytra_target.fireworkSlot").min(1.0f).max(9.0f).step(1.0f).currentValue(7.0f).suffix(" slot");
    private final BooleanSetting swapVector = new BooleanSetting(this, "modules.settings.elytra_target.swapVector").enable();
    private final BooleanSetting defensive = new BooleanSetting(this, "modules.settings.elytra_target.defensive").enable();
    private boolean defensiveActive;
    private boolean prevDefensive;
    private class_243 defensivePos;
    private final EventListener<SendPacketEvent> onPacket = event -> {
        if (this.defensiveActive) {
            this.blink().savePacket((SendPacketEvent)event);
        }
    };
    private final EventListener<AttackEvent> onAttack = event -> {};
    private final EventListener<PostAttackEvent> onPostAttack = event -> {
        if (CombatUtility.getMace() != null) {
            ElytraUtility.swapInHotbar(false);
            if (ElytraTarget.mc.field_1724.method_5624() && ElytraTarget.mc.field_1724.field_3913.method_20622() && ElytraTarget.mc.field_1724.method_23668()) {
                ElytraTarget.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)ElytraTarget.mc.field_1724, class_2848.class_2849.field_12982));
            }
        }
        class_1309 target = Experiment.getInstance().getTargetManager().getLivingTarget();
        ElytraUtility.setLastVec(ElytraUtility.leaveVec(target));
        ElytraUtility.useFirework(this.fireworkSlot.getCurrentValue());
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        class_9801 builtLinesBuffer;
        class_4587 matrices = event.getMatrices();
        class_4184 camera = ElytraTarget.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (class_742 player : ElytraTarget.mc.field_1687.method_18456()) {
            if (ElytraTarget.mc.field_1724 == player) continue;
            ElytraUtility.drawBoxes(matrices, linesBuffer, player.method_5829().method_997(ElytraPredictionSystem.predictPlayerPosition((class_1657)player)).method_989(-player.method_23317(), -player.method_23318(), -player.method_23321()).method_989(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215()), Colors.ACCENT.withAlpha(100.0f));
        }
        if (this.defensivePos != null) {
            ElytraUtility.drawBoxes(matrices, linesBuffer, ElytraTarget.mc.field_1724.method_5829().method_997(this.defensivePos).method_989(-ElytraTarget.mc.field_1724.method_23317(), -ElytraTarget.mc.field_1724.method_23318(), -ElytraTarget.mc.field_1724.method_23321()).method_989(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215()), Colors.ACCENT.withAlpha(200.0f));
        }
        if ((builtLinesBuffer = linesBuffer.method_60794()) != null) {
            class_286.method_43433((class_9801)builtLinesBuffer);
        }
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    };
    private final EventListener<HudRenderEvent> on2DRender = event -> {};

    @Override
    public void tick() {
        class_1657 player;
        Aura aura = Experiment.getInstance().getModuleManager().getModule(Aura.class);
        class_1309 target = Experiment.getInstance().getTargetManager().getLivingTarget();
        if (!Experiment.getInstance().getModuleManager().getModule(ElytraStrafe.class).isEnabled() && ElytraUtility.getFireworkTimer().finished(target != null && ElytraTarget.mc.field_1724.method_5739((class_1297)target) < 6.0f ? 500L : (target != null ? 1000L : 1500L)) && ElytraTarget.mc.field_1724.method_6128() && !ElytraTarget.mc.field_1724.method_6115()) {
            ElytraUtility.useFirework(this.fireworkSlot.getCurrentValue());
        }
        if (ElytraTarget.mc.field_1724.method_6128() && target != null) {
            RotationHandler handler = Experiment.getInstance().getRotationHandler();
            Rotation rot = RotationMath.getRotationTo(ElytraUtility.leaving() ? target.method_33571().method_1019(ElytraUtility.leaveVec(target)) : ElytraUtility.targetPoint(target));
            handler.rotate(rot, MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.OVERRIDE);
        }
        if (InventoryUtility.getChestplateSlot().item() == class_1802.field_8833 && ElytraTarget.mc.field_1724.method_5624() && ElytraTarget.mc.field_1724.field_3913.method_20622() && ElytraTarget.mc.field_1724.method_23668()) {
            ElytraTarget.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)ElytraTarget.mc.field_1724, class_2848.class_2849.field_12982));
        }
        this.defensiveActive = this.defensive.isEnabled() && target instanceof class_1657 && !ElytraPredictionSystem.isLeaving(player = (class_1657)target) && player.method_6128() && !ElytraUtility.leaving() && ElytraTarget.mc.field_1724.method_5739((class_1297)target) > 10.0f;
        boolean bl = this.defensiveActive;
        if (this.defensiveActive != this.prevDefensive) {
            if (this.defensiveActive) {
                this.blink().onEnable();
                this.defensivePos = ElytraTarget.mc.field_1724.method_19538();
            } else {
                this.blink().onDisable();
                this.defensivePos = null;
            }
        }
        this.prevDefensive = this.defensiveActive;
        if (CombatUtility.getMace() != null) {
            ElytraUtility.swapInHotbar(target != null && ElytraTarget.mc.field_1724.method_5739((class_1297)target) < 10.0f && ElytraTarget.mc.field_1724.method_7261(0.0f) >= 1.0f && ElytraTarget.mc.field_1724.field_6017 > 5.0f);
        }
    }

    private Blink blink() {
        return Experiment.getInstance().getModuleManager().getModule(Blink.class);
    }

    @Override
    public void onDisable() {
        this.defensiveActive = false;
    }

    public BooleanSetting getSwapVector() {
        return this.swapVector;
    }

    public boolean isDefensiveActive() {
        return this.defensiveActive;
    }

    public boolean isPrevDefensive() {
        return this.prevDefensive;
    }
}

