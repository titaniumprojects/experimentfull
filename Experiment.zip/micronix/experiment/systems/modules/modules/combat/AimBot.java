/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1764
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_243
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.target.TargetComparators;
import micronix.experiment.systems.target.TargetSettings;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationMath;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import ru.kotopushka.compiler.sdk.annotations.VMProtect;
import ru.kotopushka.compiler.sdk.enums.VMProtectType;

@ModuleInfo(name="Aim Bot", category=ModuleCategory.COMBAT, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043d\u0430\u0432\u043e\u0434\u0438\u0442\u0441\u044f \u043b\u0443\u043a\u043e\u043c, \u0442\u0440\u0435\u0437\u0443\u0431\u0446\u0435\u043c \u0438\u043b\u0438 \u0430\u0440\u0431\u0430\u043b\u0435\u0442\u043e\u043c")
@Environment(value=EnvType.CLIENT)
public class AimBot
extends BaseModule {
    private SelectSetting.Value bow;
    private SelectSetting.Value crossbow;
    private SelectSetting.Value trident;
    private SliderSetting distance;
    private SliderSetting fov;
    private BooleanSetting prediction;
    private BooleanSetting silent;
    private SelectSetting.Value players;
    private SelectSetting.Value animals;
    private SelectSetting.Value mobs;
    private SelectSetting.Value invisibles;
    private SelectSetting.Value naked;
    private SelectSetting.Value friends;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (AimBot.mc.field_1724 == null || AimBot.mc.field_1687 == null || !this.isHoldingSelected()) {
            return;
        }
        TargetSettings settings = new TargetSettings.Builder().targetPlayers(this.players.isSelected()).targetAnimals(this.animals.isSelected()).targetMobs(this.mobs.isSelected()).targetInvisibles(this.invisibles.isSelected()).targetNakedPlayers(this.naked.isSelected()).targetFriends(this.friends.isSelected()).requiredRange(this.distance.getCurrentValue()).sortBy(TargetComparators.FOV).build();
        Experiment.getInstance().getTargetManager().update(settings);
        class_1297 targetEntity = Experiment.getInstance().getTargetManager().getCurrentTarget();
        if (targetEntity == null) {
            return;
        }
        class_243 aimPos = this.getAimPosition(targetEntity);
        Rotation toTarget = this.calculateRotation(aimPos);
        float yaw = toTarget.getYaw();
        float pitch = toTarget.getPitch();
        float deltaYaw = RotationMath.getAngleDifference(yaw, AimBot.mc.field_1724.method_36454());
        if (deltaYaw > this.fov.getCurrentValue() || !MathUtility.canSeen(targetEntity.method_19538())) {
            return;
        }
        if (this.silent.isEnabled()) {
            Experiment.getInstance().getRotationHandler().rotate(toTarget);
        } else {
            AimBot.mc.field_1724.method_36456(yaw);
            AimBot.mc.field_1724.method_36457(pitch);
            AimBot.mc.field_1724.method_5847(yaw);
        }
    };

    public AimBot() {
        this.initialize();
    }

    @VMProtect(type=VMProtectType.VIRTUALIZATION)
    private void initialize() {
        SelectSetting items = new SelectSetting(this, "items");
        this.bow = new SelectSetting.Value(items, "bow").select();
        this.crossbow = new SelectSetting.Value(items, "crossbow");
        this.trident = new SelectSetting.Value(items, "trident");
        this.prediction = new BooleanSetting(this, "predict");
        this.silent = new BooleanSetting(this, "silent_aim");
        this.distance = new SliderSetting((SettingsContainer)this, "distance", "\u041c\u0430\u043a\u0441. \u0440\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f").min(0.0f).max(100.0f).step(1.0f).currentValue(30.0f);
        this.fov = new SliderSetting(this, "fov").min(1.0f).max(180.0f).step(1.0f).currentValue(90.0f);
        SelectSetting targets = new SelectSetting(this, "targets");
        this.players = new SelectSetting.Value(targets, "players").select();
        this.animals = new SelectSetting.Value(targets, "animals").select();
        this.mobs = new SelectSetting.Value(targets, "mobs").select();
        this.invisibles = new SelectSetting.Value(targets, "invisibles").select();
        this.naked = new SelectSetting.Value(targets, "nakedPlayers").select();
        this.friends = new SelectSetting.Value(targets, "friends");
    }

    private boolean isHoldingSelected() {
        if (AimBot.mc.field_1724 == null || AimBot.mc.field_1724.method_29504()) {
            return false;
        }
        class_1792 main = AimBot.mc.field_1724.method_6047().method_7909();
        if (main == class_1802.field_8102 && this.bow.isSelected()) {
            return AimBot.mc.field_1724.method_6115();
        }
        if (main == class_1802.field_8399 && this.crossbow.isSelected()) {
            return class_1764.method_7781((class_1799)AimBot.mc.field_1724.method_6047());
        }
        if (main == class_1802.field_8547 && this.trident.isSelected()) {
            return AimBot.mc.field_1724.method_6115();
        }
        return false;
    }

    private Rotation calculateRotation(class_243 targetPos) {
        class_243 eyes = AimBot.mc.field_1724.method_5836(1.0f);
        double dx = targetPos.field_1352 - eyes.field_1352;
        double dy = targetPos.field_1351 - eyes.field_1351;
        double dz = targetPos.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return new Rotation(yaw, pitch);
    }

    private class_243 getAimPosition(class_1297 target) {
        class_243 pos = target.method_19538();
        if (!this.prediction.isEnabled()) {
            return pos.method_1031(0.0, (double)(target.method_17682() / 2.0f), 0.0);
        }
        class_243 motion = new class_243(target.method_23317() - target.field_6014, target.method_23318() - target.field_6036, target.method_23321() - target.field_5969).method_1021(10.0);
        return pos.method_1019(motion).method_1031(0.0, (double)(target.method_17682() / 2.0f), 0.0);
    }

    @Override
    public void onDisable() {
        Experiment.getInstance().getTargetManager().reset();
    }
}

