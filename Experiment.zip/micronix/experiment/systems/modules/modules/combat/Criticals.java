/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2830
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.InternalAttackEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationMath;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

@ModuleInfo(name="Criticals", category=ModuleCategory.COMBAT)
@Environment(value=EnvType.CLIENT)
public class Criticals
extends BaseModule {
    private int airTicks;
    private final EventListener<InternalAttackEvent> onAttack = event -> {
        if (Criticals.mc.field_1724.method_5799()) {
            return;
        }
        if (!Criticals.mc.field_1724.method_24828() && Criticals.mc.field_1724.field_6017 == 0.0f) {
            RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
            Rotation rot = rotationHandler.isIdling() ? rotationHandler.getPlayerRotation() : rotationHandler.getCurrentRotation();
            rot = new Rotation(rot.getYaw() + MathUtility.random(-1.0, 1.0), rot.getPitch() + MathUtility.random(-1.0, 1.0));
            rot = RotationMath.correctRotation(rot);
            Criticals.mc.field_1724.field_6017 = MathUtility.random(1.0E-5f, 1.0E-4f);
            Criticals.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(Criticals.mc.field_1724.method_23317(), Criticals.mc.field_1724.method_23318() - (double)Criticals.mc.field_1724.field_6017, Criticals.mc.field_1724.method_23321(), rot.getYaw(), rot.getPitch(), Criticals.mc.field_1724.method_24828(), Criticals.mc.field_1724.field_5976));
        }
    };

    @Override
    public void tick() {
        this.airTicks = Criticals.mc.field_1724.method_24828() ? 0 : (this.airTicks = this.airTicks + 1);
    }

    public boolean canCritical() {
        return this.isEnabled() && Criticals.mc.field_1724.field_6017 <= 0.0f && !Criticals.mc.field_1724.method_24828();
    }
}

