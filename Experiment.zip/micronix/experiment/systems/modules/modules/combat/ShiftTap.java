/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_3966
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3966;

@ModuleInfo(name="ShiftTap", category=ModuleCategory.COMBAT, desc="modules.descriptions.shifttap")
@Environment(value=EnvType.CLIENT)
public class ShiftTap
extends BaseModule {
    private boolean wasAttackPressed = false;
    private int sneakTicksRemaining = 0;
    private boolean shouldReleaseNext = false;
    private final SliderSetting intervalTicks = new SliderSetting(this, "modules.settings.shifttap.interval").step(1.0f).min(1.0f).max(10.0f).currentValue(3.0f);
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (this.isEnabled() && mc != null && ShiftTap.mc.field_1690 != null && ShiftTap.mc.field_1724 != null) {
            boolean isUsingItem = ShiftTap.mc.field_1724.method_6115();
            if (isUsingItem) {
                this.sneakTicksRemaining = 0;
                this.shouldReleaseNext = false;
                this.wasAttackPressed = ShiftTap.mc.field_1690.field_1886.method_1434();
            } else {
                boolean isEntityTarget;
                boolean attackPressed = ShiftTap.mc.field_1690.field_1886.method_1434();
                if (this.shouldReleaseNext) {
                    ShiftTap.mc.field_1690.field_1832.method_23481(false);
                    this.shouldReleaseNext = false;
                }
                if (attackPressed && !this.wasAttackPressed && (isEntityTarget = ShiftTap.mc.field_1765 instanceof class_3966)) {
                    int hold = Math.max(1, Math.round(this.intervalTicks.getCurrentValue()));
                    ShiftTap.mc.field_1690.field_1832.method_23481(true);
                    if (hold == 1) {
                        this.shouldReleaseNext = true;
                    } else {
                        this.sneakTicksRemaining = hold - 1;
                    }
                }
                this.wasAttackPressed = attackPressed;
                if (this.sneakTicksRemaining > 0) {
                    --this.sneakTicksRemaining;
                    if (this.sneakTicksRemaining == 0) {
                        ShiftTap.mc.field_1690.field_1832.method_23481(false);
                    }
                }
            }
        }
    };

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        if (mc != null && ShiftTap.mc.field_1690 != null && ShiftTap.mc.field_1724 != null && !ShiftTap.mc.field_1724.method_6115()) {
            ShiftTap.mc.field_1690.field_1832.method_23481(false);
        }
        this.sneakTicksRemaining = 0;
        this.wasAttackPressed = false;
        this.shouldReleaseNext = false;
    }
}

