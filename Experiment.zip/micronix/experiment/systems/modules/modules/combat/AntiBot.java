/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_2596
 *  net.minecraft.class_2703
 *  net.minecraft.class_2703$class_2705
 *  net.minecraft.class_2703$class_5893
 */
package micronix.experiment.systems.modules.modules.combat;

import com.mojang.authlib.GameProfile;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2596;
import net.minecraft.class_2703;

@ModuleInfo(name="Anti Bot", category=ModuleCategory.COMBAT, desc="\u041f\u043e\u043c\u0435\u0447\u0430\u0435\u0442 \u0431\u043e\u0442\u043e\u0432 \u0441\u043e\u0437\u0434\u0430\u043d\u043d\u044b\u0445 \u0430\u043d\u0442\u0438 \u0447\u0438\u0442\u043e\u043c")
@Environment(value=EnvType.CLIENT)
public class AntiBot
extends BaseModule {
    private final ModeSetting modeSetting = new ModeSetting(this, "\u041c\u043e\u0434");
    private final ModeSetting.Value rw = new ModeSetting.Value(this.modeSetting, "RW");
    private final ModeSetting.Value defaults = new ModeSetting.Value(this.modeSetting, "Default");
    private final Set<UUID> bots = Collections.newSetFromMap(new ConcurrentHashMap());
    private final Set<UUID> warnPlayers = ConcurrentHashMap.newKeySet();
    private final EventListener<ReceivePacketEvent> onPacket = event -> {
        class_2703 packet;
        block6: {
            block5: {
                class_2596<?> patt0$temp = event.getPacket();
                if (!(patt0$temp instanceof class_2703)) break block5;
                packet = (class_2703)patt0$temp;
                if (this.rw.isSelected()) break block6;
            }
            return;
        }
        if (!packet.method_46327().contains(class_2703.class_5893.field_29136)) {
            return;
        }
        for (class_2703.class_2705 entry : packet.method_46329()) {
            GameProfile profile = entry.comp_1107();
            if (this.warnPlayers.contains(profile.getId()) || this.bots.contains(profile.getId()) || !profile.getProperties().isEmpty() || entry.comp_1109() == 0) continue;
            this.warnPlayers.add(profile.getId());
        }
    };

    @Override
    public void onDisable() {
        this.bots.clear();
        super.onDisable();
    }

    @Override
    public void tick() {
        if (AntiBot.mc.field_1687 == null || AntiBot.mc.field_1724 == null) {
            return;
        }
        if (this.rw.isSelected()) {
            this.checkPlayersForFakes();
            this.checkWarnedPlayers();
            this.cleanupBots();
        } else {
            for (class_1657 player : AntiBot.mc.field_1687.method_18456()) {
                if (!(player.method_6032() <= 0.0f) && !player.field_5960) continue;
                this.bots.add(player.method_5667());
            }
        }
        super.tick();
    }

    private void checkPlayersForFakes() {
        class_1297 currentTarget = Experiment.getInstance().getTargetManager().getCurrentTarget();
        for (class_1657 player : AntiBot.mc.field_1687.method_18456()) {
            if (this.isInvalidPlayer(player) || !this.isSuspiciousTargetFake(player, currentTarget) || player.field_6012 >= 30) continue;
            this.bots.add(player.method_5667());
        }
    }

    private void checkWarnedPlayers() {
        for (UUID uuid : this.warnPlayers) {
            class_1657 player = AntiBot.mc.field_1687.method_18470(uuid);
            if (player == null || !this.hasFullArmor(player) && !this.hasSuspiciousUUID(player)) continue;
            this.bots.add(player.method_5667());
        }
    }

    private void cleanupBots() {
        if (AntiBot.mc.field_1724.field_6012 % 100 == 0) {
            this.bots.removeIf(uuid -> AntiBot.mc.field_1687.method_18470(uuid) == null);
        }
    }

    private boolean isInvalidPlayer(class_1657 player) {
        return player == AntiBot.mc.field_1724 || this.bots.contains(player.method_5667());
    }

    private boolean isSuspiciousTargetFake(class_1657 player, class_1297 target) {
        if (!(target instanceof class_1657)) {
            return false;
        }
        class_1657 realTarget = (class_1657)target;
        boolean sameIdentity = player.method_7334().getName().equals(realTarget.method_7334().getName()) || player.method_5628() == realTarget.method_5628();
        return sameIdentity && !player.method_31548().equals(realTarget.method_31548());
    }

    private boolean hasFullArmor(class_1657 player) {
        int armorCount = 0;
        for (class_1799 stack : player.method_5661()) {
            if (stack.method_7960()) continue;
            ++armorCount;
        }
        return armorCount == 4;
    }

    private boolean hasSuspiciousUUID(class_1657 player) {
        try {
            UUID nameAsUUID = UUID.fromString(player.method_7334().getName());
            return !player.method_5667().equals(nameAsUUID);
        }
        catch (IllegalArgumentException e) {
            return false;
        }
    }

    public boolean isRWBot(class_1657 player) {
        return this.bots.contains(player.method_5667());
    }
}

