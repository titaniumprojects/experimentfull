/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1308
 *  net.minecraft.class_1309
 *  net.minecraft.class_1429
 *  net.minecraft.class_1657
 *  net.minecraft.class_2246
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 *  org.joml.Vector2f
 */
package micronix.experiment.systems.modules.modules.combat;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.combat.aura.TargetFinder;
import micronix.experiment.utility.game.CombatUtility;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector2f;

@ModuleInfo(name="Rotating Hitbox", category=ModuleCategory.COMBAT, desc="\u0423\u0432\u0435\u043b\u0438\u0447\u0435\u043d\u043d\u044b\u0439 \u0445\u0438\u0442\u0431\u043e\u043a\u0441 \u0441 \u0440\u043e\u0442\u0430\u0446\u0438\u0435\u0439 \u043a\u0430\u043a \u0432 Aura-Funtime")
@Environment(value=EnvType.CLIENT)
public class RotatingHitbox
extends BaseModule {
    private static RotatingHitbox instance;
    private final ModeSetting rotationMode = new ModeSetting(this, "\u0420\u043e\u0442\u0430\u0446\u0438\u044f");
    private final ModeSetting.Value ftSnapRot = new ModeSetting.Value(this.rotationMode, "FTSnap").select();
    private final ModeSetting.Value simpleRot = new ModeSetting.Value(this.rotationMode, "Simple");
    private final ModeSetting.Value funTimeRot = new ModeSetting.Value(this.rotationMode, "FunTime");
    private final ModeSetting.Value funtimeV2Rot = new ModeSetting.Value(this.rotationMode, "FuntimeV2");
    private final ModeSetting.Value spookyRot = new ModeSetting.Value(this.rotationMode, "SpookyTime");
    private final ModeSetting.Value holyWorldRot = new ModeSetting.Value(this.rotationMode, "HolyWorld");
    private final ModeSetting.Value intaveRot = new ModeSetting.Value(this.rotationMode, "Intave");
    private final ModeSetting.Value snapRot = new ModeSetting.Value(this.rotationMode, "Snap");
    private final ModeSetting.Value hvhRot = new ModeSetting.Value(this.rotationMode, "HvH");
    private final ModeSetting.Value lonyRot = new ModeSetting.Value(this.rotationMode, "LonyGrief");
    private final ModeSetting.Value noRot = new ModeSetting.Value(this.rotationMode, "None");
    private PerlinNoise rhNoise = new PerlinNoise(1234);
    private float rhNoiseFactor = 1.0f;
    private long rhRotationStartTime = 0L;
    private Rotation rhAdditional = null;
    private final Timer rhAttackTimer = new Timer();
    private final Timer rhCollideTimer = new Timer();
    private Vector2f rhRotateVector = new Vector2f(0.0f, 0.0f);
    private final TargetFinder targetFinder = new TargetFinder();
    private final InternalFTSnapRotation ftSnapRotation = new InternalFTSnapRotation(this);
    private final SliderSetting attackRange = new SliderSetting(this, "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043f\u043e\u0438\u0441\u043a\u0430").min(1.0f).max(6.0f).step(0.1f).currentValue(3.5f);
    private final SliderSetting expandSize = new SliderSetting(this, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0443\u0432\u0435\u043b\u0438\u0447\u0435\u043d\u0438\u044f").min(0.1f).max(2.0f).step(0.1f).currentValue(0.5f);
    private final SelectSetting targetTypes = new SelectSetting(this, "\u0422\u0438\u043f\u044b \u0446\u0435\u043b\u0435\u0439");
    private final SelectSetting.Value players = new SelectSetting.Value(this.targetTypes, "Players").select();
    private final SelectSetting.Value mobs = new SelectSetting.Value(this.targetTypes, "Mobs").select();
    private final SelectSetting.Value animals = new SelectSetting.Value(this.targetTypes, "Animals");
    private final BooleanSetting ignoreWalls = new BooleanSetting(this, "\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0441\u0442\u0435\u043d\u044b");
    private final BooleanSetting antiReach = new BooleanSetting(this, "\u0410\u043d\u0442\u0438-Reach");
    private final SliderSetting antiReachDistance = new SliderSetting(this, "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0410\u043d\u0442\u0438-Reach").min(1.0f).max(3.0f).step(0.01f).currentValue(2.85f);
    private final BooleanSetting fakeSwing = new BooleanSetting(this, "\u0424\u0435\u0439\u043a \u0441\u0432\u0438\u043d\u0433");
    private final BooleanSetting legitSprint = new BooleanSetting(this, "\u041b\u0435\u0433\u0438\u0442 \u0441\u043f\u0440\u0438\u043d\u0442").enable();
    private final BooleanSetting autoTargetESP = new BooleanSetting(this, "\u0410\u0432\u0442\u043e TargetESP").enable();
    private final BooleanSetting dontExpandFriends = new BooleanSetting(this, "\u041d\u0435 \u0443\u0432\u0435\u043b\u0438\u0447\u0438\u0432\u0430\u0442\u044c \u0434\u0440\u0443\u0437\u0435\u0439").enable();
    private final SliderSetting lineWidth = new SliderSetting(this, "\u0422\u043e\u043b\u0449\u0438\u043d\u0430 \u043b\u0438\u043d\u0438\u0439").min(1.0f).max(5.0f).step(0.5f).currentValue(2.5f);
    private final ColorSetting hitboxColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u0445\u0438\u0442\u0431\u043e\u043a\u0441\u0430").color(new ColorRGBA(100.0f, 150.0f, 255.0f, 100.0f));
    private final ColorSetting activeColor = new ColorSetting(this, "\u0426\u0432\u0435\u0442 \u043f\u0440\u0438 \u0430\u043a\u0442\u0438\u0432\u0430\u0446\u0438\u0438").color(new ColorRGBA(255.0f, 50.0f, 50.0f, 120.0f));
    private class_1309 currentTarget = null;
    private boolean isAimingAtHitbox = false;
    private boolean sprintResetActive = false;
    private long sprintResetStartTime = 0L;
    private static final long SPRINT_RESET_DURATION = 250L;
    private final Map<Integer, class_238> originalHitboxes = new HashMap<Integer, class_238>();
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (RotatingHitbox.mc.field_1724 == null || RotatingHitbox.mc.field_1687 == null) {
            this.resetState();
            return;
        }
        List<String> selectedTypes = this.targetTypes.getSelectedValues().stream().map(SelectSetting.Value::getName).toList();
        this.targetFinder.searchTargets(this.attackRange.getCurrentValue(), 90.0f, this.ignoreWalls.isEnabled(), selectedTypes);
        this.targetFinder.validateTarget(target -> {
            float distance;
            if (target == null || !target.method_5805() || target.method_6032() <= 0.0f) {
                return false;
            }
            if (this.dontExpandFriends.isEnabled() && target instanceof class_1657) {
                class_1657 player = (class_1657)target;
                if (Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString())) {
                    return false;
                }
            }
            return (distance = RotatingHitbox.mc.field_1724.method_5739((class_1297)target)) <= this.attackRange.getCurrentValue();
        });
        class_1309 previousTarget = this.currentTarget;
        this.currentTarget = this.targetFinder.getCurrentTarget();
        if (this.currentTarget != previousTarget) {
            this.ftSnapRotation.notifyTargetChanged(this.currentTarget);
        }
        if (this.currentTarget != null) {
            this.isAimingAtHitbox = this.isLookingAtExpandedHitbox();
            if (this.isAimingAtHitbox && !this.isAuraEnabled()) {
                this.applyRotation(this.currentTarget);
                if (this.legitSprint.isEnabled()) {
                    this.handleLegitSprintReset();
                }
            }
            if (this.autoTargetESP.isEnabled()) {
                Experiment.getInstance().getTargetManager().setCurrentTarget(this.currentTarget);
            }
        } else {
            this.sprintResetActive = false;
            if (this.autoTargetESP.isEnabled()) {
                Experiment.getInstance().getTargetManager().setCurrentTarget(null);
            }
        }
    };
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (RotatingHitbox.mc.field_1724 == null || RotatingHitbox.mc.field_1687 == null) {
            return;
        }
        List<String> selectedTypes = this.targetTypes.getSelectedValues().stream().map(SelectSetting.Value::getName).toList();
        for (class_1297 entity : RotatingHitbox.mc.field_1687.method_18112()) {
            class_1309 livingEntity;
            if (!(entity instanceof class_1309) || (livingEntity = (class_1309)entity) == RotatingHitbox.mc.field_1724) continue;
            boolean isValidType = false;
            for (String type : selectedTypes) {
                if (type.equals("Players") && livingEntity instanceof class_1657) {
                    isValidType = true;
                    break;
                }
                if (type.equals("Mobs") && livingEntity instanceof class_1308) {
                    isValidType = true;
                    break;
                }
                if (!type.equals("Animals") || !(livingEntity instanceof class_1429)) continue;
                isValidType = true;
                break;
            }
            if (!isValidType || !livingEntity.method_5805()) continue;
            int id = livingEntity.method_5628();
            if (!this.originalHitboxes.containsKey(id)) {
                this.originalHitboxes.put(id, this.getOriginalHitbox((class_1297)livingEntity));
            }
            boolean isFriend = false;
            if (this.dontExpandFriends.isEnabled() && livingEntity instanceof class_1657) {
                class_1657 player = (class_1657)livingEntity;
                isFriend = Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString());
            }
            if (isFriend) {
                class_238 originalBox = this.getOriginalHitbox((class_1297)livingEntity);
                ColorRGBA friendColor = new ColorRGBA(0.0f, 255.0f, 0.0f, 100.0f);
                this.renderHitbox(event.getMatrices(), originalBox, false, friendColor);
                continue;
            }
            float radius = this.getEntityRadius((class_1297)livingEntity);
            float expandedRadius = radius + this.expandSize.getCurrentValue();
            this.setEntityHitbox(livingEntity, expandedRadius);
            class_238 expandedBox = this.calculateExpandedHitbox(livingEntity);
            boolean isCurrentTarget = livingEntity == this.currentTarget && this.isAimingAtHitbox;
            this.renderHitbox(event.getMatrices(), expandedBox, isCurrentTarget, null);
        }
    };
    private final EventListener<AttackEvent> onAttack = event -> {
        double maxDistance;
        class_243 closestPoint;
        class_1297 target = event.getEntity();
        if (this.legitSprint.isEnabled() && target instanceof class_1309) {
            this.sprintResetActive = true;
            this.sprintResetStartTime = System.currentTimeMillis();
        }
        if (!this.antiReach.isEnabled() || RotatingHitbox.mc.field_1724 == null) {
            return;
        }
        if (!(target instanceof class_1309)) {
            return;
        }
        class_1309 livingEntity = (class_1309)target;
        if (livingEntity == RotatingHitbox.mc.field_1724) {
            return;
        }
        class_238 originalBox = this.getOriginalHitbox((class_1297)livingEntity);
        class_243 eyes = RotatingHitbox.mc.field_1724.method_33571();
        double distance = eyes.method_1022(closestPoint = this.getClosestPoint(eyes, originalBox));
        if (distance > (maxDistance = (double)this.antiReachDistance.getCurrentValue())) {
            event.cancel();
            if (this.fakeSwing.isEnabled() && RotatingHitbox.mc.field_1724 != null) {
                RotatingHitbox.mc.field_1724.method_6104(class_1268.field_5808);
                RotatingHitbox.mc.field_1724.method_7350();
            }
        }
    };

    public RotatingHitbox() {
        instance = this;
    }

    public static RotatingHitbox getInstance() {
        return instance;
    }

    private void applyRotation(class_1309 target) {
        RotationHandler handler = Experiment.getInstance().getRotationHandler();
        Rotation currentRot = handler.getCurrentRotation();
        MoveCorrection mc2 = MoveCorrection.SILENT;
        if (this.rotationMode.is(this.ftSnapRot)) {
            this.ftSnapRotation.updateSavedView();
            this.ftSnapRotation.rotateTo(target, false);
            return;
        }
        if (this.rotationMode.is(this.noRot)) {
            return;
        }
        if (this.rotationMode.is(this.simpleRot)) {
            Rotation rot = RotationMath.getRotationTo(RotationMath.getNearestPoint(target));
            handler.rotate(rot, mc2, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            return;
        }
        if (this.rotationMode.is(this.snapRot)) {
            Rotation snap = RotationMath.getRotationTo(target.method_5829().method_1005());
            handler.rotate(snap, mc2, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            return;
        }
        if (this.rotationMode.is(this.hvhRot)) {
            Rotation rot = RotationMath.getRotationTo(target.method_5829().method_1005());
            handler.rotate(rot, mc2, 360.0f, 360.0f, 360.0f, RotationPriority.TO_TARGET);
            return;
        }
        if (this.rotationMode.is(this.lonyRot)) {
            this.rhApplyLonyGrief(target, mc2, handler);
            return;
        }
        if (this.rotationMode.is(this.funTimeRot)) {
            Rotation rot = this.rhGetFunTime(target, currentRot);
            handler.rotate(rot, mc2, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            return;
        }
        if (this.rotationMode.is(this.funtimeV2Rot) || this.rotationMode.is(this.spookyRot)) {
            this.rhApplySpooky(target, mc2, handler, currentRot);
            return;
        }
        if (this.rotationMode.is(this.holyWorldRot)) {
            Rotation rot = this.rhGetHolyWorld(target, currentRot);
            handler.rotate(rot, mc2, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            return;
        }
        if (this.rotationMode.is(this.intaveRot)) {
            this.rhApplyIntave(target, mc2, handler, currentRot);
        }
    }

    private Rotation rhGetFunTime(class_1309 target, Rotation currentRot) {
        if (RotatingHitbox.mc.field_1724.field_6012 % 500 == 0) {
            this.rhNoise = new PerlinNoise(1234);
            this.rhNoiseFactor = 1.0f;
        }
        class_243 nearY = RotationMath.getNearestPoint(target);
        Rotation targetRot = RotationMath.getRotationTo(new class_243(nearY.field_1352, class_3532.method_15350((double)MathUtility.interpolate(RotatingHitbox.mc.field_1724.method_23318(), target.method_23320(), 0.5), (double)target.method_5829().field_1322, (double)target.method_5829().field_1325), nearY.field_1350));
        boolean idle = this.rhAttackTimer.finished(300L);
        if (this.rhAdditional == null) {
            this.rhAdditional = new Rotation(0.0f, 0.0f);
        }
        float targetYaw = targetRot.getYaw();
        float targetPitch = targetRot.getPitch();
        float yawDiff = RotationMath.getAngleDifference(currentRot.getYaw(), targetYaw);
        float pitchDiff = RotationMath.getAngleDifference(currentRot.getPitch(), targetPitch);
        if (idle) {
            targetYaw -= 5.0f;
        }
        if (!idle) {
            targetYaw += this.rhAdditional.getYaw();
            targetPitch += this.rhAdditional.getPitch();
        }
        long elapsed = System.currentTimeMillis() - this.rhRotationStartTime;
        float yawOffset = this.rhNoise.noise((float)((double)elapsed * 5.0E-4), 0.0f) * 25.0f * this.rhNoiseFactor;
        float pitchOffset = this.rhNoise.noise((float)((double)elapsed * 5.0E-4), 10.0f) * 25.0f * this.rhNoiseFactor;
        if (Math.abs(yawDiff) + Math.abs(pitchDiff) < 10.0f) {
            this.rhNoiseFactor = Math.max(0.0f, this.rhNoiseFactor - 0.05f);
        }
        return new Rotation(targetYaw + yawOffset, class_3532.method_15363((float)(targetPitch + pitchOffset), (float)-90.0f, (float)90.0f));
    }

    private void rhApplySpooky(class_1309 target, MoveCorrection mc2, RotationHandler handler, Rotation currentRot) {
        if (RotatingHitbox.mc.field_1724.field_6012 % 500 == 0) {
            this.rhNoise = new PerlinNoise(1234);
            this.rhNoiseFactor = 1.0f;
        }
        boolean collide = EntityUtility.collideWith(target, 1.0f);
        class_243 nearY = RotationMath.getNearestPoint(target);
        Rotation targetRot = RotationMath.getRotationTo(new class_243(nearY.field_1352, class_3532.method_15350((double)MathUtility.interpolate(RotatingHitbox.mc.field_1724.method_23318(), target.method_23320(), 0.5), (double)target.method_5829().field_1322, (double)target.method_5829().field_1325), nearY.field_1350));
        Rotation multipoint = RotationMath.getRotationTo(RotationMath.getNearestPoint(target));
        if (collide) {
            targetRot = RotationMath.getRotationTo(target.method_19538().method_1031(0.0, 0.5, 0.0));
        }
        if (RotatingHitbox.mc.field_1724.method_33571().method_1022(target.method_33571()) > 3.0) {
            targetRot.setPitch(multipoint.getPitch() + 10.0f);
        }
        boolean idle = this.rhAttackTimer.finished(collide ? 500L : 200L);
        if (this.rhAdditional == null) {
            this.rhAdditional = new Rotation(0.0f, 0.0f);
        }
        float targetYaw = targetRot.getYaw();
        float targetPitch = targetRot.getPitch();
        float yawDiff = RotationMath.getAngleDifference(currentRot.getYaw(), targetYaw);
        float pitchDiff = RotationMath.getAngleDifference(currentRot.getPitch(), targetPitch);
        if (idle && EntityUtility.getBlock(0.0, 2.0, 0.0) == class_2246.field_10124) {
            targetYaw += 10.0f;
            targetPitch -= 20.0f;
        }
        float yawSpeed = Math.max((90.0f - Math.abs(yawDiff)) / (idle ? (RotatingHitbox.mc.field_1724.field_6017 > 0.0f ? 25.0f : 10.0f) : 60.0f), MathUtility.random(1.0, 5.0)) * MathUtility.random(0.9, 1.1);
        float pitchSpeed = Math.abs(pitchDiff) / (idle ? (RotatingHitbox.mc.field_1724.field_6017 > 0.0f ? 25.0f : 10.0f) : 40.0f) * MathUtility.random(0.9, 1.1);
        if (!EntityUtility.collideWith(target)) {
            this.rhCollideTimer.reset();
        }
        if (this.rhCollideTimer.finished(500L) && CombatUtility.stalin(target)) {
            targetPitch = (float)(64.0 + (RotatingHitbox.mc.field_1724.method_23318() - target.method_23318() + 1.0) * (5.0 + Math.sin((float)(RotatingHitbox.mc.field_1724.field_6012 % 100 / 5) * 1924.12f) * 35.0) - 5.0 + 10.0);
            yawSpeed /= MathUtility.random(30.0, 50.0);
        }
        if (!idle && EntityUtility.getBlock(0.0, 2.0, 0.0) == class_2246.field_10124 && !collide) {
            targetYaw += this.rhAdditional.getYaw();
            targetPitch += this.rhAdditional.getPitch();
        }
        long elapsed = System.currentTimeMillis() - this.rhRotationStartTime;
        float yawOffset = this.rhNoise.noise((float)((double)elapsed * 5.0E-4), 0.0f) * 25.0f * this.rhNoiseFactor;
        float pitchOffset = this.rhNoise.noise((float)((double)elapsed * 5.0E-4), 10.0f) * 25.0f * this.rhNoiseFactor;
        if (Math.abs(yawDiff) + Math.abs(pitchDiff) < 10.0f) {
            this.rhNoiseFactor = Math.max(0.0f, this.rhNoiseFactor - 0.05f);
        }
        handler.rotate(new Rotation(targetYaw + yawOffset, class_3532.method_15363((float)(targetPitch + pitchOffset), (float)-90.0f, (float)90.0f)), mc2, yawSpeed * 25.0f, pitchSpeed * 25.0f, MathUtility.random(30.0, 70.0), RotationPriority.TO_TARGET);
    }

    private Rotation rhGetHolyWorld(class_1309 target, Rotation currentRot) {
        double offsetX = 0.15 * Math.cos((double)System.currentTimeMillis() / 1000.0);
        double offsetY = 0.15 * Math.cos((double)System.currentTimeMillis() / 10000.0);
        double offsetZ = 0.15 * Math.cos((double)System.currentTimeMillis() / 1000.0);
        class_243 nearY = RotationMath.getNearestPoint(target);
        class_243 targetPos = new class_243(nearY.field_1352, class_3532.method_15350((double)MathUtility.interpolate(RotatingHitbox.mc.field_1724.method_23318(), target.method_23320(), 0.5), (double)target.method_5829().field_1322, (double)target.method_5829().field_1325), nearY.field_1350);
        class_238 box = target.method_5829();
        double cx = class_3532.method_15350((double)(targetPos.method_10216() + offsetX), (double)box.field_1323, (double)box.field_1320);
        double cy = targetPos.method_10214() + (double)(target.method_17682() / 2.0f) + offsetY;
        double cz = class_3532.method_15350((double)(targetPos.method_10215() + offsetZ), (double)box.field_1321, (double)box.field_1324);
        class_243 vec = new class_243(cx, cy, cz).method_1020(RotatingHitbox.mc.field_1724.method_33571());
        float yaw = (float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(vec.field_1350, vec.field_1352)) - 90.0));
        float yawDelta = class_3532.method_15393((float)(yaw - currentRot.getYaw()));
        return new Rotation(currentRot.getYaw() + yawDelta, class_3532.method_15363((float)currentRot.getPitch(), (float)-90.0f, (float)90.0f));
    }

    private void rhApplyIntave(class_1309 target, MoveCorrection mc2, RotationHandler handler, Rotation currentRot) {
        if (RotatingHitbox.mc.field_1724.field_6012 % 500 == 0) {
            this.rhNoise = new PerlinNoise(1234);
            this.rhNoiseFactor = 1.0f;
        }
        class_243 nearY = RotationMath.getNearestPoint(target);
        Rotation targetRot = RotationMath.getRotationTo(new class_243(nearY.field_1352, class_3532.method_15350((double)MathUtility.interpolate(RotatingHitbox.mc.field_1724.method_23318(), target.method_23320(), 0.5), (double)target.method_5829().field_1322, (double)target.method_5829().field_1325), nearY.field_1350));
        boolean idle = this.rhAttackTimer.finished(300L);
        if (this.rhAdditional == null) {
            this.rhAdditional = new Rotation(0.0f, 0.0f);
        }
        float targetYaw = targetRot.getYaw();
        float targetPitch = targetRot.getPitch();
        float yawDiff = RotationMath.getAngleDifference(currentRot.getYaw(), targetYaw);
        float pitchDiff = RotationMath.getAngleDifference(currentRot.getPitch(), targetPitch);
        if (idle) {
            targetYaw -= 5.0f;
        }
        if (!idle) {
            targetYaw += this.rhAdditional.getYaw();
            targetPitch += this.rhAdditional.getPitch();
        }
        float yawSpeed = Math.max((90.0f - Math.abs(yawDiff)) / (idle ? (RotatingHitbox.mc.field_1724.field_6017 > 0.0f ? 20.0f : 60.0f) : 40.0f), MathUtility.random(1.0, 5.0)) * MathUtility.random(0.9, 1.1);
        float pitchSpeed = Math.abs(pitchDiff) / (idle ? (RotatingHitbox.mc.field_1724.field_6017 > 0.0f ? 60.0f : 100.0f) : 30.0f) * MathUtility.random(0.9, 1.1);
        handler.rotate(new Rotation(targetYaw, class_3532.method_15363((float)targetPitch, (float)-90.0f, (float)90.0f)), mc2, yawSpeed * 25.0f, pitchSpeed * 25.0f, MathUtility.random(5.0, 50.0), RotationPriority.TO_TARGET);
    }

    private void rhApplyLonyGrief(class_1309 target, MoveCorrection mc2, RotationHandler handler) {
        class_238 box = target.method_5829();
        double targetX = box.field_1323 + (box.field_1320 - box.field_1323) * Math.random();
        double targetY = box.field_1322 + (box.field_1325 - box.field_1322) * Math.random();
        double targetZ = box.field_1321 + (box.field_1324 - box.field_1321) * Math.random();
        double time = (double)System.currentTimeMillis() / 500.0;
        class_243 finalPos = new class_243(targetX + Math.sin(time) * 0.15, targetY + Math.cos(time * 1.2) * 0.2, targetZ + Math.cos(time * 0.8) * 0.15);
        handler.rotate(RotationMath.getRotationTo(finalPos), mc2, 120.0f, 100.0f, 150.0f, RotationPriority.TO_TARGET);
    }

    private class_238 getOriginalHitbox(class_1297 entity) {
        return entity.method_5864().method_18386().method_30757(entity.method_19538());
    }

    private float getEntityRadius(class_1297 entity) {
        class_238 box = this.getOriginalHitbox(entity);
        return (float)(box.method_17939() / 2.0);
    }

    private void setEntityHitbox(class_1309 entity, float radius) {
        entity.method_5857(new class_238(entity.method_23317() - (double)radius, entity.method_5829().field_1322, entity.method_23321() - (double)radius, entity.method_23317() + (double)radius, entity.method_5829().field_1325, entity.method_23321() + (double)radius));
    }

    private class_238 calculateExpandedHitbox(class_1309 target) {
        float radius = this.getEntityRadius((class_1297)target);
        float expandedRadius = radius + this.expandSize.getCurrentValue();
        return new class_238(target.method_23317() - (double)expandedRadius, target.method_5829().field_1322, target.method_23321() - (double)expandedRadius, target.method_23317() + (double)expandedRadius, target.method_5829().field_1325, target.method_23321() + (double)expandedRadius);
    }

    private boolean isLookingAtExpandedHitbox() {
        if (RotatingHitbox.mc.field_1724 == null || this.currentTarget == null) {
            return false;
        }
        float yaw = RotatingHitbox.mc.field_1724.method_36454();
        float pitch = RotatingHitbox.mc.field_1724.method_36455();
        float yawRad = (float)Math.toRadians(yaw);
        float pitchRad = (float)Math.toRadians(pitch);
        float x = (float)(-Math.sin(yawRad) * Math.cos(pitchRad));
        float y = (float)(-Math.sin(pitchRad));
        float z = (float)(Math.cos(yawRad) * Math.cos(pitchRad));
        class_243 direction = new class_243((double)x, (double)y, (double)z);
        class_243 eyes = RotatingHitbox.mc.field_1724.method_33571();
        class_238 expandedBox = this.calculateExpandedHitbox(this.currentTarget);
        if (expandedBox.method_1006(eyes)) {
            return true;
        }
        class_243 end = eyes.method_1019(direction.method_1021((double)this.attackRange.getCurrentValue() + 2.0));
        return expandedBox.method_992(eyes, end).isPresent();
    }

    private void resetState() {
        this.isAimingAtHitbox = false;
    }

    private void handleLegitSprintReset() {
        if (RotatingHitbox.mc.field_1724 == null) {
            return;
        }
        long currentTime = System.currentTimeMillis();
        if (this.sprintResetActive) {
            RotatingHitbox.mc.field_1690.field_1867.method_23481(false);
            RotatingHitbox.mc.field_1724.method_5728(false);
            if (currentTime - this.sprintResetStartTime >= 250L) {
                this.sprintResetActive = false;
            }
        }
    }

    private boolean isAuraEnabled() {
        return Experiment.getInstance().getModuleManager().getModule(Aura.class).isEnabled();
    }

    private void restoreAllHitboxes() {
        if (RotatingHitbox.mc.field_1687 == null) {
            return;
        }
        for (class_1297 entity : RotatingHitbox.mc.field_1687.method_18112()) {
            int id;
            class_1309 livingEntity;
            if (!(entity instanceof class_1309) || (livingEntity = (class_1309)entity) == RotatingHitbox.mc.field_1724 || !this.originalHitboxes.containsKey(id = livingEntity.method_5628())) continue;
            float radius = this.getEntityRadius((class_1297)livingEntity);
            this.setEntityHitbox(livingEntity, radius);
        }
        this.originalHitboxes.clear();
    }

    private class_243 getClosestPoint(class_243 point, class_238 box) {
        double x = Math.max(box.field_1323, Math.min(point.field_1352, box.field_1320));
        double y = Math.max(box.field_1322, Math.min(point.field_1351, box.field_1325));
        double z = Math.max(box.field_1321, Math.min(point.field_1350, box.field_1324));
        return new class_243(x, y, z);
    }

    private void renderHitbox(class_4587 matrices, class_238 box, boolean active, ColorRGBA friendColor) {
        if (RotatingHitbox.mc.field_1724 == null) {
            return;
        }
        matrices.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        RenderSystem.lineWidth((float)this.lineWidth.getCurrentValue());
        class_243 cameraPos = RotatingHitbox.mc.field_1773.method_19418().method_19326();
        matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
        ColorRGBA color = friendColor != null ? friendColor : (active ? this.activeColor.getColor() : this.hitboxColor.getColor());
        this.drawBoxFilled(matrices, box, color);
        ColorRGBA outlineColor = new ColorRGBA(Math.min(255.0f, color.getRed() + 50.0f), Math.min(255.0f, color.getGreen() + 50.0f), Math.min(255.0f, color.getBlue() + 50.0f), Math.min(255.0f, color.getAlpha() + 80.0f));
        this.drawBoxOutline(matrices, box, outlineColor);
        RenderSystem.lineWidth((float)1.0f);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        matrices.method_22909();
    }

    private void drawBoxFilled(class_4587 matrices, class_238 box, ColorRGBA color) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        float r = color.getRed() / 255.0f;
        float g = color.getGreen() / 255.0f;
        float b = color.getBlue() / 255.0f;
        float a = color.getAlpha() / 255.0f * 0.5f;
        float minX = (float)box.field_1323;
        float minY = (float)box.field_1322;
        float minZ = (float)box.field_1321;
        float maxX = (float)box.field_1320;
        float maxY = (float)box.field_1325;
        float maxZ = (float)box.field_1324;
        buffer.method_22918(matrix, minX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_22915(r, g, b, a);
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    private void drawBoxOutline(class_4587 matrices, class_238 box, ColorRGBA color) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        float r = color.getRed() / 255.0f;
        float g = color.getGreen() / 255.0f;
        float b = color.getBlue() / 255.0f;
        float a = color.getAlpha() / 255.0f;
        float minX = (float)box.field_1323;
        float minY = (float)box.field_1322;
        float minZ = (float)box.field_1321;
        float maxX = (float)box.field_1320;
        float maxY = (float)box.field_1325;
        float maxZ = (float)box.field_1324;
        buffer.method_22918(matrix, minX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, minY, maxZ).method_22915(r, g, b, a);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_22915(r, g, b, a);
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    @Override
    public void onEnable() {
        this.targetFinder.releaseTarget();
        this.currentTarget = null;
        this.isAimingAtHitbox = false;
        this.originalHitboxes.clear();
        this.ftSnapRotation.reset();
        this.sprintResetActive = false;
        this.sprintResetStartTime = 0L;
        this.rhNoise = new PerlinNoise(1234);
        this.rhNoiseFactor = 1.0f;
        this.rhRotationStartTime = System.currentTimeMillis();
        this.rhAdditional = null;
        this.rhAttackTimer.reset();
        this.rhCollideTimer.reset();
        this.rhRotateVector = new Vector2f(0.0f, 0.0f);
    }

    @Override
    public void onDisable() {
        this.targetFinder.releaseTarget();
        this.currentTarget = null;
        this.isAimingAtHitbox = false;
        this.restoreAllHitboxes();
        this.ftSnapRotation.reset();
        this.sprintResetActive = false;
        if (this.autoTargetESP.isEnabled()) {
            Experiment.getInstance().getTargetManager().setCurrentTarget(null);
        }
    }

    private static float rnd(float a, float b) {
        if (b <= a) {
            return a;
        }
        return a + ThreadLocalRandom.current().nextFloat() * (b - a);
    }

    @Environment(value=EnvType.CLIENT)
    private static class PerlinNoise {
        private final int[] p = new int[512];

        public PerlinNoise(int seed) {
            int i;
            int[] perm = new int[256];
            for (int i2 = 0; i2 < 256; ++i2) {
                perm[i2] = i2;
            }
            Random r = new Random(seed);
            for (i = 255; i > 0; --i) {
                int j = r.nextInt(i + 1);
                int t = perm[i];
                perm[i] = perm[j];
                perm[j] = t;
            }
            for (i = 0; i < 256; ++i) {
                int v;
                this.p[i] = v = perm[i] & 0xFF;
                this.p[i + 256] = v;
            }
        }

        private static float fade(float t) {
            return t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f);
        }

        private static float lerp(float t, float a, float b) {
            return a + t * (b - a);
        }

        private static float grad(int hash, float x, float y, float z) {
            float u;
            int h = hash & 0xF;
            float f = u = h < 8 ? x : y;
            float v = h < 4 ? y : (h == 12 || h == 14 ? x : z);
            return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
        }

        public float noise(float x, float y) {
            float z = 0.0f;
            int X = (int)Math.floor(x) & 0xFF;
            int Y = (int)Math.floor(y) & 0xFF;
            int Z = (int)Math.floor(z) & 0xFF;
            x = (float)((double)x - Math.floor(x));
            y = (float)((double)y - Math.floor(y));
            z = (float)((double)z - Math.floor(z));
            float u = PerlinNoise.fade(x);
            float v = PerlinNoise.fade(y);
            float w = PerlinNoise.fade(z);
            int A = this.p[X] + Y;
            int AA = this.p[A] + Z;
            int AB = this.p[A + 1] + Z;
            int B = this.p[X + 1] + Y;
            int BA = this.p[B] + Z;
            int BB = this.p[B + 1] + Z;
            return PerlinNoise.lerp(w, PerlinNoise.lerp(v, PerlinNoise.lerp(u, PerlinNoise.grad(this.p[AA], x, y, z), PerlinNoise.grad(this.p[BA], x - 1.0f, y, z)), PerlinNoise.lerp(u, PerlinNoise.grad(this.p[AB], x, y - 1.0f, z), PerlinNoise.grad(this.p[BB], x - 1.0f, y - 1.0f, z))), PerlinNoise.lerp(v, PerlinNoise.lerp(u, PerlinNoise.grad(this.p[AA + 1], x, y, z - 1.0f), PerlinNoise.grad(this.p[BA + 1], x - 1.0f, y, z - 1.0f)), PerlinNoise.lerp(u, PerlinNoise.grad(this.p[AB + 1], x, y - 1.0f, z - 1.0f), PerlinNoise.grad(this.p[BB + 1], x - 1.0f, y - 1.0f, z - 1.0f))));
        }

        public float fbm(float x, float y, int octaves, float lacunarity, float gain) {
            float sum = 0.0f;
            float amp = 0.5f;
            float fx = x;
            float fy = y;
            for (int i = 0; i < octaves; ++i) {
                sum += this.noise(fx, fy) * amp;
                fx *= lacunarity;
                fy *= lacunarity;
                amp *= gain;
            }
            return sum;
        }
    }

    @Environment(value=EnvType.CLIENT)
    private class InternalFTSnapRotation {
        private final PerlinNoise perlin = new PerlinNoise(1337);
        private static final float NOISE_YAW_MIN = 0.06f;
        private static final float NOISE_YAW_MAX = 0.38f;
        private static final float NOISE_PITCH_MIN = 0.04f;
        private static final float NOISE_PITCH_MAX = 0.22f;
        private static final float NOISE_FREQ_MIN = 0.55f;
        private static final float NOISE_FREQ_MAX = 1.65f;
        private float noisePhaseYaw = 0.0f;
        private float noisePhasePitch = 0.0f;
        private class_243 mpCurrent = class_243.field_1353;
        private float mpOrbit = 0.0f;
        private long mpLastUpdate = 0L;
        private int mpLastTargetId = Integer.MIN_VALUE;
        private float critHeightOffset = 0.0f;
        private long lastAttackTime = 0L;
        private float overshootYaw = 0.0f;
        private float overshootPitch = 0.0f;
        private long overshootStartTime = 0L;
        private static final float OVERSHOOT_PROB = 0.25f;
        private static final float OVERSHOOT_MIN = 0.8f;
        private static final float OVERSHOOT_MAX = 2.5f;
        private static final long OVERSHOOT_DURATION = 80L;
        private float smoothedYaw = 0.0f;
        private float smoothedPitch = 0.0f;
        private long smoothLastTime = 0L;
        private int smoothTargetId = -1;
        private long targetLockTime = 0L;
        private int lastLockedTargetId = -1;
        private float currentSpeedMultiplier = 1.0f;
        private boolean savedViewValid = false;
        private float savedYaw = 0.0f;
        private float savedPitch = 0.0f;
        private boolean returnActive = false;
        private long returnStartTime = 0L;
        private float returnYaw = 0.0f;
        private float returnPitch = 0.0f;

        private InternalFTSnapRotation(RotatingHitbox rotatingHitbox) {
        }

        public void notifyTargetChanged(class_1309 newTarget) {
            if (newTarget == null) {
                this.lastLockedTargetId = -1;
                this.overshootYaw = 0.0f;
                this.overshootPitch = 0.0f;
                return;
            }
            int newId = newTarget.method_5628();
            if (this.lastLockedTargetId != newId) {
                long now;
                this.lastLockedTargetId = newId;
                this.targetLockTime = now = System.currentTimeMillis();
                this.currentSpeedMultiplier = RotatingHitbox.rnd(0.65f, 0.95f);
                if (ThreadLocalRandom.current().nextFloat() < 0.25f) {
                    this.overshootYaw = RotatingHitbox.rnd(0.8f, 2.5f) * (float)(ThreadLocalRandom.current().nextBoolean() ? 1 : -1);
                    this.overshootPitch = RotatingHitbox.rnd(0.48000002f, 1.5f) * (float)(ThreadLocalRandom.current().nextBoolean() ? 1 : -1);
                    this.overshootStartTime = now;
                } else {
                    this.overshootYaw = 0.0f;
                    this.overshootPitch = 0.0f;
                }
            }
        }

        public void updateSavedView() {
            if (IMinecraft.mc.field_1724 == null) {
                return;
            }
            if (!this.savedViewValid) {
                this.savedViewValid = true;
                Rotation currentRotation = Experiment.getInstance().getRotationHandler().getCurrentRotation();
                this.savedYaw = currentRotation.getYaw();
                this.savedPitch = currentRotation.getPitch();
            }
        }

        public void rotateTo(class_1309 target, boolean attacking) {
            long dtMs;
            if (IMinecraft.mc.field_1724 == null || target == null) {
                return;
            }
            this.updateSavedView();
            long now = System.currentTimeMillis();
            int tid = target.method_5628();
            if (this.smoothTargetId == -1) {
                Rotation currentRotation = Experiment.getInstance().getRotationHandler().getCurrentRotation();
                this.smoothedYaw = currentRotation.getYaw();
                this.smoothedPitch = currentRotation.getPitch();
            }
            if (attacking && now - this.lastAttackTime > 400L) {
                this.critHeightOffset = RotatingHitbox.rnd(-0.15f, 0.15f);
                this.lastAttackTime = now;
            }
            float k = 0.035f;
            this.noisePhaseYaw += k * (0.65f + 0.35f * (float)(tid * 1103515245 & 0xFF) / 255.0f);
            this.noisePhasePitch += k * (0.65f + 0.35f * (float)(tid * 1664525 & 0xFF) / 255.0f);
            class_243 targetPoint = this.getMultiPoint(target, attacking, now);
            class_243 eyes = IMinecraft.mc.field_1724.method_33571();
            class_243 direction = targetPoint.method_1020(eyes);
            double horizontalDistance = Math.sqrt(direction.field_1352 * direction.field_1352 + direction.field_1350 * direction.field_1350);
            float targetYaw = (float)Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90.0f;
            float targetPitch = (float)(-Math.toDegrees(Math.atan2(direction.field_1351, horizontalDistance)));
            targetYaw = this.normalizeAngle(targetYaw);
            targetPitch = InternalFTSnapRotation.clamp(targetPitch, -90.0f, 90.0f);
            if (this.smoothTargetId != tid) {
                this.smoothTargetId = tid;
                this.smoothLastTime = now;
            }
            if ((dtMs = now - this.smoothLastTime) < 1L) {
                dtMs = 1L;
            }
            if (dtMs > 120L) {
                dtMs = 120L;
            }
            this.smoothLastTime = now;
            long timeSinceLock = now - this.targetLockTime;
            float lockProgress = Math.min(1.0f, (float)timeSinceLock / 1000.0f);
            float speedMultiplier = lockProgress * lockProgress * (3.0f - 2.0f * lockProgress);
            speedMultiplier = 0.35f + speedMultiplier * 0.65f;
            float baseYawSpeed = attacking ? 55.0f : 60.0f;
            float basePitchSpeed = attacking ? 44.0f : 48.0f;
            float yawSpeed = baseYawSpeed * (speedMultiplier *= this.currentSpeedMultiplier);
            float pitchSpeed = basePitchSpeed * speedMultiplier;
            float yawMaxDelta = yawSpeed * ((float)dtMs / 50.0f);
            float pitchMaxDelta = pitchSpeed * ((float)dtMs / 50.0f);
            float yawError = this.normalizeAngle(targetYaw - this.smoothedYaw);
            float pitchError = targetPitch - this.smoothedPitch;
            this.smoothedYaw += InternalFTSnapRotation.clamp(yawError, -yawMaxDelta, yawMaxDelta);
            this.smoothedPitch += InternalFTSnapRotation.clamp(pitchError, -pitchMaxDelta, pitchMaxDelta);
            this.smoothedYaw = this.normalizeAngle(this.smoothedYaw);
            this.smoothedPitch = InternalFTSnapRotation.clamp(this.smoothedPitch, -90.0f, 90.0f);
            float overshootFactor = 0.0f;
            if (this.overshootYaw != 0.0f || this.overshootPitch != 0.0f) {
                long timeSinceOvershoot = now - this.overshootStartTime;
                if (timeSinceOvershoot < 80L) {
                    overshootFactor = 1.0f - (float)timeSinceOvershoot / 80.0f;
                    overshootFactor *= overshootFactor;
                } else {
                    this.overshootYaw = 0.0f;
                    this.overshootPitch = 0.0f;
                }
            }
            float jitterYaw = this.getJitter(now, tid, true);
            float jitterPitch = this.getJitter(now, tid, false);
            float finalYaw = this.smoothedYaw + jitterYaw + this.overshootYaw * overshootFactor;
            float finalPitch = this.smoothedPitch + jitterPitch + this.overshootPitch * overshootFactor;
            finalYaw = this.normalizeAngle(finalYaw);
            finalPitch = InternalFTSnapRotation.clamp(finalPitch, -90.0f, 90.0f);
            Rotation rotation = new Rotation(finalYaw, finalPitch);
            Experiment.getInstance().getRotationHandler().rotate(rotation, MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.OVERRIDE);
        }

        private class_243 getMultiPoint(class_1309 target, boolean attacking, long now) {
            long dtMs;
            int tid = target.method_5628();
            if (tid != this.mpLastTargetId) {
                this.mpLastTargetId = tid;
                this.mpCurrent = class_243.field_1353;
                this.mpOrbit = RotatingHitbox.rnd(0.0f, (float)Math.PI * 2);
                this.mpLastUpdate = now;
            }
            if ((dtMs = now - this.mpLastUpdate) < 1L) {
                dtMs = 1L;
            }
            if (dtMs > 60L) {
                dtMs = 60L;
            }
            this.mpLastUpdate = now;
            float orbitSpeed = 0.36f;
            float dtScale = (float)dtMs / 50.0f;
            this.mpOrbit += orbitSpeed * dtScale + RotatingHitbox.rnd(-0.018f, 0.018f) * dtScale;
            class_243 desired = this.calculateOrbitPoint(this.mpOrbit, attacking);
            float tau = 120.0f;
            float alpha = (float)dtMs / tau;
            alpha = InternalFTSnapRotation.clamp(alpha, 0.0f, 1.0f);
            alpha = alpha * alpha * (3.0f - 2.0f * alpha);
            this.mpCurrent = this.mpCurrent == class_243.field_1353 ? desired : new class_243(InternalFTSnapRotation.lerp(this.mpCurrent.field_1352, desired.field_1352, (double)alpha), InternalFTSnapRotation.lerp(this.mpCurrent.field_1351, desired.field_1351, (double)alpha), InternalFTSnapRotation.lerp(this.mpCurrent.field_1350, desired.field_1350, (double)alpha));
            class_238 box = target.method_5829();
            double fx = 0.5 + this.mpCurrent.field_1352 * 0.5;
            double fy = this.mpCurrent.field_1351;
            double fz = 0.5 + this.mpCurrent.field_1350 * 0.5;
            fx = InternalFTSnapRotation.clamp(fx, 0.0, 1.0);
            fy = InternalFTSnapRotation.clamp(fy, 0.36, 0.82);
            fz = InternalFTSnapRotation.clamp(fz, 0.0, 1.0);
            double x = box.field_1323 + (box.field_1320 - box.field_1323) * fx;
            double y = box.field_1322 + (box.field_1325 - box.field_1322) * fy;
            double z = box.field_1321 + (box.field_1324 - box.field_1321) * fz;
            return new class_243(InternalFTSnapRotation.clamp(x, box.field_1323 + 1.0E-4, box.field_1320 - 1.0E-4), InternalFTSnapRotation.clamp(y, box.field_1322 + 1.0E-4, box.field_1325 - 1.0E-4), InternalFTSnapRotation.clamp(z, box.field_1321 + 1.0E-4, box.field_1324 - 1.0E-4));
        }

        private class_243 calculateOrbitPoint(float orbit, boolean attacking) {
            float o = orbit;
            float y = 0.56f + 0.1f * (float)Math.sin(o * 0.74f + 0.9f) + 0.06f * (float)Math.sin(o * 1.28f + 2.2f) - 0.05f * (float)(0.5 + 0.5 * Math.sin(o * 0.35f + 1.7f)) + this.critHeightOffset;
            float x = 0.22f * (float)Math.sin(o) + 0.06f * (float)Math.sin(o * 1.85f + 0.25f);
            float z = 0.08f * (float)Math.cos(o * 0.92f + 0.4f) + 0.03f * (float)Math.sin(o * 1.35f + 1.1f);
            float jitter = 0.02f;
            x += RotatingHitbox.rnd(-jitter, jitter);
            z += RotatingHitbox.rnd(-jitter, jitter);
            y += RotatingHitbox.rnd(-jitter * 0.55f, jitter * 0.55f);
            x = InternalFTSnapRotation.clamp(x, -0.46f, 0.46f);
            z = InternalFTSnapRotation.clamp(z, -0.36f, 0.36f);
            y = InternalFTSnapRotation.clamp(y, 0.36f, 0.82f);
            return new class_243((double)x, (double)y, (double)z);
        }

        private float getJitter(long now, int tid, boolean isYaw) {
            float amp = isYaw ? InternalFTSnapRotation.lerp(0.06f, 0.38f, 0.5f) : InternalFTSnapRotation.lerp(0.04f, 0.22f, 0.5f);
            float freq = InternalFTSnapRotation.lerp(0.55f, 1.65f, 0.5f);
            float phase = isYaw ? this.noisePhaseYaw : this.noisePhasePitch;
            float tt = (float)((double)(now % 100000L) / 1000.0);
            float noise = this.perlin.fbm(tt * freq + phase, (float)((double)tid * 0.013 + 0.11), 4, 2.0f, 0.55f);
            float sway = this.perlin.noise(tt * 0.22f + phase * 0.07f, (float)((double)tid * 0.009 + 9.3));
            return (noise * 0.72f + sway * 0.28f) * amp;
        }

        public void reset() {
            this.noisePhaseYaw = RotatingHitbox.rnd(0.0f, 999.0f);
            this.noisePhasePitch = RotatingHitbox.rnd(0.0f, 999.0f);
            this.mpCurrent = class_243.field_1353;
            this.mpOrbit = 0.0f;
            this.mpLastUpdate = 0L;
            this.mpLastTargetId = Integer.MIN_VALUE;
            this.smoothedYaw = 0.0f;
            this.smoothedPitch = 0.0f;
            this.smoothLastTime = 0L;
            this.smoothTargetId = -1;
            this.targetLockTime = 0L;
            this.lastLockedTargetId = -1;
            this.currentSpeedMultiplier = 1.0f;
            this.savedViewValid = false;
            this.returnActive = false;
            this.overshootYaw = 0.0f;
            this.overshootPitch = 0.0f;
        }

        private float normalizeAngle(float angle) {
            if ((angle %= 360.0f) >= 180.0f) {
                angle -= 360.0f;
            }
            if (angle < -180.0f) {
                angle += 360.0f;
            }
            return angle;
        }

        private static float clamp(float value, float min, float max) {
            if (value < min) {
                return min;
            }
            if (value > max) {
                return max;
            }
            return value;
        }

        private static double clamp(double value, double min, double max) {
            if (value < min) {
                return min;
            }
            if (value > max) {
                return max;
            }
            return value;
        }

        private static float lerp(float a, float b, float t) {
            return a + (b - a) * t;
        }

        private static double lerp(double a, double b, double t) {
            return a + (b - a) * t;
        }
    }
}

