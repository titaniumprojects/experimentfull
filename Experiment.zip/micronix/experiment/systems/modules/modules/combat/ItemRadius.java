/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1802
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_2902$class_2903
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.AxisAngle4f
 *  org.joml.Quaternionf
 */
package micronix.experiment.systems.modules.modules.combat;

import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2902;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;

@ModuleInfo(name="ItemRadius", category=ModuleCategory.COMBAT, desc="modules.descriptions.itemradius")
@Environment(value=EnvType.CLIENT)
public class ItemRadius
extends BaseModule {
    private final BooleanSetting enderEye = new BooleanSetting((SettingsContainer)this, "modules.settings.itemradius.ender_eye", "modules.settings.itemradius.ender_eye.description").enable();
    private final ColorSetting enderEyeColor = new ColorSetting(this, "modules.settings.itemradius.ender_eye_color").color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f)).alpha(true);
    private final BooleanSetting sugar = new BooleanSetting((SettingsContainer)this, "modules.settings.itemradius.sugar", "modules.settings.itemradius.sugar.description").enable();
    private final ColorSetting sugarColor = new ColorSetting(this, "modules.settings.itemradius.sugar_color").color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f)).alpha(true);
    private final BooleanSetting netheriteScrap = new BooleanSetting((SettingsContainer)this, "modules.settings.itemradius.netherite_scrap", "modules.settings.itemradius.netherite_scrap.description").enable();
    private final ColorSetting netheriteScrapColor = new ColorSetting(this, "modules.settings.itemradius.netherite_scrap_color").color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f)).alpha(true);
    private final BooleanSetting driedKelp = new BooleanSetting((SettingsContainer)this, "modules.settings.itemradius.dried_kelp", "modules.settings.itemradius.dried_kelp.description").enable();
    private final ColorSetting driedKelpColor = new ColorSetting(this, "modules.settings.itemradius.dried_kelp_color").color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f)).alpha(true);
    private final BooleanSetting snowball = new BooleanSetting((SettingsContainer)this, "modules.settings.itemradius.snowball", "modules.settings.itemradius.snowball.description").enable();
    private final ColorSetting snowballColor = new ColorSetting(this, "modules.settings.itemradius.snowball_color").color(new ColorRGBA(255.0f, 255.0f, 255.0f, 255.0f)).alpha(true);
    private final BooleanSetting proximityColor = new BooleanSetting((SettingsContainer)this, "modules.settings.itemradius.proximity_color", "modules.settings.itemradius.proximity_color.description").enable();
    private final ColorSetting proximityColorSetting = new ColorSetting(this, "modules.settings.itemradius.proximity_color_setting").color(new ColorRGBA(0.0f, 255.0f, 0.0f, 255.0f)).alpha(true);
    private static final float ENDER_EYE_RADIUS = 14.0f;
    private static final float SUGAR_RADIUS = 14.0f;
    private static final float SNOWBALL_RADIUS = 12.0f;
    private static final float NETHERITE_SCRAP_RADIUS = 2.0f;
    private static final float TRAP_WIDTH = 5.0f;
    private static final float TRAP_HEIGHT = 4.0f;
    private static final float PLASTIC_WIDTH = 2.0f;
    private static final float PLASTIC_LENGTH = 5.0f;
    private static final float PLASTIC_HEIGHT = 4.0f;
    private static final float PLASTIC_FLOOR_SIZE = 5.0f;
    private static final float PLASTIC_FLOOR_HEIGHT = 2.0f;
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (ItemRadius.mc.field_1724 != null) {
            boolean hasSnowball;
            boolean hasEnderEye = ItemRadius.mc.field_1724.method_6047().method_7909() == class_1802.field_8449 || ItemRadius.mc.field_1724.method_6079().method_7909() == class_1802.field_8449;
            boolean hasSugar = ItemRadius.mc.field_1724.method_6047().method_7909() == class_1802.field_8479 || ItemRadius.mc.field_1724.method_6079().method_7909() == class_1802.field_8479;
            boolean hasNetheriteScrap = ItemRadius.mc.field_1724.method_6047().method_7909() == class_1802.field_22021 || ItemRadius.mc.field_1724.method_6079().method_7909() == class_1802.field_22021;
            boolean hasDriedKelp = ItemRadius.mc.field_1724.method_6047().method_7909() == class_1802.field_8551 || ItemRadius.mc.field_1724.method_6079().method_7909() == class_1802.field_8551;
            boolean bl = hasSnowball = ItemRadius.mc.field_1724.method_6047().method_7909() == class_1802.field_8543 || ItemRadius.mc.field_1724.method_6079().method_7909() == class_1802.field_8543;
            if (hasEnderEye || hasSugar || hasNetheriteScrap || hasDriedKelp || hasSnowball) {
                class_243 blockPos;
                int colorHex;
                ColorRGBA color;
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.disableDepthTest();
                RenderSystem.setShader((class_10156)class_10142.field_53876);
                RenderSystem.lineWidth((float)8.0f);
                class_4587 matrices = event.getMatrices();
                matrices.method_22903();
                class_243 cameraPos = ItemRadius.mc.field_1773.method_19418().method_19326();
                matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
                class_243 playerPos = ItemRadius.mc.field_1724.method_19538();
                class_243 centerPos = playerPos.method_1031(0.0, -0.1, 0.0);
                if (this.enderEye.isEnabled() && hasEnderEye) {
                    color = this.enderEyeColor.getColor();
                    colorHex = color.getRGB();
                    if (this.proximityColor.isEnabled() && this.isPlayerInRadius(centerPos, 14.0f)) {
                        colorHex = this.proximityColorSetting.getColor().getRGB();
                    }
                    this.drawCircle(matrices, centerPos, 14.0f, colorHex);
                }
                if (this.sugar.isEnabled() && hasSugar) {
                    color = this.sugarColor.getColor();
                    colorHex = color.getRGB();
                    if (this.proximityColor.isEnabled() && this.isPlayerInRadius(centerPos, 14.0f)) {
                        colorHex = this.proximityColorSetting.getColor().getRGB();
                    }
                    this.drawCircle(matrices, centerPos, 14.0f, colorHex);
                }
                if (this.netheriteScrap.isEnabled() && hasNetheriteScrap) {
                    color = this.netheriteScrapColor.getColor();
                    colorHex = color.getRGB();
                    blockPos = this.getBlockAlignedPlayerPos();
                    class_243 trapPos = blockPos.method_1031(0.0, 1.5, 0.0);
                    if (this.proximityColor.isEnabled() && this.isPlayerInRadius(trapPos, 2.5f)) {
                        colorHex = this.proximityColorSetting.getColor().getRGB();
                    }
                    this.drawTrapCubeWithFill(matrices, trapPos, colorHex);
                }
                if (this.driedKelp.isEnabled() && hasDriedKelp) {
                    color = this.driedKelpColor.getColor();
                    colorHex = color.getRGB();
                    blockPos = this.getBlockAlignedPlayerPos();
                    class_243 plasticPos = blockPos.method_1031(0.0, 1.5, 0.0);
                    if (this.proximityColor.isEnabled() && this.isPlayerInRadius(plasticPos, Math.max(2.0f, 5.0f) / 2.0f)) {
                        colorHex = this.proximityColorSetting.getColor().getRGB();
                    }
                    this.drawPlastic(matrices, plasticPos, colorHex);
                }
                if (this.snowball.isEnabled() && hasSnowball) {
                    color = this.snowballColor.getColor();
                    colorHex = color.getRGB();
                    class_243 landingPos = this.getSnowballLandingPosition();
                    if (this.proximityColor.isEnabled() && this.isPlayerInRadius(landingPos, 12.0f)) {
                        colorHex = this.proximityColorSetting.getColor().getRGB();
                    }
                    this.drawCircle(matrices, landingPos, 12.0f, colorHex);
                }
                matrices.method_22909();
                RenderSystem.enableDepthTest();
                RenderSystem.disableBlend();
            }
        }
    };

    private boolean isPlayerInRadius(class_243 center, float radius) {
        return ItemRadius.mc.field_1724 != null && ItemRadius.mc.field_1687 != null ? ItemRadius.mc.field_1687.method_18456().stream().anyMatch(player -> {
            if (player == ItemRadius.mc.field_1724) {
                return false;
            }
            class_243 playerPos = player.method_19538();
            double distance = Math.sqrt(Math.pow(playerPos.field_1352 - center.field_1352, 2.0) + Math.pow(playerPos.field_1351 - center.field_1351, 2.0) + Math.pow(playerPos.field_1350 - center.field_1350, 2.0));
            return distance <= (double)radius;
        }) : false;
    }

    private void drawCircle(class_4587 matrices, class_243 center, float radius, int color) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        double y = center.field_1351;
        int segments = 64;
        for (int i = 0; i < segments; ++i) {
            double angle1 = Math.PI * 2 * (double)i / (double)segments;
            double angle2 = Math.PI * 2 * (double)(i + 1) / (double)segments;
            double x1 = center.field_1352 + (double)radius * Math.cos(angle1);
            double z1 = center.field_1350 + (double)radius * Math.sin(angle1);
            double x2 = center.field_1352 + (double)radius * Math.cos(angle2);
            double z2 = center.field_1350 + (double)radius * Math.sin(angle2);
            buffer.method_22918(matrices.method_23760().method_23761(), (float)x1, (float)y, (float)z1).method_39415(color);
            buffer.method_22918(matrices.method_23760().method_23761(), (float)x2, (float)y, (float)z2).method_39415(color);
        }
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    private class_243 getSnowballLandingPosition() {
        if (ItemRadius.mc.field_1724 == null) {
            return class_243.field_1353;
        }
        class_243 eyePos = ItemRadius.mc.field_1724.method_33571();
        class_243 lookVec = ItemRadius.mc.field_1724.method_5828(1.0f);
        float pitch = ItemRadius.mc.field_1724.method_5695(1.0f);
        double pitchRadians = Math.toRadians(pitch);
        double baseDistance = 20.0;
        double verticalMultiplier = 1.0 + Math.abs(Math.sin(pitchRadians)) * 1.0;
        double distance = baseDistance * verticalMultiplier;
        distance = Math.max(10.0, Math.min(50.0, distance));
        class_243 landingPos = eyePos.method_1019(lookVec.method_1021(distance));
        double groundY = ItemRadius.mc.field_1724.method_23318();
        if (ItemRadius.mc.field_1687 != null) {
            groundY = ItemRadius.mc.field_1687.method_8624(class_2902.class_2903.field_13197, (int)landingPos.field_1352, (int)landingPos.field_1350);
        }
        return new class_243(landingPos.field_1352, groundY, landingPos.field_1350);
    }

    private class_243 getBlockAlignedPlayerPos() {
        if (ItemRadius.mc.field_1724 == null) {
            return class_243.field_1353;
        }
        double blockX = Math.floor(ItemRadius.mc.field_1724.method_23317()) + 0.5;
        double blockY = Math.floor(ItemRadius.mc.field_1724.method_23318()) + 0.5;
        double blockZ = Math.floor(ItemRadius.mc.field_1724.method_23321()) + 0.5;
        return new class_243(blockX, blockY, blockZ);
    }

    private class_243 getInterpolatedPlayerPos(float partialTicks) {
        if (ItemRadius.mc.field_1724 == null) {
            return class_243.field_1353;
        }
        double currentX = ItemRadius.mc.field_1724.method_23317();
        double currentY = ItemRadius.mc.field_1724.method_23318();
        double currentZ = ItemRadius.mc.field_1724.method_23321();
        double prevX = ItemRadius.mc.field_1724.field_6014;
        double prevY = ItemRadius.mc.field_1724.field_6036;
        double prevZ = ItemRadius.mc.field_1724.field_5969;
        double interpolatedX = prevX + (currentX - prevX) * (double)partialTicks;
        double interpolatedY = prevY + (currentY - prevY) * (double)partialTicks;
        double interpolatedZ = prevZ + (currentZ - prevZ) * (double)partialTicks;
        return new class_243(interpolatedX, interpolatedY, interpolatedZ);
    }

    private void drawTrapCubeWithFill(class_4587 matrices, class_243 center, int color) {
        class_289 tessellator = class_289.method_1348();
        float halfWidth = 2.5f;
        float halfHeight = 2.0f;
        float[][] vertices = new float[][]{{-halfWidth, -halfHeight, -halfWidth}, {halfWidth, -halfHeight, -halfWidth}, {halfWidth, halfHeight, -halfWidth}, {-halfWidth, halfHeight, -halfWidth}, {-halfWidth, -halfHeight, halfWidth}, {halfWidth, -halfHeight, halfWidth}, {halfWidth, halfHeight, halfWidth}, {-halfWidth, halfHeight, halfWidth}};
        int[][] faces = new int[][]{{0, 1, 2, 3}, {4, 7, 6, 5}, {0, 4, 5, 1}, {2, 6, 7, 3}, {0, 3, 7, 4}, {1, 5, 6, 2}};
        int fillColor = color & 0xFFFFFF | 0x55000000;
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        for (int[] face : faces) {
            for (int i = 0; i < face.length - 2; ++i) {
                int v0 = face[0];
                int v1 = face[i + 1];
                int v2 = face[i + 2];
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v0][0]), (float)(center.field_1351 + (double)vertices[v0][1]), (float)(center.field_1350 + (double)vertices[v0][2])).method_39415(fillColor);
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v1][0]), (float)(center.field_1351 + (double)vertices[v1][1]), (float)(center.field_1350 + (double)vertices[v1][2])).method_39415(fillColor);
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v2][0]), (float)(center.field_1351 + (double)vertices[v2][1]), (float)(center.field_1350 + (double)vertices[v2][2])).method_39415(fillColor);
            }
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        int[][] edges = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        buffer = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (int[] edge : edges) {
            int v1 = edge[0];
            int v2 = edge[1];
            buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v1][0]), (float)(center.field_1351 + (double)vertices[v1][1]), (float)(center.field_1350 + (double)vertices[v1][2])).method_39415(color);
            buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v2][0]), (float)(center.field_1351 + (double)vertices[v2][1]), (float)(center.field_1350 + (double)vertices[v2][2])).method_39415(color);
        }
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    private void drawPlastic(class_4587 matrices, class_243 center, int color) {
        boolean isLookingUp;
        float pitch = ItemRadius.mc.field_1724.method_5695(1.0f);
        boolean bl = isLookingUp = pitch < -45.0f;
        if (isLookingUp) {
            class_243 headPos = ItemRadius.mc.field_1724.method_33571();
            class_243 floorPos = headPos.method_1031(0.0, 0.0, 3.0);
            this.drawPlasticFloor(matrices, floorPos, color);
        } else {
            class_243 panelPos = this.getPanelPositionFromCenter(center, 4.0);
            this.drawPlasticPanel(matrices, panelPos, color);
        }
    }

    private class_243 getPanelPositionFromCenter(class_243 center, double distance) {
        float yaw = ItemRadius.mc.field_1724.method_5705(1.0f);
        double lookX = -Math.sin(Math.toRadians(yaw));
        double lookZ = Math.cos(Math.toRadians(yaw));
        double panelX = Math.floor(center.field_1352 + lookX * distance) + 0.5;
        double panelZ = Math.floor(center.field_1350 + lookZ * distance) + 0.5;
        double panelY = Math.floor(center.field_1351) + 0.5;
        return new class_243(panelX, panelY, panelZ);
    }

    private void drawPlasticPanel(class_4587 matrices, class_243 center, int color) {
        class_289 tessellator = class_289.method_1348();
        float halfWidth = 1.0f;
        float halfLength = 2.5f;
        float halfHeight = 2.0f;
        RenderSystem.enableDepthTest();
        float[][] vertices = new float[][]{{-halfWidth, -halfHeight, -halfLength}, {halfWidth, -halfHeight, -halfLength}, {halfWidth, halfHeight, -halfLength}, {-halfWidth, halfHeight, -halfLength}, {-halfWidth, -halfHeight, halfLength}, {halfWidth, -halfHeight, halfLength}, {halfWidth, halfHeight, halfLength}, {-halfWidth, halfHeight, halfLength}};
        float yaw = ItemRadius.mc.field_1724.method_5705(1.0f);
        matrices.method_22903();
        matrices.method_22904(center.field_1352, center.field_1351, center.field_1350);
        matrices.method_22907(new Quaternionf(new AxisAngle4f((float)Math.toRadians(-yaw + 90.0f), 0.0f, 1.0f, 0.0f)));
        matrices.method_22904(-center.field_1352, -center.field_1351, -center.field_1350);
        int[][] faces = new int[][]{{0, 1, 2, 3}, {4, 7, 6, 5}, {0, 4, 5, 1}, {2, 6, 7, 3}, {0, 3, 7, 4}, {1, 5, 6, 2}};
        int fillColor = color & 0xFFFFFF | 0x55000000;
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        for (int[] face : faces) {
            for (int i = 0; i < face.length - 2; ++i) {
                int v0 = face[0];
                int v1 = face[i + 1];
                int v2 = face[i + 2];
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v0][0]), (float)(center.field_1351 + (double)vertices[v0][1]), (float)(center.field_1350 + (double)vertices[v0][2])).method_39415(fillColor);
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v1][0]), (float)(center.field_1351 + (double)vertices[v1][1]), (float)(center.field_1350 + (double)vertices[v1][2])).method_39415(fillColor);
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v2][0]), (float)(center.field_1351 + (double)vertices[v2][1]), (float)(center.field_1350 + (double)vertices[v2][2])).method_39415(fillColor);
            }
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        int[][] edges = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        buffer = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (int[] edge : edges) {
            int v1 = edge[0];
            int v2 = edge[1];
            buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v1][0]), (float)(center.field_1351 + (double)vertices[v1][1]), (float)(center.field_1350 + (double)vertices[v1][2])).method_39415(color);
            buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v2][0]), (float)(center.field_1351 + (double)vertices[v2][1]), (float)(center.field_1350 + (double)vertices[v2][2])).method_39415(color);
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        matrices.method_22909();
    }

    private void drawPlasticFloor(class_4587 matrices, class_243 center, int color) {
        class_289 tessellator = class_289.method_1348();
        RenderSystem.disableDepthTest();
        float halfSize = 2.5f;
        float halfHeight = 1.0f;
        float[][] vertices = new float[][]{{-halfSize, -halfHeight, -halfSize}, {halfSize, -halfHeight, -halfSize}, {halfSize, halfHeight, -halfSize}, {-halfSize, halfHeight, -halfSize}, {-halfSize, -halfHeight, halfSize}, {halfSize, -halfHeight, halfSize}, {halfSize, halfHeight, halfSize}, {-halfSize, halfHeight, halfSize}};
        int[][] faces = new int[][]{{0, 1, 2, 3}, {4, 7, 6, 5}, {0, 4, 5, 1}, {2, 6, 7, 3}, {0, 3, 7, 4}, {1, 5, 6, 2}};
        int fillColor = color & 0xFFFFFF | 0x55000000;
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        for (int[] face : faces) {
            for (int i = 0; i < face.length - 2; ++i) {
                int v0 = face[0];
                int v1 = face[i + 1];
                int v2 = face[i + 2];
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v0][0]), (float)(center.field_1351 + (double)vertices[v0][1]), (float)(center.field_1350 + (double)vertices[v0][2])).method_39415(fillColor);
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v1][0]), (float)(center.field_1351 + (double)vertices[v1][1]), (float)(center.field_1350 + (double)vertices[v1][2])).method_39415(fillColor);
                buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v2][0]), (float)(center.field_1351 + (double)vertices[v2][1]), (float)(center.field_1350 + (double)vertices[v2][2])).method_39415(fillColor);
            }
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        int[][] edges = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        buffer = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (int[] edge : edges) {
            int v1 = edge[0];
            int v2 = edge[1];
            buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v1][0]), (float)(center.field_1351 + (double)vertices[v1][1]), (float)(center.field_1350 + (double)vertices[v1][2])).method_39415(color);
            buffer.method_22918(matrices.method_23760().method_23761(), (float)(center.field_1352 + (double)vertices[v2][0]), (float)(center.field_1351 + (double)vertices[v2][1]), (float)(center.field_1350 + (double)vertices[v2][2])).method_39415(color);
        }
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    public BooleanSetting getEnderEye() {
        return this.enderEye;
    }

    public ColorSetting getEnderEyeColor() {
        return this.enderEyeColor;
    }

    public BooleanSetting getSugar() {
        return this.sugar;
    }

    public ColorSetting getSugarColor() {
        return this.sugarColor;
    }

    public BooleanSetting getNetheriteScrap() {
        return this.netheriteScrap;
    }

    public ColorSetting getNetheriteScrapColor() {
        return this.netheriteScrapColor;
    }

    public BooleanSetting getDriedKelp() {
        return this.driedKelp;
    }

    public ColorSetting getDriedKelpColor() {
        return this.driedKelpColor;
    }

    public BooleanSetting getSnowball() {
        return this.snowball;
    }

    public ColorSetting getSnowballColor() {
        return this.snowballColor;
    }

    public BooleanSetting getProximityColor() {
        return this.proximityColor;
    }

    public ColorSetting getProximityColorSetting() {
        return this.proximityColorSetting;
    }

    public EventListener<Render3DEvent> getOnRender3D() {
        return this.onRender3D;
    }
}

