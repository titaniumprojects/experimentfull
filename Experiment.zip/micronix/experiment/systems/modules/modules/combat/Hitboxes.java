/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_746
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.target.TargetSettings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_746;

@ModuleInfo(name="Hitboxes", category=ModuleCategory.COMBAT, desc="modules.descriptions.hitboxes")
@Environment(value=EnvType.CLIENT)
public class Hitboxes
extends BaseModule {
    private final SliderSetting scale = new SliderSetting(this, "size").min(0.0f).max(1.0f).step(0.1f).currentValue(0.3f);
    private final SelectSetting targets = new SelectSetting(this, "targets");
    private final SelectSetting.Value players = new SelectSetting.Value(this.targets, "players").select();
    private final SelectSetting.Value animals = new SelectSetting.Value(this.targets, "animals").select();
    private final SelectSetting.Value mobs = new SelectSetting.Value(this.targets, "mobs").select();
    private final SelectSetting.Value invisibles = new SelectSetting.Value(this.targets, "invisibles").select();
    private final SelectSetting.Value nakedPlayers = new SelectSetting.Value(this.targets, "nakedPlayers").select();
    private final SelectSetting.Value friends = new SelectSetting.Value(this.targets, "friends");

    public boolean shouldModifyHitbox(class_1309 entity) {
        TargetSettings settings = new TargetSettings.Builder().targetPlayers(this.players.isSelected()).targetAnimals(this.animals.isSelected()).targetMobs(this.mobs.isSelected()).targetInvisibles(this.invisibles.isSelected()).targetNakedPlayers(this.nakedPlayers.isSelected()).targetFriends(this.friends.isSelected()).build();
        if (entity instanceof class_746) {
            return false;
        }
        if (entity.method_29504()) {
            return false;
        }
        if (Experiment.getInstance().isPanic()) {
            return false;
        }
        return settings.isEntityValid((class_1297)entity);
    }

    public SliderSetting getScale() {
        return this.scale;
    }
}

