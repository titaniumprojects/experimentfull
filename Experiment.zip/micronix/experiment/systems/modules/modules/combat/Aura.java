/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1839
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2868
 *  net.minecraft.class_2886
 *  net.minecraft.class_3532
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.Criticals;
import micronix.experiment.systems.modules.modules.combat.ElytraTarget;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.target.TargetComparators;
import micronix.experiment.systems.target.TargetSettings;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.game.CombatUtility;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.game.prediction.ElytraPredictionSystem;
import micronix.experiment.utility.game.prediction.FallingPlayer;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.math.PerlinNoise;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import ru.kotopushka.compiler.sdk.annotations.VMProtect;
import ru.kotopushka.compiler.sdk.enums.VMProtectType;

@ModuleInfo(name="Aura", category=ModuleCategory.COMBAT, desc="\u0423\u0431\u0438\u0432\u0430\u0435\u0442 \u0441\u0443\u0449\u043d\u043e\u0441\u0442\u0435\u0439 \u0437\u0430 \u0432\u0430\u0441")
@Environment(value=EnvType.CLIENT)
public class Aura
extends BaseModule {
    private SliderSetting attackDistance;
    private SliderSetting aimDistance;
    private SelectSetting targets;
    private SelectSetting.Value players;
    private SelectSetting.Value animals;
    private SelectSetting.Value mobs;
    private SelectSetting.Value invisibles;
    private SelectSetting.Value nakedPlayers;
    private SelectSetting.Value friends;
    private ModeSetting sortingMode;
    private ModeSetting.Value distanceSorting;
    private ModeSetting.Value healthSorting;
    private ModeSetting.Value fovSorting;
    private ModeSetting rotationMode;
    private ModeSetting.Value noRotation;
    private ModeSetting.Value simpleRotation;
    private ModeSetting.Value funTimeRotation;
    private ModeSetting.Value spookyTimeRotation;
    private ModeSetting.Value holyWorldRotation;
    private ModeSetting.Value intaveRotation;
    private ModeSetting.Value cakeWorldRotation;
    private ModeSetting.Value hvhRotation;
    private ModeSetting.Value universalRotation;
    private ModeSetting moveCorrectionMode;
    private ModeSetting.Value noMoveCorrection;
    private ModeSetting.Value directMoveCorrection;
    private ModeSetting.Value silentMoveCorrection;
    private ModeSetting styleAttack;
    private ModeSetting.Value fastPvp;
    private ModeSetting.Value slowPvp;
    private BooleanSetting onlyCriticals;
    private BooleanSetting walls;
    private BooleanSetting rayTrace;
    private BooleanSetting onlyWeapon;
    private BooleanSetting targeting;
    private final Animation nononoYaw = new Animation(300L, Easing.LINEAR);
    private final Animation nononoPitch = new Animation(1000L, Easing.LINEAR);
    private Timer attackTimer;
    boolean shield;
    private PerlinNoise noise = new PerlinNoise();
    private long rotationStartTime = 0L;
    private float noiseFactor = 0.0f;
    private int attacks;
    private Rotation additional;
    private final Timer collideTimer = new Timer();
    private Rotation currentRotation;
    private Rotation previousRotation;
    private Rotation targetRotation;
    private long rotationUpdateTime = 0L;
    private float rotationProgress = 0.0f;
    private final EventListener<ClientPlayerTickEvent> onPlayerTick = event -> {
        if (Aura.mc.field_1724 != null) {
            class_1309 living;
            class_1309 target;
            float requiredAimDistance = Experiment.getInstance().getModuleManager().getModule(ElytraTarget.class).isEnabled() ? 50.0f : this.aimDistance.getCurrentValue();
            TargetSettings.Builder builder = new TargetSettings.Builder().targetPlayers(this.players.isSelected()).targetAnimals(this.animals.isSelected()).targetMobs(this.mobs.isSelected()).targetInvisibles(this.invisibles.isSelected()).targetNakedPlayers(this.nakedPlayers.isSelected()).targetFriends(this.friends.isSelected()).requiredRange(requiredAimDistance);
            if (this.sortingMode.is(this.distanceSorting)) {
                builder.sortBy(TargetComparators.DISTANCE);
            } else if (this.sortingMode.is(this.healthSorting)) {
                builder.sortBy(TargetComparators.HEALTH);
            } else if (this.sortingMode.is(this.fovSorting)) {
                builder.sortBy(TargetComparators.FOV);
            }
            TargetSettings settings = builder.build();
            class_1297 patt0$temp = Experiment.getInstance().getTargetManager().getCurrentTarget();
            class_1309 class_13092 = target = patt0$temp instanceof class_1309 ? (living = (class_1309)patt0$temp) : null;
            if (!this.targeting.isEnabled() || target == null || class_3532.method_15355((float)((float)Aura.mc.field_1724.method_5707(RotationMath.getNearestPoint(target)))) > requiredAimDistance || !Aura.mc.field_1687.method_62145((class_1297)target) || !target.method_5805()) {
                Experiment.getInstance().getTargetManager().update(settings);
            }
            if (target != null) {
                this.rotateHead(target);
                if (this.shouldAttackEntity(target)) {
                    this.attack(target);
                }
            } else {
                this.rotationStartTime = System.currentTimeMillis();
                this.noise = new PerlinNoise();
                this.noiseFactor = 1.0f;
            }
        }
    };

    public Aura() {
        this.initialize();
    }

    @VMProtect(type=VMProtectType.VIRTUALIZATION)
    private void initialize() {
        this.rotationMode = new ModeSetting(this, "modules.settings.aura.rotationMode");
        this.noRotation = new ModeSetting.Value(this.rotationMode, "modules.settings.aura.noRotation");
        this.simpleRotation = new ModeSetting.Value(this.rotationMode, "modules.settings.aura.simpleRotation").select();
        this.funTimeRotation = new ModeSetting.Value(this.rotationMode, "FunTime");
        this.spookyTimeRotation = new ModeSetting.Value(this.rotationMode, "SpookyTime");
        this.holyWorldRotation = new ModeSetting.Value(this.rotationMode, "HolyWorld");
        this.intaveRotation = new ModeSetting.Value(this.rotationMode, "Intave");
        this.cakeWorldRotation = new ModeSetting.Value(this.rotationMode, "CakeWorld");
        this.hvhRotation = new ModeSetting.Value(this.rotationMode, "HvH");
        this.universalRotation = new ModeSetting.Value(this.rotationMode, "Universal");
        this.attackDistance = new SliderSetting(this, "modules.settings.aura.attackDistance").min(0.1f).max(6.0f).step(0.1f).currentValue(3.0f).suffix(number -> " %s".formatted(Localizator.translate("block")) + TextUtility.makeCountTranslated(number));
        this.aimDistance = new SliderSetting(this, "modules.settings.aura.aimDistance").min(0.1f).max(6.0f).step(0.1f).currentValue(3.0f).suffix(number -> " %s".formatted(Localizator.translate("block")) + TextUtility.makeCountTranslated(number));
        this.onlyCriticals = new BooleanSetting(this, "only_crits");
        this.walls = new BooleanSetting(this, "modules.settings.aura.walls").enable();
        this.rayTrace = new BooleanSetting(this, "modules.settings.aura.rayTrace").enable();
        this.targeting = new BooleanSetting(this, "modules.settings.aura.targeting").enable();
        this.onlyWeapon = new BooleanSetting(this, "modules.settings.aura.onlyWeapon");
        this.targets = new SelectSetting(this, "targets");
        this.players = new SelectSetting.Value(this.targets, "players").select();
        this.animals = new SelectSetting.Value(this.targets, "animals").select();
        this.mobs = new SelectSetting.Value(this.targets, "mobs").select();
        this.invisibles = new SelectSetting.Value(this.targets, "invisibles").select();
        this.nakedPlayers = new SelectSetting.Value(this.targets, "nakedPlayers").select();
        this.friends = new SelectSetting.Value(this.targets, "friends");
        this.sortingMode = new ModeSetting(this, "sorting");
        this.distanceSorting = new ModeSetting.Value(this.sortingMode, "modules.settings.aura.distanceSorting").select();
        this.healthSorting = new ModeSetting.Value(this.sortingMode, "modules.settings.aura.healthSorting");
        this.fovSorting = new ModeSetting.Value(this.sortingMode, "modules.settings.aura.fovSorting");
        this.moveCorrectionMode = new ModeSetting(this, "modules.settings.aura.moveCorrectionMode");
        this.noMoveCorrection = new ModeSetting.Value(this.moveCorrectionMode, "modules.settings.aura.noMoveCorrection");
        this.directMoveCorrection = new ModeSetting.Value(this.moveCorrectionMode, "modules.settings.aura.directMoveCorrection");
        this.silentMoveCorrection = new ModeSetting.Value(this.moveCorrectionMode, "modules.settings.aura.silentMoveCorrection").select();
        this.styleAttack = new ModeSetting(this, "modules.settings.aura.styleAttack");
        this.fastPvp = new ModeSetting.Value(this.styleAttack, "1.8");
        this.slowPvp = new ModeSetting.Value(this.styleAttack, "1.9").select();
        this.attackTimer = new Timer();
    }

    private boolean shouldAttackEntity(class_1309 targetedEntity) {
        if (!this.isCooledDown()) {
            return false;
        }
        if (this.onlyWeapon.isEnabled() && !EntityUtility.isHoldingWeapon()) {
            return false;
        }
        if (Aura.mc.field_1724.method_6115() && Aura.mc.field_1724.method_6058() == class_1268.field_5808) {
            return false;
        }
        if (this.inRange(targetedEntity)) {
            return false;
        }
        if (this.walls.isEnabled() && this.spookyTimeRotation.isSelected() && Aura.mc.field_1687.method_17742(new class_3959(Aura.mc.field_1724.method_33571(), Aura.mc.field_1724.method_33571().method_1019(Aura.mc.field_1724.method_5631(-90.0f, Experiment.getInstance().getRotationHandler().getCurrentRotation().getYaw()).method_1021((double)this.attackDistance.getCurrentValue())), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)Aura.mc.field_1724)).method_17783() == class_239.class_240.field_1332) {
            return false;
        }
        if (this.rotationMode.is(this.hvhRotation) || this.rotationMode.is(this.universalRotation)) {
            return !this.onlyCriticals.isEnabled() || !this.isCriticalRequired(targetedEntity) || CombatUtility.canPerformCriticalHit(targetedEntity, true);
        }
        return !MathUtility.canTraceWithBlock(this.attackDistance.getCurrentValue(), Experiment.getInstance().getRotationHandler().getCurrentRotation().getYaw(), Experiment.getInstance().getRotationHandler().getCurrentRotation().getPitch(), (class_1297)Aura.mc.field_1724, (class_1297)targetedEntity, !this.walls.isEnabled()) && this.rayTrace.isEnabled() ? false : !this.onlyCriticals.isEnabled() || !this.isCriticalRequired(targetedEntity) || CombatUtility.canPerformCriticalHit(targetedEntity, true);
    }

    private boolean isCriticalRequired(class_1309 targetedEntity) {
        float damage = this.calculateDamage(targetedEntity);
        return damage <= targetedEntity.method_6032();
    }

    public boolean isCooledDown() {
        if (Aura.mc.field_1724 == null) {
            return false;
        }
        return CombatUtility.getMace() != null ? this.attackTimer.finished(500L) : Aura.mc.field_1724.method_7261(1.5f) > 0.93f && this.attackTimer.finished(500L) || this.fastPvp.isSelected() && this.attackTimer.finished(50L);
    }

    public float calculateDamage(class_1309 targetedEntity) {
        return 0.0f;
    }

    private void attack(class_1309 targetedEntity) {
        if (Aura.mc.field_1761 != null && Aura.mc.field_1724 != null) {
            HotbarSlot slot;
            boolean bl = this.shield = Aura.mc.field_1724.method_6115() && Aura.mc.field_1724.method_6030().method_7909().method_7853(Aura.mc.field_1724.method_6030()) == class_1839.field_8949;
            if (this.shield) {
                Aura.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
            }
            if (CombatUtility.shouldBreakShield(targetedEntity) && CombatUtility.canBreakShield(targetedEntity)) {
                CombatUtility.tryBreakShield(targetedEntity);
            }
            if ((slot = CombatUtility.getMace()) != null) {
                Aura.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
                CombatUtility.tryBreakShield(targetedEntity);
            }
            Aura.mc.field_1761.method_2918((class_1657)Aura.mc.field_1724, (class_1297)targetedEntity);
            Aura.mc.field_1724.method_6104(class_1268.field_5808);
            if (slot != null) {
                Aura.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(Aura.mc.field_1724.method_31548().field_7545));
            }
            if (this.shield) {
                Aura.mc.field_1761.method_41931(Aura.mc.field_1687, sequence -> new class_2886(Aura.mc.field_1724.method_6058(), sequence, Experiment.getInstance().getRotationHandler().getCurrentRotation().getYaw(), Experiment.getInstance().getRotationHandler().getCurrentRotation().getPitch()));
            }
            this.additional = new Rotation(MathUtility.random(5.0, 20.0), MathUtility.random(5.0, 10.0));
            this.attackTimer.reset();
            ++this.attacks;
        }
    }

    private void rotateHead(class_1309 targetedEntity) {
        if (!(this.onlyWeapon.isEnabled() && !EntityUtility.isHoldingWeapon() || this.rotationMode.is(this.noRotation))) {
            class_243 nearestPoint;
            class_238 box;
            MoveCorrection moveCorrection = this.moveCorrectionMode.is(this.silentMoveCorrection) ? MoveCorrection.SILENT : (this.moveCorrectionMode.is(this.directMoveCorrection) ? MoveCorrection.DIRECT : MoveCorrection.NONE);
            RotationHandler handler = Experiment.getInstance().getRotationHandler();
            Rotation calculatedRotation = null;
            if (this.rotationMode.is(this.simpleRotation)) {
                class_243 class_2432;
                if (Experiment.getInstance().getModuleManager().getModule(ElytraTarget.class).isEnabled() && targetedEntity instanceof class_1657) {
                    class_1657 player = (class_1657)targetedEntity;
                    class_2432 = ElytraPredictionSystem.predictPlayerPosition(player);
                } else {
                    class_2432 = targetedEntity.method_19538();
                }
                Rotation rot = RotationMath.getRotationTo(RotationMath.getNearestPoint(targetedEntity, class_2432));
                if (Aura.mc.field_1724.method_33571().method_1022(targetedEntity.method_33571()) > 3.0) {
                    class_243 class_2433;
                    if (Experiment.getInstance().getModuleManager().getModule(ElytraTarget.class).isEnabled() && targetedEntity instanceof class_1657) {
                        class_1657 playerx = (class_1657)targetedEntity;
                        class_2433 = ElytraPredictionSystem.predictPlayerPosition(playerx);
                    } else {
                        class_2433 = targetedEntity.method_19538();
                    }
                    rot.setYaw(RotationMath.getRotationTo(class_2433.method_1031(0.0, (double)targetedEntity.method_18381(targetedEntity.method_18376()), 0.0)).getYaw());
                }
                calculatedRotation = rot;
                handler.rotate(rot, moveCorrection, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
            if (this.rotationMode.is(this.holyWorldRotation)) {
                Rotation current = Experiment.getInstance().getRotationHandler().getCurrentRotation();
                box = targetedEntity.method_5829();
                double offsetX = (double)this.getSensitivity((float)Math.cos((double)System.currentTimeMillis() / 1000.0)) * 0.15;
                double offsetY = (double)this.getSensitivity((float)Math.cos((double)System.currentTimeMillis() / 10000.0)) * 0.15;
                double offsetZ = (double)this.getSensitivity((float)Math.cos((double)System.currentTimeMillis() / 1000.0)) * 0.15;
                class_243 nearY = RotationMath.getNearestPoint(targetedEntity);
                class_243 targetPos = new class_243(nearY.field_1352, class_3532.method_15350((double)MathUtility.interpolate(Aura.mc.field_1724.method_23318(), targetedEntity.method_23320(), 0.5), (double)targetedEntity.method_5829().field_1322, (double)targetedEntity.method_5829().field_1325), nearY.field_1350);
                double clampedX = class_3532.method_15350((double)(targetPos.method_10216() + offsetX), (double)box.field_1323, (double)box.field_1320);
                double clampedY = targetPos.method_10214() + (double)(targetedEntity.method_17682() / 2.0f) + offsetY;
                double clampedZ = class_3532.method_15350((double)(targetPos.method_10215() + offsetZ), (double)box.field_1321, (double)box.field_1324);
                class_243 vec = new class_243(clampedX, clampedY, clampedZ).method_1020(Aura.mc.field_1724.method_33571());
                float yawToTarget = (float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(vec.field_1350, vec.field_1352)) - 90.0));
                float yawDelta = class_3532.method_15393((float)(yawToTarget - current.getYaw()));
                float yaw = current.getYaw() + yawDelta;
                float pitch = Math.clamp(current.getPitch(), -90.0f, 90.0f);
                if (!MathUtility.canTraceWithBlock(this.attackDistance.getCurrentValue(), yaw, pitch, (class_1297)Aura.mc.field_1724, (class_1297)targetedEntity, !this.walls.isEnabled()) && this.rayTrace.isEnabled()) {
                    pitch = RotationMath.getRotationTo(targetPos).getPitch();
                }
                handler.rotate(new Rotation(yaw, pitch), moveCorrection, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
            if (this.rotationMode.is(this.funTimeRotation) || this.rotationMode.is(this.intaveRotation)) {
                if (Aura.mc.field_1724.field_6012 % 500 == 0) {
                    this.noise = new PerlinNoise();
                    this.noiseFactor = 1.0f;
                }
                class_243 nearY = RotationMath.getNearestPoint(targetedEntity);
                Rotation targetRot = RotationMath.getRotationTo(new class_243(nearY.field_1352, class_3532.method_15350((double)MathUtility.interpolate(Aura.mc.field_1724.method_23318(), targetedEntity.method_23320(), 0.5), (double)targetedEntity.method_5829().field_1322, (double)targetedEntity.method_5829().field_1325), nearY.field_1350));
                Rotation multipoint = RotationMath.getRotationTo(RotationMath.getNearestPoint(targetedEntity));
                boolean idle = this.attackTimer.finished(300L);
                if (this.additional == null) {
                    this.additional = new Rotation(0.0f, 0.0f);
                }
                float targetYaw = targetRot.getYaw();
                float targetPitch = targetRot.getPitch();
                Rotation currentRot = handler.getCurrentRotation();
                float currentYaw = currentRot.getYaw();
                float currentPitch = currentRot.getPitch();
                float yawDiff = RotationMath.getAngleDifference(currentYaw, targetYaw);
                float pitchDiff = RotationMath.getAngleDifference(currentPitch, targetPitch);
                if (idle) {
                    if (this.shouldPreventSprinting()) {
                        targetYaw += 5.0f;
                        targetPitch -= 10.0f;
                    } else {
                        targetYaw -= 5.0f;
                    }
                }
                if (!this.rotationMode.is(this.intaveRotation) && !idle) {
                    targetYaw += this.additional.getYaw();
                    targetPitch += this.additional.getPitch();
                }
                float yawSpeed = Math.max((90.0f - Math.abs(yawDiff)) / (idle ? (Aura.mc.field_1724.field_6017 > 0.0f ? 20.0f : 60.0f) : 40.0f), MathUtility.random(1.0, 5.0)) * MathUtility.random(0.9, 1.1);
                float pitchSpeed = Math.abs(pitchDiff) / (idle ? (Aura.mc.field_1724.field_6017 > 0.0f ? 60.0f : 100.0f) : 30.0f) * MathUtility.random(0.9, 1.1);
                long timeElapsed = System.currentTimeMillis() - this.rotationStartTime;
                float yawNoise = (float)this.noise.noise((double)timeElapsed * 5.0E-4);
                float pitchNoise = (float)this.noise.noise((double)timeElapsed * 5.0E-4, 10.0);
                float yawOffset = yawNoise * 25.0f * this.noiseFactor;
                float pitchOffset = pitchNoise * 25.0f * this.noiseFactor;
                float finalTargetYaw = targetYaw + yawOffset;
                float finalTargetPitch = targetPitch + pitchOffset;
                float totalDiff = Math.abs(yawDiff) + Math.abs(pitchDiff);
                if (totalDiff < 10.0f) {
                    this.noiseFactor = Math.max(0.0f, this.noiseFactor - 0.05f);
                }
                handler.rotate(new Rotation(targetYaw, Math.clamp(targetPitch, -90.0f, 90.0f)), moveCorrection, yawSpeed * 25.0f, pitchSpeed * 25.0f, MathUtility.random(5.0, 50.0), RotationPriority.TO_TARGET);
            }
            if (this.rotationMode.is(this.spookyTimeRotation)) {
                if (Aura.mc.field_1724.field_6012 % 500 == 0) {
                    this.noise = new PerlinNoise();
                    this.noiseFactor = 1.0f;
                }
                boolean collide = EntityUtility.collideWith(targetedEntity, 1.0f);
                class_243 nearYx = RotationMath.getNearestPoint(targetedEntity);
                Rotation targetRotx = RotationMath.getRotationTo(new class_243(nearYx.field_1352, class_3532.method_15350((double)MathUtility.interpolate(Aura.mc.field_1724.method_23318(), targetedEntity.method_23320(), 0.5), (double)targetedEntity.method_5829().field_1322, (double)targetedEntity.method_5829().field_1325), nearYx.field_1350));
                Rotation multipointx = RotationMath.getRotationTo(RotationMath.getNearestPoint(targetedEntity));
                if (collide) {
                    targetRotx = RotationMath.getRotationTo(targetedEntity.method_19538().method_1031(0.0, 0.5, 0.0));
                }
                if (!MathUtility.canTraceWithBlock(this.attackDistance.getCurrentValue(), targetRotx.getYaw(), targetRotx.getPitch(), (class_1297)Aura.mc.field_1724, (class_1297)targetedEntity, !this.walls.isEnabled()) && Aura.mc.field_1724.method_33571().method_1022(targetedEntity.method_33571()) > 3.0) {
                    targetRotx.setPitch(multipointx.getPitch() + 10.0f);
                }
                boolean idlex = this.attackTimer.finished(collide ? 500L : 200L);
                if (this.additional == null) {
                    this.additional = new Rotation(0.0f, 0.0f);
                }
                float targetYawx = targetRotx.getYaw();
                float targetPitchx = targetRotx.getPitch();
                Rotation currentRotx = handler.getCurrentRotation();
                float currentYawx = currentRotx.getYaw();
                float currentPitchx = currentRotx.getPitch();
                float yawDiffx = RotationMath.getAngleDifference(currentYawx, targetYawx);
                float pitchDiffx = RotationMath.getAngleDifference(currentPitchx, targetPitchx);
                if (!this.shouldPreventSprinting() && idlex && EntityUtility.getBlock(0.0, 2.0, 0.0) == class_2246.field_10124) {
                    targetYawx += 10.0f;
                    targetPitchx -= 20.0f;
                }
                float yawSpeed = Math.max((90.0f - Math.abs(yawDiffx)) / (!this.shouldPreventSprinting() && idlex ? 5.0f : (idlex ? (Aura.mc.field_1724.field_6017 > 0.0f ? 25.0f : 10.0f) : 60.0f)), MathUtility.random(1.0, 5.0)) * MathUtility.random(0.9, 1.1);
                float pitchSpeed = Math.abs(pitchDiffx) / (!this.shouldPreventSprinting() && idlex ? 5.0f : (idlex ? (Aura.mc.field_1724.field_6017 > 0.0f ? 25.0f : 10.0f) : 40.0f)) * MathUtility.random(0.9, 1.1);
                if (!EntityUtility.collideWith(targetedEntity)) {
                    this.collideTimer.reset();
                }
                if (this.collideTimer.finished(500L) && CombatUtility.stalin(targetedEntity)) {
                    targetPitchx = (float)(64.0 + (Aura.mc.field_1724.method_23318() - targetedEntity.method_23318() + 1.0) * (5.0 + Math.sin((float)(Aura.mc.field_1724.field_6012 % 100 / 5) * 1924.12f) * 35.0) - 5.0 + 10.0);
                    yawSpeed /= MathUtility.random(30.0, 50.0);
                }
                if (!idlex && EntityUtility.getBlock(0.0, 2.0, 0.0) == class_2246.field_10124 && !collide) {
                    targetYawx += this.additional.getYaw();
                    targetPitchx += this.additional.getPitch();
                }
                if (this.walls.isEnabled() && !MathUtility.canSeen(nearYx) && Aura.mc.field_1724.field_6017 <= CombatUtility.getFallDistance(targetedEntity)) {
                    targetPitchx = -90.0f;
                }
                long timeElapsed = System.currentTimeMillis() - this.rotationStartTime;
                float yawNoise = (float)this.noise.noise((double)timeElapsed * 5.0E-4);
                float pitchNoise = (float)this.noise.noise((double)timeElapsed * 5.0E-4, 10.0);
                float yawOffset = yawNoise * 25.0f * this.noiseFactor;
                float pitchOffset = pitchNoise * 25.0f * this.noiseFactor;
                float finalTargetYaw = targetYawx + yawOffset;
                float finalTargetPitch = targetPitchx + pitchOffset;
                float totalDiff = Math.abs(yawDiffx) + Math.abs(pitchDiffx);
                if (totalDiff < 10.0f) {
                    this.noiseFactor = Math.max(0.0f, this.noiseFactor - 0.05f);
                }
                handler.rotate(new Rotation(finalTargetYaw, Math.clamp(finalTargetPitch, -90.0f, 90.0f)), moveCorrection, yawSpeed * 25.0f, pitchSpeed * 25.0f, MathUtility.random(30.0, 70.0), RotationPriority.TO_TARGET);
            }
            if (this.rotationMode.is(this.cakeWorldRotation)) {
                float jitterPitch;
                float baseSpeed;
                Rotation currentRotation = handler.getCurrentRotation();
                nearestPoint = RotationMath.getNearestPoint(targetedEntity);
                Rotation targetRotation = RotationMath.getRotationTo(nearestPoint);
                float yawDelta = class_3532.method_15393((float)(targetRotation.getYaw() - currentRotation.getYaw()));
                float pitchDelta = class_3532.method_15393((float)(targetRotation.getPitch() - currentRotation.getPitch()));
                float rotationDifference = (float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
                boolean canAttack = this.attackTimer.finished(0L);
                float distanceToTarget = Aura.mc.field_1724.method_5739((class_1297)targetedEntity);
                float speed = baseSpeed = canAttack ? 0.87f : 0.56f;
                if (distanceToTarget > 0.0f && distanceToTarget < 0.66f) {
                    float closeRangeSpeed = class_3532.method_15363((float)(distanceToTarget / 1.5f * 0.35f), (float)0.1f, (float)0.6f);
                    speed = canAttack ? 0.85f : Math.min(speed, closeRangeSpeed);
                }
                float lineYaw = Math.abs(yawDelta / rotationDifference) * 180.0f;
                float linePitch = Math.abs(pitchDelta / rotationDifference) * 180.0f;
                float jitterYaw = canAttack ? 0.0f : (float)((double)MathUtility.random(18.0, 27.0) * Math.sin((double)System.currentTimeMillis() / 50.0));
                float f = jitterPitch = canAttack ? 0.0f : (float)((double)MathUtility.random(15.0, 22.0) * Math.sin((double)System.currentTimeMillis() / 13.0));
                if (!this.isEnabled() || Experiment.getInstance().getTargetManager().getCurrentTarget() == null && this.attackTimer.finished(1000L)) {
                    baseSpeed = 0.35f;
                    jitterYaw = 0.0f;
                    jitterPitch = 0.0f;
                }
                float moveYaw = class_3532.method_15363((float)yawDelta, (float)(-lineYaw), (float)lineYaw);
                float movePitch = class_3532.method_15363((float)pitchDelta, (float)(-linePitch), (float)linePitch);
                float finalYaw = class_3532.method_16439((float)baseSpeed, (float)currentRotation.getYaw(), (float)(currentRotation.getYaw() + moveYaw)) + jitterYaw;
                float finalPitch = class_3532.method_16439((float)baseSpeed, (float)currentRotation.getPitch(), (float)(currentRotation.getPitch() + movePitch)) + jitterPitch;
                handler.rotate(new Rotation(finalYaw += MathUtility.random(-0.01, 0.01), Math.clamp(finalPitch += MathUtility.random(-0.07, 0.07), -90.0f, 90.0f)), moveCorrection, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
            if (this.rotationMode.is(this.hvhRotation)) {
                float baseSpeed;
                Rotation currentRot = handler.getCurrentRotation();
                nearestPoint = RotationMath.getNearestPoint(targetedEntity);
                Rotation targetRot = RotationMath.getRotationTo(nearestPoint);
                float yawDelta = class_3532.method_15393((float)(targetRot.getYaw() - currentRot.getYaw()));
                float pitchDelta = class_3532.method_15393((float)(targetRot.getPitch() - currentRot.getPitch()));
                float distance = Aura.mc.field_1724.method_5739((class_1297)targetedEntity);
                boolean canAttack = this.attackTimer.finished(0L);
                float f = baseSpeed = canAttack ? 0.75f : 0.55f;
                if (distance > 3.0f) {
                    baseSpeed *= 1.3f;
                }
                float jitterYaw = (float)((double)MathUtility.random(-1.5, 1.5) * Math.sin((double)System.currentTimeMillis() / 80.0));
                float jitterPitch = (float)((double)MathUtility.random(-1.0, 1.0) * Math.sin((double)System.currentTimeMillis() / 100.0));
                float finalYaw = class_3532.method_16439((float)baseSpeed, (float)currentRot.getYaw(), (float)(currentRot.getYaw() + yawDelta)) + jitterYaw;
                float finalPitch = class_3532.method_16439((float)baseSpeed, (float)currentRot.getPitch(), (float)(currentRot.getPitch() + pitchDelta)) + jitterPitch;
                handler.rotate(new Rotation(finalYaw += MathUtility.random(-0.05, 0.05), Math.clamp(finalPitch += MathUtility.random(-0.08, 0.08), -90.0f, 90.0f)), moveCorrection, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
            if (this.rotationMode.is(this.universalRotation)) {
                float baseSpeed;
                Rotation currentRot = handler.getCurrentRotation();
                box = targetedEntity.method_5829();
                class_243[] multipoints = new class_243[]{new class_243(box.method_1005().field_1352, box.field_1325 - 0.2, box.method_1005().field_1350), new class_243(box.method_1005().field_1352, box.method_1005().field_1351, box.method_1005().field_1350), new class_243(box.field_1323 + 0.2, box.field_1325 - 0.5, box.method_1005().field_1350), new class_243(box.field_1320 - 0.2, box.field_1325 - 0.5, box.method_1005().field_1350), new class_243(box.method_1005().field_1352, box.field_1322 + 0.3, box.method_1005().field_1350)};
                class_243 bestPoint = multipoints[0];
                float minAngleDiff = Float.MAX_VALUE;
                for (class_243 point : multipoints) {
                    float pitchDiff;
                    Rotation rot = RotationMath.getRotationTo(point);
                    float yawDiff = Math.abs(class_3532.method_15393((float)(rot.getYaw() - currentRot.getYaw())));
                    float totalDiff = yawDiff + (pitchDiff = Math.abs(class_3532.method_15393((float)(rot.getPitch() - currentRot.getPitch()))));
                    if (!(totalDiff < minAngleDiff)) continue;
                    minAngleDiff = totalDiff;
                    bestPoint = point;
                }
                Rotation targetRot = RotationMath.getRotationTo(bestPoint);
                float yawDelta = class_3532.method_15393((float)(targetRot.getYaw() - currentRot.getYaw()));
                float pitchDelta = class_3532.method_15393((float)(targetRot.getPitch() - currentRot.getPitch()));
                float distance = Aura.mc.field_1724.method_5739((class_1297)targetedEntity);
                boolean canAttack = this.attackTimer.finished(0L);
                float f = baseSpeed = canAttack ? 0.65f : 0.45f;
                if (minAngleDiff < 10.0f) {
                    baseSpeed *= 1.5f;
                }
                float jitterYaw = (float)((double)MathUtility.random(-0.8, 0.8) * Math.sin((double)System.currentTimeMillis() / 90.0));
                float jitterPitch = (float)((double)MathUtility.random(-0.6, 0.6) * Math.sin((double)System.currentTimeMillis() / 110.0));
                float finalYaw = class_3532.method_16439((float)baseSpeed, (float)currentRot.getYaw(), (float)(currentRot.getYaw() + yawDelta)) + jitterYaw;
                float finalPitch = class_3532.method_16439((float)baseSpeed, (float)currentRot.getPitch(), (float)(currentRot.getPitch() + pitchDelta)) + jitterPitch;
                handler.rotate(new Rotation(finalYaw += MathUtility.random(-0.03, 0.03), Math.clamp(finalPitch += MathUtility.random(-0.05, 0.05), -90.0f, 90.0f)), moveCorrection, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
            if (calculatedRotation != null) {
                this.updateRotationData(calculatedRotation);
            } else {
                Rotation currentRot = handler.getCurrentRotation();
                if (currentRot != null) {
                    this.updateRotationData(currentRot);
                }
            }
        }
    }

    public float getGCDValue() {
        double sensitivity = (Double)Aura.mc.field_1690.method_42495().method_41753();
        double value = sensitivity * 0.6 + 0.2;
        double result = Math.pow(value, 3.0) * 0.8;
        return (float)result * 0.15f;
    }

    public float getSensitivity(float rot) {
        return this.getDeltaMouse(rot) * this.getGCDValue();
    }

    public float getDeltaMouse(float delta) {
        return Math.round(delta / this.getGCDValue());
    }

    public boolean shouldPreventSprinting() {
        boolean predict;
        class_1309 living;
        class_1309 target;
        class_1297 class_12972 = Experiment.getInstance().getTargetManager().getCurrentTarget();
        class_1309 class_13092 = target = class_12972 instanceof class_1309 ? (living = (class_1309)class_12972) : null;
        if (target == null || Aura.mc.field_1724 == null) {
            return false;
        }
        if (this.styleAttack.is(this.fastPvp)) {
            return false;
        }
        Criticals criticals = Experiment.getInstance().getModuleManager().getModule(Criticals.class);
        boolean bl = predict = criticals.isEnabled() && (criticals.canCritical() || Aura.mc.field_1724.method_24828()) || !Aura.mc.field_1724.method_24828() && FallingPlayer.fromPlayer(Aura.mc.field_1724).findFall(CombatUtility.getFallDistance(target));
        return this.onlyCriticals.isEnabled() && this.isCriticalRequired(target) && (predict || CombatUtility.canPerformCriticalHit(target, true) || !this.attackTimer.finished(!ServerUtility.isHW() && !ServerUtility.isST() ? 50L : (long)MathUtility.random(50.0, 150.0)));
    }

    private boolean inRange(class_1309 target) {
        return class_3532.method_15355((float)((float)Aura.mc.field_1724.method_5707(RotationMath.getNearestPoint(target)))) > this.attackDistance.getCurrentValue();
    }

    public void updateRotationData(Rotation rotation) {
        if (rotation == null) {
            return;
        }
        this.previousRotation = this.currentRotation;
        this.currentRotation = rotation;
        this.rotationUpdateTime = System.currentTimeMillis();
    }

    public void setTargetRotation(Rotation rotation) {
        this.targetRotation = rotation;
        this.rotationProgress = 0.0f;
    }

    public Rotation getCurrentRotation() {
        return this.currentRotation != null ? this.currentRotation : new Rotation(Aura.mc.field_1724.method_36454(), Aura.mc.field_1724.method_36455());
    }

    public Rotation getPreviousRotation() {
        return this.previousRotation != null ? this.previousRotation : this.getCurrentRotation();
    }

    public Rotation getTargetRotation() {
        return this.targetRotation;
    }

    public float getRotationProgress() {
        return this.rotationProgress;
    }

    public void incrementRotationProgress(float delta) {
        this.rotationProgress = Math.min(1.0f, this.rotationProgress + delta);
    }

    public long getRotationUpdateTime() {
        return this.rotationUpdateTime;
    }

    public Rotation interpolateRotation(float progress) {
        if (this.previousRotation == null || this.currentRotation == null) {
            return this.getCurrentRotation();
        }
        float yaw = MathUtility.interpolate(this.previousRotation.getYaw(), this.currentRotation.getYaw(), progress);
        float pitch = MathUtility.interpolate(this.previousRotation.getPitch(), this.currentRotation.getPitch(), progress);
        return new Rotation(yaw, pitch);
    }

    @Override
    public void onEnable() {
        this.rotationStartTime = System.currentTimeMillis();
        this.noise = new PerlinNoise();
        this.noiseFactor = 1.0f;
        if (Aura.mc.field_1724 != null) {
            this.previousRotation = this.currentRotation = new Rotation(Aura.mc.field_1724.method_36454(), Aura.mc.field_1724.method_36455());
        }
        this.targetRotation = null;
        this.rotationProgress = 0.0f;
        this.rotationUpdateTime = System.currentTimeMillis();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        Experiment.getInstance().getTargetManager().reset();
        this.currentRotation = null;
        this.previousRotation = null;
        this.targetRotation = null;
        this.rotationProgress = 0.0f;
        super.onDisable();
    }

    public ModeSetting.Value getFastPvp() {
        return this.fastPvp;
    }

    public ModeSetting.Value getSlowPvp() {
        return this.slowPvp;
    }

    public Timer getAttackTimer() {
        return this.attackTimer;
    }

    public int getAttacks() {
        return this.attacks;
    }
}

