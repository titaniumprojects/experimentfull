/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_5250
 */
package micronix.experiment.systems.modules.modules.combat;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.TotemLossEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

@ModuleInfo(name="Totem Tracker", category=ModuleCategory.COMBAT, desc="modules.descriptions.totem_tracker")
@Environment(value=EnvType.CLIENT)
public class TotemTracker
extends BaseModule {
    private long lastTotemTime = 0L;
    private String lastPlayerName = "";
    private final EventListener<TotemLossEvent> onTotemLoss = event -> {
        String playerName = event.getPlayer().method_5477().getString();
        boolean wasEnchanted = event.wasEnchanted();
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastTotemTime >= 100L || !playerName.equals(this.lastPlayerName)) {
            this.lastTotemTime = currentTime;
            this.lastPlayerName = playerName;
            String totemType = wasEnchanted ? "\u0417\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0439" : "\u041d\u0435 \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0439";
            int totemColor = wasEnchanted ? 0x55FF55 : 0xFF5555;
            class_5250 message = class_2561.method_43470((String)"").method_10852((class_2561)class_2561.method_43470((String)"[Experiment]").method_54663(10190335)).method_10852((class_2561)class_2561.method_43470((String)" ")).method_10852((class_2561)class_2561.method_43470((String)"\u0418\u0433\u0440\u043e\u043a ").method_54663(0xFFFFFF)).method_10852((class_2561)class_2561.method_43470((String)playerName).method_54663(0xFFFFFF)).method_10852((class_2561)class_2561.method_43470((String)" \u043f\u043e\u0442\u0435\u0440\u044f\u043b ").method_54663(0xFFFFFF)).method_10852((class_2561)class_2561.method_43470((String)totemType).method_54663(totemColor)).method_10852((class_2561)class_2561.method_43470((String)" \u0442\u043e\u0442\u0435\u043c").method_54663(0xFFFFFF));
            if (TotemTracker.mc.field_1724 != null) {
                TotemTracker.mc.field_1724.method_7353((class_2561)message, false);
            }
        }
    };

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}

