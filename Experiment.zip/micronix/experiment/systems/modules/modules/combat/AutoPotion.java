/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1291
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1828
 *  net.minecraft.class_2246
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2886
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_6880
 *  net.minecraft.class_742
 */
package micronix.experiment.systems.modules.modules.combat;

import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.player.GuiMove;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.PotionUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1828;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2886;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import net.minecraft.class_742;

@ModuleInfo(name="Auto Potion", category=ModuleCategory.COMBAT, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0431\u0440\u043e\u0441\u0430\u0435\u0442 \u0437\u0435\u043b\u044c\u044f")
@Environment(value=EnvType.CLIENT)
public class AutoPotion
extends BaseModule {
    private final SelectSetting potions = new SelectSetting(this, "modules.settings.auto_potion.potions");
    private final SelectSetting.Value health;
    private final SelectSetting.Value cerka;
    private SliderSetting healthHealth = null;
    private SliderSetting cerkaHealth = null;
    private final SelectSetting allow = new SelectSetting(this, "modules.settings.auto_potion.allow");
    private final SelectSetting.Value up = new SelectSetting.Value(this.allow, "modules.settings.auto_potion.allow.throw_up").select();
    private final SelectSetting.Value walls = new SelectSetting.Value(this.allow, "modules.settings.auto_potion.allow.throw_walls").select();
    private final SelectSetting.Value don = new SelectSetting.Value(this.allow, "modules.settings.auto_potion.allow.donate");
    private final Timer staying = new Timer();
    private final Timer ground = new Timer();
    private final Timer wall = new Timer();
    private final Timer roof = new Timer();
    private UseTask task;
    private final EventListener<InputEvent> onInput = event -> {
        if (this.task == null) {
            return;
        }
        GuiMove guiMove = Experiment.getInstance().getModuleManager().getModule(GuiMove.class);
        boolean hotbar = this.task.slot instanceof HotbarSlot;
        if (guiMove.isEnabled() && guiMove.slowing() && !hotbar) {
            event.setForward(0.0f);
            event.setStrafe(0.0f);
        }
    };
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        Rotation rotation = this.getRotation();
        GuiMove guiMove = Experiment.getInstance().getModuleManager().getModule(GuiMove.class);
        if (this.task != null) {
            Experiment.getInstance().getRotationHandler().rotate(rotation, RotationPriority.USE_ITEM);
            boolean hotbar = this.task.slot instanceof HotbarSlot;
            int offset = guiMove.isEnabled() && guiMove.slowing() && !hotbar ? 1 : 0;
            int n = offset;
            if (hotbar) {
                switch (this.task.stage) {
                    case 0: {
                        InventoryUtility.selectHotbarSlot(this.task.slot.getIdForServer() - 36);
                        break;
                    }
                    case 1: {
                        this.usePotion();
                        break;
                    }
                    case 2: {
                        InventoryUtility.selectHotbarSlot(this.task.prevSlot);
                    }
                }
            } else {
                switch (this.task.stage - offset) {
                    case 0: {
                        InventoryUtility.hotbarSwap(this.task.slot.getIdForServer(), this.task.prevSlot);
                        InventoryUtility.selectHotbarSlot(this.task.prevSlot);
                        break;
                    }
                    case 1: {
                        this.usePotion();
                        break;
                    }
                    case 2: {
                        InventoryUtility.hotbarSwap(this.task.slot.getIdForServer(), this.task.prevSlot);
                    }
                }
            }
            if (this.task.stage >= 2 + offset) {
                this.task = null;
            } else {
                ++this.task.stage;
                return;
            }
        }
        if (rotation.getYaw() == -1.0f || rotation.getPitch() == -1.0f) {
            return;
        }
        for (SelectSetting.Value selectedValue : this.potions.getSelectedValues()) {
            SlotGroup<ItemSlot> search;
            ItemSlot slot;
            PotionValue potionValue = (PotionValue)selectedValue;
            if (AutoPotion.mc.field_1724.method_6059(potionValue.effect) || !potionValue.throwTimer.finished(2000L) || !potionValue.canThrow() || (slot = (search = SlotGroups.inventory().and(SlotGroups.hotbar())).findItem(this.potionPredicate(potionValue.effect))) == null) continue;
            this.task = new UseTask(slot, InventoryUtility.getCurrentHotbarSlot().getSlotId());
            Experiment.getInstance().getRotationHandler().rotate(rotation, MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.USE_ITEM);
            potionValue.throwTimer.reset();
            break;
        }
    };

    public AutoPotion() {
        new PotionValue(this.potions, "modules.settings.auto_potion.potions.strength", (class_6880<class_1291>)class_1294.field_5910).select();
        new PotionValue(this.potions, "modules.settings.auto_potion.potions.speed", (class_6880<class_1291>)class_1294.field_5904).select();
        new PotionValue(this.potions, "modules.settings.auto_potion.potions.fire_resistance", (class_6880<class_1291>)class_1294.field_5918).select();
        this.health = new PotionValue(this.potions, "modules.settings.auto_potion.potions.heal", (class_6880<class_1291>)class_1294.field_5915, () -> AutoPotion.mc.field_1724.method_6032() <= this.healthHealth.getCurrentValue()).select();
        this.cerka = new PotionValue(this.potions, "modules.settings.auto_potion.potions.heal.cerka", (class_6880<class_1291>)class_1294.field_5911, () -> {
            SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar());
            ItemSlot health = slotsToSearch.findItem(stack -> PotionUtility.hasEffect(stack, (class_6880<class_1291>)class_1294.field_5915) && !AutoPotion.mc.field_1724.method_7357().method_7904(stack));
            ItemSlot golden = slotsToSearch.findItem(stack -> stack.method_7909() == class_1802.field_8367 && !AutoPotion.mc.field_1724.method_7357().method_7904(stack));
            boolean near = false;
            for (class_742 player : AutoPotion.mc.field_1687.method_18456()) {
                if (!(AutoPotion.mc.field_1724.method_5739((class_1297)player) < 5.0f) || player == AutoPotion.mc.field_1724) continue;
                near = true;
            }
            return AutoPotion.mc.field_1724.method_6032() + AutoPotion.mc.field_1724.method_6067() <= this.cerkaHealth.getCurrentValue() && golden == null && health == null && near;
        }).select();
        this.healthHealth = new SliderSetting((SettingsContainer)this, "modules.settings.auto_potion.potions.heal_health", () -> !this.health.isSelected()).min(1.0f).max(19.0f).step(0.5f).currentValue(6.0f);
        this.cerkaHealth = new SliderSetting((SettingsContainer)this, "modules.settings.auto_potion.potions.cerka_health", () -> !this.cerka.isSelected()).min(1.0f).max(19.0f).step(0.5f).currentValue(6.0f);
    }

    private void usePotion() {
        Rotation rotation = this.getRotation();
        AutoPotion.mc.field_1761.method_41931(AutoPotion.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, rotation.getYaw(), rotation.getPitch()));
    }

    private Rotation getRotation() {
        boolean canThrow = false;
        float yaw = AutoPotion.mc.field_1724.method_36454();
        float pitch = 90.0f;
        if (this.cerka.isSelected() && ((PotionValue)this.cerka).canThrow()) {
            for (class_742 player : AutoPotion.mc.field_1687.method_18456()) {
                if (!(AutoPotion.mc.field_1724.method_5739((class_1297)player) < 5.0f) || player == AutoPotion.mc.field_1724) continue;
                class_243 eyes = AutoPotion.mc.field_1724.method_5836(1.0f);
                double dx = player.method_19538().field_1352 - eyes.field_1352;
                double dy = player.method_19538().field_1351 - eyes.field_1351;
                double dz = player.method_19538().field_1350 - eyes.field_1350;
                double dist = Math.sqrt(dx * dx + dz * dz);
                return new Rotation((float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0), (float)(-Math.toDegrees(Math.atan2(dy, dist))));
            }
        }
        if (this.up.isSelected()) {
            if (AutoPotion.mc.field_1724.method_18798().field_1352 == 0.0 && AutoPotion.mc.field_1724.method_18798().field_1350 == 0.0 && Math.abs(AutoPotion.mc.field_1724.method_18798().field_1351) < (double)0.1f && EntityUtility.getBlockAbove((class_1297)AutoPotion.mc.field_1724) == class_2246.field_10124) {
                if (this.staying.finished(500L)) {
                    pitch = -90.0f;
                    return new Rotation(yaw, pitch);
                }
            } else {
                this.staying.reset();
            }
        }
        if (AutoPotion.mc.field_1724.method_24828()) {
            if (this.ground.finished(300L)) {
                class_3965 groundResult = AutoPotion.mc.field_1687.method_17742(new class_3959(AutoPotion.mc.field_1724.method_33571(), AutoPotion.mc.field_1724.method_33571().method_1019(AutoPotion.mc.field_1724.method_5631(pitch, yaw).method_1021(2.0)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AutoPotion.mc.field_1724));
                if (groundResult.method_17783() == class_239.class_240.field_1332) {
                    canThrow = true;
                } else {
                    pitch = 76.0f;
                    for (int i = 0; i < 360; i += 45) {
                        class_3965 result = AutoPotion.mc.field_1687.method_17742(new class_3959(AutoPotion.mc.field_1724.method_33571(), AutoPotion.mc.field_1724.method_33571().method_1019(AutoPotion.mc.field_1724.method_5631(pitch, (float)i).method_1021(2.0)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AutoPotion.mc.field_1724));
                        if (result.method_17783() != class_239.class_240.field_1332) continue;
                        yaw = RotationMath.adjustAngle(AutoPotion.mc.field_1724.method_36454(), i);
                        canThrow = true;
                    }
                }
            }
        } else {
            this.ground.reset();
            if (this.walls.isSelected()) {
                class_3965 result;
                boolean wallThrow = false;
                pitch = 5.0f;
                for (int i = 0; i < 360; i += 45) {
                    result = AutoPotion.mc.field_1687.method_17742(new class_3959(AutoPotion.mc.field_1724.method_33571(), AutoPotion.mc.field_1724.method_33571().method_1019(AutoPotion.mc.field_1724.method_5631(pitch, (float)i).method_1021(0.5)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AutoPotion.mc.field_1724));
                    if (result.method_17783() != class_239.class_240.field_1332) continue;
                    yaw = RotationMath.adjustAngle(AutoPotion.mc.field_1724.method_36454(), i);
                    wallThrow = true;
                }
                if (!wallThrow) {
                    this.wall.reset();
                } else if (this.wall.finished(300L)) {
                    canThrow = true;
                }
                if (!canThrow) {
                    boolean roofThrow = false;
                    pitch = -90.0f;
                    result = AutoPotion.mc.field_1687.method_17742(new class_3959(AutoPotion.mc.field_1724.method_33571(), AutoPotion.mc.field_1724.method_33571().method_1019(AutoPotion.mc.field_1724.method_5631(pitch, AutoPotion.mc.field_1724.method_36454()).method_1021(0.5)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AutoPotion.mc.field_1724));
                    if (result.method_17783() == class_239.class_240.field_1332) {
                        yaw = AutoPotion.mc.field_1724.method_36454();
                        roofThrow = true;
                    }
                    if (!roofThrow) {
                        this.roof.reset();
                    } else if (this.roof.finished(300L)) {
                        canThrow = true;
                    }
                }
            }
        }
        return canThrow ? new Rotation(yaw, pitch) : new Rotation(-1.0f, -1.0f);
    }

    private Predicate<class_1799> potionPredicate(class_6880<class_1291> type) {
        return stack -> {
            if (stack.method_7960() || !(stack.method_7909() instanceof class_1828)) {
                return false;
            }
            List<class_1293> effects = PotionUtility.effects(stack);
            return this.don.isSelected() || type == class_1294.field_5911 ? effects.stream().anyMatch(effect -> effect.method_5579() == type) : effects.size() == 1 && effects.getFirst().method_5579() == type;
        };
    }

    @Environment(value=EnvType.CLIENT)
    static class PotionValue
    extends SelectSetting.Value {
        final class_6880<class_1291> effect;
        final Timer throwTimer = new Timer();
        Supplier<Boolean> canThrow = () -> true;

        public PotionValue(SelectSetting parent, String name, class_6880<class_1291> effect) {
            super(parent, name);
            this.effect = effect;
        }

        public PotionValue(SelectSetting parent, String name, class_6880<class_1291> effect, Supplier<Boolean> canThrow) {
            super(parent, name);
            this.effect = effect;
            this.canThrow = canThrow;
        }

        public boolean canThrow() {
            return this.canThrow.get();
        }
    }

    @Environment(value=EnvType.CLIENT)
    static class UseTask {
        int stage;
        final ItemSlot slot;
        final int prevSlot;

        public UseTask(ItemSlot slot, int prevSlot) {
            this.slot = slot;
            this.prevSlot = prevSlot;
        }
    }
}

