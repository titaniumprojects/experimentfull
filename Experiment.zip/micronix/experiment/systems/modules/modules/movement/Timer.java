/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.EntityUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Timer", category=ModuleCategory.MOVEMENT, desc="modules.descriptions.timer")
@Environment(value=EnvType.CLIENT)
public class Timer
extends BaseModule {
    private final SliderSetting speed = new SliderSetting(this, "modules.settings.timer.speed").step(0.1f).min(0.1f).max(15.0f).currentValue(1.0f);

    @Override
    public void tick() {
        EntityUtility.setTimer(this.speed.getCurrentValue());
        super.tick();
    }

    @Override
    public void onDisable() {
        EntityUtility.resetTimer();
        super.onDisable();
    }

    public SliderSetting getSpeed() {
        return this.speed;
    }
}

