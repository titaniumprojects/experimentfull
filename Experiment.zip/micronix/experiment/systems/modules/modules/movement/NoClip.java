/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;

@ModuleInfo(name="NoClip", category=ModuleCategory.MOVEMENT, desc="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043f\u0440\u043e\u0445\u043e\u0434\u0438\u0442\u044c \u0447\u0435\u0440\u0435\u0437 \u0441\u0442\u0435\u043d\u044b \u043a\u0430\u043a \u043f\u0440\u0438\u0437\u0440\u0430\u043a")
@Environment(value=EnvType.CLIENT)
public class NoClip
extends BaseModule {
    private final BooleanSetting verticalClip = new BooleanSetting(this, "Vertical Clip").enabled(true);
    private final SliderSetting speed = new SliderSetting(this, "Speed").min(0.1f).max(5.0f).step(0.1f).currentValue(1.0f);
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (NoClip.mc.field_1724 == null || NoClip.mc.field_1687 == null) {
            return;
        }
        NoClip.mc.field_1724.field_5960 = true;
        NoClip.mc.field_1724.method_24830(false);
        this.handleMovement();
        if (this.verticalClip.isEnabled()) {
            this.handleVerticalMovement();
        }
        NoClip.mc.field_1724.field_6017 = 0.0f;
    };

    private void handleMovement() {
        if (NoClip.mc.field_1724 == null) {
            return;
        }
        float moveForward = NoClip.mc.field_1724.field_3913.field_3905;
        float moveSideways = NoClip.mc.field_1724.field_3913.field_3907;
        boolean jumping = NoClip.mc.field_1690.field_1903.method_1434();
        boolean sneaking = NoClip.mc.field_1690.field_1832.method_1434();
        double currentSpeed = this.speed.getCurrentValue();
        class_243 velocity = NoClip.mc.field_1724.method_18798();
        double moveX = 0.0;
        double moveZ = 0.0;
        if (moveForward != 0.0f || moveSideways != 0.0f) {
            float yaw = NoClip.mc.field_1724.method_36454();
            float sin = (float)Math.sin(Math.toRadians(yaw));
            float cos = (float)Math.cos(Math.toRadians(yaw));
            moveX = (double)(moveSideways * cos - moveForward * sin) * currentSpeed;
            moveZ = (double)(moveForward * cos + moveSideways * sin) * currentSpeed;
        }
        if (jumping) {
            NoClip.mc.field_1724.method_18800(moveX, currentSpeed, moveZ);
        } else if (sneaking) {
            NoClip.mc.field_1724.method_18800(moveX, -currentSpeed, moveZ);
        } else {
            NoClip.mc.field_1724.method_18800(moveX, velocity.field_1351, moveZ);
        }
    }

    private void handleVerticalMovement() {
        if (NoClip.mc.field_1724 == null) {
            return;
        }
        class_238 box = NoClip.mc.field_1724.method_5829();
        class_243 pos = NoClip.mc.field_1724.method_19538();
        boolean headBlocked = NoClip.mc.field_1687.method_20812((class_1297)NoClip.mc.field_1724, box.method_989(0.0, 1.0, 0.0)).iterator().hasNext();
        boolean feetBlocked = NoClip.mc.field_1687.method_20812((class_1297)NoClip.mc.field_1724, box.method_989(0.0, -1.0, 0.0)).iterator().hasNext();
        if (headBlocked && NoClip.mc.field_1724.method_18798().field_1351 > 0.0) {
            NoClip.mc.field_1724.method_5814(pos.field_1352, pos.field_1351 + 1.0, pos.field_1350);
        }
        if (feetBlocked && NoClip.mc.field_1724.method_18798().field_1351 < 0.0) {
            NoClip.mc.field_1724.method_5814(pos.field_1352, pos.field_1351 - 1.0, pos.field_1350);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (NoClip.mc.field_1724 != null) {
            NoClip.mc.field_1724.field_5960 = true;
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (NoClip.mc.field_1724 != null) {
            NoClip.mc.field_1724.field_5960 = false;
        }
    }
}

