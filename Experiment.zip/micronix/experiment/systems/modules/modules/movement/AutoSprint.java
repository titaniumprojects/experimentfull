/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Auto Sprint", category=ModuleCategory.MOVEMENT, enabledByDefault=true)
@Environment(value=EnvType.CLIENT)
public class AutoSprint
extends BaseModule {
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> AutoSprint.mc.field_1690.field_1867.method_23481(true);
}

