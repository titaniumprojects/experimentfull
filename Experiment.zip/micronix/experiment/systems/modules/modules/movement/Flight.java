/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1735
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2848
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_2868
 */
package micronix.experiment.systems.modules.modules.movement;

import java.math.BigDecimal;
import java.math.RoundingMode;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEndEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_2868;

@ModuleInfo(name="Flight", category=ModuleCategory.MOVEMENT)
@Environment(value=EnvType.CLIENT)
public class Flight
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.flight.mode");
    private final ModeSetting.Value vanilla = new ModeSetting.Value(this.mode, "modules.settings.flight.vanilla");
    private final ModeSetting.Value elytraY = new ModeSetting.Value(this.mode, "ElytraY");
    private final ModeSetting.Value elytraGlide = new ModeSetting.Value(this.mode, "Elytra Glide").select();
    private final ModeSetting.Value grimGlide = new ModeSetting.Value(this.mode, "Grim Glide");
    private boolean wasFlyingAllowed = false;
    private boolean wasFlying = false;
    private final SliderSetting speed = new SliderSetting((SettingsContainer)this, "modules.settings.flight.speed", () -> !this.vanilla.isSelected()).currentValue(1.0f).max(10.0f).min(0.1f).step(0.1f);
    private int ticks;
    private Timer ticksTimer = new Timer();
    int ticksTwo = 0;
    private final EventListener<ClientPlayerTickEndEvent> tickEnd = event -> {
        if (this.grimGlide.isSelected() && Flight.mc.field_1724.method_6128()) {
            ++this.ticksTwo;
            class_243 pos = Flight.mc.field_1724.method_19538();
            float yaw = Flight.mc.field_1724.method_36454();
            double forward = 0.085f;
            double motion = Flight.getBps((class_1297)Flight.mc.field_1724, 1);
            if (motion >= 52.0) {
                forward = 0.0;
            }
            double dx = -Math.sin(Math.toRadians(yaw)) * forward;
            double dz = Math.cos(Math.toRadians(yaw)) * forward;
            Flight.mc.field_1724.method_18800(dx * (double)MathUtility.random(1.1f, 1.21f), Flight.mc.field_1724.method_18798().field_1351 - (double)0.01f, dz * (double)MathUtility.random(1.1f, 1.21f));
            if (this.ticksTimer.finished(45L)) {
                Flight.mc.field_1724.method_5814(pos.method_10216() + dx, pos.method_10214(), pos.method_10215() + dz);
                this.ticksTimer.reset();
            }
            Flight.mc.field_1724.method_18800(dx * (double)MathUtility.random(1.1f, 1.21f), Flight.mc.field_1724.method_18798().field_1351 + (double)0.015f, dz * (double)MathUtility.random(1.1f, 1.21f));
        }
    };

    @Override
    public void onEnable() {
        if (Flight.mc.field_1724 == null) {
            return;
        }
        if (this.vanilla.isSelected()) {
            Flight.mc.field_1724.method_31549().field_7478 = true;
        }
        super.onEnable();
    }

    @Override
    public void tick() {
        SlotGroup<HotbarSlot> slotsToSearch;
        HotbarSlot slot;
        if (Flight.mc.field_1724 == null) {
            return;
        }
        if (this.vanilla.isSelected()) {
            this.wasFlyingAllowed = Flight.mc.field_1724.method_31549().field_7478;
            this.wasFlying = Flight.mc.field_1724.method_31549().field_7479;
            Flight.mc.field_1724.method_31549().field_7478 = true;
            Flight.mc.field_1724.method_31549().method_7248(this.speed.getCurrentValue() / 10.0f);
            super.tick();
        } else if (this.elytraY.isSelected()) {
            if (Flight.mc.field_1724.method_6128()) {
                Flight.mc.field_1724.method_18800(Flight.mc.field_1724.method_18798().field_1352, Flight.mc.field_1724.method_18798().field_1351 + 0.05999999761581421, Flight.mc.field_1724.method_18798().field_1350);
            }
        } else if (this.elytraGlide.isSelected() && (slot = (slotsToSearch = SlotGroups.hotbar()).findItem(class_1802.field_8833)) != null && Flight.mc.field_1724.field_6012 % 10 != 0) {
            HotbarSlot currentItem = InventoryUtility.getCurrentHotbarSlot();
            Flight.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
            InventoryUtility.selectHotbarSlot(slot);
            Flight.mc.field_1761.method_2919((class_1657)Flight.mc.field_1724, class_1268.field_5808);
            ((class_1735)Flight.mc.field_1724.field_7512.field_7761.get(6)).method_53512(new class_1799((class_1935)class_1802.field_8833));
            if (Flight.mc.field_1724.method_5624() && Flight.mc.field_1724.field_3913.method_20622() && Flight.mc.field_1724.method_23668()) {
                Flight.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Flight.mc.field_1724, class_2848.class_2849.field_12982));
            }
            InventoryUtility.selectHotbarSlot(currentItem);
            Flight.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(Flight.mc.field_1724.method_31548().field_7545));
        }
    }

    public static double getBps(class_1297 entity, int decimal) {
        double x = entity.method_23317() - entity.field_6014;
        double y = entity.method_23318() - entity.field_6036;
        double z = entity.method_23321() - entity.field_5969;
        double speed = Math.sqrt(x * x + y * y + z * z) * 20.0;
        return Flight.roundHalfUp(speed, decimal);
    }

    public static double roundHalfUp(double num, double increment) {
        double v = (double)Math.round(num / increment) * increment;
        BigDecimal bd = new BigDecimal(v);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    @Override
    public void onDisable() {
        if (Flight.mc.field_1724 == null) {
            return;
        }
        if (this.vanilla.isSelected()) {
            Flight.mc.field_1724.method_31549().method_7248(0.05f);
            Flight.mc.field_1724.method_31549().field_7478 = false;
            Flight.mc.field_1724.method_31549().field_7479 = false;
        }
        super.onDisable();
    }
}

