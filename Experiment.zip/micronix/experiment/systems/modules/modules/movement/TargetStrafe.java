/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3532;

@ModuleInfo(name="TargetStrafe", category=ModuleCategory.MOVEMENT, desc="Strafe around target")
@Environment(value=EnvType.CLIENT)
public class TargetStrafe
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "Mode");
    private final ModeSetting.Value modeMatrix = new ModeSetting.Value(this.mode, "Matrix").select();
    private final ModeSetting.Value modeGrim = new ModeSetting.Value(this.mode, "Grim");
    private final ModeSetting grimType = new ModeSetting(this, "Grim Point");
    private final ModeSetting.Value grimCube = new ModeSetting.Value(this.grimType, "Cube").select();
    private final ModeSetting.Value grimCenter = new ModeSetting.Value(this.grimType, "Center");
    private final ModeSetting.Value grimCircle = new ModeSetting.Value(this.grimType, "Circle");
    private final ModeSetting matrixType = new ModeSetting(this, "Matrix Point");
    private final ModeSetting.Value matrixCircle = new ModeSetting.Value(this.matrixType, "Circle").select();
    private final ModeSetting.Value matrixCube = new ModeSetting.Value(this.matrixType, "Cube");
    private final ModeSetting directionMode = new ModeSetting(this, "Direction");
    private final ModeSetting.Value clockwise = new ModeSetting.Value(this.directionMode, "Clockwise").select();
    private final ModeSetting.Value counterclockwise = new ModeSetting.Value(this.directionMode, "Counterclockwise");
    private final ModeSetting.Value random = new ModeSetting.Value(this.directionMode, "Random");
    private final BooleanSetting autoJump = new BooleanSetting(this, "Auto Jump").enable();
    private final BooleanSetting onlyKeyPressed = new BooleanSetting(this, "Only Key Pressed");
    private final BooleanSetting inFrontOfTarget = new BooleanSetting(this, "In Front Of Target");
    private final SliderSetting grimRadius = new SliderSetting(this, "Grim Radius").min(0.1f).max(1.5f).step(0.01f).currentValue(0.87f);
    private final SliderSetting radius = new SliderSetting(this, "Matrix Radius").min(0.1f).max(7.0f).step(0.01f).currentValue(2.5f);
    private final SliderSetting speed = new SliderSetting(this, "Matrix Speed").min(0.1f).max(1.0f).step(0.01f).currentValue(0.3f);
    private int grimPointIndex = 0;
    private final EventListener<InputEvent> onInput = event -> {
        class_243 nextPoint;
        if (TargetStrafe.mc.field_1724 == null || TargetStrafe.mc.field_1687 == null) {
            return;
        }
        if (!this.modeGrim.isSelected()) {
            return;
        }
        class_1309 target = this.getTarget();
        if (target == null || !target.method_5805()) {
            return;
        }
        if (!(!this.onlyKeyPressed.isEnabled() || TargetStrafe.mc.field_1690.field_1894.method_1434() || TargetStrafe.mc.field_1690.field_1881.method_1434() || TargetStrafe.mc.field_1690.field_1913.method_1434() || TargetStrafe.mc.field_1690.field_1849.method_1434())) {
            return;
        }
        class_243 playerPos = TargetStrafe.mc.field_1724.method_19538();
        class_243 targetPos = target.method_19538();
        double r = this.grimRadius.getCurrentValue();
        int dir = this.getDirectionMultiplier();
        if (this.inFrontOfTarget.isEnabled()) {
            float targetYaw = target.method_36454();
            if (this.grimCenter.isSelected()) {
                nextPoint = targetPos.method_1031(-Math.sin(Math.toRadians(targetYaw)) * r * (double)dir, 0.0, Math.cos(Math.toRadians(targetYaw)) * r * (double)dir);
            } else {
                double offset = Math.cos((double)System.currentTimeMillis() / 500.0) * r * (double)dir;
                nextPoint = targetPos.method_1031(-Math.sin(Math.toRadians(targetYaw)) * r + Math.cos(Math.toRadians(targetYaw)) * offset, 0.0, Math.cos(Math.toRadians(targetYaw)) * r + Math.sin(Math.toRadians(targetYaw)) * offset);
            }
        } else if (this.grimCube.isSelected()) {
            class_243[] points = this.getCubePoints(targetPos, playerPos, r);
            if (playerPos.method_1022(points[this.grimPointIndex]) < 0.5) {
                this.grimPointIndex = (this.grimPointIndex + dir + points.length) % points.length;
            }
            nextPoint = points[this.grimPointIndex];
        } else if (this.grimCircle.isSelected()) {
            double baseAngle = (double)(System.currentTimeMillis() % 3600L) / 3600.0 * 4.0 * Math.PI;
            double angle = dir > 0 ? baseAngle : Math.PI * 2 - baseAngle;
            nextPoint = new class_243(targetPos.field_1352 + Math.cos(angle) * r, playerPos.field_1351, targetPos.field_1350 + Math.sin(angle) * r);
        } else {
            nextPoint = new class_243(targetPos.field_1352, playerPos.field_1351, targetPos.field_1350);
        }
        class_243 direction = nextPoint.method_1020(playerPos).method_1029();
        float yaw = Experiment.getInstance().getRotationHandler().getCurrentRotation().getYaw();
        float movementAngle = (float)Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90.0f;
        float angleDiff = class_3532.method_15393((float)(movementAngle - yaw));
        float fwd = 0.0f;
        float strafe = 0.0f;
        if (angleDiff >= -22.5f && angleDiff < 22.5f) {
            fwd = 1.0f;
        } else if (angleDiff >= 22.5f && angleDiff < 67.5f) {
            fwd = 1.0f;
            strafe = 1.0f;
        } else if (angleDiff >= 67.5f && angleDiff < 112.5f) {
            strafe = 1.0f;
        } else if (angleDiff >= 112.5f && angleDiff < 157.5f) {
            fwd = -1.0f;
            strafe = 1.0f;
        } else if (angleDiff >= -67.5f && angleDiff < -22.5f) {
            fwd = 1.0f;
            strafe = -1.0f;
        } else if (angleDiff >= -112.5f && angleDiff < -67.5f) {
            strafe = -1.0f;
        } else if (angleDiff >= -157.5f && angleDiff < -112.5f) {
            fwd = -1.0f;
            strafe = -1.0f;
        } else {
            fwd = -1.0f;
        }
        float desiredYaw = (float)Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90.0f;
        event.setYaw(desiredYaw);
        if (this.autoJump.isEnabled() && TargetStrafe.mc.field_1724.method_24828()) {
            event.setJump(true);
        }
    };
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (TargetStrafe.mc.field_1724 == null || TargetStrafe.mc.field_1687 == null) {
            return;
        }
        if (!this.modeMatrix.isSelected()) {
            return;
        }
        class_1309 target = this.getTarget();
        if (target == null || !target.method_5805()) {
            return;
        }
        if (!(!this.onlyKeyPressed.isEnabled() || TargetStrafe.mc.field_1690.field_1894.method_1434() || TargetStrafe.mc.field_1690.field_1881.method_1434() || TargetStrafe.mc.field_1690.field_1913.method_1434() || TargetStrafe.mc.field_1690.field_1849.method_1434())) {
            return;
        }
        if (this.autoJump.isEnabled() && TargetStrafe.mc.field_1724.method_24828()) {
            TargetStrafe.mc.field_1724.method_6043();
        }
        class_243 playerPos = TargetStrafe.mc.field_1724.method_19538();
        class_243 targetPos = target.method_19538();
        double r = this.radius.getCurrentValue();
        int dir = this.getDirectionMultiplier();
        double motionSpeed = this.speed.getCurrentValue();
        if (this.inFrontOfTarget.isEnabled()) {
            float targetYaw = target.method_36454();
            double x = targetPos.field_1352 - Math.sin(Math.toRadians(targetYaw)) * r * (double)dir;
            double z = targetPos.field_1350 + Math.cos(Math.toRadians(targetYaw)) * r * (double)dir;
            float yaw = (float)Math.toDegrees(Math.atan2(z - playerPos.field_1350, x - playerPos.field_1352)) - 90.0f;
            TargetStrafe.mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * motionSpeed, TargetStrafe.mc.field_1724.method_18798().field_1351, Math.cos(Math.toRadians(yaw)) * motionSpeed);
            return;
        }
        if (this.matrixCube.isSelected()) {
            class_243[] points = this.getCubePoints(targetPos, playerPos, r);
            if (playerPos.method_1022(points[this.grimPointIndex]) < 0.5) {
                this.grimPointIndex = (this.grimPointIndex + dir + points.length) % points.length;
            }
            class_243 next = points[this.grimPointIndex];
            class_243 dirVec = next.method_1020(playerPos).method_1029();
            float yaw = (float)Math.toDegrees(Math.atan2(dirVec.field_1350, dirVec.field_1352)) - 90.0f;
            TargetStrafe.mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * motionSpeed, TargetStrafe.mc.field_1724.method_18798().field_1351, Math.cos(Math.toRadians(yaw)) * motionSpeed);
        } else {
            double angle = Math.atan2(playerPos.field_1350 - targetPos.field_1350, playerPos.field_1352 - targetPos.field_1352);
            double x = targetPos.field_1352 + r * Math.cos(angle += (double)dir * motionSpeed / Math.max(playerPos.method_1022(targetPos), r));
            double z = targetPos.field_1350 + r * Math.sin(angle);
            float yaw = (float)Math.toDegrees(Math.atan2(z - playerPos.field_1350, x - playerPos.field_1352)) - 90.0f;
            TargetStrafe.mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * motionSpeed, TargetStrafe.mc.field_1724.method_18798().field_1351, Math.cos(Math.toRadians(yaw)) * motionSpeed);
        }
    };

    private class_1309 getTarget() {
        class_1309 living;
        class_1297 class_12972 = Experiment.getInstance().getTargetManager().getCurrentTarget();
        return class_12972 instanceof class_1309 ? (living = (class_1309)class_12972) : null;
    }

    private int getDirectionMultiplier() {
        if (this.counterclockwise.isSelected()) {
            return -1;
        }
        if (this.random.isSelected()) {
            return System.currentTimeMillis() / 3000L % 2L == 0L ? 1 : -1;
        }
        return 1;
    }

    private class_243[] getCubePoints(class_243 targetPos, class_243 playerPos, double r) {
        return new class_243[]{new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 - r), new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 + r), new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 + r), new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 - r)};
    }

    @Override
    public void onEnable() {
        this.grimPointIndex = 0;
        super.onEnable();
    }
}

