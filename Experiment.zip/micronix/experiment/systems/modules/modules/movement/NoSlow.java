/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_2886
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.SlowDownEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_2886;

@ModuleInfo(name="No Slow", category=ModuleCategory.MOVEMENT)
@Environment(value=EnvType.CLIENT)
public class NoSlow
extends BaseModule {
    private int ticks;
    private int packetTicks = 0;
    private final EventListener<SlowDownEvent> onSlowEventEvent = event -> {
        if (NoSlow.mc.field_1724 == null || NoSlow.mc.field_1687 == null || NoSlow.mc.field_1761 == null) {
            return;
        }
        if (!NoSlow.mc.field_1724.method_6115()) {
            this.ticks = 0;
            return;
        }
        ++this.ticks;
        NoSlow.mc.field_1724.method_5728(true);
        if (this.ticks >= 2) {
            this.ticks = 0;
        }
        event.cancel();
    };
    private final EventListener<ReceivePacketEvent> onReceivePacket = event -> {};
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
        if (NoSlow.mc.field_1724 != null && NoSlow.mc.field_1724.method_6115() && NoSlow.mc.field_1761 != null && NoSlow.mc.field_1687 != null) {
            ++this.packetTicks;
            if (this.packetTicks >= 1) {
                NoSlow.mc.field_1761.method_41931(NoSlow.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, NoSlow.mc.field_1724.method_36454(), NoSlow.mc.field_1724.method_36455()));
                this.packetTicks = 0;
            }
        } else {
            this.packetTicks = 0;
        }
    };
}

