/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1747
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2577
 *  net.minecraft.class_2596
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2868
 *  net.minecraft.class_2886
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2577;
import net.minecraft.class_2596;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

@ModuleInfo(name="Spider", category=ModuleCategory.MOVEMENT, desc="\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043b\u0430\u0437\u0438\u0442\u044c \u043f\u043e \u0441\u0442\u0435\u043d\u0430\u043c")
@Environment(value=EnvType.CLIENT)
public class Spider
extends BaseModule {
    private final Timer jumpDelay = new Timer();
    private final Timer carpetDelay = new Timer();
    private final ModeSetting mode = new ModeSetting(this, "Mode");
    private final ModeSetting.Value funTime = new ModeSetting.Value(this.mode, "FunTime").select();
    private final ModeSetting.Value funSky = new ModeSetting.Value(this.mode, "FunSky");
    private final ModeSetting.Value funTimeFly = new ModeSetting.Value(this.mode, "FunTime Fly");
    private final ModeSetting.Value slimeBlock = new ModeSetting.Value(this.mode, "Slime Block");
    private final ModeSetting.Value spookyTime = new ModeSetting.Value(this.mode, "SpookyTime");
    private final ModeSetting.Value griefCarpet = new ModeSetting.Value(this.mode, "Grief Carpet");
    private final ModeSetting.Value iceWalk = new ModeSetting.Value(this.mode, "Ice Walk");
    private final ModeSetting.Value water = new ModeSetting.Value(this.mode, "Water");
    private int slimeJumpCooldown;
    private long lastWaterBucketUse;
    private boolean touchingWall;

    @Override
    public void onEnable() {
        if (Spider.mc.field_1724 == null) {
            return;
        }
        Spider.mc.field_1690.field_1903.method_23481(false);
        Spider.mc.field_1690.field_1832.method_23481(false);
        this.lastWaterBucketUse = 0L;
        this.touchingWall = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (Spider.mc.field_1724 == null) {
            return;
        }
        Spider.mc.field_1690.field_1903.method_23481(false);
        Spider.mc.field_1690.field_1832.method_23481(false);
        super.onDisable();
    }

    @Override
    public void tick() {
        if (Spider.mc.field_1724 == null || Spider.mc.field_1687 == null) {
            return;
        }
        if (this.mode.is(this.spookyTime)) {
            this.handleSpookyTimeWaterBucketClimb();
        }
        if (this.mode.is(this.funSky)) {
            this.touchingWall = Spider.mc.field_1724.field_5976;
            this.handleFunSkyWaterBucketClimb();
            if (!this.touchingWall) {
                Spider.mc.field_1690.field_1832.method_23481(false);
            }
        }
        if (this.mode.is(this.funTime)) {
            this.handleFunTime();
        }
        if (this.mode.is(this.slimeBlock)) {
            this.handleSlimeBlock();
        }
        if (this.mode.is(this.iceWalk)) {
            this.handleIceWalk();
        }
        if (this.mode.is(this.funTimeFly)) {
            this.handleFunTimeFly();
        }
        if (this.mode.is(this.griefCarpet)) {
            this.handleGriefCarpet();
        }
        if (this.mode.is(this.water)) {
            this.handleWater();
        }
    }

    private void handleFunTime() {
        Spider.mc.field_1690.field_1903.method_23481(Spider.mc.field_1690.field_1894.method_1434());
        Spider.mc.field_1724.method_36457(75.0f);
        if (!Spider.mc.field_1724.field_5976) {
            return;
        }
        if (!this.jumpDelay.hasReached(110)) {
            return;
        }
        Spider.mc.field_1724.method_24830(true);
        Spider.mc.field_1724.method_6043();
        int wheatSlot = this.findHotbarSlot(class_1802.field_8861);
        if (wheatSlot != -1) {
            this.useWheatOnCrosshairBlock(wheatSlot);
            Spider.mc.field_1724.field_6017 = 0.0f;
            this.jumpDelay.reset();
        }
    }

    private void handleWater() {
        if (!this.jumpDelay.hasReached(110)) {
            return;
        }
        int waterSlot = this.findHotbarSlot(class_1802.field_8705);
        if (waterSlot == -1) {
            return;
        }
        this.sendUseItemPacketForHotbarSlot(waterSlot);
        if (Spider.mc.field_1724.field_5976) {
            Spider.mc.field_1761.method_2919((class_1657)Spider.mc.field_1724, class_1268.field_5808);
        }
    }

    private void handleSlimeBlock() {
        class_2338 playerPos = Spider.mc.field_1724.method_24515();
        class_2338[] adjacentBlocks = new class_2338[]{playerPos.method_10078(), playerPos.method_10067(), playerPos.method_10095(), playerPos.method_10072()};
        boolean slimeNearby = false;
        for (class_2338 pos : adjacentBlocks) {
            if (Spider.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10030) continue;
            slimeNearby = true;
            break;
        }
        if (!slimeNearby || !Spider.mc.field_1724.field_5976 || Spider.mc.field_1724.method_18798().field_1351 <= -1.0) {
            return;
        }
        class_239 class_2392 = Spider.mc.field_1765;
        if (class_2392 instanceof class_3965) {
            class_3965 hitResult = (class_3965)class_2392;
            class_2338 targetPos = hitResult.method_17777();
            if (Spider.mc.field_1687.method_8320(targetPos).method_26204() == class_2246.field_10124) {
                return;
            }
            int slimeSlot = this.findHotbarSlot(class_1802.field_8828);
            if (slimeSlot != -1) {
                Spider.mc.field_1724.method_31548().field_7545 = slimeSlot;
                Spider.mc.field_1724.method_36457(54.0f);
                Spider.mc.field_1761.method_2896(Spider.mc.field_1724, class_1268.field_5808, hitResult);
                Spider.mc.field_1724.method_6104(class_1268.field_5808);
                if (this.slimeJumpCooldown >= 1) {
                    Spider.mc.field_1724.method_18800(Spider.mc.field_1724.method_18798().field_1352, 0.63, Spider.mc.field_1724.method_18798().field_1350);
                    this.slimeJumpCooldown = 0;
                } else {
                    ++this.slimeJumpCooldown;
                }
            }
        }
    }

    private void handleIceWalk() {
        Spider.mc.field_1724.method_36457(90.0f);
        int blockSlot = this.findIceOrSoulSandSlot();
        if (blockSlot != -1) {
            this.placeBlockBelowPlayer(blockSlot);
        }
    }

    private void handleFunTimeFly() {
        if (!Spider.mc.field_1724.field_5976) {
            return;
        }
        if (!this.jumpDelay.hasReached(1)) {
            return;
        }
        Spider.mc.field_1724.method_24830(true);
        Spider.mc.field_1724.method_6043();
        int rodSlot = this.ensureHotbarSlot(class_1802.field_27051);
        if (rodSlot != -1) {
            this.placeLightningRodsAbovePlayer(rodSlot);
            Spider.mc.field_1724.field_6017 = 0.0f;
            this.jumpDelay.reset();
        }
    }

    private void handleFunSkyWaterBucketClimb() {
        int waterSlot = this.findHotbarSlot(class_1802.field_8705);
        if (waterSlot == -1) {
            return;
        }
        if (Spider.mc.field_1724.method_5799()) {
            Spider.mc.field_1724.method_18800(Spider.mc.field_1724.method_18798().field_1352, 0.46, Spider.mc.field_1724.method_18798().field_1350);
            return;
        }
        if (Spider.mc.field_1724.method_24828()) {
            this.lastWaterBucketUse = 0L;
            this.jumpDelay.reset();
            return;
        }
        if (!this.jumpDelay.hasReached(120)) {
            return;
        }
        if (!this.touchingWall) {
            Spider.mc.field_1690.field_1903.method_23481(false);
            Spider.mc.field_1690.field_1832.method_23481(false);
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastWaterBucketUse >= this.getWaterBucketReuseDelayMs()) {
            Spider.mc.field_1690.field_1903.method_23481(true);
            this.useWaterBucketLookingDown(waterSlot);
            Spider.mc.field_1690.field_1832.method_23481(true);
            this.lastWaterBucketUse = now;
        }
    }

    private void handleSpookyTimeWaterBucketClimb() {
        int waterSlot = this.findHotbarSlot(class_1802.field_8705);
        if (waterSlot == -1) {
            return;
        }
        if (!Spider.mc.field_1724.field_5976) {
            return;
        }
        this.sendUseItemPacketForHotbarSlot(waterSlot);
        Spider.mc.field_1724.method_18800(Spider.mc.field_1724.method_18798().field_1352, 0.29, Spider.mc.field_1724.method_18798().field_1350);
    }

    private void handleGriefCarpet() {
        int carpetSlot = this.findHotbarCarpetSlot();
        if (carpetSlot == -1) {
            return;
        }
        class_2338 playerPos = Spider.mc.field_1724.method_24515();
        class_2338 belowPos = playerPos.method_10074();
        if (!Spider.mc.field_1724.method_24828() && Spider.mc.field_1687.method_8320(playerPos).method_26215() && !Spider.mc.field_1687.method_8320(belowPos).method_26215() && this.carpetDelay.hasReached(1)) {
            int prevSlot = Spider.mc.field_1724.method_31548().field_7545;
            float prevYaw = Spider.mc.field_1724.method_36454();
            float prevPitch = Spider.mc.field_1724.method_36455();
            Spider.mc.field_1724.method_31548().field_7545 = carpetSlot;
            this.interactWithBlockFace(belowPos, class_2350.field_11036);
            Spider.mc.field_1724.method_36456(prevYaw);
            Spider.mc.field_1724.method_36457(prevPitch);
            Spider.mc.field_1724.method_31548().field_7545 = prevSlot;
            this.carpetDelay.reset();
        }
        class_2338 carpetPos = Spider.mc.field_1724.method_24515().method_10074();
        if (Spider.mc.field_1724.method_24828() && Spider.mc.field_1687.method_8320(carpetPos).method_26204() instanceof class_2577) {
            Spider.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, carpetPos, class_2350.field_11036));
            Spider.mc.field_1724.method_6043();
            class_243 vel = Spider.mc.field_1724.method_18798();
            Spider.mc.field_1724.method_18800(vel.field_1352, 0.4, vel.field_1350);
        }
    }

    private void useWheatOnCrosshairBlock(int slot) {
        int prevSlot = Spider.mc.field_1724.method_31548().field_7545;
        Spider.mc.field_1724.method_31548().field_7545 = slot;
        Spider.mc.field_1724.method_36457(75.0f);
        class_3965 hit = this.raycastFromRotation(Spider.mc.field_1724.method_36454(), 75.0f, 4.5);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            Spider.mc.field_1761.method_2896(Spider.mc.field_1724, class_1268.field_5808, hit);
        }
        Spider.mc.field_1724.method_31548().field_7545 = prevSlot;
    }

    private void useWaterBucketLookingDown(int slot) {
        int prevSlot = Spider.mc.field_1724.method_31548().field_7545;
        float prevPitch = Spider.mc.field_1724.method_36455();
        Spider.mc.field_1724.method_31548().field_7545 = slot;
        Spider.mc.field_1724.method_36457(-90.0f);
        Spider.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, 0, Spider.mc.field_1724.method_36454(), Spider.mc.field_1724.method_36455()));
        Spider.mc.field_1724.method_18800(Spider.mc.field_1724.method_18798().field_1352, 0.45, Spider.mc.field_1724.method_18798().field_1350);
        Spider.mc.field_1724.method_36457(prevPitch);
        Spider.mc.field_1724.method_31548().field_7545 = prevSlot;
    }

    private long getWaterBucketReuseDelayMs() {
        double dist = this.getDistanceToGround();
        if (dist < 5.0) {
            return 450L;
        }
        if (dist < 20.0) {
            return 550L;
        }
        return 650L;
    }

    private double getDistanceToGround() {
        double y;
        for (double scanY = y = Spider.mc.field_1724.method_23318(); scanY > (double)Spider.mc.field_1687.method_31607(); scanY -= 0.1) {
            class_2338 pos = class_2338.method_49637((double)Spider.mc.field_1724.method_23317(), (double)scanY, (double)Spider.mc.field_1724.method_23321());
            if (Spider.mc.field_1687.method_8320(pos).method_26215()) continue;
            return Math.max(y - (scanY + 1.0), 0.0);
        }
        return 0.0;
    }

    private int findHotbarSlot(class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            if (Spider.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private int findInventorySlot(class_1792 item) {
        for (int i = 9; i < 36; ++i) {
            if (Spider.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private int ensureHotbarSlot(class_1792 item) {
        int slot = this.findHotbarSlot(item);
        if (slot != -1) {
            return slot;
        }
        int invSlot = this.findInventorySlot(item);
        if (invSlot == -1) {
            return -1;
        }
        int selected = Spider.mc.field_1724.method_31548().field_7545;
        Spider.mc.field_1761.method_2906(Spider.mc.field_1724.field_7498.field_7763, invSlot, selected, class_1713.field_7791, (class_1657)Spider.mc.field_1724);
        return selected;
    }

    private int findIceOrSoulSandSlot() {
        for (int i = 0; i < 9; ++i) {
            class_1792 item = Spider.mc.field_1724.method_31548().method_5438(i).method_7909();
            if (item != class_1802.field_8426 && item != class_1802.field_8081 && item != class_1802.field_8178 && item != class_1802.field_8067) continue;
            return i;
        }
        return -1;
    }

    private int findHotbarCarpetSlot() {
        for (int i = 0; i < 9; ++i) {
            class_1747 blockItem;
            class_1792 class_17922;
            class_1799 stack = Spider.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() || !((class_17922 = stack.method_7909()) instanceof class_1747) || !((blockItem = (class_1747)class_17922).method_7711() instanceof class_2577)) continue;
            return i;
        }
        return -1;
    }

    private void placeBlockBelowPlayer(int slot) {
        class_2338 replacePos = Spider.mc.field_1724.method_24515().method_10074();
        class_2338 supportPos = replacePos.method_10074();
        if (!Spider.mc.field_1687.method_8320(replacePos).method_45474()) {
            return;
        }
        if (Spider.mc.field_1687.method_8320(supportPos).method_26215()) {
            return;
        }
        int prevSlot = Spider.mc.field_1724.method_31548().field_7545;
        Spider.mc.field_1724.method_31548().field_7545 = slot;
        Spider.mc.field_1724.method_36457(90.0f);
        class_243 hitPos = new class_243((double)supportPos.method_10263() + 0.5, (double)supportPos.method_10264() + 1.0, (double)supportPos.method_10260() + 0.5);
        class_3965 hit = new class_3965(hitPos, class_2350.field_11036, supportPos, false);
        Spider.mc.field_1761.method_2896(Spider.mc.field_1724, class_1268.field_5808, hit);
        Spider.mc.field_1724.method_31548().field_7545 = prevSlot;
    }

    private void placeLightningRodsAbovePlayer(int slot) {
        int prevSlot = Spider.mc.field_1724.method_31548().field_7545;
        Spider.mc.field_1724.method_31548().field_7545 = slot;
        class_2338 pos = Spider.mc.field_1724.method_24515();
        for (int i = 1; i <= 2; ++i) {
            class_2338 up = pos.method_10086(i);
            if (!Spider.mc.field_1687.method_8320(up).method_26215()) continue;
            class_243 hitPos = new class_243((double)up.method_10263() + 0.5, (double)up.method_10264() + 0.5, (double)up.method_10260() + 0.5);
            class_3965 hit = new class_3965(hitPos, class_2350.field_11036, up.method_10074(), false);
            Spider.mc.field_1761.method_2896(Spider.mc.field_1724, class_1268.field_5808, hit);
            Spider.mc.field_1724.method_6104(class_1268.field_5808);
        }
        Spider.mc.field_1724.method_31548().field_7545 = prevSlot;
    }

    private void interactWithBlockFace(class_2338 pos, class_2350 side) {
        this.rotateToward(pos);
        class_243 hitPos = class_243.method_24953((class_2382)pos);
        class_3965 hit = new class_3965(hitPos, side, pos, false);
        Spider.mc.field_1761.method_2896(Spider.mc.field_1724, class_1268.field_5808, hit);
        Spider.mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void rotateToward(class_2338 pos) {
        class_243 eyes = Spider.mc.field_1724.method_33571();
        class_243 center = class_243.method_24953((class_2382)pos);
        double dx = center.field_1352 - eyes.field_1352;
        double dy = center.field_1351 - eyes.field_1351;
        double dz = center.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        Spider.mc.field_1724.method_36456((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        Spider.mc.field_1724.method_36457((float)(-Math.toDegrees(Math.atan2(dy, dist))));
    }

    private class_3965 raycastFromRotation(float yaw, float pitch, double range) {
        class_243 eyes = Spider.mc.field_1724.method_33571();
        class_243 dir = class_243.method_1030((float)pitch, (float)yaw).method_1029();
        class_243 end = eyes.method_1019(dir.method_1021(range));
        class_3959 context = new class_3959(eyes, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Spider.mc.field_1724);
        return Spider.mc.field_1687.method_17742(context);
    }

    private void sendUseItemPacketForHotbarSlot(int slot) {
        int prevSlot = Spider.mc.field_1724.method_31548().field_7545;
        if (slot != prevSlot) {
            Spider.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot));
        }
        Spider.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, 0, Spider.mc.field_1724.method_36454(), Spider.mc.field_1724.method_36455()));
        if (slot != prevSlot) {
            Spider.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(prevSlot));
        }
    }
}

