/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2886
 *  net.minecraft.class_3675
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.OffhandSlot;
import micronix.experiment.utility.rotations.RotationMath;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_2886;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

@ModuleInfo(name="High Jump", category=ModuleCategory.MOVEMENT)
@Environment(value=EnvType.CLIENT)
public class HighJump
extends BaseModule {
    @Override
    public void tick() {
        HighJump.mc.field_1690.field_1832.method_23481(true);
        HighJump.mc.field_1724.method_36457(90.0f);
        HighJump.mc.field_1690.field_1904.method_23481(true);
        if (HighJump.mc.field_1724.method_24828() && !HighJump.mc.field_1724.method_7357().method_7904(class_1802.field_49098.method_7854())) {
            this.useWindCharge();
        }
    }

    @Override
    public void onDisable() {
        int keyCode = class_3675.method_15981((String)HighJump.mc.field_1690.field_1832.method_1428()).method_1444();
        HighJump.mc.field_1690.field_1832.method_23481(class_3675.method_15987((long)mc.method_22683().method_4490(), (int)keyCode));
        keyCode = class_3675.method_15981((String)HighJump.mc.field_1690.field_1904.method_1428()).method_1444();
        HighJump.mc.field_1690.field_1904.method_23481(class_3675.method_15987((long)mc.method_22683().method_4490(), (int)keyCode));
    }

    private void useWindCharge() {
        if (HighJump.mc.field_1687 == null || HighJump.mc.field_1724 == null || HighJump.mc.field_1761 == null) {
            return;
        }
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.offhand().and(SlotGroups.hotbar());
        ItemSlot slot = slotsToSearch.findItem(class_1802.field_49098);
        boolean isOffhand = slot instanceof OffhandSlot;
        if (slot != null) {
            float pitch;
            HotbarSlot hotbarSlot;
            int oldHotbarSlotId = HighJump.mc.field_1724.method_31548().field_7545;
            if (slot instanceof HotbarSlot && HighJump.mc.field_1724.method_31548().field_7545 != (hotbarSlot = (HotbarSlot)slot).getSlotId()) {
                InventoryUtility.selectHotbarSlot(hotbarSlot);
            }
            class_1268 hand = isOffhand ? class_1268.field_5810 : class_1268.field_5808;
            float yaw = HighJump.mc.field_1724.method_36454();
            if (!HighJump.mc.field_1724.method_24828() && EntityUtility.getBlock(0.0, -2.0, 0.0) == class_2246.field_10124 && HighJump.mc.field_1724.method_18798().field_1351 > (double)0.4f) {
                pitch = 75.0f;
                for (int i = 0; i < 360; i += 45) {
                    class_3965 result = HighJump.mc.field_1687.method_17742(new class_3959(HighJump.mc.field_1724.method_33571(), HighJump.mc.field_1724.method_33571().method_1019(HighJump.mc.field_1724.method_5631(pitch, (float)i).method_1021(1.5)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)HighJump.mc.field_1724));
                    if (result.method_17783() != class_239.class_240.field_1332) continue;
                    yaw = RotationMath.adjustAngle(HighJump.mc.field_1724.method_36454(), i);
                }
            } else {
                pitch = 90.0f;
            }
            float finalYaw = yaw;
            HighJump.mc.field_1761.method_41931(HighJump.mc.field_1687, sequence -> new class_2886(hand, sequence, finalYaw, pitch));
            HighJump.mc.field_1724.method_6104(hand);
            if (slot instanceof HotbarSlot) {
                InventoryUtility.selectHotbarSlot(oldHotbarSlotId);
            }
        }
    }
}

