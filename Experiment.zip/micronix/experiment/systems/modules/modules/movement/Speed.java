/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1735
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2848
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_2868
 *  net.minecraft.class_2885
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.rotations.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_3965;

@ModuleInfo(name="Speed", category=ModuleCategory.MOVEMENT, desc="modules.descriptions.speed")
@Environment(value=EnvType.CLIENT)
public class Speed
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.speed.mode");
    private final ModeSetting.Value vanilla = new ModeSetting.Value(this.mode, "modules.settings.speed.vanilla");
    private final ModeSetting.Value elytra = new ModeSetting.Value(this.mode, "Spooky Elytra");
    private final ModeSetting.Value metaHvh = new ModeSetting.Value(this.mode, "MetaHvH");
    private static final float META_HVH_BASE_SPEED = 0.36f;

    @Override
    public void tick() {
        SlotGroup<HotbarSlot> slotsToSearch;
        HotbarSlot slot;
        if (this.metaHvh.isSelected()) {
            int amplifier;
            String itemName;
            class_1799 offhandItem = Speed.mc.field_1724.method_6079();
            class_1293 speedEffect = Speed.mc.field_1724.method_6112(class_1294.field_5904);
            class_1293 slowEffect = Speed.mc.field_1724.method_6112(class_1294.field_5909);
            String string = itemName = offhandItem.method_7960() ? "" : offhandItem.method_7964().getString();
            float appliedSpeed = speedEffect != null ? ((amplifier = speedEffect.method_5578()) >= 2 ? 0.4158f : (amplifier >= 1 ? 0.36f : 0.30600002f)) : 0.24480002f;
            if (!itemName.isEmpty() && itemName.contains("\u041b\u043e\u043c\u0442\u0438\u043a \u0414\u044b\u043d\u0438")) {
                float f = appliedSpeed = speedEffect != null && speedEffect.method_5578() >= 2 ? 0.41755f : 0.217126f;
            }
            if (slowEffect != null) {
                appliedSpeed *= 0.835f;
            }
            if (!Speed.mc.field_1724.method_24828()) {
                appliedSpeed *= 1.435f;
            }
            EntityUtility.setSpeed(appliedSpeed);
        } else if (this.vanilla.isSelected()) {
            class_2338 pos = Speed.mc.field_1724.method_24515().method_10069(0, -1, 0);
            Speed.mc.field_1690.field_1832.method_23481(false);
            Experiment.getInstance().getRotationHandler().rotate(new Rotation(Speed.mc.field_1724.method_36454(), 90.0f));
            if (Speed.mc.field_1724.method_24828() && !Speed.mc.field_1690.field_1903.method_1434()) {
                Speed.mc.field_1724.method_6043();
                class_243 velocity = Speed.mc.field_1724.method_18798();
                Speed.mc.field_1724.method_18800(velocity.field_1352, velocity.field_1351 - (double)0.4f, velocity.field_1350);
                class_2338 target5 = Speed.mc.field_1724.method_24515().method_10069(0, 1, 0);
                class_2338 target = Speed.mc.field_1724.method_24515();
                class_2338 target1 = Speed.mc.field_1724.method_24515().method_10069(0, -1, 0);
                class_2338 target2 = Speed.mc.field_1724.method_24515().method_10069(0, -2, 0);
                Speed.mc.field_1687.method_8501(target1, class_2246.field_10295.method_9564());
                class_243 vector3d = new class_243((double)target.method_10263(), (double)target.method_10264(), (double)target.method_10260());
                class_3965 result = new class_3965(vector3d, class_2350.field_11036, target, false);
                class_243 vector3d1 = new class_243((double)target1.method_10263(), (double)target1.method_10264(), (double)target1.method_10260());
                class_3965 result1 = new class_3965(vector3d1, class_2350.field_11036, target1, false);
                class_243 vector3d2 = new class_243((double)target2.method_10263(), (double)target2.method_10264(), (double)target2.method_10260());
                class_3965 result2 = new class_3965(vector3d2, class_2350.field_11036, target2, false);
                Speed.mc.field_1724.field_3944.method_52787((class_2596)new class_2885(class_1268.field_5810, result1, 0));
            }
        } else if (this.elytra.isSelected() && (slot = (slotsToSearch = SlotGroups.hotbar()).findItem(class_1802.field_8833)) != null && Speed.mc.field_1724.field_6017 > 1.0f) {
            HotbarSlot currentItem = InventoryUtility.getCurrentHotbarSlot();
            Speed.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
            InventoryUtility.selectHotbarSlot(slot);
            Speed.mc.field_1761.method_2919((class_1657)Speed.mc.field_1724, class_1268.field_5808);
            ((class_1735)Speed.mc.field_1724.field_7512.field_7761.get(6)).method_53512(new class_1799((class_1935)class_1802.field_8833));
            if (Speed.mc.field_1724.method_5624() && Speed.mc.field_1724.field_3913.method_20622() && Speed.mc.field_1724.method_23668()) {
                Speed.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Speed.mc.field_1724, class_2848.class_2849.field_12982));
            }
            InventoryUtility.selectHotbarSlot(currentItem);
            Speed.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(Speed.mc.field_1724.method_31548().field_7545));
        }
        super.tick();
    }

    @Override
    public void onDisable() {
        EntityUtility.resetTimer();
        super.onDisable();
    }
}

