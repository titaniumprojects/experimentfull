/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2246
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.CollisionShapeEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2246;

@ModuleInfo(name="No Web", category=ModuleCategory.MOVEMENT)
@Environment(value=EnvType.CLIENT)
public class NoWeb
extends BaseModule {
    private final EventListener<CollisionShapeEvent> onCollision = event -> {
        if ((event.getState().method_26204() == class_2246.field_10343 || event.getState().method_26204() == class_2246.field_16999) && this.lengthSquared() > 1.0E-7 && NoWeb.mc.field_1690.field_1894.method_1434()) {
            EntityUtility.setSpeed(0.66f);
            if (ServerUtility.isFT() || ServerUtility.isST()) {
                EntityUtility.setSpeed(0.12f);
            }
        }
    };

    public double lengthSquared() {
        return NoWeb.mc.field_1724.method_23317() * NoWeb.mc.field_1724.method_23317() + NoWeb.mc.field_1724.method_23318() * NoWeb.mc.field_1724.method_23318() + NoWeb.mc.field_1724.method_23321() * NoWeb.mc.field_1724.method_23321();
    }
}

