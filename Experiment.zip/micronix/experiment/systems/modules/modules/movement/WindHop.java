/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1738
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2886
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_8051
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.EntityJumpEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.ArmorSlot;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.OffhandSlot;
import micronix.experiment.utility.mixins.ArmorItemAddition;
import micronix.experiment.utility.rotations.RotationMath;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_2886;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_8051;

@ModuleInfo(name="Wind Hop", category=ModuleCategory.MOVEMENT, desc="modules.descriptions.wind_hop")
@Environment(value=EnvType.CLIENT)
public class WindHop
extends BaseModule {
    private final BooleanSetting autoJump = new BooleanSetting((SettingsContainer)this, "modules.settings.wind_hop.autoJump", "modules.settings.wind_hop.autoJump.description").enable();
    private final BooleanSetting swingArm = new BooleanSetting((SettingsContainer)this, "modules.settings.wind_hop.swingArm", "modules.settings.wind_hop.swingArm.description").enable();
    private final BooleanSetting predictJump = new BooleanSetting((SettingsContainer)this, "modules.settings.wind_hop.predictJump", "modules.settings.wind_hop.predictJump.description").enable();
    private boolean elytra;
    private final EventListener<EntityJumpEvent> onJump = event -> {
        if (event.getEntity() == WindHop.mc.field_1724) {
            this.useWindCharge();
        }
    };

    private void swapElytraChestplate() {
        ArmorSlot chestplateSlot = InventoryUtility.getChestplateSlot();
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar());
        ItemSlot elytraItemSlot = slotsToSearch.findItem(itemStack -> itemStack.method_7909() == class_1802.field_8833 && !itemStack.method_63692());
        ItemSlot chestplateItemSlot = slotsToSearch.findItem(itemStack -> {
            class_1738 armorItem;
            class_1792 patt0$temp = itemStack.method_7909();
            return patt0$temp instanceof class_1738 && ((ArmorItemAddition)(armorItem = (class_1738)patt0$temp)).experiment$getType() == class_8051.field_41935;
        });
        boolean isElytraEquipped = chestplateSlot.item() == class_1802.field_8833;
        boolean bl = isElytraEquipped;
        if (!isElytraEquipped && elytraItemSlot != null) {
            elytraItemSlot.swapTo(chestplateSlot);
        } else if (chestplateItemSlot != null) {
            chestplateItemSlot.swapTo(chestplateSlot);
        }
    }

    @Override
    public void tick() {
        if (WindHop.mc.field_1724 == null || WindHop.mc.field_1687 == null) {
            return;
        }
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.offhand().and(SlotGroups.hotbar());
        ItemSlot slot = slotsToSearch.findItem(class_1802.field_49098);
        boolean canUse = false;
        if (!WindHop.mc.field_1724.method_24828() && EntityUtility.getBlock(0.0, -2.0, 0.0) == class_2246.field_10124 && WindHop.mc.field_1724.method_18798().field_1351 > (double)0.4f) {
            float pitch = 75.0f;
            for (int i = 0; i < 360; i += 45) {
                class_3965 result = WindHop.mc.field_1687.method_17742(new class_3959(WindHop.mc.field_1724.method_33571(), WindHop.mc.field_1724.method_33571().method_1019(WindHop.mc.field_1724.method_5631(pitch, (float)i).method_1021(1.5)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)WindHop.mc.field_1724));
                if (result.method_17783() != class_239.class_240.field_1332) continue;
                canUse = true;
            }
        } else {
            canUse = this.predictJump.isEnabled() && EntityUtility.getBlock(0.0, -1.0, 0.0) != class_2246.field_10124 && WindHop.mc.field_1724.field_6017 > 2.0f;
            boolean bl = canUse;
        }
        if (canUse && (WindHop.mc.field_1690.field_1903.method_1434() || this.autoJump.isEnabled()) && slot != null) {
            this.useWindCharge();
        }
        if (WindHop.mc.field_1724.method_24828() && this.autoJump.isEnabled() && slot != null) {
            WindHop.mc.field_1724.method_6043();
        }
        super.tick();
    }

    private void useWindCharge() {
        if (WindHop.mc.field_1687 == null || WindHop.mc.field_1724 == null || WindHop.mc.field_1761 == null) {
            return;
        }
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.offhand().and(SlotGroups.hotbar());
        ItemSlot slot = slotsToSearch.findItem(class_1802.field_49098);
        boolean isOffhand = slot instanceof OffhandSlot;
        if (slot != null) {
            float pitch;
            HotbarSlot hotbarSlot;
            int oldHotbarSlotId = WindHop.mc.field_1724.method_31548().field_7545;
            if (slot instanceof HotbarSlot && WindHop.mc.field_1724.method_31548().field_7545 != (hotbarSlot = (HotbarSlot)slot).getSlotId()) {
                InventoryUtility.selectHotbarSlot(hotbarSlot);
            }
            class_1268 hand = isOffhand ? class_1268.field_5810 : class_1268.field_5808;
            float yaw = WindHop.mc.field_1724.method_36454();
            if (!WindHop.mc.field_1724.method_24828() && EntityUtility.getBlock(0.0, -2.0, 0.0) == class_2246.field_10124 && WindHop.mc.field_1724.method_18798().field_1351 > (double)0.4f) {
                pitch = 75.0f;
                for (int i = 0; i < 360; i += 45) {
                    class_3965 result = WindHop.mc.field_1687.method_17742(new class_3959(WindHop.mc.field_1724.method_33571(), WindHop.mc.field_1724.method_33571().method_1019(WindHop.mc.field_1724.method_5631(pitch, (float)i).method_1021(1.5)), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)WindHop.mc.field_1724));
                    if (result.method_17783() != class_239.class_240.field_1332) continue;
                    yaw = RotationMath.adjustAngle(WindHop.mc.field_1724.method_36454(), i);
                }
            } else {
                pitch = 90.0f;
            }
            float finalYaw = yaw;
            WindHop.mc.field_1761.method_41931(WindHop.mc.field_1687, sequence -> new class_2886(hand, sequence, finalYaw, pitch));
            if (this.swingArm.isEnabled()) {
                WindHop.mc.field_1724.method_6104(hand);
            }
            if (slot instanceof HotbarSlot) {
                InventoryUtility.selectHotbarSlot(oldHotbarSlotId);
            }
        }
    }
}

