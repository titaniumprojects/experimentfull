/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1802
 *  net.minecraft.class_2596
 *  net.minecraft.class_2848
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_2868
 *  net.minecraft.class_2886
 */
package micronix.experiment.systems.modules.modules.movement;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2886;

@ModuleInfo(name="Elytra Strafe", category=ModuleCategory.MOVEMENT)
@Environment(value=EnvType.CLIENT)
public class ElytraStrafe
extends BaseModule {
    private final SliderSetting fireworkSlot = new SliderSetting(this, "modules.settings.elytra_target.fireworkSlot").min(1.0f).max(9.0f).step(1.0f).currentValue(7.0f).suffix(" slot");
    private final SliderSetting fireworkDelay = new SliderSetting(this, "modules.settings.elytra_target.fireworkDelay").min(0.1f).max(2.0f).step(0.1f).currentValue(1.0f).suffix(" sec");
    private final BooleanSetting autoTakeoff = new BooleanSetting(this, "modules.settings.elytra_strafe.autoTakeoff").enable();
    private final Timer fireworkTimer = new Timer();
    private final EventListener<InputEvent> onInput = event -> {
        float pitch = 0.0f;
        if (ElytraStrafe.mc.field_1724 == null || !ElytraStrafe.mc.field_1724.method_6128()) {
            return;
        }
        float yaw = (float)Math.toDegrees(EntityUtility.direction(ElytraStrafe.mc.field_1724.method_36454(), event.getForward(), event.getStrafe()));
        if (ElytraStrafe.mc.field_1690.field_1832.method_1434() || ElytraStrafe.mc.field_1690.field_1903.method_1434()) {
            float f = pitch = event.getStrafe() + event.getForward() > 0.1f ? -45.0f : -90.0f;
        }
        if (ElytraStrafe.mc.field_1690.field_1832.method_1434()) {
            pitch *= -1.0f;
        }
        Experiment.getInstance().getRotationHandler().rotate(new Rotation(yaw, pitch), MoveCorrection.DIRECT, 180.0f, 180.0f, 180.0f, RotationPriority.NOT_IMPORTANT);
    };

    @Override
    public void tick() {
        if (ElytraStrafe.mc.field_1724 == null) {
            return;
        }
        if (this.autoTakeoff.isEnabled()) {
            boolean isElytraEquipped = InventoryUtility.getChestplateSlot().item() == class_1802.field_8833;
            boolean bl = isElytraEquipped;
            if (!ElytraStrafe.mc.field_1724.method_6128() && isElytraEquipped && !ElytraStrafe.mc.field_1724.method_24828() && !ElytraStrafe.mc.field_1724.method_52535()) {
                ElytraStrafe.mc.field_1724.method_23669();
                ElytraStrafe.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)ElytraStrafe.mc.field_1724, class_2848.class_2849.field_12982));
            } else if (ElytraStrafe.mc.field_1724.method_24828() && isElytraEquipped && !ElytraStrafe.mc.field_1724.method_52535() && !ElytraStrafe.mc.field_1724.method_6128()) {
                ElytraStrafe.mc.field_1724.method_6043();
            }
        }
        if (!ElytraStrafe.mc.field_1724.method_6128()) {
            return;
        }
        if (this.fireworkTimer.finished((long)(this.fireworkDelay.getCurrentValue() * 1000.0f)) && !ElytraStrafe.mc.field_1724.method_6115()) {
            this.useFirework();
        }
    }

    private void useFirework() {
        SlotGroup<HotbarSlot> slotsToSearch = SlotGroups.hotbar();
        HotbarSlot slot = slotsToSearch.findItem(class_1802.field_8639);
        if (slot != null) {
            ElytraStrafe.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
            ElytraStrafe.mc.field_1761.method_41931(ElytraStrafe.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, ElytraStrafe.mc.field_1724.method_36454(), ElytraStrafe.mc.field_1724.method_36455()));
            ElytraStrafe.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(ElytraStrafe.mc.field_1724.method_31548().field_7545));
            this.fireworkTimer.reset();
            return;
        }
        SlotGroup<InventorySlot> search = SlotGroups.inventory();
        InventorySlot invSlot = search.findItem(class_1802.field_8639);
        if (invSlot != null) {
            InventoryUtility.hotbarSwap(invSlot.getIdForServer(), (int)(this.fireworkSlot.getCurrentValue() - 1.0f));
            this.fireworkTimer.reset();
        }
    }
}

