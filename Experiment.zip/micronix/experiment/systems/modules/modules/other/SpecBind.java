/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Spec Bind", category=ModuleCategory.OTHER, desc="\u041e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u0443 !\u0421\u043f\u0435\u043a \u0441 \u0432\u0430\u0448\u0438\u043c \u043d\u0438\u043a\u043e\u043c \u0432 \u0447\u0430\u0442 \u043f\u043e \u043d\u0430\u0436\u0430\u0442\u0438\u044e \u0431\u0438\u043d\u0434\u0430")
@Environment(value=EnvType.CLIENT)
public class SpecBind
extends BaseModule {
    private final BindSetting specKey = new BindSetting(this, "\u0411\u0438\u043d\u0434 \u0441\u043f\u0435\u043a\u0430").key(-1);
    private long lastSpecMs = 0L;
    private final EventListener<KeyPressEvent> onKeyPress = event -> {
        if (this.isEnabled() && SpecBind.mc.field_1724 != null && event.getAction() == 1 && SpecBind.mc.field_1755 == null && this.specKey.isKey(event.getKey())) {
            long now = System.currentTimeMillis();
            if (now - this.lastSpecMs < 400L) {
                return;
            }
            this.lastSpecMs = now;
            this.handleSpec();
        }
    };

    private void handleSpec() {
        if (SpecBind.mc.field_1724 != null) {
            String playerName = SpecBind.mc.field_1724.method_5477().getString();
            String command = "!\u0421\u043f\u0435\u043a " + playerName;
            if (SpecBind.mc.field_1724.field_3944 != null) {
                SpecBind.mc.field_1724.field_3944.method_45729(command);
                Experiment.getInstance().getNotificationManager().addNotification(NotificationType.SUCCESS, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0430");
                ClientSounds.MODULE.play(1.0f, 1.1f);
            } else {
                ClientSounds.CRITICAL.play(1.0f, 1.0f);
            }
        }
    }

    @Override
    public void onEnable() {
        this.lastSpecMs = 0L;
    }
}

