/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

@ModuleInfo(name="Inventory Cleaner", category=ModuleCategory.OTHER, desc="\u041e\u0447\u0438\u0449\u0430\u0435\u0442 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u044c \u043e\u0442 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u043d\u044b\u0445 \u0431\u043b\u043e\u043a\u043e\u0432")
@Environment(value=EnvType.CLIENT)
public class InventoryCleaner
extends BaseModule {
    private final Timer timer = new Timer();
    private final List<class_1792> items = List.of(class_1802.field_20391, class_1802.field_20412, class_1802.field_20394, class_1802.field_8599, class_1802.field_8775, class_1802.field_8809);
    private final List<ItemSlot> slots = new ArrayList<ItemSlot>();
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (!this.isEnabled() || InventoryCleaner.mc.field_1724 == null || InventoryCleaner.mc.field_1724.field_7512 == null) {
            return;
        }
        if (this.timer.finished(150L)) {
            this.slots.clear();
            SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar());
            for (class_1792 item : this.items) {
                ItemSlot itemSlot = slotsToSearch.findItem(item);
                if (itemSlot == null) continue;
                this.slots.add(itemSlot);
            }
            if (this.slots.isEmpty()) {
                return;
            }
            ItemSlot slot = this.slots.removeFirst();
            InventoryCleaner.mc.field_1761.method_2906(InventoryCleaner.mc.field_1724.field_7512.field_7763, slot.getIdForServer(), 1, class_1713.field_7795, (class_1657)InventoryCleaner.mc.field_1724);
            this.timer.reset();
        }
    };
}

