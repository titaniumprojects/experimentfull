/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1113
 *  net.minecraft.class_1294
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.Random;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.sounds.ClientSoundInstance;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1113;
import net.minecraft.class_1294;

@ModuleInfo(name="Hit Sound", category=ModuleCategory.OTHER, desc="modules.descriptions.hit_sound")
@Environment(value=EnvType.CLIENT)
public class HitSound
extends BaseModule {
    private final Random random = new Random();
    private final BooleanSetting onlyCritical = new BooleanSetting((SettingsContainer)this, "modules.settings.hit_sound.only_critical", "modules.settings.hit_sound.only_critical.description");
    private final ModeSetting soundMode = new ModeSetting(this, "modules.settings.hit_sound.sound");
    private final ModeSetting.Value hit1 = new ModeSetting.Value(this.soundMode, "Hit 1").select();
    private final ModeSetting.Value hit2 = new ModeSetting.Value(this.soundMode, "Hit 2");
    private final ModeSetting.Value bell = new ModeSetting.Value(this.soundMode, "Bell");
    private final ModeSetting.Value bonk = new ModeSetting.Value(this.soundMode, "Bonk");
    private final ModeSetting.Value bubble = new ModeSetting.Value(this.soundMode, "Bubble");
    private final ModeSetting.Value krit = new ModeSetting.Value(this.soundMode, "Krit");
    private final ModeSetting.Value pop = new ModeSetting.Value(this.soundMode, "Pop");
    private final ModeSetting.Value uwu = new ModeSetting.Value(this.soundMode, "UwU");
    private final ModeSetting.Value moan1 = new ModeSetting.Value(this.soundMode, "Moan 1");
    private final ModeSetting.Value moan2 = new ModeSetting.Value(this.soundMode, "Moan 2");
    private final ModeSetting.Value moan3 = new ModeSetting.Value(this.soundMode, "Moan 3");
    private final ModeSetting.Value moan4 = new ModeSetting.Value(this.soundMode, "Moan 4");
    private final ModeSetting.Value randomMode = new ModeSetting.Value(this.soundMode, "Random");
    private final SliderSetting volume = new SliderSetting((SettingsContainer)this, "modules.settings.hit_sound.volume", "modules.settings.hit_sound.volume.description").min(0.1f).max(2.0f).step(0.1f).currentValue(1.0f);
    private final SliderSetting pitch = new SliderSetting((SettingsContainer)this, "modules.settings.hit_sound.pitch", "modules.settings.hit_sound.pitch.description").min(0.5f).max(2.0f).step(0.1f).currentValue(1.0f);
    private final EventListener<AttackEvent> onAttack = event -> {
        if (HitSound.mc.field_1687 != null && HitSound.mc.field_1724 != null && event.getEntity() != null) {
            mc.execute(() -> {
                ClientSoundInstance sound;
                if (this.onlyCritical.isEnabled()) {
                    boolean isCritical;
                    boolean bl = isCritical = HitSound.mc.field_1724.field_6017 > 0.0f && !HitSound.mc.field_1724.method_24828() && !HitSound.mc.field_1724.method_6101() && !HitSound.mc.field_1724.method_5799() && !HitSound.mc.field_1724.method_6059(class_1294.field_5919);
                    if (!isCritical) {
                        return;
                    }
                }
                if ((sound = this.getSelectedSound()) != null) {
                    mc.method_1483().method_4873((class_1113)new ClientSoundInstance(sound.getFileName(), this.volume.getCurrentValue(), this.pitch.getCurrentValue()));
                }
            });
        }
    };

    private ClientSoundInstance getSelectedSound() {
        if (this.soundMode.is(this.hit1)) {
            return ClientSounds.HITSOUND1;
        }
        if (this.soundMode.is(this.hit2)) {
            return ClientSounds.HITSOUND2;
        }
        if (this.soundMode.is(this.bell)) {
            return ClientSounds.HITSOUND3;
        }
        if (this.soundMode.is(this.bonk)) {
            return ClientSounds.HITSOUND4;
        }
        if (this.soundMode.is(this.bubble)) {
            return ClientSounds.HITSOUND5;
        }
        if (this.soundMode.is(this.krit)) {
            return ClientSounds.HITSOUND6;
        }
        if (this.soundMode.is(this.pop)) {
            return ClientSounds.HITSOUND7;
        }
        if (this.soundMode.is(this.uwu)) {
            return ClientSounds.HITSOUND8;
        }
        if (this.soundMode.is(this.moan1)) {
            return ClientSounds.MOAN1;
        }
        if (this.soundMode.is(this.moan2)) {
            return ClientSounds.MOAN2;
        }
        if (this.soundMode.is(this.moan3)) {
            return ClientSounds.MOAN3;
        }
        if (this.soundMode.is(this.moan4)) {
            return ClientSounds.MOAN4;
        }
        if (this.soundMode.is(this.randomMode)) {
            ClientSoundInstance[] hitSounds = new ClientSoundInstance[]{ClientSounds.HITSOUND1, ClientSounds.HITSOUND2, ClientSounds.HITSOUND3, ClientSounds.HITSOUND4, ClientSounds.HITSOUND5, ClientSounds.HITSOUND6, ClientSounds.HITSOUND7, ClientSounds.HITSOUND8};
            return hitSounds[this.random.nextInt(hitSounds.length)];
        }
        return ClientSounds.HITSOUND1;
    }
}

