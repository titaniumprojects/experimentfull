/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1802
 *  net.minecraft.class_2596
 *  net.minecraft.class_2886
 *  net.minecraft.class_7439
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2886;
import net.minecraft.class_7439;

@ModuleInfo(name="Auto Join", category=ModuleCategory.OTHER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0437\u0430\u0445\u043e\u0434\u0438\u0442 \u043d\u0430 \u0440\u0435\u0436\u0438\u043c")
@Environment(value=EnvType.CLIENT)
public class AutoJoin
extends BaseModule {
    private final String griefString = "306";
    private final ModeSetting mode = new ModeSetting(this, "\u0420\u0435\u0436\u0438\u043c");
    private final ModeSetting.Value duels = new ModeSetting.Value(this.mode, "\u0414\u0443\u044d\u043b\u0438 SpookyTime").select();
    private final ModeSetting.Value grief = new ModeSetting.Value(this.mode, "\u0413\u0440\u0438\u0444 RW/FT/Spooky");
    private final Timer timer = new Timer();
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (ServerUtility.isST() && this.duels.isSelected()) {
            SlotGroup<HotbarSlot> search = SlotGroups.hotbar();
            HotbarSlot compass = search.findItem(class_1802.field_8251);
            HotbarSlot sword = search.findItem(class_1802.field_8802);
            if (compass != null && this.timer.finished(300L)) {
                AutoJoin.mc.field_1724.method_31548().field_7545 = compass.getSlotId();
                AutoJoin.mc.field_1761.method_41931(AutoJoin.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, AutoJoin.mc.field_1724.method_36454(), AutoJoin.mc.field_1724.method_36455()));
                if (AutoJoin.mc.field_1724.field_7512 instanceof class_1707 && AutoJoin.mc.field_1755.method_25440().getString().contains("\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043c")) {
                    AutoJoin.mc.field_1761.method_2906(AutoJoin.mc.field_1724.field_7512.field_7763, 14, 0, class_1713.field_7794, (class_1657)AutoJoin.mc.field_1724);
                }
                this.timer.reset();
            }
            if (sword != null) {
                Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, "\u0423\u0441\u043f\u0435\u0448\u043d\u044b\u0439 \u0432\u0445\u043e\u0434", "\u0412\u044b \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0432\u043e\u0448\u043b\u0438 \u043d\u0430 \u0434\u0443\u044d\u043b\u0438");
                this.toggle();
            }
        }
        if ((ServerUtility.isFT() || ServerUtility.isRW() || ServerUtility.isST()) && this.grief.isSelected()) {
            AutoJoin.mc.field_1724.field_3944.method_45730("an306");
        }
    };
    private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_7439) {
            class_7439 packet = (class_7439)patt0$temp;
            if ((ServerUtility.isFT() || ServerUtility.isRW() || ServerUtility.isST()) && this.grief.isSelected()) {
                String message = packet.comp_763().getString().toLowerCase();
                if (ServerUtility.isFT() ? message.contains("\u0432\u044b \u0443\u0436\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u044b \u043a \u044d\u0442\u043e\u043c\u0443 \u0441\u0435\u0440\u0432\u0435\u0440\u0432\u0443!") : message.contains("\u0432\u044b \u0443\u0436\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u044b \u043d\u0430 \u044d\u0442\u043e\u0442 \u0441\u0435\u0440\u0432\u0435\u0440!")) {
                    this.toggle();
                }
            }
        }
    };
}

