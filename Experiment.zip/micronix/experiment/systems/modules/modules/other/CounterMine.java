/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2735
 *  net.minecraft.class_2828$class_2830
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_337
 *  net.minecraft.class_345
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 *  net.minecraft.class_5498
 *  net.minecraft.class_7225$class_7874
 *  net.minecraft.class_8113$class_8122
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.other;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import micronix.experiment.Experiment;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.EntityJumpEvent;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.game.countermine.AntiAim;
import micronix.experiment.utility.game.countermine.CMUtility;
import micronix.experiment.utility.game.countermine.Point;
import micronix.experiment.utility.game.countermine.PositionScanner;
import micronix.experiment.utility.game.countermine.RageBot;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2735;
import net.minecraft.class_2828;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_337;
import net.minecraft.class_345;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_5498;
import net.minecraft.class_7225;
import net.minecraft.class_8113;
import net.minecraft.class_9801;

@ModuleInfo(name="Counter Mine", category=ModuleCategory.OTHER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0443\u0431\u0438\u0432\u0430\u0435\u0442 \u043a\u0440\u0438\u043f\u0435\u0440\u043e\u0432 \u043d\u0430 \u0444\u0430\u0440\u043c\u0438\u043b\u043a\u0435")
@Environment(value=EnvType.CLIENT)
public class CounterMine
extends BaseModule {
    private final BooleanSetting moderDetect = new BooleanSetting(this, "ModerDetect");
    private final BooleanSetting wallHack = new BooleanSetting(this, "WallHack");
    private final BooleanSetting noF5 = new BooleanSetting(this, "No F5");
    private final BooleanSetting noSmoke = new BooleanSetting(this, "HideSmoke");
    private final BooleanSetting hideScope = new BooleanSetting(this, "HideScope");
    private final BindSetting pickAssist = new BindSetting(this, "Pick Assist");
    private final BindSetting minDamageBind = new BindSetting(this, "MinDamage");
    private boolean minDamage;
    private final Timer moderTimer = new Timer();
    private final AntiAim antiAim;
    private final RageBot rageBot;
    private final PositionScanner scanner = new PositionScanner();
    private final Timer jumping = new Timer();
    private boolean jump = true;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (this.moderTimer.finished(5000L)) {
            List<String> moders = Arrays.asList("corisabi", "petiuka", "johnebik", "sherlock");
            for (String moderator : moders) {
                if (!CMUtility.isPlayerOnline(moderator)) continue;
                MessageUtility.info(class_2561.method_30163((String)("\u041e\u0431\u043d\u0430\u0440\u0443\u0436\u0435\u043d \u043c\u043e\u0434\u0435\u0440\u0430\u0442\u043e\u0440: " + moderator)));
                if (this.moderDetect.isEnabled()) {
                    CounterMine.mc.field_1724.field_3944.method_45730("hub");
                }
                this.moderTimer.reset();
                break;
            }
        }
        if (this.jumping.finished(100L) && CounterMine.mc.field_1724.method_24828() && !this.jump) {
            this.minDamage = true;
            CounterMine.mc.field_1724.method_6043();
            this.minDamage = false;
            this.jump = true;
        }
    };
    private final EventListener<HudRenderEvent> onRender = event -> {
        if (this.minDamage) {
            event.getContext().drawCenteredText(Fonts.MEDIUM.getFont(11.0f), "Min-Damange", sr.getScaledWidth() / 2.0f, sr.getScaledHeight() / 2.0f + 10.0f, ColorRGBA.WHITE);
        }
    };
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
        if (event.getAction() == 1 && CounterMine.mc.field_1755 == null) {
            if (this.pickAssist.isKey(event.getKey())) {
                CounterMine.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(CounterMine.mc.field_1724.method_23317(), CounterMine.mc.field_1724.method_23318() + 10.0, CounterMine.mc.field_1724.method_23321(), CounterMine.mc.field_1724.method_36454(), CounterMine.mc.field_1724.method_36455(), false, false));
            }
            if (this.minDamageBind.isKey(event.getKey())) {
                this.minDamage = !this.minDamage;
            }
        }
    };
    private final EventListener<MouseEvent> onMouseButtonPress = event -> {
        if (event.getAction() == 1 && CounterMine.mc.field_1755 == null) {
            if (this.pickAssist.isKey(event.getButton())) {
                CounterMine.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(CounterMine.mc.field_1724.method_23317(), CounterMine.mc.field_1724.method_23318() + 10.0, CounterMine.mc.field_1724.method_23321(), CounterMine.mc.field_1724.method_36454(), CounterMine.mc.field_1724.method_36455(), false, false));
            }
            if (this.minDamageBind.isKey(event.getButton())) {
                this.minDamage = !this.minDamage;
            }
        }
    };
    private final EventListener<HudRenderEvent> on2DRender = event -> {
        if (this.noF5.isEnabled()) {
            CMUtility.removeAllArmor();
        }
    };
    private final EventListener<ReceivePacketEvent> onPacket = event -> {
        if (event.getPacket() instanceof class_2735) {
            event.cancel();
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        class_337 boss = CounterMine.mc.field_1705.method_1740();
        if (boss != null && this.hideScope.isEnabled()) {
            Class<class_337> bossbarklass = class_337.class;
            try {
                Field field = bossbarklass.getField("bossBars");
                Map bossBars = (Map)field.get(boss);
                for (UUID uuid : bossBars.keySet()) {
                    class_345 clientBossBar = (class_345)bossBars.get(uuid);
                    List siblings = clientBossBar.method_5414().method_10855();
                    class_5250 newText = class_2561.method_43470((String)"");
                    AtomicInteger i = new AtomicInteger();
                    siblings.stream().allMatch(text -> {
                        if (!text.getString().contains("\ub8f3\ua223\ua203\ub8f2\ua223\ua205")) {
                            newText.method_10852(text);
                        }
                        i.getAndIncrement();
                        return true;
                    });
                    clientBossBar.method_5413((class_2561)newText);
                }
            }
            catch (Exception field) {
                // empty catch block
            }
        }
        if (CounterMine.mc.field_1687 == null || CounterMine.mc.field_1724 == null || !this.wallHack.isEnabled()) {
            return;
        }
        class_4587 ms = event.getMatrices();
        class_4184 camera = CounterMine.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        ms.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask((boolean)false);
        class_2960 id = Experiment.id("textures/bloom.png");
        RenderSystem.setShaderTexture((int)0, (class_2960)id);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (Point point : this.scanner.getPoints()) {
            float bigSize = 4.0f;
            float size = 1.2f;
            ms.method_22903();
            RenderUtility.prepareMatrices(ms, point.getPos());
            ms.method_22907(camera.method_23767());
            DrawUtility.drawImage(ms, builder, (double)(-bigSize / 2.0f), (double)(-bigSize / 2.0f), 0.0, (double)bigSize, (double)bigSize, (point.isFriend() ? Colors.GREEN : Colors.ACCENT).withAlpha(12.75f));
            DrawUtility.drawImage(ms, builder, (double)(-size / 2.0f), (double)(-size / 2.0f), 0.0, (double)size, (double)size, (point.isFriend() ? Colors.GREEN : Colors.ACCENT).withAlpha(102.0f));
            ms.method_22909();
        }
        class_9801 builtLinesBuffer1 = builder.method_60794();
        if (builtLinesBuffer1 != null) {
            class_286.method_43433((class_9801)builtLinesBuffer1);
        }
        RenderSystem.depthMask((boolean)true);
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.disableDepthTest();
        ms.method_22909();
    };
    private final EventListener<EntityJumpEvent> onJump = event -> {
        if (event.getEntity() == CounterMine.mc.field_1724 && !this.minDamage) {
            event.cancel();
            this.jumping.reset();
            this.jump = false;
        }
    };

    public CounterMine() {
        this.rageBot = new RageBot(this);
        this.antiAim = new AntiAim(this);
    }

    public static boolean shouldHideEntity(class_8113.class_8122 entity) {
        String modelId = CMUtility.getModelIdFromNbt(entity.method_48900(), (class_7225.class_7874)class_310.method_1551().field_1724.method_56673());
        CounterMine mod = Experiment.getInstance().getModuleManager().getModule(CounterMine.class);
        if (modelId != null) {
            String modelJson = CMUtility.findHashedModel(modelId);
            return modelJson != null && (modelJson.contains("smoke_sprite_transparent") && mod.noSmoke.isEnabled() || modelJson.contains(",\"textures\":{\"arms\":\"") && mod.noF5.isEnabled() && CounterMine.mc.field_1690.method_31044() != class_5498.field_26664 || modelJson.contains("\"textures\":{\"particle\":\"item/") && modelJson.contains("\",\"skin\":\"item/") && mod.noF5.isEnabled() && CounterMine.mc.field_1690.method_31044() != class_5498.field_26664 && CounterMine.mc.field_1724.method_5739((class_1297)entity) < 3.0f);
        }
        return false;
    }

    @Override
    public void onEnable() {
        Experiment.getInstance().getEventManager().subscribe(this.scanner);
        Experiment.getInstance().getEventManager().subscribe(this.antiAim);
        Experiment.getInstance().getEventManager().subscribe(this.rageBot);
    }

    @Override
    public void onDisable() {
        Experiment.getInstance().getTargetManager().reset();
        Experiment.getInstance().getEventManager().unsubscribe(this.scanner);
        Experiment.getInstance().getEventManager().unsubscribe(this.antiAim);
        Experiment.getInstance().getEventManager().unsubscribe(this.rageBot);
    }

    public BooleanSetting getHideScope() {
        return this.hideScope;
    }

    public boolean isMinDamage() {
        return this.minDamage;
    }

    public AntiAim getAntiAim() {
        return this.antiAim;
    }

    public PositionScanner getScanner() {
        return this.scanner;
    }

    public Timer getJumping() {
        return this.jumping;
    }
}

