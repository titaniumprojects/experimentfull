/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1661
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2487
 *  net.minecraft.class_2596
 *  net.minecraft.class_2856
 *  net.minecraft.class_2856$class_2857
 *  net.minecraft.class_310
 *  net.minecraft.class_3944
 *  net.minecraft.class_7439
 *  net.minecraft.class_8673$class_9058
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.function.BooleanSupplier;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventIntegration;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.ItemUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2856;
import net.minecraft.class_310;
import net.minecraft.class_3944;
import net.minecraft.class_7439;
import net.minecraft.class_8673;

@ModuleInfo(name="Assist", category=ModuleCategory.OTHER, desc="\u041f\u043e\u043c\u043e\u0449\u043d\u0438\u043a \u0434\u043b\u044f \u0440\u0430\u0437\u043d\u044b\u0445 \u0441\u0435\u0440\u0432\u0435\u0440\u043e\u0432")
@Environment(value=EnvType.CLIENT)
public class Assist
extends BaseModule {
    private final BooleanSupplier rwCondition = () -> ServerUtility.isHW() || ServerUtility.isPastaFT() || ServerUtility.isCM() || ServerUtility.isSaturn() || ServerUtility.isIntave();
    private final BooleanSupplier ftCondition = () -> ServerUtility.isHW() || ServerUtility.isRW() || ServerUtility.isCM() || ServerUtility.isSaturn() || ServerUtility.isIntave();
    private final BooleanSupplier hwCondition = () -> ServerUtility.isPastaFT() || ServerUtility.isRW() || ServerUtility.isCM() || ServerUtility.isSaturn() || ServerUtility.isIntave();
    private final BooleanSetting spoof = new BooleanSetting(this, "\u0421\u043f\u0443\u0444 \u0440\u043f", "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0437\u0430\u0439\u0442\u0438 \u043d\u0430 \u0441\u0435\u0440\u0432\u0435\u0440 \u0431\u0435\u0437 \u0441\u043a\u0430\u0447\u0438\u0432\u0430\u043d\u0438\u044f \u0440\u0435\u0441\u0443\u0440\u0441 \u043f\u0430\u043a\u0430", this.rwCondition);
    private final BooleanSetting closeMenu = new BooleanSetting(this, "\u0417\u0430\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u043c\u0435\u043d\u044e", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043c\u0435\u043d\u044e \u043f\u0440\u0438 \u0437\u0430\u0445\u043e\u0434\u0435 \u043d\u0430 \u0433\u0440\u0438\u0444", this.rwCondition).enable();
    private final BooleanSetting autoFix = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e\u043f\u043e\u0447\u0438\u043d\u043a\u0430", this.rwCondition);
    private final BooleanSetting warnArmor = new BooleanSetting((SettingsContainer)this, "\u041f\u043e\u043b\u043e\u043c\u043a\u0430 \u0431\u0440\u043e\u043d\u0438", "\u041f\u0440\u0435\u0434\u0443\u043f\u0440\u0435\u0436\u0434\u0430\u0435\u0442 \u0435\u0441\u043b\u0438 \u0431\u0440\u043e\u043d\u044f \u043f\u043e\u043b\u043e\u043c\u0430\u043d\u0430");
    private final BooleanSetting fly = new BooleanSetting((SettingsContainer)this, "\u0414\u0440\u0430\u0433\u043e\u043d \u0444\u043b\u0430\u0439", "\u0423\u0441\u043a\u043e\u0440\u044f\u0435\u0442 \u0444\u043b\u0430\u0439 \u0438\u0437 \u043a\u0440\u0435\u0430\u0442\u0438\u0432\u0430").enable();
    private final SliderSetting flySpeedXZ = new SliderSetting((SettingsContainer)this, "\u0423\u0441\u043a\u043e\u0440\u044f\u0442\u044c \u043f\u043e XZ", () -> !this.fly.isEnabled()).currentValue(1.0f).max(5.0f).min(1.0f).step(0.5f).currentValue(5.0f);
    private final SliderSetting flySpeedY = new SliderSetting((SettingsContainer)this, "\u0423\u0441\u043a\u043e\u0440\u044f\u0442\u044c \u043f\u043e Y", () -> !this.fly.isEnabled()).currentValue(1.0f).max(5.0f).min(1.0f).step(0.5f).currentValue(5.0f);
    private final BooleanSetting autoPiona = new BooleanSetting(this, "\u0410\u0432\u0442\u043e \u043f\u0438\u043e\u043d\u0430", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043f\u0440\u043e\u043f\u0438\u0441\u044b\u0432\u0430\u0435\u0442 /piona \u043f\u0440\u0438 \u0437\u0430\u0445\u043e\u0434\u0435 \u043d\u0430 Funtime", ServerUtility::isRW).enable();
    private final BindSetting dezorentKey = new BindSetting(this, "\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f", this.ftCondition);
    private final BindSetting trapkaKey = new BindSetting(this, "\u0422\u0440\u0430\u043f\u043a\u0430", this.ftCondition);
    private final BindSetting smerchKey = new BindSetting(this, "\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447", this.ftCondition);
    private final BindSetting plastKey = new BindSetting(this, "\u041f\u043b\u0430\u0441\u0442", this.ftCondition);
    private final BindSetting auraKey = new BindSetting(this, "\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430", this.ftCondition);
    private final BindSetting pilbKey = new BindSetting(this, "\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c", this.ftCondition);
    private final BooleanSetting autoZako = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e /zako", this.hwCondition);
    private final BooleanSetting autoStop = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e-\u0441\u0442\u043e\u043f", this.hwCondition);
    private final BindSetting stanKey = new BindSetting(this, "\u0421\u0442\u0430\u043d", this.hwCondition);
    private final BindSetting snowKey = new BindSetting(this, "\u041a\u043e\u043c \u0441\u043d\u0435\u0433\u0430", this.hwCondition);
    private final BindSetting bombKey = new BindSetting(this, "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0448\u0442\u0443\u0447\u043a\u0430", this.hwCondition);
    private final BindSetting hwTrapKey = new BindSetting(this, "\u0422\u0440\u0430\u043f\u043a\u0430", this.hwCondition);
    private final BindSetting boomTrapKey = new BindSetting(this, "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430", this.hwCondition);
    private final BindSetting goolKey = new BindSetting(this, "\u041f\u0440\u043e\u0449\u0430\u043b\u044c\u043d\u044b\u0439 \u0433\u0443\u043b", this.hwCondition);
    private final BindSetting backpackKey = new BindSetting(this, "\u0420\u044e\u043a\u0437\u0430\u043a", this.hwCondition);
    private final Timer timer = new Timer();
    private final Timer timerStop = new Timer();
    private boolean stopHandle;
    private boolean zakoCommandSent = true;
    private boolean pionaCommandSent = true;
    private boolean visible;
    private final EventListener<MouseEvent> onMouseEvent = event -> this.handleButtonPress(event.getButton());
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
        if (event.getAction() != 1) {
            return;
        }
        this.handleButtonPress(event.getKey());
    };
    private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
        class_3944 screenPacket;
        String title;
        class_7439 packet;
        String message;
        class_2596<?> patt0$temp;
        if (this.autoPiona.isEnabled() && (patt0$temp = event.getPacket()) instanceof class_7439 && ((message = (packet = (class_7439)patt0$temp).comp_763().getString().toLowerCase()).contains("10,000 \u0431\u044b\u043b\u043e \u043d\u0430\u0447\u0438\u0441\u043b\u0435\u043d\u043e \u0432\u0430\u043c") || message.contains("\u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u0442\u0435\u043a\u0441\u0442 \u0435\u0449\u0435 \u0440\u0430\u0437"))) {
            this.pionaCommandSent = false;
            this.timer.reset();
        }
        if (this.autoZako.isEnabled() && (patt0$temp = event.getPacket()) instanceof class_7439) {
            packet = (class_7439)patt0$temp;
            message = packet.comp_763().getString();
            if (message.contains("\u0412\u044b \u0443\u0436\u0435 \u0430\u043a\u0442\u0438\u0432\u0438\u0440\u043e\u0432\u0430\u043b\u0438 \u044d\u0442\u043e\u0442 \u043f\u0440\u043e\u043c\u043e\u043a\u043e\u0434")) {
                this.zakoCommandSent = false;
                this.timer.reset();
            } else if (message.contains("\u041f\u0440\u044f\u043c\u043e \u0441\u0435\u0439\u0447\u0430\u0441 \u0438\u0434\u0435\u0442 \u043d\u0430\u0431\u043e\u0440")) {
                this.zakoCommandSent = true;
            }
        }
        if (this.autoStop.isEnabled() && (patt0$temp = event.getPacket()) instanceof class_7439 && (message = (packet = (class_7439)patt0$temp).comp_763().getString()).contains("\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0430\u0446\u0438\u044f \u043f\u0440\u0438\u043d\u044f\u0442\u0430")) {
            this.stopHandle = true;
        }
        if (this.closeMenu.isEnabled() && (patt0$temp = event.getPacket()) instanceof class_3944 && ((title = (screenPacket = (class_3944)patt0$temp).method_17594().getString()).contains("\u041c\u0435\u043d\u044e") || title.contains("\ua201\ua000\ua202\ua301\ua202\ua001"))) {
            Assist.mc.field_1724.method_3137();
            event.cancel();
        }
    };
    private final EventListener<InputEvent> inputEvent = event -> {
        if (this.autoStop.isEnabled() && this.stopHandle && !this.timerStop.finished(3200L)) {
            event.setForward(0.0f);
            event.setJump(false);
            event.setStrafe(0.0f);
            this.timerStop.reset();
        }
    };
    private Timer shootTimer = new Timer();
    private Timer chargeTimer = new Timer();
    private ItemSlot previousSlot = null;
    private boolean isCharging = false;
    private boolean needsSlotSwapBack = false;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {};

    @Override
    public void tick() {
        float currentDamage;
        float maxDamage;
        if (Assist.mc.field_1724 == null || Assist.mc.field_1687 == null || Assist.mc.field_1761 == null) {
            return;
        }
        if (this.warnArmor.isEnabled()) {
            float armorPoint = 1.0f;
            for (class_1799 stack : Assist.mc.field_1724.method_56674()) {
                if (stack.method_7960()) continue;
                maxDamage = stack.method_7936();
                currentDamage = maxDamage - (float)stack.method_7919();
                armorPoint = currentDamage / maxDamage;
            }
            if ((double)armorPoint < 0.36) {
                if (this.visible) {
                    Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.INFO, "\u041f\u043e\u043b\u043e\u043c\u043a\u0430", "\u0412\u0430\u0448\u0430 \u0431\u0440\u043e\u043d\u044f \u043d\u0430 \u0433\u0440\u0430\u043d\u0438 \u043f\u043e\u043b\u043e\u043c\u043a\u0438");
                    this.visible = false;
                }
            } else {
                this.visible = true;
            }
        }
        if (this.fly.isEnabled() && Assist.mc.field_1724.method_31549().field_7479) {
            if (!Assist.mc.field_1724.method_5715() && Assist.mc.field_1690.field_1903.method_1434()) {
                Assist.mc.field_1724.method_18800(Assist.mc.field_1724.method_18798().field_1352, (double)this.flySpeedY.getCurrentValue(), Assist.mc.field_1724.method_18798().field_1350);
            } else if (Assist.mc.field_1690.field_1832.method_1434()) {
                Assist.mc.field_1724.method_18800(Assist.mc.field_1724.method_18798().field_1352, (double)(-this.flySpeedY.getCurrentValue()), Assist.mc.field_1724.method_18798().field_1350);
            }
            EntityUtility.setSpeed(this.flySpeedXZ.getCurrentValue());
        }
        if (this.autoFix.isEnabled() && !ServerUtility.hasCT) {
            class_1661 inventory = Assist.mc.field_1724.method_31548();
            for (int i = 0; i < inventory.method_5439(); ++i) {
                float f;
                class_1799 stack;
                stack = inventory.method_5438(i);
                if (stack.method_7960() || !stack.method_7963()) continue;
                maxDamage = stack.method_7936();
                currentDamage = maxDamage - (float)stack.method_7919();
                if (!(f / maxDamage > 0.5f) || Assist.mc.field_1724.field_6012 % 25 != 0) continue;
                Assist.mc.field_1724.field_3944.method_45730("fix all");
                break;
            }
        }
        if (this.spoof.isEnabled() && this.spoof.isVisible() && Assist.mc.field_1724.field_6012 > 20 && Assist.mc.field_1755 instanceof class_8673.class_9058) {
            Assist.mc.field_1724.field_3944.method_52787((class_2596)new class_2856(Assist.mc.field_1724.method_5667(), class_2856.class_2857.field_13016));
            Assist.mc.field_1724.field_3944.method_52787((class_2596)new class_2856(Assist.mc.field_1724.method_5667(), class_2856.class_2857.field_13017));
            Assist.mc.field_1724.method_3137();
        }
        if (this.autoPiona.isEnabled()) {
            if (Assist.mc.field_1724.field_7512 instanceof class_1707 && Assist.mc.field_1755.method_25440().getString().contains("\u0412\u0430\u043c \u043f\u043e\u0434\u0430\u0440\u043e\u043a")) {
                Assist.mc.field_1761.method_2906(Assist.mc.field_1724.field_7512.field_7763, 13, 0, class_1713.field_7790, (class_1657)Assist.mc.field_1724);
            }
            if (this.timer.finished(1000L) && !this.pionaCommandSent) {
                this.pionaCommandSent = true;
                Assist.mc.field_1724.field_3944.method_45730("piona");
            }
        }
        if (this.autoZako.isEnabled() && this.timer.finished(500L) && this.zakoCommandSent) {
            this.zakoCommandSent = false;
            Assist.mc.field_1724.field_3944.method_45730("zako");
        }
        super.tick();
    }

    private void handleButtonPress(int button) {
        if (this.dezorentKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8449);
        } else if (this.trapkaKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_22021);
        } else if (this.smerchKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8814);
        } else if (this.stanKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8137);
        } else if (this.plastKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8551);
        } else if (this.auraKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8614);
        } else if (this.pilbKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8479);
        } else if (this.snowKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8543);
        } else if (this.bombKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8814);
        } else if (this.hwTrapKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8882);
        } else if (this.boomTrapKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8662);
        } else if (this.goolKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8450);
        } else if (this.backpackKey.isKey(button)) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8050);
        }
    }

    private void attemptShoot() {
        class_1799 crossbowStack;
        SlotGroup<ItemSlot> group = SlotGroups.hotbar().and(SlotGroups.inventory());
        ItemSlot crossbowSlot = group.findItem(class_1802.field_8399);
        if (crossbowSlot == null) {
            return;
        }
        if (this.previousSlot == null) {
            this.previousSlot = InventoryUtility.getCurrentHotbarSlot();
        }
        if (crossbowSlot instanceof HotbarSlot) {
            HotbarSlot hotbarSlot = (HotbarSlot)crossbowSlot;
            if (InventoryUtility.getCurrentHotbarSlot().item() != class_1802.field_8399) {
                InventoryUtility.selectHotbarSlot(hotbarSlot);
            }
        }
        if (!this.isCrossbowCharged(crossbowStack = InventoryUtility.getCurrentHotbarSlot().itemStack())) {
            this.startCharging();
            return;
        }
        this.shoot();
        this.startCharging();
    }

    private boolean isCrossbowCharged(class_1799 crossbow) {
        if (crossbow.method_7960() || crossbow.method_7909() != class_1802.field_8399) {
            return false;
        }
        class_2487 nbt = ItemUtility.getNBT(crossbow);
        return nbt != null && nbt.method_10577("Charged");
    }

    private void startCharging() {
        if (this.isCharging) {
            return;
        }
        this.isCharging = true;
        this.chargeTimer.reset();
        class_310.method_1551().field_1690.field_1904.method_23481(true);
    }

    private void finishCharging() {
        if (!this.isCharging) {
            return;
        }
        this.isCharging = false;
        class_310.method_1551().field_1690.field_1904.method_23481(false);
        this.needsSlotSwapBack = true;
    }

    private void shoot() {
        if (Assist.mc.field_1761 != null) {
            Assist.mc.field_1761.method_2919((class_1657)Assist.mc.field_1724, class_1268.field_5808);
        }
    }

    public void stop() {
        ItemSlot itemSlot;
        if (this.isCharging) {
            class_310.method_1551().field_1690.field_1904.method_23481(false);
            this.isCharging = false;
        }
        if (this.previousSlot != null && (itemSlot = this.previousSlot) instanceof HotbarSlot) {
            HotbarSlot hotbarSlot = (HotbarSlot)itemSlot;
            InventoryUtility.selectHotbarSlot(hotbarSlot);
            this.previousSlot = null;
        }
        this.needsSlotSwapBack = false;
    }
}

