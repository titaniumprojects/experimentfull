/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1887
 *  net.minecraft.class_1893
 *  net.minecraft.class_2338
 *  net.minecraft.class_2596
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_5321
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.utility.inventory.EnchantmentUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2846;
import net.minecraft.class_5321;

@ModuleInfo(name="Fast Item Use", category=ModuleCategory.OTHER, desc="modules.descriptions.fast_item_use")
@Environment(value=EnvType.CLIENT)
public class FastItemUse
extends BaseModule {
    private final BooleanSetting bow = new BooleanSetting((SettingsContainer)this, "modules.settings.fast_item_use.bow", "modules.settings.fast_item_use.bow.description").enable();
    private final BooleanSetting trident = new BooleanSetting((SettingsContainer)this, "modules.settings.fast_item_use.trident", "modules.settings.fast_item_use.trident.description").enable();
    private final BooleanSetting crossbow = new BooleanSetting((SettingsContainer)this, "modules.settings.fast_item_use.crossbow", "modules.settings.fast_item_use.crossbow.description").enable();
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
        if (this.trident.isEnabled() && this.canReleaseTrident()) {
            this.releaseItem();
        }
        if (this.bow.isEnabled() && this.canReleaseBow()) {
            this.releaseItem();
        }
        if (this.crossbow.isEnabled() && this.canReleaseCrossbow()) {
            this.releaseItem();
        }
    };

    private void releaseItem() {
        if (FastItemUse.mc.field_1724 == null) {
            return;
        }
        FastItemUse.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, FastItemUse.mc.field_1724.method_5735()));
        FastItemUse.mc.field_1724.method_6075();
    }

    private boolean canReleaseTrident() {
        if (FastItemUse.mc.field_1724 == null) {
            return false;
        }
        class_1799 heldStack = FastItemUse.mc.field_1724.method_6047();
        return heldStack.method_7909() == class_1802.field_8547 && EnchantmentUtility.getEnchantmentLevel(heldStack, (class_5321<class_1887>)class_1893.field_9104) > 0 && FastItemUse.mc.field_1724.method_6115() && (double)FastItemUse.mc.field_1724.method_6048() >= 10.0 && FastItemUse.mc.field_1724.method_7261(0.5f) > 0.92f;
    }

    private boolean canReleaseBow() {
        if (FastItemUse.mc.field_1724 == null) {
            return false;
        }
        return FastItemUse.mc.field_1724.method_6047().method_7909() == class_1802.field_8102 && FastItemUse.mc.field_1724.method_6115() && (double)FastItemUse.mc.field_1724.method_6048() >= 10.0;
    }

    private boolean canReleaseCrossbow() {
        if (FastItemUse.mc.field_1724 == null) {
            return false;
        }
        return FastItemUse.mc.field_1724.method_6047().method_7909() == class_1802.field_8399 && FastItemUse.mc.field_1724.method_6115() && FastItemUse.mc.field_1724.method_6048() >= 10;
    }
}

