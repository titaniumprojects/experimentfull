/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2960
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.sounds.ClientSoundInstance;
import micronix.experiment.utility.sounds.ClientSounds;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2960;

@ModuleInfo(name="RoflMod", category=ModuleCategory.OTHER, desc="\u041c\u043e\u0434\u0443\u043b\u044c \u0434\u043b\u044f \u0440\u043e\u0444\u043b\u043e\u0432")
@Environment(value=EnvType.CLIENT)
public class RoflMod
extends BaseModule {
    private final ModeSetting activeMode = new ModeSetting(this, "\u0420\u0435\u0436\u0438\u043c");
    private final ModeSetting.Value screenAura = new ModeSetting.Value(this.activeMode, "ScreenAura").select();
    private final ModeSetting.Value fluger = new ModeSetting.Value(this.activeMode, "Fluger");
    private final ModeSetting.Value russianRoulette = new ModeSetting.Value(this.activeMode, "RussianRoulette");
    private final ModeSetting.Value huesos = new ModeSetting.Value(this.activeMode, "Huesos (IIoneR)");
    private final BooleanSetting soundEnabled = new BooleanSetting(this, "\u0417\u0432\u0443\u043a").enabled(true);
    private final SliderSetting volume = new SliderSetting(this, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c").min(0.0f).max(1.0f).step(0.1f).currentValue(0.5f);
    private final Animation imageAnimation = new Animation(1000L, Easing.FIGMA_EASE_IN_OUT);
    private boolean removingImage = false;
    private class_2960 currentTexture = null;
    private boolean imageActive = false;
    private final Timer cooldown = new Timer();
    private final Random random = new Random();
    private float lastHealth = 20.0f;
    private boolean gameActive = false;
    private final Map<class_1309, Float> entityHealthMap = new HashMap<class_1309, Float>();
    private static final class_2960 FLUGER_TEXTURE = Experiment.id("textures/fluger.png");
    private static final class_2960 HUESOS_TEXTURE = Experiment.id("textures/huesos.png");
    private final EventListener<PreHudRenderEvent> onPreHudRender = event -> {
        if (!this.imageActive || this.currentTexture == null) {
            return;
        }
        if (this.imageAnimation.getValue() == 0.0f) {
            return;
        }
        float textureWidth = mc.method_22683().method_4486();
        float textureHeight = mc.method_22683().method_4502();
        event.getContext().drawTexture(this.currentTexture, 0.0f, 0.0f, textureWidth, textureHeight, Colors.WHITE.withAlpha(255.0f * this.imageAnimation.getValue()));
    };
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (RoflMod.mc.field_1724 == null || RoflMod.mc.field_1687 == null) {
            return;
        }
        if (this.activeMode.is(this.screenAura)) {
            float currentHealth = RoflMod.mc.field_1724.method_6032();
            if (currentHealth < this.lastHealth && this.soundEnabled.isEnabled()) {
                ClientSounds.CAMERA_SHUTTER.play(this.volume.getCurrentValue(), 1.0f);
            }
            this.lastHealth = currentHealth;
            for (class_1297 entity : RoflMod.mc.field_1687.method_18112()) {
                class_1309 living;
                if (!(entity instanceof class_1309) || (living = (class_1309)entity) == RoflMod.mc.field_1724) continue;
                float currentEntityHealth = living.method_6032();
                Float lastEntityHealth = this.entityHealthMap.get(living);
                if (lastEntityHealth != null && currentEntityHealth < lastEntityHealth.floatValue() && this.soundEnabled.isEnabled()) {
                    ClientSounds.CAMERA_SHUTTER.play(this.volume.getCurrentValue(), 1.0f);
                }
                this.entityHealthMap.put(living, Float.valueOf(currentEntityHealth));
            }
            this.entityHealthMap.entrySet().removeIf(entry -> !((class_1309)entry.getKey()).method_5805());
        }
        if (this.activeMode.is(this.russianRoulette) && !this.gameActive && this.cooldown.hasReached(5000)) {
            this.startRussianRoulette();
        }
        if (this.imageActive) {
            if (this.imageAnimation.getValue() == 1.0f && !this.removingImage) {
                this.removingImage = true;
            }
            this.imageAnimation.update(this.removingImage ? 0.0f : 1.0f);
            if (this.imageAnimation.getValue() == 0.0f && this.removingImage) {
                this.imageActive = false;
                this.currentTexture = null;
                this.removingImage = false;
            }
        }
    };

    private void startRussianRoulette() {
        this.gameActive = true;
        this.cooldown.reset();
        boolean lose = this.random.nextBoolean();
        if (lose) {
            Experiment.getInstance().getModuleManager().getModules().forEach(module -> {
                if (module.isEnabled() && module != this) {
                    module.disable();
                }
            });
            if (this.soundEnabled.isEnabled()) {
                ClientSounds.CRITICAL.play(this.volume.getCurrentValue(), 1.0f);
            }
            this.disable();
        } else if (this.soundEnabled.isEnabled()) {
            ClientSounds.UWU.play(this.volume.getCurrentValue(), 1.0f);
        }
        this.gameActive = false;
    }

    private void showImage(class_2960 texture, ClientSoundInstance sound) {
        this.currentTexture = texture;
        this.imageActive = true;
        this.removingImage = false;
        this.imageAnimation.update(1.0f);
        if (this.soundEnabled.isEnabled() && sound != null) {
            sound.play(this.volume.getCurrentValue(), 1.0f);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        Experiment.getInstance().getEventManager().subscribe(this.onPreHudRender);
        if (RoflMod.mc.field_1724 != null) {
            this.lastHealth = RoflMod.mc.field_1724.method_6032();
        }
        this.entityHealthMap.clear();
        if (this.activeMode.is(this.fluger)) {
            this.showImage(FLUGER_TEXTURE, ClientSounds.FLUGER_SCREAM);
        } else if (this.activeMode.is(this.huesos)) {
            this.showImage(HUESOS_TEXTURE, ClientSounds.HUESOS_APPEAR);
        } else if (this.activeMode.is(this.russianRoulette)) {
            this.startRussianRoulette();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        Experiment.getInstance().getEventManager().unsubscribe(this.onPreHudRender);
        this.imageActive = false;
        this.currentTexture = null;
        this.removingImage = false;
        this.gameActive = false;
        this.entityHealthMap.clear();
    }
}

