/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2189
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_2397
 *  net.minecraft.class_243
 *  net.minecraft.class_3965
 *  net.minecraft.class_746
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2397;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_746;

@ModuleInfo(name="AppleFarm", category=ModuleCategory.OTHER, desc="\u0424\u0435\u0440\u043c\u0430 \u044f\u0431\u043b\u043e\u043a")
@Environment(value=EnvType.CLIENT)
public class AppleFarm
extends BaseModule {
    private static final int RADIUS = 8;
    private State state = State.FIND_TREE;
    private final Timer actionTimer = new Timer();
    private final Timer waitTimer = new Timer();
    private final Timer noTreesTimer = new Timer();
    private class_2338 currentTreePos = null;
    private int emptyBreakAttempts = 0;
    private int leavesBrokenCount = 0;
    private final BooleanSetting useBonemeal = new BooleanSetting(this, "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u043a\u043e\u0441\u0442\u043d\u0443\u044e \u043c\u0443\u043a\u0443").enabled(true);
    private final BooleanSetting autoSwitch = new BooleanSetting(this, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043c\u0435\u043d\u044f\u0442\u044c \u0438\u043d\u0441\u0442\u0440\u0443\u043c\u0435\u043d\u0442\u044b").enabled(true);
    private final BooleanSetting ignorePause = new BooleanSetting(this, "\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043f\u0430\u0443\u0437\u0443 (ESC)").enabled(true);
    private final BooleanSetting breakLeavesFirst = new BooleanSetting(this, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u043b\u043e\u043c\u0430\u0442\u044c \u043b\u0438\u0441\u0442\u0432\u0443").enabled(true);
    private final SliderSetting leavesBreakDelay = new SliderSetting(this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043b\u043e\u043c\u0430\u043d\u0438\u044f \u043b\u0438\u0441\u0442\u0432\u044b").min(50.0f).max(500.0f).step(10.0f).currentValue(80.0f);
    private final SliderSetting logBreakDelay = new SliderSetting(this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0440\u0443\u0431\u043a\u0438 \u0434\u0435\u0440\u0435\u0432\u0430").min(10.0f).max(500.0f).step(10.0f).currentValue(80.0f);
    private final SliderSetting placeDelay = new SliderSetting(this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043f\u043e\u0441\u0430\u0434\u043a\u0438").min(50.0f).max(500.0f).step(10.0f).currentValue(150.0f);
    private final SliderSetting bonemealDelay = new SliderSetting(this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0443\u0434\u043e\u0431\u0440\u0435\u043d\u0438\u044f").min(50.0f).max(500.0f).step(10.0f).currentValue(80.0f);
    private final SliderSetting waitDropTime = new SliderSetting(this, "\u0412\u0440\u0435\u043c\u044f \u043e\u0436\u0438\u0434\u0430\u043d\u0438\u044f \u0434\u0440\u043e\u043f\u0430").min(500.0f).max(5000.0f).step(100.0f).currentValue(1500.0f);
    private final SliderSetting noTreesTimeout = new SliderSetting(this, "\u0422\u0430\u0439\u043c-\u0430\u0443\u0442 \u043f\u043e\u0441\u043b\u0435 \u0440\u0443\u0431\u043a\u0438").min(1000.0f).max(10000.0f).step(500.0f).currentValue(5000.0f);

    @Override
    public void onEnable() {
        this.state = State.FIND_TREE;
        this.actionTimer.reset();
        this.waitTimer.reset();
        this.noTreesTimer.reset();
        this.currentTreePos = null;
        this.emptyBreakAttempts = 0;
        this.leavesBrokenCount = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.state = State.FIND_TREE;
        super.onDisable();
    }

    @Override
    public void tick() {
        if (this.ignorePause.isEnabled() && mc.method_1493()) {
            this.runFarmLogic();
        } else {
            this.runFarmLogic();
        }
        super.tick();
    }

    private void runFarmLogic() {
        class_746 player = AppleFarm.mc.field_1724;
        if (player == null || AppleFarm.mc.field_1687 == null || AppleFarm.mc.field_1761 == null) {
            return;
        }
        switch (this.state.ordinal()) {
            case 0: {
                this.currentTreePos = this.findNearestTree(player.method_24515(), 8);
                if (this.currentTreePos == null) {
                    if (this.emptyBreakAttempts > 3) {
                        this.state = State.NO_TREES;
                        this.noTreesTimer.reset();
                        this.emptyBreakAttempts = 0;
                    } else {
                        ++this.emptyBreakAttempts;
                    }
                    return;
                }
                this.emptyBreakAttempts = 0;
                if (this.breakLeavesFirst.isEnabled() && this.hasLeavesAround(this.currentTreePos)) {
                    this.state = State.BREAK_LEAVES;
                    this.leavesBrokenCount = 0;
                } else {
                    this.state = State.BREAK_LOG;
                }
                this.actionTimer.reset();
                break;
            }
            case 1: {
                if (!this.actionTimer.finished((long)this.leavesBreakDelay.getCurrentValue())) {
                    return;
                }
                class_2338 leaf = this.findNearestLeaf(this.currentTreePos, 8);
                if (leaf == null) {
                    this.state = State.BREAK_LOG;
                    this.actionTimer.reset();
                    return;
                }
                if (this.autoSwitch.isEnabled()) {
                    this.selectBestHoe(player);
                }
                this.lookAt(player, leaf);
                AppleFarm.mc.field_1761.method_2910(leaf, class_2350.field_11036);
                ++this.leavesBrokenCount;
                this.actionTimer.reset();
                break;
            }
            case 2: {
                if (!this.actionTimer.finished((long)this.logBreakDelay.getCurrentValue())) {
                    return;
                }
                if (this.currentTreePos == null || !this.isValidTreeBlock(this.currentTreePos)) {
                    this.waitTimer.reset();
                    this.state = State.WAIT_DROP;
                    this.actionTimer.reset();
                    return;
                }
                if (this.autoSwitch.isEnabled()) {
                    this.selectBestAxe(player);
                }
                this.lookAt(player, this.currentTreePos);
                AppleFarm.mc.field_1761.method_2910(this.currentTreePos, class_2350.field_11036);
                this.actionTimer.reset();
                break;
            }
            case 3: {
                if (!this.waitTimer.finished((long)this.waitDropTime.getCurrentValue())) {
                    return;
                }
                this.state = this.hasSapling(player) ? State.PLACE_SAPLING : State.FIND_TREE;
                this.actionTimer.reset();
                break;
            }
            case 4: {
                if (!this.actionTimer.finished((long)this.placeDelay.getCurrentValue())) {
                    return;
                }
                class_2338 existingSapling = this.findNearestBlock(player.method_24515(), 8, class_2246.field_10394, class_2246.field_10575, class_2246.field_10217, class_2246.field_10160);
                if (existingSapling != null) {
                    this.state = State.BONEMEAL;
                    this.actionTimer.reset();
                    return;
                }
                class_2338 ground = this.findPlantableSpot(player.method_24515());
                if (ground == null) {
                    return;
                }
                this.selectItem(player, class_1802.field_17535);
                this.lookAt(player, ground);
                if (!this.isLookingAt(player, ground, 8.0f)) {
                    return;
                }
                class_3965 hit = new class_3965(class_243.method_24953((class_2382)ground).method_1031(0.0, 0.5, 0.0), class_2350.field_11036, ground, false);
                class_1269 result = AppleFarm.mc.field_1761.method_2896(player, class_1268.field_5808, hit);
                if (result.method_23665()) {
                    this.state = State.BONEMEAL;
                }
                this.actionTimer.reset();
                break;
            }
            case 5: {
                if (!this.actionTimer.finished((long)this.bonemealDelay.getCurrentValue())) {
                    return;
                }
                class_2338 log = this.findNearestTree(player.method_24515(), 8);
                if (log != null) {
                    this.currentTreePos = log;
                    this.state = State.FIND_TREE;
                    this.actionTimer.reset();
                    return;
                }
                class_2338 sapling = this.findNearestBlock(player.method_24515(), 8, class_2246.field_10394, class_2246.field_10575, class_2246.field_10217, class_2246.field_10160);
                if (sapling == null) {
                    this.state = State.PLACE_SAPLING;
                    this.actionTimer.reset();
                    return;
                }
                if (!this.useBonemeal.isEnabled() || !this.hasBoneMeal(player)) {
                    return;
                }
                this.selectItem(player, class_1802.field_8324);
                this.lookAt(player, sapling);
                if (!this.isLookingAt(player, sapling, 8.0f)) {
                    return;
                }
                class_3965 hit = new class_3965(class_243.method_24953((class_2382)sapling), class_2350.field_11036, sapling, false);
                AppleFarm.mc.field_1761.method_2896(player, class_1268.field_5808, hit);
                this.actionTimer.reset();
                break;
            }
            case 6: {
                if (this.noTreesTimer.finished((long)this.noTreesTimeout.getCurrentValue())) {
                    this.state = State.FIND_TREE;
                    this.noTreesTimer.reset();
                    this.emptyBreakAttempts = 0;
                    break;
                }
                class_2338 log = this.findNearestTree(player.method_24515(), 8);
                if (log == null) break;
                this.currentTreePos = log;
                this.state = State.FIND_TREE;
                this.noTreesTimer.reset();
            }
        }
    }

    private boolean hasLeavesAround(class_2338 treePos) {
        for (int x = -3; x <= 3; ++x) {
            for (int y = -2; y <= 5; ++y) {
                for (int z = -3; z <= 3; ++z) {
                    class_2338 pos = treePos.method_10069(x, y, z);
                    if (!this.isLeaves(pos)) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private class_2338 findNearestLeaf(class_2338 center, int radius) {
        class_2338 nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -radius; y <= radius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    double d;
                    class_2338 pos = center.method_10069(x, y, z);
                    if (!this.isLeaves(pos) || !((d = center.method_10262((class_2382)pos)) < nearestDist)) continue;
                    nearestDist = d;
                    nearest = pos;
                }
            }
        }
        return nearest;
    }

    private boolean isLeaves(class_2338 pos) {
        class_2248 block = AppleFarm.mc.field_1687.method_8320(pos).method_26204();
        return block instanceof class_2397;
    }

    private boolean isValidTreeBlock(class_2338 pos) {
        if (pos == null || AppleFarm.mc.field_1687 == null) {
            return false;
        }
        class_2248 block = AppleFarm.mc.field_1687.method_8320(pos).method_26204();
        return block == class_2246.field_10431 || block == class_2246.field_10126 || block == class_2246.field_10511 || block == class_2246.field_10307 || block == class_2246.field_10037 || block == class_2246.field_10155 || block == class_2246.field_10010 || block == class_2246.field_10178 || block == class_2246.field_10306 || block == class_2246.field_10303 || block == class_2246.field_10533 || block == class_2246.field_9999;
    }

    private class_2338 findNearestTree(class_2338 center, int radius) {
        class_2338 nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -radius; y <= radius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    double d;
                    class_2338 pos = center.method_10069(x, y, z);
                    if (!this.isValidTreeBlock(pos) || !((d = center.method_10262((class_2382)pos)) < nearestDist)) continue;
                    nearestDist = d;
                    nearest = pos;
                }
            }
        }
        return nearest;
    }

    private class_2338 findPlantableSpot(class_2338 center) {
        for (int r = 0; r <= 8; ++r) {
            for (int x = -r; x <= r; ++x) {
                for (int z = -r; z <= r; ++z) {
                    for (int y = -2; y <= 2; ++y) {
                        class_2338 pos = center.method_10069(x, y, z);
                        if (!this.canPlantSapling(pos)) continue;
                        return pos;
                    }
                }
            }
        }
        return null;
    }

    private boolean canPlantSapling(class_2338 pos) {
        class_2248 below = AppleFarm.mc.field_1687.method_8320(pos).method_26204();
        class_2248 above = AppleFarm.mc.field_1687.method_8320(pos.method_10084()).method_26204();
        boolean goodSoil = below == class_2246.field_10219 || below == class_2246.field_10566 || below == class_2246.field_10253 || below == class_2246.field_10520 || below == class_2246.field_28685 || below == class_2246.field_28681 || below == class_2246.field_10362;
        boolean airAbove = above instanceof class_2189;
        return goodSoil && airAbove;
    }

    private class_2338 findNearestBlock(class_2338 center, int radius, class_2248 ... blocks) {
        class_2338 nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -radius; y <= radius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    class_2338 pos = center.method_10069(x, y, z);
                    class_2248 b = AppleFarm.mc.field_1687.method_8320(pos).method_26204();
                    for (class_2248 t : blocks) {
                        double d;
                        if (b != t || !((d = center.method_10262((class_2382)pos)) < nearestDist)) continue;
                        nearestDist = d;
                        nearest = pos;
                    }
                }
            }
        }
        return nearest;
    }

    private void selectBestHoe(class_746 player) {
        class_1792[] hoes;
        for (class_1792 hoe : hoes = new class_1792[]{class_1802.field_22026, class_1802.field_8527, class_1802.field_8609, class_1802.field_8303, class_1802.field_8431, class_1802.field_8167}) {
            for (int i = 0; i < 9; ++i) {
                if (player.method_31548().method_5438(i).method_7909() != hoe) continue;
                player.method_31548().field_7545 = i;
                return;
            }
        }
    }

    private void selectBestAxe(class_746 player) {
        class_1792[] axes;
        for (class_1792 axe : axes = new class_1792[]{class_1802.field_22025, class_1802.field_8556, class_1802.field_8475, class_1802.field_8825, class_1802.field_8062, class_1802.field_8406}) {
            for (int i = 0; i < 9; ++i) {
                if (player.method_31548().method_5438(i).method_7909() != axe) continue;
                player.method_31548().field_7545 = i;
                return;
            }
        }
    }

    private void selectItem(class_746 player, class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            if (player.method_31548().method_5438(i).method_7909() != item) continue;
            player.method_31548().field_7545 = i;
            return;
        }
    }

    private boolean hasSapling(class_746 p) {
        for (int i = 0; i < p.method_31548().method_5439(); ++i) {
            class_1799 stack = p.method_31548().method_5438(i);
            if (stack.method_7909() != class_1802.field_17535 && stack.method_7909() != class_1802.field_17537 && stack.method_7909() != class_1802.field_17536 && stack.method_7909() != class_1802.field_17540) continue;
            return true;
        }
        return false;
    }

    private boolean hasBoneMeal(class_746 p) {
        for (int i = 0; i < p.method_31548().method_5439(); ++i) {
            if (p.method_31548().method_5438(i).method_7909() != class_1802.field_8324) continue;
            return true;
        }
        return false;
    }

    private void lookAt(class_746 player, class_2338 pos) {
        class_243 eyes = player.method_33571();
        class_243 target = class_243.method_24953((class_2382)pos);
        double dx = target.field_1352 - eyes.field_1352;
        double dy = target.field_1351 - eyes.field_1351;
        double dz = target.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        player.method_36456((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.method_36457((float)(-Math.toDegrees(Math.atan2(dy, dist))));
    }

    private boolean isLookingAt(class_746 player, class_2338 pos, float maxDeg) {
        class_243 eyes = player.method_33571();
        class_243 target = class_243.method_24953((class_2382)pos);
        double dx = target.field_1352 - eyes.field_1352;
        double dy = target.field_1351 - eyes.field_1351;
        double dz = target.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float wantYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float wantPitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return Math.abs(this.wrap(player.method_36454() - wantYaw)) < maxDeg && Math.abs(this.wrap(player.method_36455() - wantPitch)) < maxDeg;
    }

    private float wrap(float d) {
        if ((d %= 360.0f) < -180.0f) {
            d += 360.0f;
        }
        if (d > 180.0f) {
            d -= 360.0f;
        }
        return d;
    }

    @Environment(value=EnvType.CLIENT)
    private static enum State {
        FIND_TREE,
        BREAK_LEAVES,
        BREAK_LOG,
        WAIT_DROP,
        PLACE_SAPLING,
        BONEMEAL,
        NO_TREES;

    }
}

