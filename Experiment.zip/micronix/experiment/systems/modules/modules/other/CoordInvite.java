/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.StringSetting;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Coord Invite", category=ModuleCategory.OTHER, desc="\u041e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0438\u0433\u0440\u043e\u043a\u0443 \u043f\u043e \u0431\u0438\u043d\u0434\u0443")
@Environment(value=EnvType.CLIENT)
public class CoordInvite
extends BaseModule {
    private final BindSetting inviteKey = new BindSetting(this, "\u0411\u0438\u043d\u0434 \u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u044f").key(-1);
    private final StringSetting playerName = new StringSetting(this, "\u041d\u0438\u043a \u0438\u0433\u0440\u043e\u043a\u0430").text("");
    private long lastInviteMs = 0L;
    private final EventListener<KeyPressEvent> onKeyPress = event -> {
        if (this.isEnabled() && CoordInvite.mc.field_1724 != null && event.getAction() == 1 && CoordInvite.mc.field_1755 == null && this.inviteKey.isKey(event.getKey())) {
            long now = System.currentTimeMillis();
            if (now - this.lastInviteMs < 400L) {
                return;
            }
            this.lastInviteMs = now;
            this.handleInvite();
        }
    };

    private void handleInvite() {
        if (CoordInvite.mc.field_1724 != null) {
            String nick = this.playerName.getText();
            if (nick != null && !nick.trim().isEmpty()) {
                if (nick.trim().length() < 3) {
                    Experiment.getInstance().getNotificationManager().addNotification(NotificationType.ERROR, "\u041d\u0438\u043a \u0441\u043b\u0438\u0448\u043a\u043e\u043c \u043a\u043e\u0440\u043e\u0442\u043a\u0438\u0439");
                    ClientSounds.CRITICAL.play(1.0f, 1.0f);
                } else {
                    int x = (int)Math.floor(CoordInvite.mc.field_1724.method_23317());
                    int y = (int)Math.floor(CoordInvite.mc.field_1724.method_23318());
                    int z = (int)Math.floor(CoordInvite.mc.field_1724.method_23321());
                    String command = String.format("/m %s %d %d %d", nick.trim(), x, y, z);
                    if (CoordInvite.mc.field_1724.field_3944 != null) {
                        CoordInvite.mc.field_1724.field_3944.method_45729(command);
                        Experiment.getInstance().getNotificationManager().addNotification(NotificationType.SUCCESS, "\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u044b");
                        ClientSounds.MODULE.play(1.0f, 1.1f);
                    } else {
                        ClientSounds.CRITICAL.play(1.0f, 1.0f);
                    }
                }
            } else {
                Experiment.getInstance().getNotificationManager().addNotification(NotificationType.ERROR, "\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u043d\u0438\u043a \u0438\u0433\u0440\u043e\u043a\u0430");
                ClientSounds.CRITICAL.play(1.0f, 1.0f);
            }
        }
    }

    @Override
    public void onEnable() {
        this.lastInviteMs = 0L;
    }
}

