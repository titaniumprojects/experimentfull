/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2596
 *  net.minecraft.class_7439
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_7439;

@ModuleInfo(name="Sounds", category=ModuleCategory.OTHER, enabledByDefault=true, desc="\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0437\u0432\u0443\u043a\u0438 \u043a\u043b\u0438\u0435\u043d\u0442\u0430")
@Environment(value=EnvType.CLIENT)
public class Sounds
extends BaseModule {
    private final SliderSetting volume = new SliderSetting(this, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u0437\u0432\u0443\u043a\u0430").step(0.1f).min(0.1f).max(1.0f).currentValue(1.0f);
    private final EventListener<ReceivePacketEvent> receivePacket = event -> {
        class_7439 packet;
        String msg;
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_7439 && ((msg = (packet = (class_7439)patt0$temp).comp_763().getString()).contains("\u0412\u044b \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043a\u0443\u043f\u0438\u043b\u0438") || msg.contains("\u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u043e \u0438\u0433\u0440\u043e\u043a\u0443"))) {
            ClientSounds.APPLEPAY.play(this.volume.getCurrentValue(), 1.0f);
        }
    };

    public SliderSetting getVolume() {
        return this.volume;
    }

    public EventListener<ReceivePacketEvent> getReceivePacket() {
        return this.receivePacket;
    }
}

