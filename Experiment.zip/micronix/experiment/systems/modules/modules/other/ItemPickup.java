/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.Map;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.PickupEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.utility.game.ItemUtility;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

@ModuleInfo(name="Item Pickup", category=ModuleCategory.OTHER, enabledByDefault=true, desc="\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u044f\u0435\u0442 \u0432\u0430\u0441 \u043f\u0440\u0438 \u043f\u043e\u0434\u043d\u044f\u0442\u0438\u0438 \u0434\u043e\u043d\u0430\u0442\u043d\u043e\u0433\u043e \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430")
@Environment(value=EnvType.CLIENT)
public class ItemPickup
extends BaseModule {
    private final Map<String, String> don = Map.of("krush-helmet", "\u0412\u044b \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043b\u0438 \u0428\u043b\u0435\u043c \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f!", "krush-chestplate", "\u0412\u044b \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043b\u0438 \u041d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f!", "krush-leggings", "\u0412\u044b \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043b\u0438 \u041f\u043e\u043d\u043e\u0436\u0438 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f!", "krush-boots", "\u0412\u044b \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043b\u0438 \u0411\u043e\u0442\u0438\u043d\u043a\u0438 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f!", "krush-sword", "\u0412\u044b \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043b\u0438 \u0434\u043e\u043d\u0430\u0442\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442: \u041c\u0435\u0447 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f");
    private final EventListener<PickupEvent> onPickupEvent = event -> {
        class_1799 stack = event.getItemStack();
        for (Map.Entry<String, String> entry : this.don.entrySet()) {
            if (!ItemUtility.checkDonItem(stack, entry.getKey())) continue;
            MessageUtility.info(class_2561.method_30163((String)entry.getValue()));
            return;
        }
        if (ItemUtility.isDonItem(stack)) {
            String name = stack.method_7964().getString();
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.INFO, "\u0414\u043e\u043d\u0430\u0442\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442", "\u0412\u044b \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043b\u0438 \u0434\u043e\u043d\u0430\u0442\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442: " + name);
        }
    };
}

