/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1294
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SelectSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;

@ModuleInfo(name="Effect Remover", category=ModuleCategory.OTHER)
@Environment(value=EnvType.CLIENT)
public class EffectRemover
extends BaseModule {
    private final SelectSetting effectsToRemove = new SelectSetting(this, "modules.settings.effect_remover.remove");
    private final SelectSetting.Value levitation = new SelectSetting.Value(this.effectsToRemove, "modules.settings.effect_remover.remove.levitation").select();
    private final SelectSetting.Value jumpBoost = new SelectSetting.Value(this.effectsToRemove, "modules.settings.effect_remover.remove.jump_boost").select();
    private final SelectSetting.Value slowFall = new SelectSetting.Value(this.effectsToRemove, "modules.settings.effect_remover.remove.slow_fall").select();
    private final EventListener<ClientPlayerTickEvent> onPlayerTick = event -> {
        if (EffectRemover.mc.field_1724 == null) {
            return;
        }
        if (this.levitation.isSelected()) {
            EffectRemover.mc.field_1724.method_6016(class_1294.field_5902);
        }
        if (this.jumpBoost.isSelected()) {
            EffectRemover.mc.field_1724.method_6016(class_1294.field_5913);
        }
        if (this.slowFall.isSelected()) {
            EffectRemover.mc.field_1724.method_6016(class_1294.field_5906);
        }
    };
}

