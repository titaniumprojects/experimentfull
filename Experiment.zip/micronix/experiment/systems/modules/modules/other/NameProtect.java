/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.StringSetting;
import micronix.experiment.utility.game.EntityUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Name Protect", category=ModuleCategory.OTHER, desc="\u0412\u0438\u0437\u0443\u0430\u043b\u044c\u043d\u043e \u0441\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043d\u0438\u043a \u0438\u0433\u0440\u043e\u043a\u0430")
@Environment(value=EnvType.CLIENT)
public class NameProtect
extends BaseModule {
    private final StringSetting fakeName = new StringSetting(this, "modules.settings.name_protect.fake_name").text("Player");

    public String patchName(String text) {
        String clientUsername = mc.method_1548().method_1676();
        if (EntityUtility.isInGame()) {
            text = text.replace(NameProtect.mc.field_1724.method_5476().getString(), this.fakeName.getText());
        }
        return text.replace(clientUsername, this.fakeName.getText());
    }

    public StringSetting getFakeName() {
        return this.fakeName;
    }
}

