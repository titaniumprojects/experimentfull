/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_2596
 *  net.minecraft.class_640
 *  net.minecraft.class_7439
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.WorldChangeEvent;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_640;
import net.minecraft.class_7439;

@ModuleInfo(name="Auto Duels", category=ModuleCategory.OTHER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043a\u0438\u0434\u0430\u0435\u0442 \u0434\u0443\u044d\u043b\u0438")
@Environment(value=EnvType.CLIENT)
public class AutoDuels
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "\u041f\u0440\u0435\u0434\u043f\u043e\u0447\u0438\u0442\u0430\u0442\u044c");
    private final ModeSetting.Value soft = new ModeSetting.Value(this.mode, "\u0421\u043e\u0444\u0442\u0435\u0440\u043e\u0432");
    private final ModeSetting.Value anSoft = new ModeSetting.Value(this.mode, "\u0410\u043d\u0441\u043e\u0444\u0442\u0435\u0440\u043e\u0432");
    private final ModeSetting.Value random = new ModeSetting.Value(this.mode, "\u0420\u0430\u043d\u0434\u043e\u043c");
    private final ModeSetting kit = new ModeSetting(this, "\u041a\u0438\u0442");
    private final ModeSetting.Value shield = new ModeSetting.Value(this.kit, "\u0429\u0438\u0442");
    private final ModeSetting.Value shipi = new ModeSetting.Value(this.kit, "\u0428\u0438\u043f\u044b 3");
    private final ModeSetting.Value bow = new ModeSetting.Value(this.kit, "\u041b\u0443\u043a");
    private final ModeSetting.Value totem = new ModeSetting.Value(this.kit, "\u0422\u043e\u0442\u0435\u043c");
    private final ModeSetting.Value noDebaff = new ModeSetting.Value(this.kit, "\u041d\u043e\u0443\u0414\u0435\u0431\u0430\u0444");
    private final ModeSetting.Value balls = new ModeSetting.Value(this.kit, "\u0428\u0430\u0440\u044b");
    private final ModeSetting.Value classik = new ModeSetting.Value(this.kit, "\u041a\u043b\u0430\u0441\u0441\u0438\u043a");
    private final ModeSetting.Value cheats = new ModeSetting.Value(this.kit, "\u0427\u0438\u0442\u0435\u0440\u0441\u043a\u0438\u0439 \u0440\u0430\u0439");
    private final ModeSetting.Value nezer = new ModeSetting.Value(this.kit, "\u041d\u0435\u0437\u0435\u0440");
    private final Timer count = new Timer();
    private final List<String> sent = new ArrayList<String>();
    private final EventListener<ReceivePacketEvent> onReceive = event -> {
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_7439) {
            class_7439 packet = (class_7439)patt0$temp;
            String msg = packet.comp_763().getString();
            if (msg.contains("\u043f\u0440\u0438\u043d\u044f\u043b") && !msg.contains("\u043d\u0435 \u043f\u0440\u0438\u043d\u044f\u043b") || msg.contains("\u043a\u043e\u043c\u0430\u043d\u0434\u044b")) {
                this.sent.clear();
                this.toggle();
            }
            if (msg.contains("\u0411\u0430\u043b\u0430\u043d\u0441") || msg.contains("\u043e\u0442\u043a\u043b\u044e\u0447\u0438\u043b \u0437\u0430\u043f\u0440\u043e\u0441\u044b")) {
                event.cancel();
            }
        }
    };
    private final EventListener<WorldChangeEvent> world = e -> this.disable();

    @Override
    public void tick() {
        ArrayList<String> playerNames = new ArrayList<String>();
        for (class_640 entry : AutoDuels.mc.field_1724.field_3944.method_2880()) {
            playerNames.add(entry.method_2966().getName());
        }
        if (this.random.isSelected()) {
            Collections.shuffle(playerNames);
        } else if (this.soft.isSelected()) {
            Collections.reverse(playerNames);
        }
        for (String name : playerNames) {
            if (!this.count.finished(750L) || this.sent.contains(name) || name.equals(AutoDuels.mc.field_1724.method_5820())) continue;
            AutoDuels.mc.field_1724.field_3944.method_45730("duel " + name);
            this.sent.add(name);
            this.count.reset();
        }
        if (AutoDuels.mc.field_1724.field_7512 instanceof class_1707) {
            String title = AutoDuels.mc.field_1755.method_25440().getString();
            if (title.contains("\u0412\u044b\u0431\u043e\u0440 \u043d\u0430\u0431\u043e\u0440\u0430")) {
                AutoDuels.mc.field_1761.method_2906(AutoDuels.mc.field_1724.field_7512.field_7763, this.kit.getValues().indexOf(this.kit.getRandomEnabledElement()), 0, class_1713.field_7790, (class_1657)AutoDuels.mc.field_1724);
                AutoDuels.mc.field_1724.field_7512.method_7593(this.kit.getValues().indexOf(this.kit.getRandomEnabledElement()), 0, class_1713.field_7790, (class_1657)AutoDuels.mc.field_1724);
            } else if (title.contains("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043f\u043e\u0435\u0434\u0438\u043d\u043a\u0430")) {
                AutoDuels.mc.field_1761.method_2906(AutoDuels.mc.field_1724.field_7512.field_7763, 0, 0, class_1713.field_7790, (class_1657)AutoDuels.mc.field_1724);
                AutoDuels.mc.field_1724.field_7512.method_7593(0, 0, class_1713.field_7790, (class_1657)AutoDuels.mc.field_1724);
            }
        }
        super.tick();
    }

    @Override
    public void onEnable() {
        this.count.reset();
        super.onEnable();
    }
}

