/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.fabricmc.loader.impl.FabricLoaderImpl
 *  net.fabricmc.loader.impl.ModContainerImpl
 *  net.minecraft.class_3262
 *  net.minecraft.class_8518
 */
package micronix.experiment.systems.modules.modules.other;

import java.nio.file.Path;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.game.TitleBarHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.impl.FabricLoaderImpl;
import net.fabricmc.loader.impl.ModContainerImpl;
import net.minecraft.class_3262;
import net.minecraft.class_8518;

@ModuleInfo(name="Panic", category=ModuleCategory.OTHER, desc="modules.descriptions.panic")
@Environment(value=EnvType.CLIENT)
public class Panic
extends BaseModule {
    @Override
    public void onEnable() {
        TitleBarHelper.setLightTitleBar();
        Experiment.getInstance().setPanic(true);
        Experiment.getInstance().getFileManager().saveClientFiles();
        for (Module module : Experiment.getInstance().getModuleManager().getModules()) {
            module.setKey(-1);
            module.disable();
        }
        try {
            mc.method_22683().method_4491((class_3262)mc.method_45573(), class_8518.field_44650);
        }
        catch (Exception exception) {
            // empty catch block
        }
        ModContainerImpl experimentMod = this.getExperimentMod();
        if (experimentMod != null) {
            for (Path path : this.getExperimentMod().getOrigin().getPaths()) {
                path.toFile().delete();
            }
            FabricLoaderImpl.INSTANCE.getModsInternal().remove(this.getExperimentMod());
        }
        super.onEnable();
    }

    private ModContainerImpl getExperimentMod() {
        return FabricLoaderImpl.INSTANCE.getAllMods().stream().filter(modContainer -> modContainer.getMetadata().getId().equals(Experiment.MOD_ID)).findFirst().orElse(null);
    }
}

