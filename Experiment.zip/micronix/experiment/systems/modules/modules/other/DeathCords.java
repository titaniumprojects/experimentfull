/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_418
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.waypoints.WayPointsManager;
import micronix.experiment.utility.game.MessageUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_418;

@ModuleInfo(name="Death Cords", category=ModuleCategory.OTHER, desc="\u041e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0441\u043c\u0435\u0440\u0442\u0438 \u0432 \u0447\u0430\u0442")
@Environment(value=EnvType.CLIENT)
public class DeathCords
extends BaseModule {
    private boolean death;
    private final BooleanSetting wayDeath = new BooleanSetting(this, "\u0421\u0442\u0430\u0432\u0438\u0442\u044c \u043c\u0435\u0442\u043a\u0443");
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (DeathCords.mc.field_1755 instanceof class_418 && DeathCords.mc.field_1724 != null) {
            if (this.death) {
                int xCord = (int)DeathCords.mc.field_1724.method_23317();
                int yCord = (int)DeathCords.mc.field_1724.method_23318();
                int zCord = (int)DeathCords.mc.field_1724.method_23321();
                MessageUtility.info(class_2561.method_30163((String)("\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0441\u043c\u0435\u0440\u0442\u0438: " + xCord + " " + yCord + " " + zCord)));
                if (this.wayDeath.isEnabled()) {
                    WayPointsManager wayPointsManager = Experiment.getInstance().getWayPointsManager();
                    if (wayPointsManager.contains("Death")) {
                        wayPointsManager.del("Death");
                    }
                    wayPointsManager.add("Death", xCord, yCord, zCord);
                }
                this.death = false;
            }
        } else {
            this.death = true;
        }
    };
}

