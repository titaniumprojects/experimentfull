/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1304$class_1305
 *  net.minecraft.class_1799
 *  net.minecraft.class_1922
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2350$class_2351
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2487
 *  net.minecraft.class_2520
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2828$class_2830
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3298
 *  net.minecraft.class_3300
 *  net.minecraft.class_337
 *  net.minecraft.class_345
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 *  net.minecraft.class_5498
 *  net.minecraft.class_634
 *  net.minecraft.class_638
 *  net.minecraft.class_640
 *  net.minecraft.class_7225$class_7874
 *  net.minecraft.class_8113$class_8122
 *  net.minecraft.class_8113$class_8123
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.other;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.WorldChangeEvent;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.target.TargetComparators;
import micronix.experiment.systems.target.TargetSettings;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_337;
import net.minecraft.class_345;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_5498;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_640;
import net.minecraft.class_7225;
import net.minecraft.class_8113;
import net.minecraft.class_9801;

@ModuleInfo(name="Counter Mine", category=ModuleCategory.OTHER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0443\u0431\u0438\u0432\u0430\u0435\u0442 \u043a\u0440\u0438\u043f\u0435\u0440\u043e\u0432 \u043d\u0430 \u0444\u0430\u0440\u043c\u0438\u043b\u043a\u0435")
@Environment(value=EnvType.CLIENT)
public class CounterMineOld
extends BaseModule {
    private final BooleanSetting moderDetect = new BooleanSetting(this, "ModerDetect");
    private final BooleanSetting wallHack = new BooleanSetting(this, "WallHack");
    private final BooleanSetting noF5 = new BooleanSetting(this, "No F5");
    private final BooleanSetting noSmoke = new BooleanSetting(this, "NoSmoke");
    private final BooleanSetting aim = new BooleanSetting(this, "Aim");
    private final BooleanSetting silent = new BooleanSetting((SettingsContainer)this, "Silent", () -> !this.aim.isEnabled());
    private final BooleanSetting autoShoot = new BooleanSetting((SettingsContainer)this, "AutoShoot", () -> !this.aim.isEnabled());
    private final BooleanSetting antiAim = new BooleanSetting(this, "AntAim");
    private final BooleanSetting fakeLag = new BooleanSetting(this, "FakeLag");
    private final Timer shootingTimer = new Timer();
    private final Timer moderTimer = new Timer();
    boolean waitRelease;
    boolean stopping;
    private final Timer movementPauseTimer = new Timer();
    private boolean temporaryStopping = false;
    private boolean hasShotDuringPause = false;
    private final List<Head> heads = new ArrayList<Head>();
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (this.moderDetect.isEnabled() && this.moderTimer.finished(5000L)) {
            if (this.isPlayerOnline("johnebik")) {
                MessageUtility.info(class_2561.method_30163((String)"johnebik"));
                CounterMineOld.mc.field_1724.field_3944.method_45730("hub");
                this.moderTimer.reset();
            }
            if (this.isPlayerOnline("sherlock")) {
                MessageUtility.info(class_2561.method_30163((String)"sherlock"));
                CounterMineOld.mc.field_1724.field_3944.method_45730("hub");
                this.moderTimer.reset();
            }
        }
        for (class_1297 entity : CounterMineOld.mc.field_1687.method_18112()) {
            Object modelJson;
            Position itemDisplay;
            String modelId;
            class_238 boundingBox = entity.method_5829();
            if (entity instanceof class_8113.class_8122) {
                String modelJson2;
                String modelId2;
                class_8113.class_8122 itemDisplay2 = (class_8113.class_8122)entity;
                if (CounterMineOld.mc.field_1724.method_5739(entity) < 3.0f && (modelId2 = CounterMineOld.getModelIdFromNbt(itemDisplay2.method_48900(), (class_7225.class_7874)CounterMineOld.mc.field_1724.method_56673())) != null && (modelJson2 = CounterMineOld.findHashedModel(modelId2)) != null && CounterMineOld.mc.field_1724.field_6012 % 200 == 0) {
                    System.out.println(modelJson2);
                }
            }
            if (boundingBox.field_1320 != boundingBox.field_1323 || CounterMineOld.mc.field_1724.method_5739(entity) < 2.0f || !entity.method_5477().getString().contains("\u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430")) continue;
            boolean hologramNearby = CounterMineOld.isHologramNearby(entity, CounterMineOld.mc.field_1687, 2.5);
            if (!(entity instanceof class_8113.class_8122) || (modelId = CounterMineOld.getModelIdFromNbt((itemDisplay = (class_8113.class_8122)entity).method_48900(), (class_7225.class_7874)CounterMineOld.mc.field_1724.method_56673())) == null || (modelJson = CounterMineOld.findHashedModel(modelId)) == null) continue;
            if (((String)modelJson).contains("\"textures\":{\"particle\":\"item/") && ((String)modelJson).contains("\",\"skin\":\"item/")) {
                entity.method_5834(true);
            }
            boolean sex = false;
            if (!((String)modelJson).contains("{\"elements\":[{\"from\":[7.765625,8.0,7.765625]")) continue;
            boolean nearGround = CounterMineOld.isEntityNearGround((class_1297)itemDisplay, (class_1937)CounterMineOld.mc.field_1687, 1.0);
            Head inList = null;
            for (Head head : this.heads) {
                if (head.entity != entity) continue;
                inList = head;
            }
            if (!nearGround) {
                if (inList != null) {
                    inList.poses.get((int)0).cords = entity.method_19538();
                    continue;
                }
                Head addHead = new Head(entity, hologramNearby);
                addHead.poses.add(new Position(entity.method_19538()));
                this.heads.add(addHead);
                continue;
            }
            if (inList == null) continue;
            this.heads.remove(inList);
        }
        for (Head head : new ArrayList<Head>(this.heads)) {
            if (!CounterMineOld.mc.field_1687.method_62145(head.entity)) {
                this.heads.remove(head);
            }
            for (Position itemDisplay : new ArrayList<Position>(head.poses)) {
            }
        }
        this.stopping = false;
        if (this.waitRelease) {
            CounterMineOld.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12971, class_2338.field_10980, class_2350.field_11033));
            this.waitRelease = false;
        }
        if (this.antiAim.isEnabled()) {
            int age = CounterMineOld.mc.field_1724.field_6012;
            float yaw = CounterMineOld.mc.field_1724.method_36454() - 90.0f - (float)(age % 5 == 0 ? 0 : (age % 5 == 1 ? 180 : 90));
            float pitch = 90.0f;
            CounterMineOld.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(CounterMineOld.mc.field_1724.method_23317(), CounterMineOld.mc.field_1724.method_23318(), CounterMineOld.mc.field_1724.method_23321(), yaw, pitch, CounterMineOld.mc.field_1724.method_24828(), CounterMineOld.mc.field_1724.field_5976));
            if (this.aim.isEnabled() && this.autoShoot.isEnabled()) {
                Experiment.getInstance().getRotationHandler().rotate(new Rotation(yaw, pitch), MoveCorrection.NONE, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
        }
        if (CounterMineOld.mc.field_1724 == null || CounterMineOld.mc.field_1687 == null || !this.aim.isEnabled()) {
            return;
        }
        TargetSettings settings = new TargetSettings.Builder().targetPlayers(true).requiredRange(200.0f).sortBy(TargetComparators.FOV).build();
        Experiment.getInstance().getTargetManager().update(settings);
        class_1297 targetEntity = Experiment.getInstance().getTargetManager().getCurrentTarget();
        if (targetEntity == null) {
            return;
        }
        boolean notShoot = true;
        if (!MathUtility.canShoot(targetEntity.method_19538())) {
            this.shootingTimer.reset();
            return;
        }
        Rotation toTarget = this.calculateRotation(targetEntity.method_19538());
        float yaw = toTarget.getYaw();
        float pitch = toTarget.getPitch();
        notShoot = false;
        if (this.silent.isEnabled()) {
            if (!this.autoShoot.isEnabled()) {
                Experiment.getInstance().getRotationHandler().rotate(toTarget, MoveCorrection.NONE, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            }
        } else {
            CounterMineOld.mc.field_1724.method_36456(yaw);
            CounterMineOld.mc.field_1724.method_36457(pitch);
            CounterMineOld.mc.field_1724.method_5847(yaw);
        }
        if (this.autoShoot.isEnabled()) {
            Experiment.getInstance().getRotationHandler().rotate(toTarget, MoveCorrection.NONE, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            if (!this.temporaryStopping) {
                this.temporaryStopping = true;
                this.hasShotDuringPause = false;
                this.movementPauseTimer.reset();
                EntityUtility.setSpeed(0.0);
            }
            if (this.temporaryStopping) {
                if (this.shootingTimer.finished(70L) && !this.hasShotDuringPause) {
                    CounterMineOld.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, class_2338.field_10980, class_2350.field_11033));
                    this.waitRelease = true;
                    this.hasShotDuringPause = true;
                    this.shootingTimer.reset();
                }
                if (this.movementPauseTimer.finished(200L) && this.hasShotDuringPause) {
                    this.temporaryStopping = false;
                    this.stopping = false;
                }
                this.stopping = this.temporaryStopping;
            }
        }
    };
    private final EventListener<InputEvent> onMove = event -> {
        if (this.stopping) {
            event.setForward(0.0f);
            event.setStrafe(0.0f);
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (this.noF5.isEnabled()) {
            this.removeAllArmor();
        }
        if (CounterMineOld.mc.field_1724.field_6012 % 200 == 0) {
            System.out.println("==============================================================");
        }
        class_337 boss = CounterMineOld.mc.field_1705.method_1740();
        boolean bebra = CounterMineOld.mc.field_1690.method_31044() != class_5498.field_26664;
        boolean bl = bebra;
        if (boss != null && bebra) {
            Class<class_337> bossbarklass = class_337.class;
            try {
                Field field = bossbarklass.getField("bossBars");
                Map bossBars = (Map)field.get(boss);
                for (Object uuid : bossBars.keySet()) {
                    class_345 clientBossBar = (class_345)bossBars.get(uuid);
                    List siblings = clientBossBar.method_5414().method_10855();
                    class_5250 newText = class_2561.method_43470((String)"");
                    AtomicInteger i = new AtomicInteger();
                    siblings.stream().allMatch(text -> {
                        if (!text.getString().contains("\ub445\ua223\ua203\ub444\ua223\ua205")) {
                            newText.method_10852(text);
                        }
                        i.getAndIncrement();
                        return true;
                    });
                    clientBossBar.method_5413((class_2561)newText);
                }
            }
            catch (Exception field) {
                // empty catch block
            }
        }
        if (CounterMineOld.mc.field_1687 == null || CounterMineOld.mc.field_1724 == null || !this.wallHack.isEnabled()) {
            return;
        }
        class_4587 matrices = event.getMatrices();
        class_4184 camera = CounterMineOld.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (Head head : this.heads) {
            for (Position pos : head.poses) {
                Draw3DUtility.renderOutlinedBox(matrices, linesBuffer, new class_238(pos.cords.method_1031((double)-0.05f, (double)-0.05f, (double)-0.05f), pos.cords.method_1031((double)0.05f, (double)0.05f, (double)0.05f)).method_989(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215()), (head.isFriend ? ColorRGBA.GREEN : ColorRGBA.RED).withAlpha(100.0f));
            }
        }
        class_9801 builtLinesBuffer = linesBuffer.method_60794();
        if (builtLinesBuffer != null) {
            class_286.method_43433((class_9801)builtLinesBuffer);
        }
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    };
    private final List<class_2596<?>> packets = new ArrayList();
    private final Timer timer = new Timer();
    private class_243 lastPos;
    private boolean replaying;
    private final EventListener<SendPacketEvent> sendListener = this::savePacket;
    private final EventListener<Render3DEvent> event3d = e -> {
        if (CounterMineOld.mc.field_1690.method_31044() != class_5498.field_26664 && this.fakeLag.isEnabled()) {
            class_4587 ms = e.getMatrices();
            class_287 quadsBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
            class_243 cameraPos = CounterMineOld.mc.field_1773.method_19418().method_19326();
            ms.method_22903();
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            Draw3DUtility.renderOutlinedBox(ms, quadsBuffer, CounterMineOld.mc.field_1724.method_5829().method_997(this.lastPos.method_1020(CounterMineOld.mc.field_1724.method_19538())).method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350), ColorRGBA.WHITE.withAlpha(180.0f));
            class_9801 buildQuadsBuffer = quadsBuffer.method_60794();
            if (buildQuadsBuffer != null) {
                class_286.method_43433((class_9801)buildQuadsBuffer);
            }
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            ms.method_22909();
        }
    };
    private final EventListener<WorldChangeEvent> world = e -> this.stop();

    public void removeAllArmor() {
        for (class_1304 slot : class_1304.values()) {
            class_1799 currentArmor;
            if (slot.method_5925() != class_1304.class_1305.field_6178 || (currentArmor = CounterMineOld.mc.field_1724.method_6118(slot)).method_7960()) continue;
            CounterMineOld.mc.field_1724.method_31548().method_7394(currentArmor.method_7972());
            CounterMineOld.mc.field_1724.method_5673(slot, class_1799.field_8037);
        }
    }

    private Rotation calculateRotation(class_243 targetPos) {
        class_243 eyes = CounterMineOld.mc.field_1724.method_5836(1.0f);
        double dx = targetPos.field_1352 - eyes.field_1352;
        double dy = targetPos.field_1351 - eyes.field_1351;
        double dz = targetPos.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return new Rotation(yaw, pitch);
    }

    private class_243 getAimPosition(class_1297 target) {
        class_243 pos = target.method_19538();
        return pos.method_1031(0.0, (double)0.1f, 0.0);
    }

    public static boolean shouldHideEntity(class_8113.class_8122 entity) {
        String modelId = CounterMineOld.getModelIdFromNbt(entity.method_48900(), (class_7225.class_7874)class_310.method_1551().field_1724.method_56673());
        CounterMineOld mod = Experiment.getInstance().getModuleManager().getModule(CounterMineOld.class);
        if (modelId != null) {
            String modelJson = CounterMineOld.findHashedModel(modelId);
            return modelJson != null && (modelJson.contains("smoke_sprite_transparent") && mod.noSmoke.isEnabled() || modelJson.contains(",\"textures\":{\"arms\":\"") && mod.noF5.isEnabled() && CounterMineOld.mc.field_1690.method_31044() != class_5498.field_26664 || modelJson.contains("\"textures\":{\"particle\":\"item/") && modelJson.contains("\",\"skin\":\"item/") && mod.noF5.isEnabled() && CounterMineOld.mc.field_1690.method_31044() != class_5498.field_26664);
        }
        return false;
    }

    public void savePacket(SendPacketEvent e) {
        if (this.replaying || !EntityUtility.isInGame() || !this.fakeLag.isEnabled()) {
            return;
        }
        this.packets.add(e.getPacket());
        e.cancel();
        if (this.timer.finished(600L) || !this.packets.stream().filter(packet -> packet instanceof class_2846).toList().isEmpty()) {
            this.stop();
            this.start();
            this.timer.reset();
        }
    }

    public void start() {
        if (CounterMineOld.mc.field_1724 == null) {
            return;
        }
        this.packets.clear();
        this.lastPos = CounterMineOld.mc.field_1724.method_19538();
        this.timer.reset();
        this.replaying = false;
    }

    public void stop() {
        if (CounterMineOld.mc.field_1724 == null) {
            return;
        }
        this.replaying = true;
        for (class_2596<?> p : this.packets) {
            CounterMineOld.mc.field_1724.field_3944.method_52787(p);
        }
        this.replaying = false;
        this.packets.clear();
        this.lastPos = null;
    }

    @Override
    public void onDisable() {
        this.stop();
        Experiment.getInstance().getTargetManager().reset();
    }

    public boolean isPlayerOnline(String playerName) {
        class_310 client = class_310.method_1551();
        class_634 networkHandler = client.method_1562();
        if (networkHandler == null) {
            return false;
        }
        for (class_640 entry : networkHandler.method_2880()) {
            if (!entry.method_2966().getName().equals(playerName)) continue;
            return true;
        }
        return false;
    }

    public static String findHashedModel(String hashedId) {
        String string;
        block9: {
            class_2960 modelPath;
            class_3300 resourceManager = mc.method_1478();
            Optional resource = resourceManager.method_14486(modelPath = class_2960.method_60655((String)"minecraft", (String)("models/item/" + hashedId.replace("minecraft:", "") + ".json")));
            if (!resource.isPresent()) {
                return null;
            }
            BufferedReader reader = ((class_3298)resource.get()).method_43039();
            try {
                string = reader.lines().collect(Collectors.joining("\n"));
                if (reader == null) break block9;
            }
            catch (Throwable throwable) {
                try {
                    if (reader != null) {
                        try {
                            reader.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException e) {
                    System.err.println("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u0438\u0438 \u0441\u0435\u0440\u0432\u0435\u0440\u043d\u043e\u0439 \u043c\u043e\u0434\u0435\u043b\u0438: " + e.getMessage());
                    return null;
                }
            }
            reader.close();
        }
        return string;
    }

    public static String getModelIdFromNbt(class_1799 itemStack, class_7225.class_7874 registryManager) {
        class_2487 components;
        class_2487 compound;
        class_2520 nbt = itemStack.method_57375(registryManager);
        if (nbt instanceof class_2487 && (compound = (class_2487)nbt).method_10573("components", 10) && (components = compound.method_10562("components")).method_10573("minecraft:item_model", 8)) {
            return components.method_10558("minecraft:item_model");
        }
        return null;
    }

    public static boolean isHologramNearby(class_1297 entity, class_638 world, double searchRadius) {
        for (class_1297 nearbyEntity : world.method_18112()) {
            class_8113.class_8123 textDisplay;
            if (!(nearbyEntity instanceof class_8113.class_8123) || (textDisplay = (class_8113.class_8123)nearbyEntity).method_48915() == null || textDisplay.method_48915().getString().isEmpty() || !((double)entity.method_5739((class_1297)textDisplay) < searchRadius)) continue;
            return true;
        }
        return false;
    }

    public static boolean isEntityNearGround(class_1297 entity, class_1937 world, double maxDistance) {
        class_2338 entityPos = entity.method_24515();
        double entityY = entity.method_23318();
        for (int y = entityPos.method_10264(); y >= entityPos.method_10264() - 3 && y >= world.method_31607(); --y) {
            class_2338 checkPos = new class_2338(entityPos.method_10263(), y, entityPos.method_10260());
            class_2680 blockState = world.method_8320(checkPos);
            class_265 collisionShape = blockState.method_26220((class_1922)world, checkPos);
            if (collisionShape.method_1110()) continue;
            double blockTopY = (double)checkPos.method_10264() + collisionShape.method_1105(class_2350.class_2351.field_11052);
            double distance = entityY - blockTopY;
            if (!(distance <= maxDistance) || !(distance >= 0.0)) break;
            return true;
        }
        return false;
    }

    @Environment(value=EnvType.CLIENT)
    static class Head {
        class_1297 entity;
        boolean isFriend;
        final List<Position> poses = new ArrayList<Position>();

        public Head(class_1297 entity, boolean isFriend) {
            this.entity = entity;
            this.isFriend = isFriend;
        }
    }

    @Environment(value=EnvType.CLIENT)
    static class Position {
        class_243 cords;
        final Timer age = new Timer();

        public Position(class_243 cords) {
            this.cords = cords;
        }
    }
}

