/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 */
package micronix.experiment.systems.modules.modules.other;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;

@ModuleInfo(name="Auto Resell", category=ModuleCategory.OTHER, desc="modules.descriptions.auto_resell")
@Environment(value=EnvType.CLIENT)
public class AutoResell
extends BaseModule {
    private final Timer openTimer = new Timer();
    private final Timer clickTimer = new Timer();
    private boolean isAutoProcess;
    private boolean auctionHandled;
    private boolean storageHandled;
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (AutoResell.mc.field_1724 == null || AutoResell.mc.field_1761 == null || !ServerUtility.isFT()) {
            return;
        }
        if (this.openTimer.finished(60000L)) {
            if (!this.isAuctionOrStorageOpen()) {
                AutoResell.mc.field_1724.field_3944.method_45730("ah " + AutoResell.mc.field_1724.method_5477().getString());
                this.isAutoProcess = true;
                this.clickTimer.reset();
            }
            this.openTimer.reset();
        }
        this.handleAuctionAndStorage();
    };

    private void handleAuctionAndStorage() {
        boolean isAuctionOpen = this.isTitleContains("\u0430\u0443\u043a\u0446\u0438\u043e\u043d\u044b");
        boolean isStorageOpen = this.isTitleContains("\u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0435");
        if (this.isAutoProcess && isAuctionOpen && !this.auctionHandled && this.clickTimer.finished(300L)) {
            AutoResell.mc.field_1761.method_2906(AutoResell.mc.field_1724.field_7512.field_7763, 46, 0, class_1713.field_7790, (class_1657)AutoResell.mc.field_1724);
            this.auctionHandled = true;
            this.clickTimer.reset();
        }
        if (this.isAutoProcess && isStorageOpen && !this.storageHandled && this.clickTimer.finished(300L)) {
            AutoResell.mc.field_1761.method_2906(AutoResell.mc.field_1724.field_7512.field_7763, 52, 0, class_1713.field_7790, (class_1657)AutoResell.mc.field_1724);
            AutoResell.mc.field_1724.method_7346();
            this.storageHandled = true;
            this.isAutoProcess = false;
            this.clickTimer.reset();
        }
        if (!isAuctionOpen) {
            this.auctionHandled = false;
        }
        if (!isStorageOpen) {
            this.storageHandled = false;
        }
    }

    private boolean isAuctionOrStorageOpen() {
        return this.isTitleContains("\u0430\u0443\u043a\u0446\u0438\u043e\u043d\u044b") || this.isTitleContains("\u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0435");
    }

    private boolean isTitleContains(String string) {
        if (AutoResell.mc.field_1755 == null || AutoResell.mc.field_1724 == null) {
            return false;
        }
        String title = AutoResell.mc.field_1755.method_25440().getString().toLowerCase();
        return AutoResell.mc.field_1724.field_7512 instanceof class_1707 && title.contains(string.toLowerCase());
    }
}

