/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1308
 *  net.minecraft.class_1429
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package micronix.experiment.systems.modules.modules.other;

import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.event.impl.window.ChatTypeEvent;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.RangeSetting;
import micronix.experiment.ui.components.animated.AnimatedNumber;
import micronix.experiment.ui.components.popup.Popup;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.gui.GuiUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1429;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

@ModuleInfo(name="Test", category=ModuleCategory.OTHER)
@Environment(value=EnvType.CLIENT)
public class TestModule
extends BaseModule {
    private final RangeSetting testBoolean = new RangeSetting(this, "Name").min(1.0f).max(10.0f).step(1.0f).firstValue(3.0f).secondValue(6.0f);
    private Popup popup = new Popup(100.0f, 100.0f);
    private AnimatedNumber time;
    private final EventListener<ChatTypeEvent> onChat = event -> {};
    private final EventListener<Render3DEvent> onRender3D = event -> {
        if (TestModule.mc.field_1724 == null) {
            return;
        }
    };
    private final EventListener<HudRenderEvent> onHudRenderEvent = event -> {
        UIContext context = UIContext.of(event.getContext(), TestModule.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32118(), TestModule.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32119(), class_310.method_1551().method_61966().method_60637(false));
    };

    @Override
    public void tick() {
        if (TestModule.mc.field_1724 == null) {
            return;
        }
        class_1297 entity = TestModule.mc.field_1692;
        boolean isAnimal = entity instanceof class_1429;
        boolean isMob = entity instanceof class_1308;
        MessageUtility.info(class_2561.method_30163((String)("Is Animal: " + isAnimal + " | IsMob: " + isMob)));
        super.tick();
    }

    @Override
    public void onEnable() {
        this.popup = new Popup(100.0f, 100.0f, 90.0f).text("Sosalin1337").separator().checkbox("\u0414\u0440\u0443\u0433", false).checkbox("\u0412\u0440\u0430\u0433", true).checkbox("\u0413\u043b\u0430\u0432\u043d\u044b\u0439 \u0432\u0440\u0430\u0433 \u0432\u0441\u0435\u0445 \u043d\u0430\u0440\u043e\u0434\u043e\u0432", false).separator().checkbox("Glabos", true).checkbox("Sosia", true).checkbox("x, x, x", false);
        for (Module module : Experiment.getInstance().getModuleManager().getModules()) {
            System.out.println(String.format("modules.descriptions.%s=%s", module.getName().toLowerCase().replace(" ", "_"), module.getDescription()));
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    private class_243 getRenderPos() {
        float tickDelta = class_310.method_1551().method_61966().method_60637(false);
        return new class_243(class_3532.method_16436((double)tickDelta, (double)TestModule.mc.field_1724.field_6014, (double)TestModule.mc.field_1724.method_23317()), class_3532.method_16436((double)tickDelta, (double)(TestModule.mc.field_1724.field_6036 + (double)TestModule.mc.field_1724.method_18381(TestModule.mc.field_1724.method_18376())), (double)(TestModule.mc.field_1724.method_23318() + (double)TestModule.mc.field_1724.method_18381(TestModule.mc.field_1724.method_18376()))), class_3532.method_16436((double)tickDelta, (double)TestModule.mc.field_1724.field_5969, (double)TestModule.mc.field_1724.method_23321()));
    }

    private void renderTexture(class_4587 matrices, class_2960 identifier, ColorRGBA color, float size) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        builder.method_22918(matrix, 0.0f, -size, 0.0f).method_22913(0.0f, 0.0f).method_39415(color.getRGB());
        builder.method_22918(matrix, -size, -size, 0.0f).method_22913(0.0f, 1.0f).method_39415(color.getRGB());
        builder.method_22918(matrix, -size, 0.0f, 0.0f).method_22913(1.0f, 1.0f).method_39415(color.getRGB());
        builder.method_22918(matrix, 0.0f, 0.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(color.getRGB());
        class_286.method_43433((class_9801)builder.method_60800());
    }
}

