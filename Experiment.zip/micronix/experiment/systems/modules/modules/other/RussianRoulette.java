/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.zxing.BarcodeFormat
 *  com.google.zxing.MultiFormatWriter
 *  com.google.zxing.client.j2se.MatrixToImageWriter
 *  com.google.zxing.common.BitMatrix
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1011
 *  net.minecraft.class_1043
 *  net.minecraft.class_1044
 *  net.minecraft.class_2561
 *  net.minecraft.class_2960
 */
package micronix.experiment.systems.modules.modules.other;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

@ModuleInfo(name="Russian Roulette", category=ModuleCategory.OTHER, desc="\u0420\u0443\u0441\u0441\u043a\u0430\u044f \u0440\u0443\u043b\u0435\u0442\u043a\u0430, \u043a\u0430\u043a \u043f\u043e\u0432\u0435\u0437\u0435\u0442 :)")
@Environment(value=EnvType.CLIENT)
public class RussianRoulette
extends BaseModule {
    private final ModeSetting mode = new ModeSetting((SettingsContainer)this, "\u0421\u043b\u043e\u0436\u043d\u043e\u0441\u0442\u044c", "\u041b\u0435\u0433\u043a\u0430\u044f - \u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0435\u0442 \u0447\u0438\u0442, \u0441\u0440\u0435\u0434\u043d\u044f\u044f - \u0432\u0440\u0443\u0431\u0430\u0435\u0442 \u0441\u043f\u044f\u0449\u0438\u0439 \u0440\u0435\u0436\u0438\u043c \u043d\u0430 \u043f\u043a, \u043e\u0447\u0435\u043d\u044c \u0441\u043b\u043e\u0436\u043d\u0430\u044f - ???");
    private final RouletteMode easy = new RouletteMode(this, this, this.mode, "\u041b\u0435\u0433\u043a\u0430\u044f"){

        @Override
        void execute() {
            IMinecraft.mc.method_1490();
        }
    };
    private final RouletteMode normal = new RouletteMode(this, this, this.mode, "\u0421\u0440\u0435\u0434\u043d\u044f\u044f"){

        @Override
        void execute() {
            try {
                Runtime.getRuntime().exec(new String[]{"rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"});
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
    };
    private final RouletteMode veryHard = new RouletteMode(this, this, this.mode, "\u041e\u0447\u0435\u043d\u044c \u0441\u043b\u043e\u0436\u043d\u0430\u044f"){

        @Override
        void execute() {
        }
    };
    private final Random RANDOM = new Random();
    private volatile class_2960 qrTexture;
    private final Animation qrAnimation = new Animation(5000L, Easing.CUBIC_IN_OUT);
    private volatile boolean qrRemoving;
    private final EventListener<PreHudRenderEvent> onPreHudRender = event -> {
        if (this.qrTexture == null) {
            return;
        }
        if ((double)this.qrAnimation.getValue() == 1.0 && !this.qrRemoving) {
            this.qrRemoving = true;
        }
        this.qrAnimation.update(this.qrRemoving ? 0.0f : 1.0f);
    };

    @Override
    public void onEnable() {
        if (RussianRoulette.mc.field_1687 == null || RussianRoulette.mc.field_1724 == null) {
            return;
        }
        int[] drum = new int[6];
        Arrays.setAll(drum, i -> i == 5 ? 1 : 0);
        int randomValue = drum[this.RANDOM.nextInt(drum.length)];
        boolean isWin = randomValue == 0;
        boolean bl = isWin;
        if (isWin) {
            MessageUtility.info(class_2561.method_30163((String)(this.veryHard.isSelected() ? "\u0422\u0435\u0431\u0435 \u043f\u043e\u0432\u0435\u0437\u043b\u043e, \u0432\u043e\u0442 \u0442\u0435\u0431\u0435 \u043f\u0440\u0438\u0437" : "\u0422\u0435\u0431\u0435 \u043f\u043e\u0432\u0435\u0437\u043b\u043e!")));
            if (this.veryHard.isSelected()) {
                this.generateAndShowQR("https://4lapy.ru/journal/info/taksa-osobennosti-porody-kharakter-soderzhanie/");
            }
        } else {
            MessageUtility.info(class_2561.method_30163((String)(this.veryHard.isSelected() ? "\u0410\u043d\u043b\u0430\u043a, \u0432\u043e\u0442 \u0442\u0435\u0431\u0435 \u0443\u0442\u0435\u0448\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0438\u0437" : "\u0410\u043d\u043b\u0430\u043a")));
            if (this.veryHard.isSelected()) {
                this.generateAndShowQR("https://pornhub.com");
            }
        }
        if (this.easy.isSelected()) {
            this.easy.execute();
        } else if (this.normal.isSelected()) {
            this.normal.execute();
        }
        super.onEnable();
    }

    private void generateAndShowQR(String url) {
        CompletableFuture.runAsync(() -> {
            try {
                BitMatrix matrix = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, 300, 300);
                BufferedImage bufferedImage = MatrixToImageWriter.toBufferedImage((BitMatrix)matrix);
                class_1011 nativeImage = this.bufferedImageToNativeImage(bufferedImage);
                mc.execute(() -> {
                    if (this.qrTexture != null) {
                        mc.method_1531().method_4615(this.qrTexture);
                    }
                    class_2960 id = Experiment.id("temp/qr/" + String.valueOf(UUID.randomUUID()));
                    mc.method_1531().method_4616(id, (class_1044)new class_1043(nativeImage));
                    this.qrTexture = id;
                    this.qrAnimation.update(1.0f);
                    this.qrRemoving = false;
                });
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private class_1011 bufferedImageToNativeImage(BufferedImage bufferedImage) {
        int width = bufferedImage.getWidth();
        int height = bufferedImage.getHeight();
        class_1011 nativeImage = new class_1011(width, height, true);
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                int argb = bufferedImage.getRGB(x, y);
                nativeImage.method_61941(x, y, argb);
            }
        }
        return nativeImage;
    }

    public class_2960 getQrTexture() {
        return this.qrTexture;
    }

    public Animation getQrAnimation() {
        return this.qrAnimation;
    }

    public boolean isQrRemoving() {
        return this.qrRemoving;
    }

    @Environment(value=EnvType.CLIENT)
    abstract class RouletteMode
    extends ModeSetting.Value {
        public RouletteMode(RussianRoulette this$0, RussianRoulette this$02, ModeSetting parent, String name) {
            super(parent, name);
        }

        abstract void execute();
    }
}

