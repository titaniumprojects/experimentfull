/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2596
 *  net.minecraft.class_7439
 */
package micronix.experiment.systems.modules.modules.other;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.StringSetting;
import micronix.experiment.utility.game.TextUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_7439;

@ModuleInfo(name="Auto Auth", category=ModuleCategory.OTHER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u0442 \u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u043d\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0435")
@Environment(value=EnvType.CLIENT)
public class AutoAuth
extends BaseModule {
    private final BooleanSetting random = new BooleanSetting(this, "\u0420\u0430\u043d\u0434\u043e\u043c");
    private final StringSetting password = new StringSetting((SettingsContainer)this, "\u041f\u0430\u0440\u043e\u043b\u044c", this.random::isEnabled).text("123123");
    private final Map<String, String> nickAndPassword = new HashMap<String, String>();
    private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_7439) {
            class_7439 packet = (class_7439)patt0$temp;
            if (AutoAuth.mc.field_1724 != null) {
                String message = packet.comp_763().getString().toLowerCase();
                String randomPass = TextUtility.getRandomNick();
                String password = this.random.isEnabled() ? randomPass : this.password.getText();
                this.nickAndPassword.put(AutoAuth.mc.field_1724.method_5476().getString(), " " + randomPass);
                if (message.contains("\u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435\u0441\u044c") || message.contains("/reg")) {
                    AutoAuth.mc.field_1724.field_3944.method_45730(String.format("reg %s %s", password, password));
                } else if (message.contains("\u0430\u0432\u0442\u043e\u0440\u0438\u0437\u0443\u0439\u0442\u0435\u0441\u044c") || message.contains("/login") || message.contains("/l") && message.matches("/l(\\s|$)")) {
                    AutoAuth.mc.field_1724.field_3944.method_45730(String.format("l %s", password));
                }
            }
        }
    };

    public Map<String, String> listPassword() {
        return Collections.unmodifiableMap(this.nickAndPassword);
    }

    public void put(String key, String value) {
        this.nickAndPassword.put(key, value);
    }
}

