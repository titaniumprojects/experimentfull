/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Inventory Utils", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class InvUtils
extends BaseModule {
    private final SelectSetting util = new SelectSetting(this, "targets");
    private final SelectSetting.Value scroller = new SelectSetting.Value(this.util, "Item Scroller").select();
    private final SelectSetting.Value slotLock = new SelectSetting.Value(this.util, "Slot Lock").select();
    private final SelectSetting lock = new SelectSetting((SettingsContainer)this, "modules.settings.slot_lock.lock", () -> !this.slotLock.isSelected());
    private final SelectSetting.Value slot1 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot1").select();
    private final SelectSetting.Value slot2 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot2");
    private final SelectSetting.Value slot3 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot3");
    private final SelectSetting.Value slot4 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot4");
    private final SelectSetting.Value slot5 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot5");
    private final SelectSetting.Value slot6 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot6");
    private final SelectSetting.Value slot7 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot7");
    private final SelectSetting.Value slot8 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot8");
    private final SelectSetting.Value slot9 = new SelectSetting.Value(this.lock, "modules.settings.slot_lock.lock.slot9");
    private final SliderSetting scrollDelay = new SliderSetting((SettingsContainer)this, "delay", () -> !this.scroller.isSelected()).currentValue(0.0f).max(150.0f).min(0.0f).step(1.0f);
    private final Timer timer = new Timer();
    private final Timer healTimer = new Timer();
    private float lastHealth = -1.0f;
    private boolean eating;

    public boolean isLocked(int slot) {
        SelectSetting.Value[] slots = new SelectSetting.Value[]{this.slot1, this.slot2, this.slot3, this.slot4, this.slot5, this.slot6, this.slot7, this.slot8, this.slot9};
        return slot >= 0 && slot < slots.length && slots[slot].isSelected() && this.isEnabled();
    }

    public SelectSetting getUtil() {
        return this.util;
    }

    public SelectSetting.Value getScroller() {
        return this.scroller;
    }

    public SelectSetting.Value getSlotLock() {
        return this.slotLock;
    }

    public SelectSetting getLock() {
        return this.lock;
    }

    public SelectSetting.Value getSlot1() {
        return this.slot1;
    }

    public SelectSetting.Value getSlot2() {
        return this.slot2;
    }

    public SelectSetting.Value getSlot3() {
        return this.slot3;
    }

    public SelectSetting.Value getSlot4() {
        return this.slot4;
    }

    public SelectSetting.Value getSlot5() {
        return this.slot5;
    }

    public SelectSetting.Value getSlot6() {
        return this.slot6;
    }

    public SelectSetting.Value getSlot7() {
        return this.slot7;
    }

    public SelectSetting.Value getSlot8() {
        return this.slot8;
    }

    public SelectSetting.Value getSlot9() {
        return this.slot9;
    }

    public SliderSetting getScrollDelay() {
        return this.scrollDelay;
    }

    public Timer getTimer() {
        return this.timer;
    }

    public Timer getHealTimer() {
        return this.healTimer;
    }

    public float getLastHealth() {
        return this.lastHealth;
    }

    public boolean isEating() {
        return this.eating;
    }
}

