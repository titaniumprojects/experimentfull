/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1810
 *  net.minecraft.class_2886
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.StartBreakBlockEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_2886;

@ModuleInfo(name="Mine Helper", category=ModuleCategory.PLAYER, desc="\u041f\u043e\u043c\u043e\u0449\u043d\u0438\u043a \u0432 \u0448\u0430\u0445\u0442\u0435")
@Environment(value=EnvType.CLIENT)
public class MineHelper
extends BaseModule {
    private final BooleanSetting save = new BooleanSetting((SettingsContainer)this, "\u0421\u043e\u0445\u0440\u0430\u043d\u044f\u0442\u044c \u043a\u0438\u0440\u043a\u0443", "\u041d\u0435 \u0434\u0430\u0435\u0442 \u0441\u043b\u043e\u043c\u0430\u0442\u044c \u0431\u043b\u043e\u043a, \u0435\u0441\u043b\u0438 \u043f\u0440\u0435\u0434\u043c\u0435\u0442 \u0434\u043e\u0441\u0442\u0438\u0433 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u043d\u043e\u0439 \u043f\u0440\u043e\u0447\u043d\u043e\u0441\u0442\u0438").enable();
    public final SliderSetting percent = new SliderSetting(this, "\u041f\u0440\u043e\u0447\u043d\u043e\u0441\u0442\u044c").step(1.0f).min(1.0f).max(70.0f).currentValue(10.0f).suffix("%");
    private final BooleanSetting autoReplace = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e \u0437\u0430\u043c\u0435\u043d\u0430", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043c\u0435\u043d\u044f\u0435\u0442 \u043a\u0438\u0440\u043a\u0443 \u043f\u0440\u0438 \u043d\u0438\u0437\u043a\u043e\u0439 \u043f\u0440\u043e\u0447\u043d\u043e\u0441\u0442\u0438");
    private final BooleanSetting autoRepair = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e \u043f\u043e\u0447\u0438\u043d\u043a\u0430", "\u0427\u0438\u043d\u0438\u0442 \u043a\u0438\u0440\u043a\u0443 \u0441 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435\u043c \u043e\u043f\u044b\u0442\u0430");
    private final BindSetting bind = new BindSetting(this, "\u041a\u043d\u043e\u043f\u043a\u0430 \u043f\u043e\u0447\u0438\u043d\u043a\u0438", () -> !this.autoRepair.isEnabled());
    private final Timer timer = new Timer();
    private boolean rotate;
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
        if (this.bind.isKey(event.getKey()) && event.getAction() == 1) {
            this.rotate = true;
            this.repairPickaxeWithBottle();
        }
    };
    private final EventListener<StartBreakBlockEvent> onStartBreakBlockEvent = event -> {
        if (MineHelper.mc.field_1724 == null) {
            return;
        }
        class_1799 currentStack = MineHelper.mc.field_1724.method_6047();
        if (!this.isValidPickaxe(currentStack)) {
            return;
        }
        double durabilityPercent = this.getDurabilityPercent(currentStack);
        if (!this.save.isEnabled() || durabilityPercent >= (double)this.percent.getCurrentValue()) {
            return;
        }
        event.cancel();
        this.handleLowDurability(currentStack);
    };
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (MineHelper.mc.field_1724 == null || !this.rotate) {
            return;
        }
        Experiment.getInstance().getRotationHandler().rotate(new Rotation(MineHelper.mc.field_1724.method_36454(), 90.0f), MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.USE_ITEM);
    };

    private void handleLowDurability(class_1799 currentStack) {
        boolean switched = false;
        if (this.autoReplace.isEnabled()) {
            switched = this.trySwitchPickaxe(currentStack);
        }
        if (!switched && this.timer.finished(800L)) {
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.ERROR, "\u041a\u0438\u0440\u043a\u0430 \u043f\u043e\u0447\u0442\u0438 \u0441\u043b\u043e\u043c\u0430\u043d\u0430!", "\u041d\u0435\u0442 \u0437\u0430\u043c\u0435\u043d\u044b/\u043e\u043f\u044b\u0442\u0430 \u0434\u043b\u044f \u043f\u043e\u0447\u0438\u043d\u043a\u0438");
            this.timer.reset();
        }
    }

    private void repairPickaxeWithBottle() {
        if (MineHelper.mc.field_1724 == null || MineHelper.mc.field_1755 != null) {
            return;
        }
        class_1799 pickaxe = MineHelper.mc.field_1724.method_6047();
        if (!this.isValidPickaxe(pickaxe) || pickaxe.method_7919() == 0) {
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.ERROR, "\u041e\u0448\u0438\u0431\u043a\u0430", "\u041d\u0435\u0442 \u043a\u0438\u0440\u043a\u0438 \u0438\u043b\u0438 \u043e\u043d\u0430 \u043d\u0435 \u043f\u043e\u0432\u0440\u0435\u0436\u0434\u0435\u043d\u0430!");
            this.rotate = false;
            return;
        }
        if (!this.ensureBottleInOffhand()) {
            return;
        }
        this.useExperienceBottle();
    }

    private boolean ensureBottleInOffhand() {
        class_1799 offhand = MineHelper.mc.field_1724.method_6079();
        if (offhand.method_7909() == class_1802.field_8287) {
            return true;
        }
        SlotGroup<ItemSlot> searchArea = SlotGroups.inventory().and(SlotGroups.hotbar());
        ItemSlot bottleSlot = searchArea.findItem(stack -> stack.method_7909() == class_1802.field_8287);
        if (bottleSlot == null) {
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.ERROR, "\u041d\u0435\u0442 \u0431\u0443\u0442\u044b\u043b\u043e\u043a \u043e\u043f\u044b\u0442\u0430!", "\u0412\u0430\u043c \u043d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c\u043e \u0438\u043c\u0435\u0442\u044c \u0431\u0443\u0442\u044b\u043b\u043e\u0447\u043a\u0438 \u043e\u043f\u044b\u0442\u0430 \u0432 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u0435");
            this.rotate = false;
            return false;
        }
        InventoryUtility.moveItem(bottleSlot, InventoryUtility.getOffHandSlot());
        return true;
    }

    private void useExperienceBottle() {
        if (MineHelper.mc.field_1724.method_6079().method_7909() != class_1802.field_8287) {
            MineHelper.mc.field_1690.field_1904.method_23481(false);
            this.rotate = false;
            return;
        }
        RotationHandler rotation = Experiment.getInstance().getRotationHandler();
        MineHelper.mc.field_1761.method_41931(MineHelper.mc.field_1687, sequence -> new class_2886(class_1268.field_5810, sequence, rotation.getServerRotation().getYaw(), rotation.getServerRotation().getYaw()));
    }

    private boolean trySwitchPickaxe(class_1799 currentStack) {
        HotbarSlot bestSlot = this.findBestPickaxeSlot(currentStack);
        if (bestSlot == null) {
            return false;
        }
        InventoryUtility.selectHotbarSlot(bestSlot);
        if (this.timer.finished(800L)) {
            class_1799 newStack = bestSlot.itemStack();
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, "\u0417\u0430\u043c\u0435\u043d\u0430 \u043a\u0438\u0440\u043a\u0438", String.format("\u0417\u0430\u043c\u0435\u043d\u0438\u043b \u043a\u0438\u0440\u043a\u0443 \u0441 %.1f%% \u043d\u0430 %.1f%%", this.getDurabilityPercent(currentStack), this.getDurabilityPercent(newStack)));
            this.timer.reset();
        }
        return true;
    }

    private HotbarSlot findBestPickaxeSlot(class_1799 currentStack) {
        double currentDurability = this.getDurabilityPercent(currentStack);
        HotbarSlot bestSlot = null;
        double bestDurability = currentDurability;
        for (int i = 0; i < 9; ++i) {
            double durability;
            HotbarSlot slot = InventoryUtility.getHotbarSlot(i);
            class_1799 stack = slot.itemStack();
            if (!this.isValidPickaxe(stack) || !((durability = this.getDurabilityPercent(stack)) > bestDurability)) continue;
            bestDurability = durability;
            bestSlot = slot;
        }
        return bestSlot;
    }

    private boolean isValidPickaxe(class_1799 stack) {
        return stack != null && stack.method_7963() && stack.method_7909() instanceof class_1810;
    }

    private double getDurabilityPercent(class_1799 stack) {
        return (double)(stack.method_7936() - stack.method_7919()) / (double)stack.method_7936() * 100.0;
    }
}

