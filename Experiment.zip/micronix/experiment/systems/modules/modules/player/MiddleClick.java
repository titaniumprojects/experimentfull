/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1802
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventIntegration;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.friends.FriendManager;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1802;

@ModuleInfo(name="Middle Click", category=ModuleCategory.PLAYER, desc="\u0412\u044b\u043f\u043e\u043b\u043d\u044f\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043f\u0440\u0438 \u043d\u0430\u0436\u0430\u0442\u0438\u0438 \u043d\u0430 \u043a\u043e\u043b\u0435\u0441\u0438\u043a\u043e \u043c\u044b\u0448\u0438")
@Environment(value=EnvType.CLIENT)
public class MiddleClick
extends BaseModule {
    private final SelectSetting actions = new SelectSetting(this, "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435").min(1);
    private final SelectSetting.Value clickPearl = new SelectSetting.Value(this.actions, "\u0411\u0440\u043e\u0441\u0430\u0442\u044c \u0436\u0435\u043c\u0447\u0443\u0433").select();
    private final SelectSetting.Value clickFriend = new SelectSetting.Value(this.actions, "\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0442\u044c \u0434\u0440\u0443\u0437\u0435\u0439");
    private final BindSetting clickFriendKey = new BindSetting(this, "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0434\u0440\u0443\u0437\u0435\u0439", () -> !this.clickFriend.isSelected());
    private final BindSetting clickPearlKey = new BindSetting(this, "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u043f\u0435\u0440\u043b\u0430", () -> !this.clickPearl.isSelected());
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> this.handleKey(event.getKey(), event.getAction());
    private final EventListener<MouseEvent> onMouseEvent = event -> this.handleKey(event.getButton(), event.getAction());

    private void handleKey(int key, int action) {
        if (MiddleClick.mc.field_1755 == null && action == 1) {
            if (this.clickFriend.isSelected() && this.clickFriendKey.isKey(key) && MiddleClick.mc.field_1692 instanceof class_1657) {
                String nick = MiddleClick.mc.field_1692.method_5477().getString();
                FriendManager friend = Experiment.getInstance().getFriendManager();
                if (friend.isFriend(nick)) {
                    friend.remove(nick);
                } else {
                    friend.add(nick);
                }
            }
            if (this.clickPearl.isSelected() && this.clickPearlKey.isKey(key)) {
                EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8634);
            }
        }
    }
}

