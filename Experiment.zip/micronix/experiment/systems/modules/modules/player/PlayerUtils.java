/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1536
 *  net.minecraft.class_1657
 *  net.minecraft.class_1787
 *  net.minecraft.class_2246
 *  net.minecraft.class_418
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.InternalAttackEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_2246;
import net.minecraft.class_418;

@ModuleInfo(name="Player Utils", category=ModuleCategory.PLAYER, desc="\u0423\u0442\u0438\u043b\u0438\u0442\u044b \u0434\u043b\u044f \u0438\u0433\u0440\u043e\u043a\u0430")
@Environment(value=EnvType.CLIENT)
public class PlayerUtils
extends BaseModule {
    private final BooleanSetting antiAfk = new BooleanSetting((SettingsContainer)this, "Anti AFK", "\u041d\u0435 \u043f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0441\u0435\u0440\u0432\u0435\u0440\u0443 \u043a\u0438\u043a\u043d\u0443\u0442\u044c \u0432\u0430\u0441, \u043f\u043e\u043a\u0430 \u0432\u044b AFK");
    private final BooleanSetting autoRespawn = new BooleanSetting((SettingsContainer)this, "Auto Respawn", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0432\u043e\u0437\u0440\u043e\u0436\u0434\u0430\u0435\u0442 \u043f\u0440\u0438 \u0441\u043c\u0435\u0440\u0442\u0438");
    private final BooleanSetting autoFish = new BooleanSetting((SettingsContainer)this, "Auto Fish", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043b\u043e\u0432\u0438\u0442 \u0440\u044b\u0431\u0443");
    private final BooleanSetting fastLadder = new BooleanSetting((SettingsContainer)this, "Fast Ladder", "\u0423\u0441\u043a\u043e\u0440\u044f\u0435\u0442 \u0432\u0430\u0441 \u043d\u0430 \u043b\u0435\u0441\u0442\u043d\u0438\u0446\u0435");
    private final BooleanSetting noFriendDamage = new BooleanSetting((SettingsContainer)this, "\u041d\u0435 \u0431\u0438\u0442\u044c \u0434\u0440\u0443\u0437\u0435\u0439", "\u041d\u0435 \u043f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0431\u0438\u0442\u044c \u0434\u0440\u0443\u0437\u0435\u0439");
    private final ModeSetting antiAFKMode = new ModeSetting((SettingsContainer)this, "\u0420\u0435\u0436\u0438\u043c\u044b", () -> !this.antiAfk.isEnabled());
    private final ModeSetting.Value chat = new ModeSetting.Value(this.antiAFKMode, "\u041f\u0438\u0441\u0430\u0442\u044c \u0432 \u0447\u0430\u0442");
    private final ModeSetting.Value jump = new ModeSetting.Value(this.antiAFKMode, "\u041f\u0440\u044b\u0433\u0430\u0442\u044c");
    private final ModeSetting.Value swing = new ModeSetting.Value(this.antiAFKMode, "\u0412\u0437\u043c\u0430\u0445 \u0440\u0443\u043a\u043e\u0439");
    private final SliderSetting delay = new SliderSetting(this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0434\u043b\u044f \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439", () -> !this.antiAfk.isEnabled()).min(5.0f).max(60.0f).step(5.0f).currentValue(50.0f);
    private final Timer timerAFK = new Timer();
    private final Timer fishTimer = new Timer();
    private boolean hookFlag;
    private boolean thrown;
    private boolean activeAFK;
    private final EventListener<InternalAttackEvent> onAttackEvent = event -> {
        if (this.noFriendDamage.isEnabled() && event.getEntity() instanceof class_1657 && Experiment.getInstance().getFriendManager().isFriend(event.getEntity().method_5477().getString())) {
            event.cancel();
        }
    };

    @Override
    public void tick() {
        if (this.antiAfk.isEnabled()) {
            if (this.timerAFK.finished(10000L)) {
                this.activeAFK = true;
            }
            if (EntityUtility.isPlayerMoving()) {
                this.activeAFK = false;
                this.timerAFK.reset();
            }
            if (this.activeAFK && (float)PlayerUtils.mc.field_1724.field_6012 % this.delay.getCurrentValue() == 5.0f) {
                if (this.chat.isSelected()) {
                    PlayerUtils.mc.field_1724.field_3944.method_45729("\u0412\u0441\u0435\u043c \u043f\u0440\u0438\u0432\u0435\u0442 " + Math.random() + " !");
                } else if (this.jump.isSelected() && PlayerUtils.mc.field_1724.method_24828()) {
                    PlayerUtils.mc.field_1724.method_6043();
                } else if (this.swing.isSelected()) {
                    PlayerUtils.mc.field_1724.method_6104(class_1268.field_5808);
                }
            }
        }
        if (this.autoRespawn.isEnabled() && PlayerUtils.mc.field_1755 instanceof class_418 && PlayerUtils.mc.field_1724 != null) {
            PlayerUtils.mc.field_1724.method_7331();
            mc.method_1507(null);
        }
        if (this.autoFish.isEnabled() && PlayerUtils.mc.field_1724.method_6047().method_7909() instanceof class_1787) {
            if (PlayerUtils.mc.field_1724.field_7513 != null) {
                this.thrown = true;
                this.fishTimer.reset();
                if (!this.hookFlag && ((Boolean)PlayerUtils.mc.field_1724.field_7513.method_5841().method_12789(class_1536.field_23234)).booleanValue()) {
                    this.throwRod();
                    this.hookFlag = true;
                    this.fishTimer.reset();
                }
            } else if (this.hookFlag && this.fishTimer.finished(600L)) {
                this.throwRod();
                this.hookFlag = false;
                this.thrown = false;
                this.fishTimer.reset();
            } else if (!this.hookFlag && this.thrown && this.fishTimer.finished(3000L)) {
                this.throwRod();
                this.thrown = false;
                this.fishTimer.reset();
            }
        }
        if (PlayerUtils.mc.field_1724 != null && PlayerUtils.mc.field_1687.method_8320(PlayerUtils.mc.field_1724.method_24515()).method_27852(class_2246.field_9983) && this.fastLadder.isEnabled()) {
            PlayerUtils.mc.field_1724.method_18799(PlayerUtils.mc.field_1724.method_18798().method_18805(1.0, 1.43, 1.0));
        }
        super.tick();
    }

    private void throwRod() {
        PlayerUtils.mc.field_1761.method_2919((class_1657)PlayerUtils.mc.field_1724, class_1268.field_5808);
        PlayerUtils.mc.field_1724.method_6104(class_1268.field_5808);
    }

    @Override
    public void onDisable() {
        this.hookFlag = false;
    }
}

