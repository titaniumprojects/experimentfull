/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1934
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828
 *  net.minecraft.class_2828$class_2829
 */
package micronix.experiment.systems.modules.modules.player;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.FakePlayerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

@ModuleInfo(name="Free Camera", category=ModuleCategory.PLAYER, desc="\u0421\u0432\u043e\u0431\u043e\u0434\u043d\u0430\u044f \u043a\u0430\u043c\u0435\u0440\u0430")
@Environment(value=EnvType.CLIENT)
public class FreeCam
extends BaseModule {
    private boolean wasFlyingAllowed = false;
    private boolean wasFlying = false;
    private float oldFlyingSpeed = 0.0f;
    private FakePlayerEntity dummy = null;
    private class_1934 prevGameMode;
    private final SliderSetting speed = new SliderSetting(this, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c").currentValue(1.0f).max(15.0f).min(0.1f).step(0.1f).currentValue(3.0f);
    private final BooleanSetting display = new BooleanSetting(this, "\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0442\u044c \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b");
    private int x;
    private int y;
    private int z;
    private final EventListener<HudRenderEvent> render2d = event -> {
        if (this.display.isEnabled()) {
            class_2338 diff = FreeCam.mc.field_1724.method_24515().method_10059(new class_2382(this.x, this.y, this.z));
            String pos = "X: " + diff.method_10263() + " Y: " + diff.method_10264() + " Z: " + diff.method_10260();
            Font bold = Fonts.BOLD.getFont(8.0f);
            event.getContext().drawText(bold, class_2561.method_30163((String)pos), sr.getScaledWidth() / 2.0f - bold.width(pos) / 2.0f + 8.0f, sr.getScaledHeight() / 2.0f - 20.0f);
        }
    };
    private final EventListener<SendPacketEvent> onSendPacket = event -> {
        if (event.getPacket() instanceof class_2828) {
            event.cancel();
        }
    };

    @Override
    public void tick() {
        if (FreeCam.mc.field_1724 == null) {
            return;
        }
        FreeCam.mc.field_1724.method_31549().method_7248(this.speed.getCurrentValue() / 10.0f);
        FreeCam.mc.field_1724.method_31549().field_7479 = true;
        super.tick();
    }

    @Override
    public void onEnable() {
        if (FreeCam.mc.field_1724 == null || FreeCam.mc.field_1687 == null) {
            return;
        }
        this.wasFlyingAllowed = FreeCam.mc.field_1724.method_31549().field_7478;
        this.wasFlying = FreeCam.mc.field_1724.method_31549().field_7479;
        this.oldFlyingSpeed = FreeCam.mc.field_1724.method_31549().method_7252();
        this.prevGameMode = FreeCam.mc.field_1761.method_2920();
        this.dummy = new FakePlayerEntity(FreeCam.mc.field_1687, new GameProfile(UUID.randomUUID(), mc.method_1548().method_1676()));
        this.dummy.method_5878((class_1297)FreeCam.mc.field_1724);
        this.dummy.method_5719((class_1297)FreeCam.mc.field_1724);
        this.dummy.spawn();
        FreeCam.mc.field_1724.method_31549().field_7478 = true;
        FreeCam.mc.field_1724.method_31549().field_7479 = true;
        FreeCam.mc.field_1761.method_2907(class_1934.field_9219);
        FreeCam.mc.field_1724.method_31549().method_7248(this.speed.getCurrentValue() / 10.0f);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (this.dummy == null || FreeCam.mc.field_1687 == null || FreeCam.mc.field_1724 == null || mc.method_1562() == null) {
            return;
        }
        FreeCam.mc.field_1724.method_5719((class_1297)this.dummy);
        mc.method_1562().method_52787((class_2596)new class_2828.class_2829(this.dummy.method_23317(), this.dummy.method_23318(), this.dummy.method_23321(), false, FreeCam.mc.field_1724.field_5976));
        FreeCam.mc.field_1724.method_31549().field_7478 = this.wasFlyingAllowed;
        FreeCam.mc.field_1724.method_31549().field_7479 = this.wasFlying;
        FreeCam.mc.field_1724.method_31549().method_7248(this.oldFlyingSpeed);
        FreeCam.mc.field_1761.method_2907(this.prevGameMode);
        this.dummy.remove();
        this.dummy = null;
        FreeCam.mc.field_1724.method_18800(0.0, 0.0, 0.0);
        super.onDisable();
    }
}

