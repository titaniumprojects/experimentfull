/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1713
 *  net.minecraft.class_1747
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_2480
 *  net.minecraft.class_2596
 *  net.minecraft.class_2645
 *  net.minecraft.class_2813
 *  net.minecraft.class_2815
 *  net.minecraft.class_304
 *  net.minecraft.class_3675
 *  net.minecraft.class_408
 *  net.minecraft.class_437
 *  net.minecraft.class_471
 *  net.minecraft.class_476
 *  net.minecraft.class_481
 *  net.minecraft.class_490
 *  net.minecraft.class_498
 *  net.minecraft.class_7706
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.ui.components.textfield.TextField;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_2596;
import net.minecraft.class_2645;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_471;
import net.minecraft.class_476;
import net.minecraft.class_481;
import net.minecraft.class_490;
import net.minecraft.class_498;
import net.minecraft.class_7706;

@ModuleInfo(name="Gui Move", category=ModuleCategory.PLAYER, enabledByDefault=true)
@Environment(value=EnvType.CLIENT)
public class GuiMove
extends BaseModule {
    private final List<class_2596<?>> packets = new ArrayList();
    private final List<class_2813> pickupPackets = new ArrayList<class_2813>();
    private final ModeSetting mode = new ModeSetting(this, "\u0420\u0435\u0436\u0438\u043c");
    private final ModeSetting.Value noBypass = new ModeSetting.Value(this.mode, "\u0411\u0435\u0437 \u043e\u0431\u0445\u043e\u0434\u0430");
    private final ModeSetting.Value auto = new ModeSetting.Value(this.mode, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439").select();
    private final ModeSetting.Value custom = new ModeSetting.Value(this.mode, "\u041d\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u0435\u043c\u044b\u0439");
    private final ModeSetting containers = new ModeSetting((SettingsContainer)this, "\u0412 \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u0430\u0445", this.auto::isSelected);
    private final ModeSetting.Value notWork = new ModeSetting.Value(this.containers, "\u0421\u0442\u043e\u044f\u0442\u044c");
    private final ModeSetting.Value vanillaCon = new ModeSetting.Value(this.containers, "\u0414\u0432\u0438\u0433\u0430\u0442\u044c\u0441\u044f").select();
    private final ModeSetting.Value shift = new ModeSetting.Value(this.containers, "\u0428\u0438\u0444\u0442");
    private final BooleanSetting cancelClose = new BooleanSetting((SettingsContainer)this, "\u041e\u0442\u043c\u0435\u043d\u044f\u0442\u044c \u0437\u0430\u043a\u0440\u044b\u0442\u0438\u0435", this.auto::isSelected).enable();
    private final BooleanSetting jump = new BooleanSetting((SettingsContainer)this, "\u0423\u0447\u0438\u0442\u044b\u0432\u0430\u0442\u044c \u043f\u0440\u044b\u0436\u043e\u043a", this.auto::isSelected);
    private final ModeSetting bypassMode = new ModeSetting((SettingsContainer)this, "\u041e\u0431\u0445\u043e\u0434", this.auto::isSelected);
    private final ModeSetting.Value vanilla = new ModeSetting.Value(this.bypassMode, "\u0411\u0435\u0437 \u043e\u0431\u0445\u043e\u0434\u0430");
    private final ModeSetting.Value slow = new ModeSetting.Value(this.bypassMode, "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u0438\u0435").select();
    private final ModeSetting.Value slowClose = new ModeSetting.Value(this.bypassMode, "\u041f\u0440\u0438 \u0437\u0430\u043a\u0440\u044b\u0442\u0438\u0438");
    private final ModeSetting.Value close = new ModeSetting.Value(this.bypassMode, "\u0424\u0435\u0439\u043a \u0437\u0430\u043a\u0440\u044b\u0442\u0438\u0435");
    private final BooleanSetting ground = new BooleanSetting((SettingsContainer)this, "\u0411\u0435\u0437 \u043e\u0431\u0445\u043e\u0434\u0430 \u043d\u0430 \u0437\u0435\u043c\u043b\u0435", () -> this.vanilla.isSelected() || this.auto.isSelected());
    private final SliderSetting cooldown = new SliderSetting((SettingsContainer)this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", () -> this.vanilla.isSelected() || this.close.isSelected() || this.auto.isSelected()).min(50.0f).max(500.0f).step(50.0f).currentValue(100.0f).suffix(" ms");
    private final Timer staying = new Timer();
    private final Timer grounding = new Timer();
    private boolean stay;
    private boolean sending;
    private int screenId = 0;
    private final EventListener<ClientPlayerTickEvent> onPlayerTick = event -> {
        if (this.auto.isSelected()) {
            if (ServerUtility.isST()) {
                this.notWork.select();
                this.cancelClose.enable();
                this.jump.enable();
                this.slow.select();
                this.ground.enable();
                this.cooldown.setCurrentValue(500.0f);
            } else if (ServerUtility.isFT()) {
                this.notWork.select();
                this.cancelClose.enable();
                this.jump.setEnabled(false);
                this.slowClose.select();
                this.ground.setEnabled(false);
                this.cooldown.setCurrentValue(100.0f);
            } else if (ServerUtility.isFT()) {
                this.notWork.select();
                this.cancelClose.enable();
                this.jump.setEnabled(false);
                this.slowClose.select();
                this.ground.setEnabled(false);
                this.cooldown.setCurrentValue(100.0f);
            } else if (ServerUtility.isIntave()) {
                this.notWork.select();
                this.cancelClose.enable();
                this.jump.setEnabled(false);
                this.slow.select();
                this.ground.setEnabled(false);
                this.cooldown.setCurrentValue(150.0f);
            } else if (ServerUtility.isHW()) {
                this.notWork.select();
                this.cancelClose.enable();
                this.jump.setEnabled(false);
                this.slow.select();
                this.ground.setEnabled(false);
                this.cooldown.setCurrentValue(100.0f);
            } else {
                this.notWork.select();
                this.cancelClose.enable();
                this.jump.setEnabled(false);
                this.slow.select();
                this.ground.setEnabled(false);
                this.cooldown.setCurrentValue(100.0f);
            }
        }
        int n = this.screenId = GuiMove.mc.field_1724.field_7512 != null ? GuiMove.mc.field_1724.field_7512.field_7763 : 0;
        if (this.slowClose.isSelected() && GuiMove.mc.field_1755 == null && !this.packets.isEmpty()) {
            this.stay = true;
        }
        if (this.canSend()) {
            this.sendPackets();
            this.stay = false;
        }
        if (!GuiMove.mc.field_1724.method_24828()) {
            this.grounding.reset();
        }
        if (!(GuiMove.mc.field_1724.field_7512 == null || !GuiMove.mc.field_1724.field_7512.method_34255().method_7960() && GuiMove.mc.field_1724.field_7512.method_34255() != class_1799.field_8037 || this.pickupPackets.isEmpty() || this.sending)) {
            this.stay = true;
            if (GuiMove.mc.field_1724.method_24828() && this.ground.isEnabled() || this.staying.finished((long)this.cooldown.getCurrentValue())) {
                this.sendPickupPackets();
            }
        }
        if (this.isTyping() || !this.invCheck()) {
            return;
        }
        long windowHandle = mc.method_22683().method_4490();
        class_304[] movementKeys = new class_304[]{GuiMove.mc.field_1690.field_1894, GuiMove.mc.field_1690.field_1881, GuiMove.mc.field_1690.field_1913, GuiMove.mc.field_1690.field_1849, GuiMove.mc.field_1690.field_1903};
        for (class_304 key : movementKeys) {
            int keyCode = class_3675.method_15981((String)key.method_1428()).method_1444();
            key.method_23481(class_3675.method_15987((long)windowHandle, (int)keyCode));
        }
        if (GuiMove.mc.field_1724.method_31549().field_7479) {
            int keyCode = class_3675.method_15981((String)GuiMove.mc.field_1690.field_1832.method_1428()).method_1444();
            GuiMove.mc.field_1690.field_1832.method_23481(class_3675.method_15987((long)windowHandle, (int)keyCode));
        }
    };
    private final EventListener<SendPacketEvent> eventEventListener = event -> {
        class_476 container;
        class_437 patt0$temp = GuiMove.mc.field_1755;
        if (patt0$temp instanceof class_476 && (container = (class_476)patt0$temp).method_25440().getString().toLowerCase().contains("\u0432\u044b\u0431\u043e\u0440")) {
            return;
        }
        if (GuiMove.mc.field_1724 == null || this.isTyping() || !this.invCheck() || this.vanilla.isSelected() || this.sending || GuiMove.mc.field_1724.method_24828() && this.ground.isEnabled() || this.noBypass.isSelected()) {
            return;
        }
        class_2596<?> patt1$temp = event.getPacket();
        if (patt1$temp instanceof class_2813) {
            class_2813 packet = (class_2813)patt1$temp;
            if (this.ground.isEnabled() && GuiMove.mc.field_1724.method_24828()) {
                this.grounding.reset();
            }
            if (packet.method_12195() == class_1713.field_7790 || packet.method_12195() == class_1713.field_7793 || packet.method_12195() == class_1713.field_7796 || packet.method_12195() == class_1713.field_7789) {
                this.pickupPackets.add(packet);
                event.cancel();
                return;
            }
            if (this.slow.isSelected()) {
                this.packets.add((class_2596<?>)packet);
                event.cancel();
                this.stay = true;
            } else if (this.slowClose.isSelected()) {
                class_1747 item;
                class_1792 patt2$temp;
                this.packets.add((class_2596<?>)packet);
                event.cancel();
                if (GuiMove.mc.field_1755 instanceof class_476 || ServerUtility.isPastaFT() && (patt2$temp = packet.method_12190().method_7909()) instanceof class_1747 && (item = (class_1747)patt2$temp).method_7711() instanceof class_2480 || packet.method_12195() == class_1713.field_7795) {
                    this.stay = true;
                }
            } else if (this.close.isSelected()) {
                GuiMove.mc.field_1724.field_3944.method_52787((class_2596)new class_2815(this.screenId));
            }
        }
    };
    private final EventListener<InputEvent> onInput = event -> {
        if (GuiMove.mc.field_1755 instanceof class_476 && this.shift.isSelected()) {
            event.setSneak(true);
        }
        if (this.stay) {
            event.setForward(0.0f);
            event.setStrafe(0.0f);
            if (this.jump.isEnabled()) {
                event.setJump(false);
            }
        }
        if (this.jump.isEnabled() && event.isJump() || event.getStrafe() != 0.0f || event.getForward() != 0.0f) {
            this.staying.reset();
        }
    };
    private final EventListener<ReceivePacketEvent> onReceivePacket = event -> {
        if (this.cancelClose.isEnabled() && event.getPacket() instanceof class_2645) {
            event.cancel();
        }
    };

    private boolean isTyping() {
        return GuiMove.mc.field_1755 instanceof class_408 || GuiMove.mc.field_1755 != null && TextField.LAST_FIELD != null && TextField.LAST_FIELD.isFocused() || GuiMove.mc.field_1755 instanceof class_498 || GuiMove.mc.field_1755 instanceof class_471 || GuiMove.mc.field_1755 instanceof class_481 && class_481.field_2896 == class_7706.method_47344();
    }

    private boolean invCheck() {
        return !this.notWork.isSelected() || this.ground.isEnabled() && GuiMove.mc.field_1724.method_24828() || GuiMove.mc.field_1755 instanceof class_490 || GuiMove.mc.field_1755 instanceof class_481 || GuiMove.mc.field_1755 == null;
    }

    private void sendPackets() {
        if (this.packets.isEmpty()) {
            return;
        }
        this.sending = true;
        this.packets.forEach(arg_0 -> GuiMove.mc.field_1724.field_3944.method_52787(arg_0));
        this.packets.clear();
        GuiMove.mc.field_1724.field_3944.method_52787((class_2596)new class_2815(this.screenId));
        this.sending = false;
    }

    public boolean canSend() {
        return this.isEnabled() && this.stay && (GuiMove.mc.field_1724.method_24828() && this.ground.isEnabled() && this.grounding.finished(500L) || this.staying.finished((long)this.cooldown.getCurrentValue()));
    }

    private void sendPickupPackets() {
        if (this.pickupPackets.isEmpty()) {
            return;
        }
        this.sending = true;
        this.pickupPackets.forEach(arg_0 -> GuiMove.mc.field_1724.field_3944.method_52787((class_2596)arg_0));
        this.pickupPackets.clear();
        this.sending = false;
    }

    public boolean slowing() {
        return this.slow.isSelected() || this.slowClose.isSelected();
    }

    public SliderSetting getCooldown() {
        return this.cooldown;
    }

    public void setStay(boolean stay) {
        this.stay = stay;
    }

    public void setSending(boolean sending) {
        this.sending = sending;
    }
}

