/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1548
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1548;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;

@ModuleInfo(name="Creeper Farm", category=ModuleCategory.PLAYER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0443\u0431\u0438\u0432\u0430\u0435\u0442 \u043a\u0440\u0438\u043f\u0435\u0440\u043e\u0432 \u043d\u0430 \u0444\u0430\u0440\u043c\u0438\u043b\u043a\u0435")
@Environment(value=EnvType.CLIENT)
public class CreeperFarm
extends BaseModule {
    private boolean retreating;
    private class_243 retreatTarget;

    @Override
    public void tick() {
        if (CreeperFarm.mc.field_1724 == null || !FabricLoader.getInstance().isModLoaded("baritone")) {
            return;
        }
        class_1309 creeper = this.findClosestCreeper();
        if (creeper == null) {
            return;
        }
        double distance = CreeperFarm.mc.field_1724.method_19538().method_1022(creeper.method_19538());
        if (distance <= 3.3) {
            Rotation rot = this.calculateCreeperRotation(creeper);
            Experiment.getInstance().getRotationHandler().rotate(rot);
            if ((double)CreeperFarm.mc.field_1724.method_7261(1.0f) >= 0.9) {
                CreeperFarm.mc.field_1761.method_2918((class_1657)CreeperFarm.mc.field_1724, (class_1297)creeper);
                CreeperFarm.mc.field_1724.method_6104(class_1268.field_5808);
                class_243 playerPos = CreeperFarm.mc.field_1724.method_19538();
                class_243 creeperPos = creeper.method_19538();
                class_243 away = playerPos.method_1020(creeperPos).method_1029();
                this.retreatTarget = playerPos.method_1019(away.method_1021(4.0));
                this.retreating = true;
            }
        }
    }

    private Rotation calculateCreeperRotation(class_1309 target) {
        class_243 toCreeper = new class_243(target.method_23317(), target.method_23318() + (double)(CreeperFarm.mc.field_1724.method_5739((class_1297)target) < 2.0f ? 0.5f : target.method_18381(target.method_18376())), target.method_23321());
        double dx = toCreeper.field_1352;
        double dy = toCreeper.field_1351;
        double dz = toCreeper.field_1350;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f + MathUtility.random(-2.0, 2.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz))) + MathUtility.random(-1.0, 1.0);
        return new Rotation(yaw, pitch);
    }

    private Rotation calculateRotationToward(class_243 targetPos) {
        class_243 playerEyes = new class_243(CreeperFarm.mc.field_1724.method_23317(), CreeperFarm.mc.field_1724.method_23318() + (double)CreeperFarm.mc.field_1724.method_18381(CreeperFarm.mc.field_1724.method_18376()), CreeperFarm.mc.field_1724.method_23321());
        class_243 toPoint = targetPos.method_1031(0.0, (double)CreeperFarm.mc.field_1724.method_18381(CreeperFarm.mc.field_1724.method_18376()), 0.0).method_1020(playerEyes);
        double dx = toPoint.field_1352;
        double dy = toPoint.field_1351;
        double dz = toPoint.field_1350;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f + MathUtility.random(-2.0, 2.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz))) + MathUtility.random(-1.0, 1.0);
        return new Rotation(yaw, pitch);
    }

    private class_1309 findClosestCreeper() {
        class_1309 closest = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1297 e : CreeperFarm.mc.field_1687.method_18112()) {
            double d;
            if (!(e instanceof class_1548)) continue;
            double d2 = CreeperFarm.mc.field_1724.method_19538().method_1022(e.method_19538());
            if (!(d <= 50.0 && Math.abs(CreeperFarm.mc.field_1724.method_23318() - e.method_23318()) < 4.0 && d2 < bestDist)) continue;
            bestDist = d2;
            closest = (class_1309)e;
        }
        return closest;
    }

    @Override
    public void onEnable() {
        if (CreeperFarm.mc.field_1724 == null) {
            return;
        }
        if (FabricLoader.getInstance().isModLoaded("baritone")) {
            CreeperFarm.mc.field_1724.field_3944.method_45729("#follow entity creeper");
            CreeperFarm.mc.field_1724.field_3944.method_45729("#allowBreak false");
        } else {
            MessageUtility.info(class_2561.method_30163((String)("\u0414\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b " + this.getName() + " \u043d\u0443\u0436\u0435\u043d \u043c\u043e\u0434 baritone")));
            this.toggle();
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (FabricLoader.getInstance().isModLoaded("baritone")) {
            CreeperFarm.mc.field_1724.field_3944.method_45729("#stop");
        }
        super.onDisable();
    }
}

