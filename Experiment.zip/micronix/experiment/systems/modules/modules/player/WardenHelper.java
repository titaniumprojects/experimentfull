/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1531
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2586
 *  net.minecraft.class_2595
 *  net.minecraft.class_2646
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 */
package micronix.experiment.systems.modules.modules.player;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.WorldChangeEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.WorldUtility;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.render.RenderUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2646;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

@ModuleInfo(name="Warden Helper", category=ModuleCategory.PLAYER, desc="Warden Helper \u043f\u043e\u043c\u043e\u0436\u0435\u0442 \u0432\u0430\u043c \u043d\u0430 1.21.8 \u0430\u043d\u043a\u0430\u0445 ")
@Environment(value=EnvType.CLIENT)
public class WardenHelper
extends BaseModule {
    private final BooleanSetting autoGPS = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e GPS", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0441\u0442\u0430\u0432\u0438\u0442 GPS-\u043c\u0435\u0442\u043a\u0443 \u043d\u0430 \u0433\u043e\u0442\u043e\u0432\u044b\u0439 \u0441\u0443\u043d\u0434\u0443\u043a").enable();
    private final BooleanSetting notifications = new BooleanSetting((SettingsContainer)this, "\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u0435 \u043a\u043e\u0433\u0434\u0430 \u0441\u0443\u043d\u0434\u0443\u043a \u0433\u043e\u0442\u043e\u0432 \u0438\u043b\u0438 \u0441\u043a\u043e\u0440\u043e \u043e\u0442\u043a\u0440\u043e\u0435\u0442\u0441\u044f").enable();
    private final BindSetting resetBind = new BindSetting(this, "\u0420\u0435\u0441\u0435\u0442 \u0441\u0443\u043d\u0434\u0443\u043a\u043e\u0432");
    private final Map<class_2338, ChestData> chestDataMap = new ConcurrentHashMap<class_2338, ChestData>();
    private final Set<class_2338> gpsVisited = new HashSet<class_2338>();
    private final Set<class_2338> notified = new HashSet<class_2338>();
    private class_2338 currentGPSTarget = null;
    private static final double WARDEN_X = 2000.0;
    private static final double WARDEN_Z = 2000.0;
    private static final double ZONE_RADIUS = 250.0;
    private static final ColorRGBA COLOR_INACTIVE = new ColorRGBA(180.0f, 180.0f, 180.0f, 120.0f);
    private static final ColorRGBA COLOR_DEFAULT = new ColorRGBA(255.0f, 60.0f, 60.0f, 180.0f);
    private static final ColorRGBA COLOR_WARN = new ColorRGBA(255.0f, 220.0f, 50.0f, 180.0f);
    private static final ColorRGBA COLOR_READY = new ColorRGBA(60.0f, 255.0f, 60.0f, 180.0f);
    private static final Pattern TIME_PATTERN = Pattern.compile("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?");
    private static final Pattern SECONDS_PATTERN = Pattern.compile("(\\d+)\\s*(\u0441|s|\u0441\u0435\u043a|sec)");
    private final EventListener<WorldChangeEvent> onWorldChange = event -> this.clearAll();
    private final EventListener<KeyPressEvent> onKeyPress = event -> {
        if (this.resetBind.isKey(event.getKey()) && event.getAction() == 1) {
            this.clearAll();
            if (WardenHelper.mc.field_1724 != null) {
                Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, "Warden Helper", "\u0421\u0443\u043d\u0434\u0443\u043a\u0438 \u0441\u0431\u0440\u043e\u0448\u0435\u043d\u044b!");
            }
        }
    };
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (WardenHelper.mc.field_1724 == null || WardenHelper.mc.field_1687 == null || !this.isInWardenZone()) {
            return;
        }
        this.updateTimersFromEntities();
        this.updateGPSAndNotifications();
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (WardenHelper.mc.field_1687 == null || WardenHelper.mc.field_1724 == null) {
            return;
        }
        class_4587 matrices = event.getMatrices();
        class_4184 camera = event.getCamera();
        class_243 cam = camera.method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 quadsBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        for (class_2586 be : WorldUtility.blockEntities) {
            if (!this.isWardenChest(be)) continue;
            class_2338 pos = be.method_11016();
            this.chestDataMap.computeIfAbsent(pos, ChestData::new);
            ColorRGBA color = this.getESPColor(this.chestDataMap.get(pos));
            class_238 box = new class_238(pos).method_989(-cam.method_10216(), -cam.method_10214(), -cam.method_10215());
            Draw3DUtility.renderFilledBox(matrices, quadsBuffer, box, color.withAlpha(50.0f));
        }
        RenderUtility.buildBuffer(quadsBuffer);
        class_287 linesBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (class_2586 be : WorldUtility.blockEntities) {
            if (!this.isWardenChest(be)) continue;
            class_2338 pos = be.method_11016();
            ColorRGBA color = this.getESPColor(this.chestDataMap.getOrDefault(pos, new ChestData(pos)));
            class_238 box = new class_238(pos).method_989(-cam.method_10216(), -cam.method_10214(), -cam.method_10215());
            Draw3DUtility.renderOutlinedBox(matrices, linesBuffer, box, color.withAlpha(200.0f));
            Draw3DUtility.renderBoxInternalDiagonals(matrices, linesBuffer, box, color.withAlpha(120.0f));
        }
        RenderUtility.buildBuffer(linesBuffer);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    };

    private void clearAll() {
        this.chestDataMap.clear();
        this.gpsVisited.clear();
        this.notified.clear();
        this.currentGPSTarget = null;
    }

    private boolean isWardenChest(class_2586 be) {
        return be instanceof class_2595 || be instanceof class_2646;
    }

    private boolean isInWardenZone() {
        return Math.abs(WardenHelper.mc.field_1724.method_23317() - 2000.0) <= 250.0 && Math.abs(WardenHelper.mc.field_1724.method_23321() - 2000.0) <= 250.0;
    }

    private void updateTimersFromEntities() {
        for (Map.Entry<class_2338, ChestData> entry : this.chestDataMap.entrySet()) {
            class_2338 pos = entry.getKey();
            ChestData data = entry.getValue();
            boolean found = false;
            class_238 searchBox = new class_238(pos).method_1009(1.0, 3.0, 1.0);
            for (class_1531 stand : WardenHelper.mc.field_1687.method_8390(class_1531.class, searchBox, class_1297::method_16914)) {
                String name = stand.method_5797().getString().replaceAll("\u00a7[0-9a-fk-or]", "");
                long seconds = this.parseTimeToSeconds(name);
                if (seconds < 0L) continue;
                data.setTimer(seconds);
                found = true;
                break;
            }
            if (found) continue;
            data.hasTimer = false;
        }
    }

    private long parseTimeToSeconds(String str) {
        Matcher m1 = TIME_PATTERN.matcher(str);
        if (m1.find()) {
            if (m1.group(3) == null) {
                return (long)Integer.parseInt(m1.group(1)) * 60L + (long)Integer.parseInt(m1.group(2));
            }
            return (long)Integer.parseInt(m1.group(1)) * 3600L + (long)Integer.parseInt(m1.group(2)) * 60L + (long)Integer.parseInt(m1.group(3));
        }
        Matcher m2 = SECONDS_PATTERN.matcher(str);
        if (m2.find()) {
            return Long.parseLong(m2.group(1));
        }
        String digits = str.replaceAll("[^0-9]", "").trim();
        if (digits.isEmpty()) {
            return -1L;
        }
        long val = Long.parseLong(digits);
        return val > 0L && val < 36000L ? val : -1L;
    }

    private void updateGPSAndNotifications() {
        if (this.currentGPSTarget != null && WardenHelper.mc.field_1724.method_5707(class_243.method_24953((class_2382)this.currentGPSTarget)) <= 100.0) {
            WardenHelper.mc.field_1724.field_3944.method_45730("gps off");
            this.currentGPSTarget = null;
        }
        for (Map.Entry<class_2338, ChestData> entry : this.chestDataMap.entrySet()) {
            class_2338 pos = entry.getKey();
            ChestData data = entry.getValue();
            if (!data.hasTimer) continue;
            float t = data.getTimeLeft();
            if (t <= 0.0f) {
                if (this.autoGPS.isEnabled() && !this.gpsVisited.contains(pos)) {
                    this.sendGPS(pos);
                }
                if (!this.notifications.isEnabled() || this.notified.contains(pos)) continue;
                Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, "Warden Helper", "\u0421\u0443\u043d\u0434\u0443\u043a \u0433\u043e\u0442\u043e\u0432! [" + pos.method_10263() + " " + pos.method_10260() + "]");
                this.notified.add(pos);
                continue;
            }
            if (!(t <= 20.0f)) continue;
            if (this.autoGPS.isEnabled() && !this.gpsVisited.contains(pos)) {
                this.sendGPS(pos);
            }
            if (!this.notifications.isEnabled() || this.notified.contains(pos)) continue;
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.INFO, "Warden Helper", "\u0421\u0443\u043d\u0434\u0443\u043a \u0447\u0435\u0440\u0435\u0437 " + (int)t + " \u0441\u0435\u043a! [" + pos.method_10263() + " " + pos.method_10260() + "]");
            this.notified.add(pos);
        }
    }

    private void sendGPS(class_2338 pos) {
        WardenHelper.mc.field_1724.field_3944.method_45730("gps set " + pos.method_10263() + " " + pos.method_10260());
        this.gpsVisited.add(pos);
        this.currentGPSTarget = pos;
    }

    private ColorRGBA getESPColor(ChestData data) {
        if (!data.hasTimer) {
            return COLOR_INACTIVE;
        }
        float t = data.getTimeLeft();
        if (t <= 0.0f) {
            float p = (float)(Math.sin((double)System.currentTimeMillis() / 200.0) * 0.3 + 0.7);
            return new ColorRGBA(0.0f, (int)(255.0f * p), (int)(128.0f * p), 220.0f);
        }
        if (t > 120.0f) {
            return COLOR_DEFAULT;
        }
        if (t > 20.0f) {
            return WardenHelper.lerpColor(COLOR_DEFAULT, COLOR_WARN, 1.0f - (t - 20.0f) / 100.0f);
        }
        return WardenHelper.lerpColor(COLOR_WARN, COLOR_READY, 1.0f - t / 20.0f);
    }

    private static ColorRGBA lerpColor(ColorRGBA a, ColorRGBA b, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        return new ColorRGBA((int)(a.getRed() + (b.getRed() - a.getRed()) * t), (int)(a.getGreen() + (b.getGreen() - a.getGreen()) * t), (int)(a.getBlue() + (b.getBlue() - a.getBlue()) * t), (int)(a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t));
    }

    @Environment(value=EnvType.CLIENT)
    private static class ChestData {
        boolean hasTimer = false;
        private long timerEndMs = 0L;

        ChestData(class_2338 pos) {
        }

        void setTimer(long secondsLeft) {
            this.timerEndMs = System.currentTimeMillis() + secondsLeft * 1000L;
            this.hasTimer = true;
        }

        float getTimeLeft() {
            return (float)(this.timerEndMs - System.currentTimeMillis()) / 1000.0f;
        }
    }
}

