/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.commands.commands.FakePlayerCommand;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ButtonSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="Fake Player", category=ModuleCategory.PLAYER, desc="modules.descriptions.fake_player")
@Environment(value=EnvType.CLIENT)
public class FakePlayer
extends BaseModule {
    private final ButtonSetting createBot = new ButtonSetting(this, "modules.settings.fake_player.create_bot").action(() -> {
        if (Experiment.getInstance().getCommandManager().getFakePlayerCommand() != null) {
            Experiment.getInstance().getCommandManager().getFakePlayerCommand().add();
        }
    });
    private final ButtonSetting deleteBot = new ButtonSetting(this, "modules.settings.fake_player.delete_bot").action(() -> {
        if (Experiment.getInstance().getCommandManager().getFakePlayerCommand() != null) {
            Experiment.getInstance().getCommandManager().getFakePlayerCommand().del();
        }
    });
    private final ButtonSetting teleportToMe = new ButtonSetting(this, "modules.settings.fake_player.teleport_to_me").action(() -> {
        FakePlayerCommand cmd;
        if (Experiment.getInstance().getCommandManager().getFakePlayerCommand() != null && (cmd = Experiment.getInstance().getCommandManager().getFakePlayerCommand()).getFakePlayer() != null && FakePlayer.mc.field_1724 != null) {
            cmd.getFakePlayer().method_33574(FakePlayer.mc.field_1724.method_19538());
            cmd.getFakePlayer().method_36456(FakePlayer.mc.field_1724.method_36454());
            cmd.getFakePlayer().method_36457(FakePlayer.mc.field_1724.method_36455());
        }
    });
}

