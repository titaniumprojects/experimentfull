/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1738
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2708
 *  net.minecraft.class_2848
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_3532
 *  net.minecraft.class_8051
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventIntegration;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.FireworkEvent;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.ElytraTarget;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.utility.game.prediction.ElytraPredictionSystem;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.ArmorSlot;
import micronix.experiment.utility.mixins.ArmorItemAddition;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2848;
import net.minecraft.class_3532;
import net.minecraft.class_8051;

@ModuleInfo(name="Elytra Utils", category=ModuleCategory.PLAYER, desc="\u041f\u043e\u043c\u043e\u0449\u043d\u0438\u043a \u0441 \u044d\u043b\u0438\u0442\u0440\u0430\u043c\u0438")
@Environment(value=EnvType.CLIENT)
public class ElytraUtils
extends BaseModule {
    private final BindSetting swapKey = new BindSetting(this, "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u0432\u0430\u043f\u0430");
    private final BindSetting fireworkKey = new BindSetting(this, "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u0430");
    private final BooleanSetting automat = new BooleanSetting((SettingsContainer)this, "\u0410\u0432\u0442\u043e \u0432\u0437\u043b\u0451\u0442", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0432\u0437\u043b\u0435\u0442\u0430\u0435\u0442 \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0430\u0445").enable();
    private final BooleanSetting withUse = new BooleanSetting(this, "\u0410\u0432\u0442\u043e \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a \u0434\u043b\u044f \u0432\u0437\u043b\u0435\u0442\u0430", () -> !this.automat.isEnabled()).enable();
    private final BooleanSetting unEquip = new BooleanSetting((SettingsContainer)this, "\u0413\u0440\u0443\u0434\u0430\u043a \u043d\u0430 \u0437\u0435\u043c\u043b\u0435", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043d\u0430\u0434\u0435\u0432\u0430\u0435\u0442 \u043d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a \u0438\u043b\u0438 \u0441\u043d\u0438\u043c\u0430\u0435\u0442 \u044d\u043b\u0438\u0442\u0440\u044b \u043f\u0440\u0438 \u043f\u0440\u0438\u0437\u0435\u043c\u043b\u0435\u043d\u0438\u0438").enable();
    private final BooleanSetting boost = new BooleanSetting((SettingsContainer)this, "\u0423\u0441\u043a\u043e\u0440\u044f\u0442\u044c", "\u0423\u0441\u043a\u043e\u0440\u044f\u0435\u0442 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435 \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0435");
    private boolean wasFlying;
    private SwapTask swapTask;
    private final EventListener<ClientPlayerTickEvent> onUpdate = event -> {
        if (ElytraUtils.mc.field_1724.method_6128()) {
            this.wasFlying = true;
        }
        ArmorSlot chestplateSlot = InventoryUtility.getChestplateSlot();
        SlotGroup<ItemSlot> group = SlotGroups.hotbar().and(SlotGroups.inventory()).and(SlotGroups.offhand());
        ItemSlot chestplateItemSlot = group.findItem(itemStack -> {
            class_1738 armorItem;
            class_1792 patt0$temp = itemStack.method_7909();
            return patt0$temp instanceof class_1738 && ((ArmorItemAddition)(armorItem = (class_1738)patt0$temp)).experiment$getType() == class_8051.field_41935;
        });
        ItemSlot slot = group.findItem(class_1802.field_8639);
        boolean isElytraEquipped = chestplateSlot.item() == class_1802.field_8833;
        boolean bl = isElytraEquipped;
        if (this.swapTask != null) {
            switch (this.swapTask.stage) {
                case 0: 
                case 2: {
                    InventoryUtility.hotbarSwap(this.swapTask.from.getIdForServer(), 40);
                    break;
                }
                case 1: {
                    InventoryUtility.hotbarSwap(this.swapTask.chest.getIdForServer(), 40);
                }
            }
            if (this.swapTask.stage++ >= 2) {
                this.swapTask = null;
            }
        }
        if (this.automat.isEnabled() && isElytraEquipped && !ElytraUtils.mc.field_1724.method_6128() && !ElytraUtils.mc.field_1724.method_24828() && !ElytraUtils.mc.field_1724.method_52535()) {
            ElytraUtils.mc.field_1724.method_23669();
            mc.method_1562().method_52787((class_2596)new class_2848((class_1297)ElytraUtils.mc.field_1724, class_2848.class_2849.field_12982));
            if (this.withUse.isEnabled() && slot != null) {
                EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8639);
            }
        } else if (ElytraUtils.mc.field_1724.method_24828() && this.automat.isEnabled() && isElytraEquipped && !ElytraUtils.mc.field_1724.method_52535()) {
            ElytraUtils.mc.field_1724.method_6043();
        }
        if (this.unEquip.isEnabled() && ElytraUtils.mc.field_1724.method_24828() && isElytraEquipped && this.wasFlying && ElytraUtils.mc.field_1724.method_6003() > 18) {
            if (chestplateItemSlot != null) {
                chestplateItemSlot.swapTo(chestplateSlot);
            } else {
                ElytraUtils.mc.field_1761.method_2906(0, 6, 0, class_1713.field_7794, (class_1657)ElytraUtils.mc.field_1724);
            }
            this.wasFlying = false;
        }
    };
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
        if (this.swapKey.isKey(event.getKey()) && event.getAction() == 1 && ElytraUtils.mc.field_1755 == null) {
            this.swapElytraChestplate();
        }
        if (this.fireworkKey.isKey(event.getKey()) && event.getAction() == 1 && ElytraUtils.mc.field_1755 == null) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8639);
        }
    };
    private final EventListener<MouseEvent> onMouseButtonPress = event -> {
        if (this.swapKey.isKey(event.getButton()) && event.getAction() == 1 && ElytraUtils.mc.field_1755 == null) {
            this.swapElytraChestplate();
        }
        if (this.fireworkKey.isKey(event.getButton()) && event.getAction() == 1 && ElytraUtils.mc.field_1755 == null) {
            EventIntegration.SWAP_INTEGRATION.useItem(class_1802.field_8639);
        }
    };
    private final EventListener<FireworkEvent> onFirework = event -> {
        if (this.boost.isEnabled() && event.getEntity() == ElytraUtils.mc.field_1724) {
            class_1657 player;
            class_1309 target = Experiment.getInstance().getTargetManager().getLivingTarget();
            if (!(target instanceof class_1657) || !ElytraPredictionSystem.isLeaving(player = (class_1657)target)) {
                // empty if block
            }
            double boostPower = 1.5 * this.getAdvancedBoost();
            RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
            class_243 rotationVector = rotationHandler.isIdling() ? rotationHandler.getPlayerRotation().getRotationVector() : rotationHandler.getCurrentRotation().getRotationVector();
            class_243 currentVelocity = event.getVelocity();
            class_243 newVelocity = currentVelocity.method_1031(rotationVector.field_1352 * 0.1 + (rotationVector.field_1352 * boostPower - currentVelocity.field_1352) * 0.5, rotationVector.field_1351 * 0.1 + (rotationVector.field_1351 * boostPower - currentVelocity.field_1351) * 0.5, rotationVector.field_1350 * 0.1 + (rotationVector.field_1350 * boostPower - currentVelocity.field_1350) * 0.5);
            event.setVelocity(newVelocity);
        }
    };
    private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
        if (event.getPacket() instanceof class_2708) {
            RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
            Rotation rot = rotationHandler.isIdling() ? rotationHandler.getPlayerRotation() : rotationHandler.getCurrentRotation();
            System.out.println(String.format("ELYTRA BOOSTER HUETA. ANGLES: yaw(%s) pitch(%s) speed(%s)", Float.valueOf(rot.getYaw()), Float.valueOf(rot.getPitch()), this.getAdvancedBoost()));
        }
    };

    private void swapElytraChestplate() {
        ArmorSlot chestplateSlot = InventoryUtility.getChestplateSlot();
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar());
        ItemSlot elytraItemSlot = slotsToSearch.findItem(itemStack -> itemStack.method_7909() == class_1802.field_8833 && !itemStack.method_63692());
        ItemSlot chestplateItemSlot = slotsToSearch.findItem(itemStack -> {
            class_1738 armorItem;
            class_1792 patt0$temp = itemStack.method_7909();
            return patt0$temp instanceof class_1738 && ((ArmorItemAddition)(armorItem = (class_1738)patt0$temp)).experiment$getType() == class_8051.field_41935;
        });
        boolean isElytraEquipped = chestplateSlot.item() == class_1802.field_8833;
        boolean bl = isElytraEquipped;
        if (!isElytraEquipped && elytraItemSlot != null) {
            this.swapTask = new SwapTask(elytraItemSlot, chestplateSlot);
        } else if (chestplateItemSlot != null) {
            this.swapTask = new SwapTask(chestplateItemSlot, chestplateSlot);
        }
    }

    private double getAdvancedBoost() {
        double yawAcceleration;
        RotationHandler rotationHandler;
        if (Experiment.getInstance().getModuleManager().getModule(ElytraTarget.class).isDefensiveActive()) {
            // empty if block
        }
        Rotation rot = (rotationHandler = Experiment.getInstance().getRotationHandler()).isIdling() ? rotationHandler.getPlayerRotation() : rotationHandler.getCurrentRotation();
        float playerYaw = rot.getYaw();
        float playerPitch = rot.getPitch();
        double A = 0.239037;
        double B = 4.489648;
        double C = 1.236087;
        double MAX_ACCELERATION_YAW = 1.47;
        double YAW_TOLERANCE = 7.9;
        double MAX_PITCH_BOOST = 1.01;
        double MAX_PITCH = -45.0;
        double MIN_PITCH = 10.0;
        double effectiveYaw = (double)Math.abs(playerYaw) % 90.0;
        if (Math.abs(effectiveYaw - 45.0) <= 7.9) {
            yawAcceleration = 1.47;
        } else {
            double argument = 4.489648 * (effectiveYaw - 45.0);
            yawAcceleration = 0.239037 * Math.cos(Math.toRadians(argument)) + 1.236087;
        }
        if (playerPitch >= 10.0f) {
            return Math.abs(effectiveYaw - 45.0) <= 5.0 ? 1.8 : yawAcceleration;
        }
        if (playerPitch >= 0.0f) {
            return 1.0;
        }
        if (playerPitch < -80.0f) {
            return 1.0;
        }
        double pitchRatio = Math.min(1.0, (double)Math.abs(playerPitch) / Math.abs(-45.0));
        double pitchMultiplier = 1.0 + 0.010000000000000009 * pitchRatio;
        double totalAcceleration = yawAcceleration * pitchMultiplier;
        totalAcceleration = Math.min(totalAcceleration, 1.49);
        return totalAcceleration;
    }

    private static int findClosestVector(float lastYaw, int[] vectors) {
        int index = 0;
        int minDistIndex = -1;
        float minDist = Float.MAX_VALUE;
        for (int vector : vectors) {
            float dist = Math.abs(class_3532.method_15393((float)lastYaw) - (float)vector);
            if (dist < minDist) {
                minDist = dist;
                minDistIndex = index;
            }
            ++index;
        }
        return minDistIndex;
    }

    private double calculateDynamicBoostPower(class_1309 player) {
        float yaw = player.method_36454();
        float pitch = player.method_36455();
        double minSpeed = 1.4;
        double maxSpeed = 1.9;
        double yawFactor = this.calculateYawFactor(yaw);
        double pitchFactor = this.calculatePitchFactor(pitch);
        double combinedFactor = yawFactor * pitchFactor;
        double boostPower = minSpeed + (maxSpeed - minSpeed) * combinedFactor;
        return Math.max(minSpeed, Math.min(maxSpeed, boostPower));
    }

    private double calculateYawFactor(float yaw) {
        yaw = (yaw % 360.0f + 360.0f) % 360.0f;
        double[] diagonalAngles = new double[]{45.0, 135.0, 225.0, 315.0};
        double minDistanceToDiagonal = Double.MAX_VALUE;
        for (double diagonal : diagonalAngles) {
            double distance = Math.min(Math.abs((double)yaw - diagonal), Math.min(Math.abs((double)yaw - diagonal + 360.0), Math.abs((double)yaw - diagonal - 360.0)));
            minDistanceToDiagonal = Math.min(minDistanceToDiagonal, distance);
        }
        if (minDistanceToDiagonal <= 45.0) {
            return 1.0 - minDistanceToDiagonal / 45.0 * 0.85;
        }
        return 0.15;
    }

    private double calculatePitchFactor(float pitch) {
        float absPitch = Math.abs(pitch);
        if (absPitch <= 10.0f) {
            return 1.0;
        }
        if (absPitch <= 30.0f) {
            return 1.0 - (double)(absPitch - 10.0f) / 20.0 * 0.3;
        }
        if (absPitch <= 60.0f) {
            return 0.7 - (double)(absPitch - 30.0f) / 30.0 * 0.4;
        }
        return 0.3;
    }

    @Override
    public void onDisable() {
        this.wasFlying = false;
    }

    @Override
    public void onEnable() {
        this.wasFlying = false;
    }

    @Environment(value=EnvType.CLIENT)
    private static class SwapTask {
        int stage;
        final ItemSlot from;
        final ItemSlot chest;

        SwapTask(ItemSlot from, ItemSlot chest) {
            this.from = from;
            this.chest = chest;
        }
    }
}

