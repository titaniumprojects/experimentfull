/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2199
 *  net.minecraft.class_2238
 *  net.minecraft.class_2244
 *  net.minecraft.class_2248
 *  net.minecraft.class_2260
 *  net.minecraft.class_2275
 *  net.minecraft.class_2281
 *  net.minecraft.class_2288
 *  net.minecraft.class_2304
 *  net.minecraft.class_2315
 *  net.minecraft.class_2325
 *  net.minecraft.class_2331
 *  net.minecraft.class_2336
 *  net.minecraft.class_2363
 *  net.minecraft.class_2377
 *  net.minecraft.class_2387
 *  net.minecraft.class_2406
 *  net.minecraft.class_2478
 *  net.minecraft.class_2480
 *  net.minecraft.class_2531
 *  net.minecraft.class_3708
 *  net.minecraft.class_3709
 *  net.minecraft.class_3711
 *  net.minecraft.class_3713
 *  net.minecraft.class_3715
 *  net.minecraft.class_3717
 *  net.minecraft.class_3718
 *  net.minecraft.class_3962
 *  net.minecraft.class_4969
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2199;
import net.minecraft.class_2238;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2260;
import net.minecraft.class_2275;
import net.minecraft.class_2281;
import net.minecraft.class_2288;
import net.minecraft.class_2304;
import net.minecraft.class_2315;
import net.minecraft.class_2325;
import net.minecraft.class_2331;
import net.minecraft.class_2336;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_2387;
import net.minecraft.class_2406;
import net.minecraft.class_2478;
import net.minecraft.class_2480;
import net.minecraft.class_2531;
import net.minecraft.class_3708;
import net.minecraft.class_3709;
import net.minecraft.class_3711;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3717;
import net.minecraft.class_3718;
import net.minecraft.class_3962;
import net.minecraft.class_4969;

@ModuleInfo(name="No Interact", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class NoInteract
extends BaseModule {
    private final SelectSetting blocks = new SelectSetting(this, "modules.settings.no_interact.blocks");
    private final SelectSetting.Value craftingTables = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.craftingTables").select();
    private final SelectSetting.Value enchantingTables = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.enchantingTables").select();
    private final SelectSetting.Value beds = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.beds").select();
    private final SelectSetting.Value chests = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.chests").select();
    private final SelectSetting.Value enderChests = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.enderChests").select();
    private final SelectSetting.Value trappedChests = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.trappedChests").select();
    private final SelectSetting.Value furnaces = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.furnaces").select();
    private final SelectSetting.Value barrels = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.barrels").select();
    private final SelectSetting.Value shulkers = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.shulkers").select();
    private final SelectSetting.Value droppers = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.droppers").select();
    private final SelectSetting.Value dispensers = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.dispensers").select();
    private final SelectSetting.Value hoppers = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.hoppers").select();
    private final SelectSetting.Value anvils = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.anvils").select();
    private final SelectSetting.Value cauldrons = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.cauldrons").select();
    private final SelectSetting.Value signs = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.signs").select();
    private final SelectSetting.Value bells = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.bells").select();
    private final SelectSetting.Value composters = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.composters").select();
    private final SelectSetting.Value brewingStands = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.brewingStands").select();
    private final SelectSetting.Value jukeBoxes = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.jukeBoxes").select();
    private final SelectSetting.Value commandBlocks = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.commandBlocks").select();
    private final SelectSetting.Value beacons = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.beacons").select();
    private final SelectSetting.Value respawnAnchors = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.respawnAnchors").select();
    private final SelectSetting.Value grindstones = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.grindstones").select();
    private final SelectSetting.Value lecterns = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.lecterns").select();
    private final SelectSetting.Value cartographyTables = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.cartographyTables").select();
    private final SelectSetting.Value looms = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.looms").select();
    private final SelectSetting.Value smithingTables = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.smithingTables").select();
    private final SelectSetting.Value stonecutters = new SelectSetting.Value(this.blocks, "modules.settings.no_interact.stonecutter").select();
    private final BooleanSetting onlyAura = new BooleanSetting(this, "modules.settings.no_interact.onlyAura");

    public boolean shouldPreventInteract(class_2248 block) {
        if (this.onlyAura.isEnabled()) {
            return Experiment.getInstance().getModuleManager().getModule(Aura.class).isEnabled();
        }
        if (block instanceof class_2304 && this.craftingTables.isSelected()) {
            return true;
        }
        if (block instanceof class_2331 && this.enchantingTables.isSelected()) {
            return true;
        }
        if (block instanceof class_2244 && this.beds.isSelected()) {
            return true;
        }
        if (block instanceof class_2281 && this.chests.isSelected()) {
            return true;
        }
        if (block instanceof class_2336 && this.enderChests.isSelected()) {
            return true;
        }
        if (block instanceof class_2531 && this.trappedChests.isSelected()) {
            return true;
        }
        if (block instanceof class_2363 && this.furnaces.isSelected()) {
            return true;
        }
        if (block instanceof class_3708 && this.barrels.isSelected()) {
            return true;
        }
        if (block instanceof class_2480 && this.shulkers.isSelected()) {
            return true;
        }
        if (block instanceof class_2325 && this.droppers.isSelected()) {
            return true;
        }
        if (block instanceof class_2315 && this.dispensers.isSelected()) {
            return true;
        }
        if (block instanceof class_2377 && this.hoppers.isSelected()) {
            return true;
        }
        if (block instanceof class_2199 && this.anvils.isSelected()) {
            return true;
        }
        if (block instanceof class_2275 && this.cauldrons.isSelected()) {
            return true;
        }
        if (block instanceof class_2478 && this.signs.isSelected()) {
            return true;
        }
        if (block instanceof class_3709 && this.bells.isSelected()) {
            return true;
        }
        if (block instanceof class_3962 && this.composters.isSelected()) {
            return true;
        }
        if (block instanceof class_2260 && this.brewingStands.isSelected()) {
            return true;
        }
        if (block instanceof class_2387 && this.jukeBoxes.isSelected()) {
            return true;
        }
        if (block instanceof class_2288 && this.commandBlocks.isSelected()) {
            return true;
        }
        if (block instanceof class_2238 && this.beacons.isSelected()) {
            return true;
        }
        if (block instanceof class_4969 && this.respawnAnchors.isSelected()) {
            return true;
        }
        if (block instanceof class_3713 && this.grindstones.isSelected()) {
            return true;
        }
        if (block instanceof class_3715 && this.lecterns.isSelected()) {
            return true;
        }
        if (block instanceof class_3711 && this.cartographyTables.isSelected()) {
            return true;
        }
        if (block instanceof class_2406 && this.looms.isSelected()) {
            return true;
        }
        if (block instanceof class_3717 && this.smithingTables.isSelected()) {
            return true;
        }
        return block instanceof class_3718 && this.stonecutters.isSelected();
    }
}

