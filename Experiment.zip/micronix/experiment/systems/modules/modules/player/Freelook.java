/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_5498
 *  org.lwjgl.glfw.GLFW
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.game.BlockBreakEvent;
import micronix.experiment.systems.event.impl.game.StartBreakBlockEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BindSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name="Freelook", category=ModuleCategory.PLAYER, desc="modules.descriptions.freelook")
@Environment(value=EnvType.CLIENT)
public class Freelook
extends BaseModule {
    public static boolean isActive = false;
    public static float x = 0.0f;
    public static float y = 0.0f;
    public static float prevX = 0.0f;
    public static float prevY = 0.0f;
    private float startYaw = 0.0f;
    private float startPitch = 0.0f;
    private class_5498 originalPerspective = class_5498.field_26664;
    private final BindSetting keybind = new BindSetting(this, "freelook.keybind").key(342);
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (Freelook.mc.field_1724 == null) {
            if (isActive) {
                isActive = false;
            }
        } else {
            boolean keyPressed;
            boolean bl = keyPressed = this.keybind.getKey() != -1 && GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)this.keybind.getKey()) == 1;
            if (keyPressed && !isActive) {
                this.activateFreelook();
            } else if (!keyPressed && isActive) {
                this.deactivateFreelook();
            }
            if (!isActive) {
                x = Freelook.mc.field_1724.method_36454();
                y = Freelook.mc.field_1724.method_36455();
                prevX = x;
                prevY = y;
            } else {
                Freelook.mc.field_1724.field_6283 = this.startYaw;
                Freelook.mc.field_1724.field_6220 = this.startYaw;
                Freelook.mc.field_1724.field_6241 = this.startYaw;
                Freelook.mc.field_1724.field_6259 = this.startYaw;
            }
        }
    };
    private final EventListener<AttackEvent> onAttack = event -> {
        if (isActive) {
            event.cancel();
        }
    };
    private final EventListener<StartBreakBlockEvent> onStartBreakBlock = event -> {
        if (isActive) {
            event.cancel();
        }
    };
    private final EventListener<BlockBreakEvent> onBlockBreak = event -> {
        if (isActive) {
            event.cancel();
        }
    };

    @Override
    public void onEnable() {
        super.onEnable();
        isActive = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (isActive) {
            this.deactivateFreelook();
        }
    }

    private void activateFreelook() {
        if (Freelook.mc.field_1724 != null && !isActive) {
            this.startYaw = Freelook.mc.field_1724.method_36454();
            this.startPitch = Freelook.mc.field_1724.method_36455();
            this.originalPerspective = Freelook.mc.field_1690.method_31044();
            isActive = true;
            x = this.startYaw;
            y = this.startPitch;
            prevX = x;
            prevY = y;
            Freelook.mc.field_1690.method_31043(class_5498.field_26665);
        }
    }

    private void deactivateFreelook() {
        if (Freelook.mc.field_1724 != null && isActive) {
            Freelook.mc.field_1690.method_31043(this.originalPerspective);
            Freelook.mc.field_1724.method_36456(this.startYaw);
            Freelook.mc.field_1724.method_36457(this.startPitch);
            Freelook.mc.field_1724.field_6241 = this.startYaw;
            Freelook.mc.field_1724.field_6259 = this.startYaw;
            isActive = false;
        }
    }

    private boolean isFacingTarget(class_1297 target) {
        if (Freelook.mc.field_1724 == null) {
            return false;
        }
        class_243 playerPos = Freelook.mc.field_1724.method_33571();
        class_243 targetPos = target.method_19538().method_1031(0.0, (double)(target.method_17682() / 2.0f), 0.0);
        class_243 direction = targetPos.method_1020(playerPos).method_1029();
        class_243 lookVec = Freelook.getCurrentLookVector();
        double dot = lookVec.method_1026(direction);
        double angle = Math.acos(class_3532.method_15350((double)dot, (double)-1.0, (double)1.0)) * 57.29577951308232;
        return angle < 90.0;
    }

    public static float calculateCorrectYawOffset(float yaw) {
        float renderYawOffset;
        if (Freelook.mc.field_1724 == null) {
            return yaw;
        }
        double xDiff = Freelook.mc.field_1724.method_23317() - Freelook.mc.field_1724.field_6014;
        double zDiff = Freelook.mc.field_1724.method_23321() - Freelook.mc.field_1724.field_5969;
        float distSquared = (float)(xDiff * xDiff + zDiff * zDiff);
        float offset = renderYawOffset = Freelook.mc.field_1724.field_6220;
        if (distSquared > 0.0025000002f) {
            offset = (float)class_3532.method_15349((double)zDiff, (double)xDiff) * 180.0f / (float)Math.PI - 90.0f;
        }
        if (Freelook.mc.field_1724.field_6251 > 0.0f) {
            offset = yaw;
        }
        float yawOffsetDiff = class_3532.method_15393((float)(yaw - (renderYawOffset + class_3532.method_15393((float)(offset - renderYawOffset)) * 0.3f)));
        yawOffsetDiff = class_3532.method_15363((float)yawOffsetDiff, (float)-75.0f, (float)75.0f);
        renderYawOffset = yaw - yawOffsetDiff;
        if (yawOffsetDiff * yawOffsetDiff > 2500.0f) {
            renderYawOffset += yawOffsetDiff * 0.2f;
        }
        return renderYawOffset;
    }

    public float getRotYaw() {
        return x;
    }

    public void setRotYaw(float rotYaw) {
        prevX = x;
        x = rotYaw;
    }

    public float getRotPitch() {
        return y;
    }

    public void setRotPitch(float rotPitch) {
        prevY = y;
        y = rotPitch;
    }

    public static float getYaw(float partialTicks) {
        return partialTicks == 1.0f ? x : prevX + (x - prevX) * partialTicks;
    }

    public static float getPitch(float partialTicks) {
        return partialTicks == 1.0f ? y : prevY + (y - prevY) * partialTicks;
    }

    public static float getActualYaw(float partialTicks) {
        return isActive ? Freelook.getYaw(partialTicks) : (Freelook.mc.field_1724 != null ? Freelook.mc.field_1724.method_5705(partialTicks) : 0.0f);
    }

    public static float getActualPitch(float partialTicks) {
        return isActive ? Freelook.getPitch(partialTicks) : (Freelook.mc.field_1724 != null ? Freelook.mc.field_1724.method_5695(partialTicks) : 0.0f);
    }

    public static class_243 getActualLookVector(float partialTicks) {
        if (!isActive && Freelook.mc.field_1724 != null) {
            return Freelook.mc.field_1724.method_5828(partialTicks);
        }
        if (!isActive) {
            return class_243.field_1353;
        }
        float yaw = Freelook.getYaw(partialTicks);
        float pitch = Freelook.getPitch(partialTicks);
        float f = pitch * ((float)Math.PI / 180);
        float f1 = -yaw * ((float)Math.PI / 180);
        float f2 = class_3532.method_15362((float)f1);
        float f3 = class_3532.method_15374((float)f1);
        float f4 = class_3532.method_15362((float)f);
        float f5 = class_3532.method_15374((float)f);
        return new class_243((double)(f3 * f4), (double)(-f5), (double)(f2 * f4));
    }

    public static class_243 getCurrentLookVector() {
        if (!isActive) {
            return Freelook.mc.field_1724 != null ? Freelook.mc.field_1724.method_5828(1.0f) : class_243.field_1353;
        }
        float yaw = x;
        float pitch = y;
        float f = pitch * ((float)Math.PI / 180);
        float f1 = -yaw * ((float)Math.PI / 180);
        float f2 = class_3532.method_15362((float)f1);
        float f3 = class_3532.method_15374((float)f1);
        float f4 = class_3532.method_15362((float)f);
        float f5 = class_3532.method_15374((float)f);
        return new class_243((double)(f3 * f4), (double)(-f5), (double)(f2 * f4));
    }
}

