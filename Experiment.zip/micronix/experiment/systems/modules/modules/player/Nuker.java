/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1268
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_2886
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.player;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationPriority;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1268;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_2886;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_9801;

@ModuleInfo(name="Nuker", category=ModuleCategory.PLAYER, desc="\u041a\u043e\u043f\u0430\u0435\u0442 \u0442\u0435\u0440\u0440\u0438\u0442\u043e\u0440\u0438\u044e \u0432\u043e\u043a\u0440\u0443\u0433 \u0441\u0435\u0431\u044f \u043d\u0430 \u0430\u0432\u0442\u043e-\u0448\u0430\u0445\u0442\u0435")
@Environment(value=EnvType.CLIENT)
public class Nuker
extends BaseModule {
    private final SliderSetting xzDistance = new SliderSetting((SettingsContainer)this, "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f XZ", "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f, \u043d\u0430 \u043a\u043e\u0442\u043e\u0440\u043e\u0439 \u0431\u0443\u0434\u0435\u0442 \u0440\u0430\u0431\u043e\u0442\u0430\u0442\u044c " + this.getName() + " \u043f\u043e \u0433\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u0438").step(1.0f).min(2.0f).max(6.0f).currentValue(4.0f);
    private final SliderSetting yDistance = new SliderSetting((SettingsContainer)this, "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f Y", "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f, \u043d\u0430 \u043a\u043e\u0442\u043e\u0440\u043e\u0439 \u0431\u0443\u0434\u0435\u0442 \u0440\u0430\u0431\u043e\u0442\u0430\u0442\u044c " + this.getName() + " \u043f\u043e \u0432\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u0438").step(1.0f).min(2.0f).max(6.0f).currentValue(5.0f);
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        class_2338 pos;
        class_2338 offset;
        int z;
        int x;
        int y;
        int radius = this.range();
        class_2338 minPos = new class_2338(-71, 77, -15);
        class_2338 maxPos = new class_2338(-51, 86, 5);
        boolean spawn = ServerUtility.spawn();
        for (y = 0; y < radius * 2; ++y) {
            for (x = 0; x < radius * 2; ++x) {
                for (z = 0; z < radius * 2; ++z) {
                    offset = new class_2338((x % 2 == 0 ? -x : x) / 2, (y % 2 == 0 ? -y : y) / 2, (z % 2 == 0 ? -z : z) / 2);
                    pos = Nuker.mc.field_1724.method_24515().method_10081((class_2382)offset);
                    if ((pos.method_10263() < minPos.method_10263() || pos.method_10263() > maxPos.method_10263() || pos.method_10264() < minPos.method_10264() || pos.method_10264() > maxPos.method_10264() || pos.method_10260() < minPos.method_10260() || pos.method_10260() > maxPos.method_10260()) && spawn || Nuker.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10442) continue;
                    double posX = pos.method_10263();
                    double posY = pos.method_10264();
                    double posZ = pos.method_10260();
                    double deltaX = posX - Nuker.mc.field_1724.method_23317();
                    double deltaY = posY - (Nuker.mc.field_1724.method_23318() + (double)Nuker.mc.field_1724.method_18381(Nuker.mc.field_1724.method_18376()));
                    double deltaZ = posZ - Nuker.mc.field_1724.method_23321();
                    double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
                    float yaw = (float)Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f + MathUtility.random(-2.0, 2.0);
                    float pitch = (float)(-Math.toDegrees(Math.atan2(deltaY, horizontalDistance))) + MathUtility.random(-1.0, 1.0);
                    Nuker.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, 0, yaw, pitch));
                    Experiment.getInstance().getRotationHandler().rotate(new Rotation(yaw, pitch), MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.NORMAL);
                    class_2350 direction = Nuker.getDirection(pos);
                    Nuker.mc.field_1761.method_2902(pos, direction);
                    Nuker.mc.field_1724.method_6104(class_1268.field_5808);
                    return;
                }
            }
        }
        y = 0;
        while ((float)y < this.yDistance.getCurrentValue()) {
            for (x = 0; x < radius * 2; ++x) {
                for (z = 0; z < radius * 2; ++z) {
                    offset = new class_2338((x % 2 == 0 ? -x : x) / 2, y, (z % 2 == 0 ? -z : z) / 2);
                    pos = Nuker.mc.field_1724.method_24515().method_10084().method_10081((class_2382)offset);
                    if ((pos.method_10263() < minPos.method_10263() || pos.method_10263() > maxPos.method_10263() || pos.method_10264() < minPos.method_10264() || pos.method_10264() > maxPos.method_10264() || pos.method_10260() < minPos.method_10260() || pos.method_10260() > maxPos.method_10260()) && spawn || Nuker.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10124) continue;
                    double posX = pos.method_10263();
                    double posY = pos.method_10264();
                    double posZ = pos.method_10260();
                    double deltaX = posX - Nuker.mc.field_1724.method_23317();
                    double deltaY = posY - (Nuker.mc.field_1724.method_23318() + (double)Nuker.mc.field_1724.method_18381(Nuker.mc.field_1724.method_18376()));
                    double deltaZ = posZ - Nuker.mc.field_1724.method_23321();
                    double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
                    float yaw = (float)Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f + MathUtility.random(-2.0, 2.0);
                    float pitch = (float)(-Math.toDegrees(Math.atan2(deltaY, horizontalDistance))) + MathUtility.random(-1.0, 1.0);
                    Experiment.getInstance().getRotationHandler().rotate(new Rotation(yaw, pitch), MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.NORMAL);
                    class_2350 direction = Nuker.getDirection(pos);
                    Nuker.mc.field_1761.method_2902(pos, direction);
                    Nuker.mc.field_1724.method_6104(class_1268.field_5808);
                    return;
                }
            }
            ++y;
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        class_2338 pos;
        class_2338 additional;
        int z;
        int x;
        int y;
        if (Nuker.mc.field_1687 == null || Nuker.mc.field_1724 == null) {
            return;
        }
        class_4587 matrices = event.getMatrices();
        class_4184 camera = Nuker.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.lineWidth((float)10.0f);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        matrices.method_22903();
        matrices.method_22904(-cameraPos.method_10216(), -cameraPos.method_10214(), -cameraPos.method_10215());
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        int radius = this.range();
        class_2338 minPos = new class_2338(-71, 77, -15);
        class_2338 maxPos = new class_2338(-51, 86, 5);
        boolean spawn = ServerUtility.spawn();
        if (spawn) {
            Draw3DUtility.renderOutlinedBox(event.getMatrices(), buffer, new class_238((double)minPos.method_10263(), (double)minPos.method_10264(), (double)minPos.method_10260(), (double)(maxPos.method_10263() + 1), (double)(maxPos.method_10264() + 1), (double)(maxPos.method_10260() + 1)), ColorRGBA.GREEN.withAlpha(110.0f));
        }
        for (y = 0; y < radius * 2; ++y) {
            for (x = 0; x < radius * 2; ++x) {
                for (z = 0; z < radius * 2; ++z) {
                    additional = new class_2338((x % 2 == 0 ? -x : x) / 2, (y % 2 == 0 ? -y : y) / 2, (z % 2 == 0 ? -z : z) / 2);
                    pos = Nuker.mc.field_1724.method_24515().method_10081((class_2382)additional);
                    if ((pos.method_10263() < minPos.method_10263() || pos.method_10263() > maxPos.method_10263() || pos.method_10264() < minPos.method_10264() || pos.method_10264() > maxPos.method_10264() || pos.method_10260() < minPos.method_10260() || pos.method_10260() > maxPos.method_10260()) && spawn || Nuker.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10442) continue;
                    class_2350 direction = Nuker.getDirection(pos);
                    Draw3DUtility.renderOutlinedBox(event.getMatrices(), buffer, Nuker.mc.field_1687.method_8320(pos).method_26201().method_1107().method_996(pos), ColorRGBA.GREEN.withAlpha(250.0f));
                    Draw3DUtility.renderBoxInternalDiagonals(event.getMatrices(), buffer, Nuker.mc.field_1687.method_8320(pos).method_26201().method_1107().method_996(pos), ColorRGBA.GREEN.withAlpha(250.0f));
                    class_9801 builtBuffer = buffer.method_60794();
                    if (builtBuffer != null) {
                        class_286.method_43433((class_9801)builtBuffer);
                    }
                    RenderSystem.enableCull();
                    RenderSystem.enableDepthTest();
                    RenderSystem.disableBlend();
                    return;
                }
            }
        }
        y = 0;
        while ((float)y < this.yDistance.getCurrentValue()) {
            for (x = 0; x < radius * 2; ++x) {
                for (z = 0; z < radius * 2; ++z) {
                    additional = new class_2338((x % 2 == 0 ? -x : x) / 2, y, (z % 2 == 0 ? -z : z) / 2);
                    pos = Nuker.mc.field_1724.method_24515().method_10084().method_10081((class_2382)additional);
                    if ((pos.method_10263() < minPos.method_10263() || pos.method_10263() > maxPos.method_10263() || pos.method_10264() < minPos.method_10264() || pos.method_10264() > maxPos.method_10264() || pos.method_10260() < minPos.method_10260() || pos.method_10260() > maxPos.method_10260()) && spawn || Nuker.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10124) continue;
                    class_2350 direction = Nuker.getDirection(pos);
                    Draw3DUtility.renderOutlinedBox(event.getMatrices(), buffer, Nuker.mc.field_1687.method_8320(pos).method_26201().method_1107().method_996(pos), ColorRGBA.GREEN.withAlpha(250.0f));
                    Draw3DUtility.renderBoxInternalDiagonals(event.getMatrices(), buffer, Nuker.mc.field_1687.method_8320(pos).method_26201().method_1107().method_996(pos), ColorRGBA.GREEN.withAlpha(250.0f));
                    class_9801 builtBuffer = buffer.method_60794();
                    if (builtBuffer != null) {
                        class_286.method_43433((class_9801)builtBuffer);
                    }
                    RenderSystem.enableCull();
                    RenderSystem.enableDepthTest();
                    RenderSystem.disableBlend();
                    return;
                }
            }
            ++y;
        }
        class_9801 builtBuffer = buffer.method_60794();
        if (builtBuffer != null) {
            class_286.method_43433((class_9801)builtBuffer);
        }
        matrices.method_22909();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    };

    public int range() {
        return (int)this.xzDistance.getCurrentValue();
    }

    public static class_2350 getDirection(class_2338 pos) {
        class_243 eyesPos = new class_243(Nuker.mc.field_1724.method_23317(), Nuker.mc.field_1724.method_23318() + (double)Nuker.mc.field_1724.method_18381(Nuker.mc.field_1724.method_18376()), Nuker.mc.field_1724.method_23321());
        if ((double)pos.method_10264() > eyesPos.field_1351) {
            if (Nuker.mc.field_1687.method_8320(pos.method_10069(0, -1, 0)).method_45474()) {
                return class_2350.field_11033;
            }
            return Nuker.mc.field_1724.method_5735().method_10153();
        }
        if (!Nuker.mc.field_1687.method_8320(pos.method_10069(0, 1, 0)).method_45474()) {
            return Nuker.mc.field_1724.method_5735().method_10153();
        }
        return class_2350.field_11036;
    }
}

