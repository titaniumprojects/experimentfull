/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1667
 *  net.minecraft.class_1684
 *  net.minecraft.class_1713
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2879
 *  net.minecraft.class_2886
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.Comparator;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1684;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

@ModuleInfo(name="Target Pearl", category=ModuleCategory.PLAYER, desc="modules.descriptions.target_pearl")
@Environment(value=EnvType.CLIENT)
public class TargetPearl
extends BaseModule {
    private final Timer delayTimer = new Timer();
    private class_2338 targetBlock;
    private int lastPearlId;
    private int lastOurPearlId;
    private float rotationYaw;
    private float rotationPitch;
    private int tick;
    private boolean shouldThrowPearl;
    private int thrownPearls = 0;
    private final Timer pearlDelayTimer = new Timer();
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if (TargetPearl.mc.field_1724 == null || TargetPearl.mc.field_1687 == null) {
            return;
        }
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        if (this.tick > 0) {
            rotationHandler.rotate(new Rotation(this.rotationYaw, this.rotationPitch), MoveCorrection.NONE, 180.0f, 180.0f, 180.0f, RotationPriority.OVERRIDE);
            ++this.tick;
        }
        if (TargetPearl.mc.field_1724.method_6032() < 5.0f) {
            return;
        }
        if (!this.delayTimer.finished(1000L)) {
            return;
        }
        for (class_1297 ent : TargetPearl.mc.field_1687.method_18112()) {
            if (!(ent instanceof class_1684)) continue;
            class_1684 pearl = (class_1684)ent;
            if (pearl.method_24921() == TargetPearl.mc.field_1724) {
                this.lastOurPearlId = pearl.method_5628();
                continue;
            }
            if (pearl.method_5628() == this.lastPearlId || pearl.method_5628() == this.lastOurPearlId) continue;
            TargetPearl.mc.field_1687.method_18456().stream().filter(p -> p != TargetPearl.mc.field_1724).min(Comparator.comparingDouble(p -> p.method_5858((class_1297)pearl))).ifPresent(player -> {
                this.targetBlock = this.calcTrajectory((class_1297)pearl);
                this.lastPearlId = pearl.method_5628();
            });
        }
        if (this.targetBlock == null) {
            return;
        }
        if (TargetPearl.mc.field_1724.method_5707(this.targetBlock.method_46558()) < 9.0) {
            return;
        }
        this.rotationPitch = (float)(-Math.toDegrees(this.calcTrajectory(this.targetBlock)));
        this.rotationYaw = (float)Math.toDegrees(Math.atan2((double)((float)this.targetBlock.method_10260() + 0.5f) - TargetPearl.mc.field_1724.method_23321(), (double)((float)this.targetBlock.method_10263() + 0.5f) - TargetPearl.mc.field_1724.method_23317())) - 90.0f;
        class_2338 tracedBP = this.checkTrajectory(this.rotationYaw, this.rotationPitch);
        if (tracedBP == null || this.targetBlock.method_10262((class_2382)tracedBP) > 36.0) {
            return;
        }
        this.tick = 1;
        this.shouldThrowPearl = true;
        this.targetBlock = null;
        this.delayTimer.reset();
        this.thrownPearls = 0;
    };

    @Override
    public void tick() {
        if (this.shouldThrowPearl && this.tick >= 3) {
            int pearlsToThrow = 1;
            if (this.thrownPearls < pearlsToThrow && this.pearlDelayTimer.finished(100L)) {
                this.throwPearl();
                ++this.thrownPearls;
                this.pearlDelayTimer.reset();
            }
            if (this.thrownPearls >= pearlsToThrow) {
                this.shouldThrowPearl = false;
                this.tick = 0;
            }
        }
    }

    private void throwPearl() {
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar());
        ItemSlot pearlItemSlot = slotsToSearch.findItem(class_1802.field_8634);
        if (pearlItemSlot != null) {
            int originalSlot = TargetPearl.mc.field_1724.method_31548().field_7545;
            int pearlSlot = pearlItemSlot.getIdForServer();
            if (pearlSlot != originalSlot) {
                TargetPearl.mc.field_1761.method_2906(0, pearlSlot, 0, class_1713.field_7790, (class_1657)TargetPearl.mc.field_1724);
                TargetPearl.mc.field_1761.method_2906(0, 36 + originalSlot, 0, class_1713.field_7790, (class_1657)TargetPearl.mc.field_1724);
            }
            mc.method_1562().method_52787((class_2596)new class_2886(class_1268.field_5808, 0, (float)((int)(this.rotationYaw * 256.0f / 360.0f)), (float)((int)(this.rotationPitch * 256.0f / 360.0f))));
            mc.method_1562().method_52787((class_2596)new class_2879(class_1268.field_5808));
            if (pearlSlot != originalSlot) {
                TargetPearl.mc.field_1761.method_2906(0, 36 + originalSlot, 0, class_1713.field_7790, (class_1657)TargetPearl.mc.field_1724);
                TargetPearl.mc.field_1761.method_2906(0, pearlSlot, 0, class_1713.field_7790, (class_1657)TargetPearl.mc.field_1724);
                if (!TargetPearl.mc.field_1724.field_7512.method_34255().method_7960()) {
                    TargetPearl.mc.field_1761.method_2906(0, 36 + originalSlot, 0, class_1713.field_7790, (class_1657)TargetPearl.mc.field_1724);
                }
            }
        }
    }

    private float calcTrajectory(class_2338 bp) {
        double a = Math.hypot((double)((float)bp.method_10263() + 0.5f) - TargetPearl.mc.field_1724.method_23317(), (double)((float)bp.method_10260() + 0.5f) - TargetPearl.mc.field_1724.method_23321());
        double y = 6.125 * ((double)((float)bp.method_10264() + 1.0f) - (TargetPearl.mc.field_1724.method_23318() + (double)TargetPearl.mc.field_1724.method_18381(TargetPearl.mc.field_1724.method_18376())));
        y = (double)0.05f * ((double)0.05f * (a * a) + y);
        y = Math.sqrt(9.37890625 - y);
        double d = 3.0625 - y;
        y = Math.atan2(d * d + y, (double)0.05f * a);
        d = Math.atan2(d, (double)0.05f * a);
        return (float)Math.min(y, d);
    }

    private class_2338 calcTrajectory(class_1297 e) {
        return this.traceTrajectory(e.method_23317(), e.method_23318(), e.method_23321(), e.method_18798().field_1352, e.method_18798().field_1351, e.method_18798().field_1350);
    }

    private class_2338 checkTrajectory(float yaw, float pitch) {
        if (Float.isNaN(pitch)) {
            return null;
        }
        float yawRad = yaw * ((float)Math.PI / 180);
        float pitchRad = pitch * ((float)Math.PI / 180);
        double x = TargetPearl.mc.field_1724.method_23317() - Math.cos(yawRad) * (double)0.16f;
        double y = TargetPearl.mc.field_1724.method_23318() + (double)TargetPearl.mc.field_1724.method_18381(TargetPearl.mc.field_1724.method_18376()) - 0.1000000014901161;
        double z = TargetPearl.mc.field_1724.method_23321() - Math.sin(yawRad) * (double)0.16f;
        double motionX = -Math.sin(yawRad) * Math.cos(pitchRad) * (double)0.4f;
        double motionY = -Math.sin(pitchRad) * (double)0.4f;
        double motionZ = Math.cos(yawRad) * Math.cos(pitchRad) * (double)0.4f;
        float distance = (float)Math.sqrt(motionX * motionX + motionY * motionY + motionZ * motionZ);
        motionX /= (double)distance;
        motionY /= (double)distance;
        motionZ /= (double)distance;
        motionX *= 1.5;
        motionY *= 1.5;
        motionZ *= 1.5;
        if (!TargetPearl.mc.field_1724.method_24828()) {
            motionY += TargetPearl.mc.field_1724.method_18798().field_1351;
        }
        return this.traceTrajectory(x, y, z, motionX, motionY, motionZ);
    }

    private class_2338 traceTrajectory(double x, double y, double z, double mx, double my, double mz) {
        for (int i = 0; i < 300; ++i) {
            class_243 lastPos = new class_243(x, y, z);
            my *= 0.99;
            class_243 pos = new class_243(x += (mx *= 0.99), y += (my -= (double)0.03f), z += (mz *= 0.99));
            class_3965 bhr = TargetPearl.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)TargetPearl.mc.field_1724));
            if (bhr != null && bhr.method_17783() == class_239.class_240.field_1332) {
                return bhr.method_17777();
            }
            for (class_1297 ent : TargetPearl.mc.field_1687.method_18112()) {
                if (ent instanceof class_1667 || ent == TargetPearl.mc.field_1724 || ent instanceof class_1684 || !ent.method_5829().method_994(new class_238(x - 0.3, y - 0.3, z - 0.3, x + 0.3, y + 0.3, z + 0.2))) continue;
                return null;
            }
            if (y <= -65.0) break;
        }
        return null;
    }
}

