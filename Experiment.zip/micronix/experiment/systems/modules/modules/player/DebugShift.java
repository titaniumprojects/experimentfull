/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1753
 *  net.minecraft.class_1764
 *  net.minecraft.class_1799
 *  net.minecraft.class_1812
 *  net.minecraft.class_1819
 *  net.minecraft.class_1835
 *  net.minecraft.class_9334
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1819;
import net.minecraft.class_1835;
import net.minecraft.class_9334;

@ModuleInfo(name="DebugShift", category=ModuleCategory.PLAYER, desc="\u0418\u0441\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u043f\u0440\u0435\u0440\u044b\u0432\u0430\u043d\u0438\u0435 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430 \u043f\u0440\u0438 \u043d\u0430\u0436\u0430\u0442\u0438\u0438 Shift")
@Environment(value=EnvType.CLIENT)
public class DebugShift
extends BaseModule {
    private boolean wasUsingItem = false;
    private class_1799 lastItem = class_1799.field_8037;
    private class_1268 lastHand = class_1268.field_5808;
    private int itemUseTime = 0;
    private boolean shouldContinue = false;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (this.isEnabled() && mc != null && DebugShift.mc.field_1724 != null) {
            class_1799 currentItem;
            boolean currentlyUsingItem = DebugShift.mc.field_1724.method_6115();
            if (currentlyUsingItem && !this.wasUsingItem) {
                this.lastItem = DebugShift.mc.field_1724.method_6030().method_7972();
                this.lastHand = DebugShift.mc.field_1724.method_6058();
                this.itemUseTime = DebugShift.mc.field_1724.method_6014();
                this.shouldContinue = false;
            }
            if (currentlyUsingItem) {
                this.itemUseTime = DebugShift.mc.field_1724.method_6014();
            }
            if (!currentlyUsingItem && this.wasUsingItem && this.itemUseTime > 0 && class_1799.method_7984((class_1799)this.lastItem, (class_1799)(currentItem = DebugShift.mc.field_1724.method_5998(this.lastHand))) && !currentItem.method_7960() && this.canUseItem(currentItem)) {
                this.shouldContinue = true;
            }
            if (this.shouldContinue && !currentlyUsingItem) {
                currentItem = DebugShift.mc.field_1724.method_5998(this.lastHand);
                if (class_1799.method_7984((class_1799)this.lastItem, (class_1799)currentItem) && !currentItem.method_7960()) {
                    DebugShift.mc.field_1761.method_2919((class_1657)DebugShift.mc.field_1724, this.lastHand);
                    this.shouldContinue = false;
                } else {
                    this.shouldContinue = false;
                }
            }
            this.wasUsingItem = currentlyUsingItem;
        }
    };

    public DebugShift() {
        this.setEnabled(false);
    }

    @Override
    public void onEnable() {
        this.reset();
    }

    @Override
    public void onDisable() {
        this.reset();
    }

    private void reset() {
        this.wasUsingItem = false;
        this.lastItem = class_1799.field_8037;
        this.itemUseTime = 0;
        this.shouldContinue = false;
    }

    private boolean canUseItem(class_1799 itemStack) {
        if (itemStack.method_7960()) {
            return false;
        }
        if (itemStack.method_57353().method_57832(class_9334.field_50075)) {
            return true;
        }
        if (itemStack.method_7909() instanceof class_1753 || itemStack.method_7909() instanceof class_1764 || itemStack.method_7909() instanceof class_1835) {
            return true;
        }
        if (itemStack.method_7909() instanceof class_1819) {
            return true;
        }
        return itemStack.method_7909() instanceof class_1812 ? true : itemStack.method_7935((class_1309)DebugShift.mc.field_1724) > 0;
    }
}

