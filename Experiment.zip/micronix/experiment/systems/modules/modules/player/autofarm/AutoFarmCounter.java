/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1792$class_9635
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1836
 *  net.minecraft.class_2561
 */
package micronix.experiment.systems.modules.modules.player.autofarm;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.player.AutoFarm;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public class AutoFarmCounter
implements IMinecraft {
    private final Timer timer = new Timer();
    public int price = 0;

    public int getTotalSelectedCrops() {
        AutoFarm autoFarm = Experiment.getInstance().getModuleManager().getModule(AutoFarm.class);
        int totalCount = 0;
        for (int i = 0; i < AutoFarmCounter.mc.field_1724.method_31548().field_7547.size(); ++i) {
            class_1799 stack = (class_1799)AutoFarmCounter.mc.field_1724.method_31548().field_7547.get(i);
            if (stack.method_7960()) continue;
            if (autoFarm.getCarrot().isSelected() && stack.method_7909() == class_1802.field_8179) {
                totalCount += stack.method_7947();
                continue;
            }
            if (autoFarm.getPotato().isSelected() && stack.method_7909() == class_1802.field_8567) {
                totalCount += stack.method_7947();
                continue;
            }
            if (!autoFarm.getBeetroot().isSelected() || stack.method_7909() != class_1802.field_8309) continue;
            totalCount += stack.method_7947();
        }
        class_1799 offHandStack = AutoFarmCounter.mc.field_1724.method_6079();
        if (!offHandStack.method_7960()) {
            if (autoFarm.getCarrot().isSelected() && offHandStack.method_7909() == class_1802.field_8179) {
                totalCount += offHandStack.method_7947();
            } else if (autoFarm.getPotato().isSelected() && offHandStack.method_7909() == class_1802.field_8567) {
                totalCount += offHandStack.method_7947();
            } else if (autoFarm.getBeetroot().isSelected() && offHandStack.method_7909() == class_1802.field_8309) {
                totalCount += offHandStack.method_7947();
            }
        }
        return totalCount;
    }

    public int getNonSelectedCropSlots() {
        boolean isSelectedCrop;
        AutoFarm autoFarm = Experiment.getInstance().getModuleManager().getModule(AutoFarm.class);
        int nonSelectedSlots = 0;
        for (int i = 0; i < AutoFarmCounter.mc.field_1724.method_31548().field_7547.size(); ++i) {
            class_1799 stack = (class_1799)AutoFarmCounter.mc.field_1724.method_31548().field_7547.get(i);
            if (stack.method_7960()) continue;
            isSelectedCrop = autoFarm.getCarrot().isSelected() && stack.method_7909() == class_1802.field_8179 || autoFarm.getPotato().isSelected() && stack.method_7909() == class_1802.field_8567 || autoFarm.getBeetroot().isSelected() && stack.method_7909() == class_1802.field_8309;
            boolean bl = isSelectedCrop;
            if (isSelectedCrop) continue;
            ++nonSelectedSlots;
        }
        class_1799 offHandStack = AutoFarmCounter.mc.field_1724.method_6079();
        if (!offHandStack.method_7960()) {
            isSelectedCrop = autoFarm.getCarrot().isSelected() && offHandStack.method_7909() == class_1802.field_8179 || autoFarm.getPotato().isSelected() && offHandStack.method_7909() == class_1802.field_8567 || autoFarm.getBeetroot().isSelected() && offHandStack.method_7909() == class_1802.field_8309;
            boolean bl = isSelectedCrop;
            if (!isSelectedCrop) {
                ++nonSelectedSlots;
            }
        }
        return nonSelectedSlots;
    }

    public void checkPrice() {
        AutoFarm autoFarm = Experiment.getInstance().getModuleManager().getModule(AutoFarm.class);
        List<class_1792> items = List.of(class_1802.field_8179, class_1802.field_8567, class_1802.field_8309);
        if (AutoFarmCounter.mc.field_1724.field_7512 instanceof class_1707 && this.price == 0) {
            if (ServerUtility.isFT() ? AutoFarmCounter.mc.field_1755.method_25440().getString().equals("\u25cf \u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0435\u043a\u0446\u0438\u044e") : AutoFarmCounter.mc.field_1755.method_25440().getString().equals("\u25cf \u0412\u044b\u0431\u0435\u0440\u0438 \u0441\u0435\u043a\u0446\u0438\u044e")) {
                AutoFarmCounter.mc.field_1761.method_2906(AutoFarmCounter.mc.field_1724.field_7512.field_7763, 21, 0, class_1713.field_7790, (class_1657)AutoFarmCounter.mc.field_1724);
            }
            if (AutoFarmCounter.mc.field_1755.method_25440().getString().equals("\u0421\u043a\u0443\u043f\u0449\u0438\u043a \u0435\u0434\u044b") && this.timer.finished(50L)) {
                class_1799 itemStack = AutoFarmCounter.mc.field_1724.field_7512.method_7611(autoFarm.ssItem()).method_7677();
                List tooltip = itemStack.method_7950(class_1792.class_9635.field_51353, (class_1657)AutoFarmCounter.mc.field_1724, (class_1836)class_1836.field_41070);
                for (class_2561 line : tooltip) {
                    Pattern pattern;
                    Matcher matcher;
                    String text = line.getString();
                    if (!text.contains("\u0426\u0435\u043d\u0430 \u0437\u0430") || !text.contains("$") || !(matcher = (pattern = Pattern.compile("(\\d+)\\$")).matcher(text)).find()) continue;
                    this.price = Integer.parseInt(matcher.group(1));
                }
                AutoFarmCounter.mc.field_1724.method_7346();
                this.timer.reset();
            }
        } else if (this.timer.finished(300L) && this.price == 0) {
            AutoFarmCounter.mc.field_1724.field_3944.method_45730("buyer");
            this.timer.reset();
        }
    }

    public Timer getTimer() {
        return this.timer;
    }

    public int getPrice() {
        return this.price;
    }
}

