/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2302
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2886
 */
package micronix.experiment.systems.modules.modules.player.autofarm;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.player.AutoFarm;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationPriority;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2886;

@Environment(value=EnvType.CLIENT)
public class AutoFarmNukeTurkey
implements IMinecraft {
    private static final int SEARCH_RADIUS = 4;

    public void nuke() {
        AutoFarm autoFarm;
        class_2248 block;
        class_2338 pos;
        class_2338 offset;
        int z;
        int x;
        int y;
        class_2338 targetBlockPos = null;
        class_2248 targetBlock = null;
        for (y = -4; y <= 4; ++y) {
            for (x = -4; x <= 4; ++x) {
                for (z = -4; z <= 4; ++z) {
                    offset = new class_2338((x % 2 == 0 ? -x : x) / 2, (y % 2 == 0 ? -y : y) / 2, (z % 2 == 0 ? -z : z) / 2);
                    pos = AutoFarmNukeTurkey.mc.field_1724.method_24515().method_10081((class_2382)offset);
                    if (AutoFarmNukeTurkey.mc.field_1724.method_19538().method_1022(class_243.method_24953((class_2382)pos)) > 6.0) continue;
                    block = AutoFarmNukeTurkey.mc.field_1687.method_8320(pos).method_26204();
                    autoFarm = Experiment.getInstance().getModuleManager().getModule(AutoFarm.class);
                    if (!(autoFarm.getMelon().isSelected() && block == class_2246.field_46283 || autoFarm.getTikva().isSelected() && block == class_2246.field_46282)) continue;
                    targetBlockPos = pos;
                    targetBlock = block;
                    break;
                }
                if (targetBlockPos != null) break;
            }
            if (targetBlockPos != null) break;
        }
        if (targetBlockPos == null) {
            for (y = 0; y < 3; ++y) {
                for (x = 0; x < 8; ++x) {
                    for (z = 0; z < 8; ++z) {
                        offset = new class_2338((x % 2 == 0 ? -x : x) / 2, y, (z % 2 == 0 ? -z : z) / 2);
                        pos = AutoFarmNukeTurkey.mc.field_1724.method_24515().method_10084().method_10081((class_2382)offset);
                        if (AutoFarmNukeTurkey.mc.field_1724.method_19538().method_1022(class_243.method_24953((class_2382)pos)) > 6.0 || AutoFarmNukeTurkey.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10124) continue;
                        block = AutoFarmNukeTurkey.mc.field_1687.method_8320(pos).method_26204();
                        autoFarm = Experiment.getInstance().getModuleManager().getModule(AutoFarm.class);
                        if (!(autoFarm.getMelon().isSelected() && block == class_2246.field_46283 || autoFarm.getTikva().isSelected() && block == class_2246.field_46282 || autoFarm.getAllCrops().isSelected() && block instanceof class_2302)) continue;
                        targetBlockPos = pos;
                        targetBlock = block;
                        break;
                    }
                    if (targetBlockPos != null) break;
                }
                if (targetBlockPos != null) break;
            }
        }
        if (targetBlockPos != null && targetBlock != null) {
            double posX = targetBlockPos.method_10263();
            double posY = targetBlockPos.method_10264();
            double posZ = targetBlockPos.method_10260();
            double deltaX = posX - AutoFarmNukeTurkey.mc.field_1724.method_23317();
            double deltaY = posY - (AutoFarmNukeTurkey.mc.field_1724.method_23318() + (double)AutoFarmNukeTurkey.mc.field_1724.method_18381(AutoFarmNukeTurkey.mc.field_1724.method_18376()));
            double deltaZ = posZ - AutoFarmNukeTurkey.mc.field_1724.method_23321();
            double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
            float yaw = (float)Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f + MathUtility.random(-2.0, 2.0);
            float pitch = (float)(-Math.toDegrees(Math.atan2(deltaY, horizontalDistance))) + MathUtility.random(-1.0, 1.0);
            AutoFarmNukeTurkey.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, 0, yaw, pitch));
            Experiment.getInstance().getRotationHandler().rotate(new Rotation(yaw, pitch), MoveCorrection.SILENT, 180.0f, 80.0f, 180.0f, RotationPriority.NORMAL);
            this.equipAxe();
            class_2350 direction = AutoFarmNukeTurkey.getDirection(targetBlockPos);
            AutoFarmNukeTurkey.mc.field_1761.method_2902(targetBlockPos, direction);
            AutoFarmNukeTurkey.mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private void equipAxe() {
        SlotGroup<ItemSlot> search = SlotGroups.inventory().and(SlotGroups.hotbar());
        ItemSlot axe = search.findItem(class_1802.field_8556);
        if (axe != null) {
            if (axe instanceof HotbarSlot) {
                HotbarSlot itemHotbarSlot = (HotbarSlot)axe;
                if (InventoryUtility.getCurrentHotbarSlot().item() != axe.item()) {
                    InventoryUtility.selectHotbarSlot(itemHotbarSlot);
                }
            } else if (axe instanceof InventorySlot) {
                InventorySlot itemInventorySlot = (InventorySlot)axe;
                HotbarSlot currentSlot = InventoryUtility.getCurrentHotbarSlot();
                itemInventorySlot.swapTo(currentSlot);
            }
        }
    }

    public static class_2350 getDirection(class_2338 pos) {
        class_243 eyesPos = new class_243(AutoFarmNukeTurkey.mc.field_1724.method_23317(), AutoFarmNukeTurkey.mc.field_1724.method_23318() + (double)AutoFarmNukeTurkey.mc.field_1724.method_18381(AutoFarmNukeTurkey.mc.field_1724.method_18376()), AutoFarmNukeTurkey.mc.field_1724.method_23321());
        if ((double)pos.method_10264() > eyesPos.field_1351) {
            if (AutoFarmNukeTurkey.mc.field_1687.method_8320(pos.method_10069(0, -1, 0)).method_45474()) {
                return class_2350.field_11033;
            }
            return AutoFarmNukeTurkey.mc.field_1724.method_5735().method_10153();
        }
        if (!AutoFarmNukeTurkey.mc.field_1687.method_8320(pos.method_10069(0, 1, 0)).method_45474()) {
            return AutoFarmNukeTurkey.mc.field_1724.method_5735().method_10153();
        }
        return class_2350.field_11036;
    }
}

