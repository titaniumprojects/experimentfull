/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_2561
 *  net.minecraft.class_7923
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.game.MessageUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

@ModuleInfo(name="Auto Bot", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class AutoBot
extends BaseModule {
    private final Timer scanTimer = new Timer();
    private Action action = Action.IDLE;

    @Override
    public void onEnable() {
        if (!FabricLoader.getInstance().isModLoaded("baritone")) {
            MessageUtility.info(class_2561.method_30163((String)("\u0414\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b " + this.getName() + " \u043d\u0443\u0436\u0435\u043d \u043c\u043e\u0434 baritone")));
            this.toggle();
            return;
        }
        this.action = Action.IDLE;
        this.msg("#allowBreak true");
    }

    @Override
    public void onDisable() {
        this.msg("#stop");
        this.msg("#sel clear");
    }

    @Override
    public void tick() {
        if (this.scanTimer.finished(200L)) {
            class_2338 player = AutoBot.mc.field_1724.method_24515();
            int radius = 10;
            for (int x = 0; x < radius * 2; ++x) {
                for (int z = 0; z < radius * 2; ++z) {
                    for (int y = 0; y < radius * 2; ++y) {
                        class_2338 offset = new class_2338((x % 2 == 0 ? -x : x) / 2, (y % 2 == 0 ? -y : y) / 2, (z % 2 == 0 ? -z : z) / 2);
                        class_2338 pos = player.method_10081((class_2382)offset);
                        if (!this.logic(pos)) continue;
                        return;
                    }
                }
            }
            this.scanTimer.reset();
        }
    }

    private boolean logic(class_2338 obsidian) {
        class_2338 target = obsidian.method_10084();
        if (AutoBot.mc.field_1687.method_8320(obsidian).method_26204() != class_2246.field_10540 || AutoBot.mc.field_1687.method_8320(obsidian.method_10078()).method_26204() != class_2246.field_10540 || AutoBot.mc.field_1687.method_8320(obsidian.method_10095()).method_26204() != class_2246.field_10540 || AutoBot.mc.field_1687.method_8320(obsidian.method_10072()).method_26204() != class_2246.field_10540 || AutoBot.mc.field_1687.method_8320(obsidian.method_10067()).method_26204() != class_2246.field_10540 || AutoBot.mc.field_1687.method_8320(target.method_10078()).method_26204() != class_2246.field_10124 || AutoBot.mc.field_1687.method_8320(target.method_10095()).method_26204() != class_2246.field_10124 || AutoBot.mc.field_1687.method_8320(target.method_10072()).method_26204() != class_2246.field_10124 || AutoBot.mc.field_1687.method_8320(target.method_10067()).method_26204() != class_2246.field_10124) {
            return false;
        }
        if (target.equals((Object)AutoBot.mc.field_1724.method_24515())) {
            if (AutoBot.mc.field_1687.method_8320(target).method_26204() == class_2246.field_10336) {
                if (this.action != Action.BREAK) {
                    this.select(target);
                    this.msg("#sel cleararea");
                    this.action = Action.BREAK;
                    this.scanTimer.reset();
                    return true;
                }
            } else if (this.action != Action.PLACE) {
                this.select(target);
                this.msg("#sel fill " + String.valueOf(class_7923.field_41175.method_10221((Object)class_2246.field_10336)));
                this.action = Action.PLACE;
                this.scanTimer.reset();
                return true;
            }
        } else if (this.action != Action.FOLLOW && this.action != Action.PLACE) {
            this.msg(String.format("#goto %s.5 %s %s.5", target.method_10263(), target.method_10264(), target.method_10260()));
            this.action = Action.FOLLOW;
            this.scanTimer.reset();
            return true;
        }
        return false;
    }

    private void select(class_2338 pos) {
        this.msg("#sel clear");
        this.msg(String.format("#sel pos1 %s %s %s", pos.method_10263(), pos.method_10264(), pos.method_10260()));
        this.msg(String.format("#sel pos2 %s %s %s", pos.method_10263(), pos.method_10264(), pos.method_10260()));
    }

    private void msg(String msg) {
        AutoBot.mc.field_1724.field_3944.method_45729(msg);
    }

    @Environment(value=EnvType.CLIENT)
    static enum Action {
        IDLE,
        FOLLOW,
        PLACE,
        BREAK;

    }
}

