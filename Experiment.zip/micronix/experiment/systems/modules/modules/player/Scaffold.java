/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1747
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.Arrays;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3965;

@ModuleInfo(name="Scaffold", desc="modules.descriptions.scaffold", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class Scaffold
extends BaseModule {
    private static final List<class_2248> BLACKLIST = Arrays.asList(class_2246.field_10034, class_2246.field_10443, class_2246.field_10380, class_2246.field_10102, class_2246.field_9980, class_2246.field_10181, class_2246.field_10158, class_2246.field_10484, class_2246.field_10592, class_2246.field_10332, class_2246.field_10026, class_2246.field_10397, class_2246.field_10470, class_2246.field_22130, class_2246.field_22131);
    private final Timer placeTimer = new Timer();
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (Scaffold.mc.field_1724 == null || Scaffold.mc.field_1687 == null || Scaffold.mc.field_1761 == null) {
            return;
        }
        class_2338 below = this.getPredictedPos();
        if (!Scaffold.mc.field_1687.method_8320(below).method_26215()) {
            return;
        }
        int slot = this.findBlockSlot();
        if (slot == -1 && (slot = this.findInventoryBlock()) != -1) {
            InventorySlot inv = InventoryUtility.getInventorySlot(slot);
            HotbarSlot target = InventoryUtility.getCurrentHotbarSlot();
            InventoryUtility.moveItem(inv, target);
            slot = target.getSlotId();
        }
        if (Scaffold.mc.field_1724.method_31548().field_7545 != slot) {
            Scaffold.mc.field_1724.method_31548().field_7545 = slot;
        }
        if (this.placeTimer.finished(50L)) {
            class_1269 result;
            class_3965 hit = this.findHit(below);
            if (hit == null) {
                return;
            }
            class_243 hitVec = hit.method_17784();
            Rotation rotation = RotationMath.getRotationTo(hitVec);
            float yawDiff = Math.abs(rotation.getYaw() - Scaffold.mc.field_1724.method_36454());
            float pitchDiff = Math.abs(rotation.getPitch() - Scaffold.mc.field_1724.method_36455());
            if (yawDiff > 10.0f || pitchDiff > 10.0f) {
                Experiment.getInstance().getRotationHandler().rotate(rotation, MoveCorrection.DIRECT, 100.0f, 100.0f, 100.0f, RotationPriority.USE_ITEM);
            }
            if ((result = Scaffold.mc.field_1761.method_2896(Scaffold.mc.field_1724, class_1268.field_5808, hit)).method_23665() && Experiment.getInstance().getRotationHandler().isIdling()) {
                Scaffold.mc.field_1724.method_6104(class_1268.field_5808);
                this.placeTimer.reset();
            }
        }
    };

    private int findInventoryBlock() {
        for (int i = 0; i < 27; ++i) {
            class_1747 blockItem;
            class_1799 stack = Scaffold.mc.field_1724.method_31548().method_5438(i + 9);
            class_1792 item = stack.method_7909();
            if (stack.method_7947() <= 0 || !(item instanceof class_1747) || BLACKLIST.contains((blockItem = (class_1747)item).method_7711())) continue;
            return i;
        }
        return -1;
    }

    private class_2338 getPredictedPos() {
        class_243 vel = Scaffold.mc.field_1724.method_18798();
        int dx = (int)Math.round(vel.field_1352);
        int dz = (int)Math.round(vel.field_1350);
        class_2338 pos = Scaffold.mc.field_1724.method_24515().method_10069(dx, 0, dz);
        return pos.method_10074();
    }

    private int findBlockSlot() {
        for (int i = 0; i < 9; ++i) {
            class_1747 blockItem;
            class_1799 stack = Scaffold.mc.field_1724.method_31548().method_5438(i);
            class_1792 item = stack.method_7909();
            if (stack.method_7947() <= 0 || !(item instanceof class_1747) || BLACKLIST.contains((blockItem = (class_1747)item).method_7711())) continue;
            return i;
        }
        return -1;
    }

    private class_3965 findHit(class_2338 target) {
        class_2350[] faces = new class_2350[]{class_2350.field_11033, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034};
        for (class_2350 face : faces) {
            class_2338 neighbour = target.method_10093(face);
            if (Scaffold.mc.field_1687.method_8320(neighbour).method_26215()) continue;
            class_243 hitVec = class_243.method_24953((class_2382)neighbour).method_1019(class_243.method_24954((class_2382)face.method_62675()).method_1021(0.5));
            return new class_3965(hitVec, face.method_10153(), neighbour, false);
        }
        return null;
    }
}

