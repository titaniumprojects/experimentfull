/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2830
 *  net.minecraft.class_2886
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2886;

@ModuleInfo(name="No Fall", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class NoFall
extends BaseModule {
    @Override
    public void tick() {
        if ((double)NoFall.mc.field_1724.field_6017 > 2.5) {
            class_243 pos = NoFall.mc.field_1724.method_19538();
            NoFall.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(pos.field_1352, pos.field_1351, pos.field_1350, NoFall.mc.field_1724.method_36454(), NoFall.mc.field_1724.method_36455(), true, true));
            NoFall.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, 0, NoFall.mc.field_1724.method_36454(), NoFall.mc.field_1724.method_36455()));
            NoFall.mc.field_1724.field_6017 = 0.0f;
        }
    }
}

