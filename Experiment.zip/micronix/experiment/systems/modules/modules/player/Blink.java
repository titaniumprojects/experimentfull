/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4587
 *  net.minecraft.class_5498
 *  net.minecraft.class_9801
 */
package micronix.experiment.systems.modules.modules.player;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.WorldChangeEvent;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_9801;

@ModuleInfo(name="Blink", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class Blink
extends BaseModule {
    private final List<class_2596<?>> packets = new ArrayList();
    private final Timer timer = new Timer();
    private final BooleanSetting pulse = new BooleanSetting(this, "modules.settings.blink.pulse");
    private final SliderSetting time = new SliderSetting((SettingsContainer)this, "modules.settings.blink.time", () -> !this.pulse.isEnabled()).min(1.0f).max(40.0f).step(1.0f).currentValue(12.0f);
    private final BooleanSetting display = new BooleanSetting(this, "modules.settings.blink.display");
    private final BooleanSetting svo = new BooleanSetting((SettingsContainer)this, "modules.settings.blink.hide_first_person", () -> !this.display.isEnabled());
    private class_243 lastPos;
    private boolean replaying;
    private final EventListener<SendPacketEvent> sendListener = this::savePacket;
    private final EventListener<Render3DEvent> event3d = e -> {
        if (this.display.isEnabled() && this.lastPos != null && (Blink.mc.field_1690.method_31044() != class_5498.field_26664 || !this.svo.isEnabled())) {
            class_4587 ms = e.getMatrices();
            class_287 quadsBuffer = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
            class_243 cameraPos = Blink.mc.field_1773.method_19418().method_19326();
            ms.method_22903();
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            Draw3DUtility.renderOutlinedBox(ms, quadsBuffer, Blink.mc.field_1724.method_5829().method_997(this.lastPos.method_1020(Blink.mc.field_1724.method_19538())).method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350), ColorRGBA.WHITE.withAlpha(180.0f));
            class_9801 buildQuadsBuffer = quadsBuffer.method_60794();
            if (buildQuadsBuffer != null) {
                class_286.method_43433((class_9801)buildQuadsBuffer);
            }
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            ms.method_22909();
        }
    };
    private final EventListener<WorldChangeEvent> world = e -> this.disable();

    public void savePacket(SendPacketEvent e) {
        if (this.replaying || !EntityUtility.isInGame()) {
            return;
        }
        this.packets.add(e.getPacket());
        e.cancel();
        if (this.pulse.isEnabled() && this.timer.finished((long)(this.time.getCurrentValue() * 50.0f))) {
            this.onDisable();
            this.onEnable();
            this.timer.reset();
        }
    }

    @Override
    public void onEnable() {
        if (Blink.mc.field_1724 == null) {
            return;
        }
        this.packets.clear();
        this.lastPos = Blink.mc.field_1724.method_19538();
        this.timer.reset();
        this.replaying = false;
    }

    @Override
    public void onDisable() {
        if (Blink.mc.field_1724 == null) {
            return;
        }
        this.replaying = true;
        for (class_2596<?> p : this.packets) {
            Blink.mc.field_1724.field_3944.method_52787(p);
        }
        this.replaying = false;
        this.packets.clear();
        this.lastPos = null;
    }

    public Timer getTimer() {
        return this.timer;
    }

    public BooleanSetting getPulse() {
        return this.pulse;
    }

    public SliderSetting getTime() {
        return this.time;
    }
}

