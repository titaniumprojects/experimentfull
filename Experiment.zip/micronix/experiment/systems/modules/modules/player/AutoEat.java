/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_9334
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.mixin.minecraft.client.IMinecraftClient;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_9334;

@ModuleInfo(name="Auto Eat", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class AutoEat
extends BaseModule {
    private boolean eating;
    private final SliderSetting food = new SliderSetting(this, "modules.settings.auto_eat.food").step(1.0f).min(1.0f).max(20.0f).currentValue(15.0f);
    private final EventListener<ClientPlayerTickEvent> onUpdateEvent = event -> {
        if ((float)AutoEat.mc.field_1724.method_7344().method_7586() <= this.food.getCurrentValue()) {
            SlotGroup<ItemSlot> search = SlotGroups.inventory().and(SlotGroups.hotbar());
            ItemSlot foodSlot = search.findItem(stack -> stack.method_7909().method_7854().method_57826(class_9334.field_50075));
            if (!AutoEat.mc.field_1724.method_6079().method_57826(class_9334.field_50075) && foodSlot != null) {
                foodSlot.moveToOffHand();
            }
            this.eating = true;
            if (AutoEat.mc.field_1755 != null && !AutoEat.mc.field_1724.method_6115()) {
                ((IMinecraftClient)mc).idoItemUse();
            } else {
                AutoEat.mc.field_1690.field_1904.method_23481(true);
            }
        } else if (this.eating) {
            this.eating = false;
            AutoEat.mc.field_1690.field_1904.method_23481(false);
        }
    };
}

