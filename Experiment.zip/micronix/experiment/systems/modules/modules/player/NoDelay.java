/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.mixin.minecraft.client.IMinecraftClient;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@ModuleInfo(name="No Delay", category=ModuleCategory.PLAYER, desc="modules.descriptions.no_delay")
@Environment(value=EnvType.CLIENT)
public class NoDelay
extends BaseModule {
    private final BooleanSetting jump = new BooleanSetting((SettingsContainer)this, "modules.settings.no_delay.jump", "modules.settings.no_delay.jump.description").enable();
    private final BooleanSetting rightClick = new BooleanSetting((SettingsContainer)this, "modules.settings.no_delay.right_click", "modules.settings.no_delay.right_click.description");

    @Override
    public void tick() {
        if (this.rightClick.isEnabled()) {
            ((IMinecraftClient)mc).setUseCooldown(0);
        }
        super.tick();
    }

    public BooleanSetting getJump() {
        return this.jump;
    }

    public BooleanSetting getRightClick() {
        return this.rightClick;
    }
}

