/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_3965;

@ModuleInfo(name="Tape Mouse", category=ModuleCategory.PLAYER, desc="modules.descriptions.tape_mouse")
@Environment(value=EnvType.CLIENT)
public class TapeMouse
extends BaseModule {
    private final ModeSetting mouseButton = new ModeSetting(this, "\u041a\u043d\u043e\u043f\u043a\u0430 \u043c\u044b\u0448\u0438");
    private final ModeSetting.Value leftButton = new ModeSetting.Value(this.mouseButton, "\u041b\u0435\u0432\u0430\u044f \u043a\u043d\u043e\u043f\u043a\u0430").select();
    private final ModeSetting.Value rightButton = new ModeSetting.Value(this.mouseButton, "\u041f\u0440\u0430\u0432\u0430\u044f \u043a\u043d\u043e\u043f\u043a\u0430");
    private final SliderSetting delay = new SliderSetting(this, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430").min(1.0f).max(100.0f).step(1.0f).currentValue(50.0f).suffix(" \u043c\u0441");
    private final Timer clickTimer = new Timer();
    private float lastDelay = 50.0f;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (TapeMouse.mc.field_1724 != null && TapeMouse.mc.field_1755 == null) {
            long delayMs;
            float currentDelay = this.delay.getCurrentValue();
            if (currentDelay != this.lastDelay) {
                this.clickTimer.reset();
                this.lastDelay = currentDelay;
            }
            if (this.clickTimer.finished(delayMs = (long)currentDelay)) {
                if (this.leftButton.isSelected()) {
                    this.performLeftClick();
                } else if (this.rightButton.isSelected()) {
                    this.performRightClick();
                }
                this.clickTimer.reset();
            }
        }
    };

    private void performLeftClick() {
        if (TapeMouse.mc.field_1761 != null) {
            if (TapeMouse.mc.field_1692 != null) {
                TapeMouse.mc.field_1761.method_2918((class_1657)TapeMouse.mc.field_1724, TapeMouse.mc.field_1692);
                TapeMouse.mc.field_1724.method_6104(class_1268.field_5808);
            } else if (TapeMouse.mc.field_1765 != null) {
                switch (TapeMouse.mc.field_1765.method_17783()) {
                    case field_1332: {
                        TapeMouse.mc.field_1761.method_2902(((class_3965)TapeMouse.mc.field_1765).method_17777(), ((class_3965)TapeMouse.mc.field_1765).method_17780());
                        TapeMouse.mc.field_1724.method_6104(class_1268.field_5808);
                        break;
                    }
                    case field_1331: {
                        if (TapeMouse.mc.field_1692 == null) break;
                        TapeMouse.mc.field_1761.method_2918((class_1657)TapeMouse.mc.field_1724, TapeMouse.mc.field_1692);
                        TapeMouse.mc.field_1724.method_6104(class_1268.field_5808);
                        break;
                    }
                    default: {
                        TapeMouse.mc.field_1724.method_6104(class_1268.field_5808);
                    }
                }
            }
        }
    }

    private void performRightClick() {
        block5: {
            block7: {
                block6: {
                    if (TapeMouse.mc.field_1761 == null) break block5;
                    if (TapeMouse.mc.field_1765 == null) break block6;
                    switch (TapeMouse.mc.field_1765.method_17783()) {
                        case field_1332: {
                            TapeMouse.mc.field_1761.method_2896(TapeMouse.mc.field_1724, class_1268.field_5808, (class_3965)TapeMouse.mc.field_1765);
                            break;
                        }
                        case field_1331: {
                            if (TapeMouse.mc.field_1692 != null) {
                                TapeMouse.mc.field_1761.method_2905((class_1657)TapeMouse.mc.field_1724, TapeMouse.mc.field_1692, class_1268.field_5808);
                                break;
                            }
                            break block7;
                        }
                        default: {
                            TapeMouse.mc.field_1761.method_2919((class_1657)TapeMouse.mc.field_1724, class_1268.field_5808);
                            break;
                        }
                    }
                    break block7;
                }
                TapeMouse.mc.field_1761.method_2919((class_1657)TapeMouse.mc.field_1724, class_1268.field_5808);
            }
            TapeMouse.mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    @Override
    public void onEnable() {
        this.clickTimer.reset();
    }
}

