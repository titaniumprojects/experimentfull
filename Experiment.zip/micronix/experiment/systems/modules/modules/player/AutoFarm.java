/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2302
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_243
 *  net.minecraft.class_2680
 *  net.minecraft.class_2886
 *  net.minecraft.class_3965
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.modules.modules.player.autofarm.AutoFarmCounter;
import micronix.experiment.systems.modules.modules.player.autofarm.AutoFarmNukeTurkey;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2886;
import net.minecraft.class_3965;

@ModuleInfo(name="Auto Farm", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class AutoFarm
extends BaseModule {
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.auto_farm.mode");
    private final ModeSetting.Value carrot = new ModeSetting.Value(this.mode, "modules.settings.auto_farm.mode.carrot").select();
    private final ModeSetting.Value potato = new ModeSetting.Value(this.mode, "modules.settings.auto_farm.mode.potato");
    private final ModeSetting.Value beetroot = new ModeSetting.Value(this.mode, "modules.settings.auto_farm.mode.beetroot");
    private final BooleanSetting mineBlocks = new BooleanSetting(this, "modules.settings.auto_farm.mine_blocks");
    private final SelectSetting blocks = new SelectSetting((SettingsContainer)this, "modules.settings.auto_farm.blocks", () -> !this.mineBlocks.isEnabled());
    private final SelectSetting.Value melon = new SelectSetting.Value(this.blocks, "modules.settings.auto_farm.blocks.melon");
    private final SelectSetting.Value tikva = new SelectSetting.Value(this.blocks, "modules.settings.auto_farm.blocks.pumpkin");
    private final SelectSetting.Value allCrops = new SelectSetting.Value(this.blocks, "modules.settings.auto_farm.blocks.other_crops");
    private final BooleanSetting autoExp = new BooleanSetting(this, "modules.settings.auto_farm.auto_exp").enabled(true);
    private final BooleanSetting autoSell = new BooleanSetting(this, "modules.settings.auto_farm.auto_sell").enabled(true);
    private final AutoFarmNukeTurkey nukeTurkey = new AutoFarmNukeTurkey();
    private final AutoFarmCounter count = new AutoFarmCounter();
    private final Timer timer = new Timer();
    private boolean repairing;
    private boolean cursorCheck;
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
        SlotGroup<ItemSlot> search = SlotGroups.inventory().and(SlotGroups.hotbar()).and(SlotGroups.offhand());
        ItemSlot exp = search.findItem(class_1802.field_8287);
        List<class_1792> hoes = List.of(class_1802.field_22026, class_1802.field_8527);
        List<class_1792> items = List.of(class_1802.field_8179, class_1802.field_8567, class_1802.field_8309);
        class_1799 mainHand = AutoFarm.mc.field_1724.method_6047();
        class_1799 offHand = AutoFarm.mc.field_1724.method_6079();
        class_2680 farmState = AutoFarm.mc.field_1687.method_8320(AutoFarm.mc.field_1724.method_24515());
        class_2680 cropState = AutoFarm.mc.field_1687.method_8320(AutoFarm.mc.field_1724.method_24515().method_10084());
        class_2338 cropPos = AutoFarm.mc.field_1724.method_24515().method_10084();
        class_3965 blockHitResult = new class_3965(new class_243(AutoFarm.mc.field_1724.method_23317(), AutoFarm.mc.field_1724.method_23318(), AutoFarm.mc.field_1724.method_23321()), class_2350.field_11036, AutoFarm.mc.field_1724.method_24515(), false);
        class_3965 cropHitResult = new class_3965(new class_243((double)cropPos.method_10263(), (double)cropPos.method_10264(), (double)cropPos.method_10260()), class_2350.field_11036, cropPos, false);
        if (!(this.mineBlocks.isEnabled() || this.melon.isSelected() || this.tikva.isSelected() || this.allCrops.isSelected())) {
            if (this.autoExp.isEnabled()) {
                int max = mainHand.method_7936();
                int cur = max - mainHand.method_7919();
                double percent = (double)cur / (double)max;
                if (!AutoFarm.mc.field_1724.field_7512.method_34255().method_7960()) {
                    int emptySlot;
                    this.cursorCheck = true;
                    if (this.timer.finished(150L) && (emptySlot = AutoFarm.mc.field_1724.method_31548().method_7376()) != -1) {
                        AutoFarm.mc.field_1761.method_2906(0, emptySlot < 9 ? emptySlot + 36 : emptySlot, 0, class_1713.field_7790, (class_1657)AutoFarm.mc.field_1724);
                    }
                    return;
                }
                if (this.cursorCheck) {
                    this.cursorCheck = false;
                    this.timer.reset();
                }
                if (this.repairing) {
                    if (exp != null && offHand.method_7909() != exp.item() && this.timer.finished(150L)) {
                        InventoryUtility.moveItem(exp.getIdForServer(), 45, false);
                        this.timer.reset();
                    } else if (exp == null && !items.contains(offHand.method_7909())) {
                        InventoryUtility.moveItem(this.findItem(), 45, false);
                    } else if (exp != null && offHand.method_7909() == exp.item() && this.timer.finished(150L)) {
                        AutoFarm.mc.field_1761.method_41931(AutoFarm.mc.field_1687, sequence -> new class_2886(class_1268.field_5810, sequence, AutoFarm.mc.field_1724.method_36454(), 90.0f));
                        this.timer.reset();
                        if (percent > 0.6) {
                            this.repairing = false;
                            if (this.findItem() != -1) {
                                InventoryUtility.moveItem(this.findItem(), 45, false);
                            }
                        }
                    }
                }
                if (hoes.contains(mainHand.method_7909()) && percent < 0.5 && !this.repairing && exp != null) {
                    this.repairing = true;
                }
            }
            if (this.autoSell.isEnabled() && AutoFarm.mc.field_1724.method_31548().method_7376() == -1) {
                if (AutoFarm.mc.field_1724.field_7512 instanceof class_1707) {
                    if (ServerUtility.isFT() ? AutoFarm.mc.field_1755.method_25440().getString().equals(Localizator.translate("modules.auto_farm.screen.select_section_ft")) : AutoFarm.mc.field_1755.method_25440().getString().equals(Localizator.translate("modules.auto_farm.screen.select_section"))) {
                        AutoFarm.mc.field_1761.method_2906(AutoFarm.mc.field_1724.field_7512.field_7763, 21, 0, class_1713.field_7790, (class_1657)AutoFarm.mc.field_1724);
                    }
                    if (AutoFarm.mc.field_1755.method_25440().getString().equals(Localizator.translate("modules.auto_farm.screen.food_seller"))) {
                        AutoFarm.mc.field_1761.method_2906(AutoFarm.mc.field_1724.field_7512.field_7763, this.ssItem(), 0, class_1713.field_7790, (class_1657)AutoFarm.mc.field_1724);
                        if (this.timer.finished(500L)) {
                            AutoFarm.mc.field_1724.method_7346();
                            this.timer.reset();
                        }
                    }
                } else if (this.timer.finished(300L)) {
                    AutoFarm.mc.field_1724.field_3944.method_45730("buyer");
                    this.timer.reset();
                }
            } else if (farmState.method_26204().equals(class_2246.field_10362) && !this.repairing) {
                Experiment.getInstance().getRotationHandler().rotate(new Rotation(AutoFarm.mc.field_1724.method_36454(), 90.0f), MoveCorrection.SILENT, 180.0f, 180.0f, 180.0f, RotationPriority.USE_ITEM);
                class_2248 patt0$temp = cropState.method_26204();
                if (patt0$temp instanceof class_2302) {
                    class_2302 crop = (class_2302)patt0$temp;
                    if (crop.method_9829(cropState) == 7) {
                        AutoFarm.mc.field_1724.method_6104(class_1268.field_5808);
                        AutoFarm.mc.field_1761.method_2910(AutoFarm.mc.field_1724.method_24515().method_10084(), class_2350.field_11036);
                        this.timer.reset();
                    } else if (hoes.contains(mainHand.method_7909())) {
                        AutoFarm.mc.field_1724.method_6104(class_1268.field_5808);
                        AutoFarm.mc.field_1761.method_2896(AutoFarm.mc.field_1724, class_1268.field_5808, cropHitResult);
                    }
                } else if (cropState.method_26215() && items.contains(offHand.method_7909())) {
                    AutoFarm.mc.field_1724.method_6104(class_1268.field_5810);
                    AutoFarm.mc.field_1761.method_2896(AutoFarm.mc.field_1724, class_1268.field_5810, blockHitResult);
                }
            }
        } else {
            this.nukeTurkey.nuke();
        }
    };

    public int findItem() {
        SlotGroup<ItemSlot> search = SlotGroups.inventory().and(SlotGroups.hotbar());
        ItemSlot foundSlot = search.findItem(stack -> this.carrot.isSelected() && stack.method_7909() == class_1802.field_8179 || this.potato.isSelected() && stack.method_7909() == class_1802.field_8567 || this.beetroot.isSelected() && stack.method_7909() == class_1802.field_8309);
        return foundSlot != null ? foundSlot.getIdForServer() : -1;
    }

    public int ssItem() {
        if (this.carrot.isSelected()) {
            return 10;
        }
        if (this.potato.isSelected()) {
            return 11;
        }
        if (this.beetroot.isSelected()) {
            return 12;
        }
        return -1;
    }

    @Override
    public void onDisable() {
        this.repairing = false;
        this.count.price = 0;
    }

    public ModeSetting getMode() {
        return this.mode;
    }

    public ModeSetting.Value getCarrot() {
        return this.carrot;
    }

    public ModeSetting.Value getPotato() {
        return this.potato;
    }

    public ModeSetting.Value getBeetroot() {
        return this.beetroot;
    }

    public BooleanSetting getMineBlocks() {
        return this.mineBlocks;
    }

    public SelectSetting getBlocks() {
        return this.blocks;
    }

    public SelectSetting.Value getMelon() {
        return this.melon;
    }

    public SelectSetting.Value getTikva() {
        return this.tikva;
    }

    public SelectSetting.Value getAllCrops() {
        return this.allCrops;
    }

    public BooleanSetting getAutoExp() {
        return this.autoExp;
    }

    public BooleanSetting getAutoSell() {
        return this.autoSell;
    }

    public AutoFarmNukeTurkey getNukeTurkey() {
        return this.nukeTurkey;
    }

    public AutoFarmCounter getCount() {
        return this.count;
    }

    public Timer getTimer() {
        return this.timer;
    }

    public boolean isRepairing() {
        return this.repairing;
    }

    public boolean isCursorCheck() {
        return this.cursorCheck;
    }

    public EventListener<ClientPlayerTickEvent> getOnClientPlayerTickEvent() {
        return this.onClientPlayerTickEvent;
    }
}

