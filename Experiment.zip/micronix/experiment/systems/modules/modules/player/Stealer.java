/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1263
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2586
 *  net.minecraft.class_2611
 *  net.minecraft.class_3965
 *  net.minecraft.class_476
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.WorldUtility;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2611;
import net.minecraft.class_3965;
import net.minecraft.class_476;

@ModuleInfo(name="Stealer", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class Stealer
extends BaseModule {
    private final SliderSetting delay = new SliderSetting(this, "modules.settings.stealer.delay").min(0.0f).max(5.0f).step(0.1f).currentValue(0.4f);
    private final BooleanSetting close = new BooleanSetting((SettingsContainer)this, "modules.settings.stealer.close", "modules.settings.stealer.close.description");
    private final BooleanSetting off = new BooleanSetting((SettingsContainer)this, "modules.settings.stealer.off", "modules.settings.stealer.off.description");
    private final BooleanSetting openMystic = new BooleanSetting((SettingsContainer)this, "modules.settings.stealer.open_mystic", "modules.settings.stealer.open_mystic.description");
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.stealer.mode");
    private final ModeSetting.Value up = new ModeSetting.Value(this.mode, "modules.settings.stealer.mode.up").select();
    private final ModeSetting.Value down = new ModeSetting.Value(this.mode, "modules.settings.stealer.mode.down");
    private final ModeSetting.Value center = new ModeSetting.Value(this.mode, "modules.settings.stealer.mode.center");
    private final ModeSetting.Value random = new ModeSetting.Value(this.mode, "modules.settings.stealer.mode.random");
    private final Timer clickTimer = new Timer();
    private final Timer openTimer = new Timer();
    private final List<class_2611> blackList = new ArrayList<class_2611>();
    private class_2611 target;

    @Override
    public void tick() {
        class_1703 screenHandler;
        if (Stealer.mc.field_1755 instanceof class_476 && (screenHandler = Stealer.mc.field_1724.field_7512) instanceof class_1707) {
            int slot;
            class_1707 handler = (class_1707)screenHandler;
            int size = handler.method_7629().method_5439();
            if (this.mode.is(this.up)) {
                for (int i = 0; i < size && this.clickTimer.finished((long)(this.delay.getCurrentValue() * 1000.0f + MathUtility.random(-100.0, 100.0))); ++i) {
                    if (handler.method_7611(i).method_7677().method_7960()) continue;
                    Stealer.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, (class_1657)Stealer.mc.field_1724);
                    this.clickTimer.reset();
                }
            } else if (this.mode.is(this.down)) {
                for (int i = size - 1; i >= 0 && this.clickTimer.finished((long)(this.delay.getCurrentValue() * 1000.0f + MathUtility.random(-100.0, 100.0))); --i) {
                    if (handler.method_7611(i).method_7677().method_7960()) continue;
                    Stealer.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, (class_1657)Stealer.mc.field_1724);
                    this.clickTimer.reset();
                }
            } else if (this.mode.is(this.center)) {
                int centerIndex = size / 2;
                for (int i = 0; i <= centerIndex && this.clickTimer.finished((long)(this.delay.getCurrentValue() * 1000.0f + MathUtility.random(-100.0, 100.0))); ++i) {
                    int left = centerIndex - i;
                    int right = centerIndex + i;
                    if (left >= 0 && !handler.method_7611(left).method_7677().method_7960()) {
                        Stealer.mc.field_1761.method_2906(handler.field_7763, left, 0, class_1713.field_7794, (class_1657)Stealer.mc.field_1724);
                        this.clickTimer.reset();
                        continue;
                    }
                    if (right >= size || handler.method_7611(right).method_7677().method_7960()) continue;
                    Stealer.mc.field_1761.method_2906(handler.field_7763, right, 0, class_1713.field_7794, (class_1657)Stealer.mc.field_1724);
                    this.clickTimer.reset();
                }
            } else if (this.mode.is(this.random) && this.clickTimer.finished((long)(this.delay.getCurrentValue() * 1000.0f + MathUtility.random(-100.0, 100.0))) && !handler.method_7611(slot = (int)MathUtility.random(0.0, size)).method_7677().method_7960()) {
                Stealer.mc.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7794, (class_1657)Stealer.mc.field_1724);
                this.clickTimer.reset();
            }
            if (this.isEmpty(handler)) {
                if (this.target != null && this.openMystic.isEnabled()) {
                    this.blackList.add(this.target);
                }
                if (this.off.isEnabled()) {
                    this.toggle();
                }
                if (this.close.isEnabled()) {
                    Stealer.mc.field_1724.method_7346();
                }
            }
            return;
        }
        if (!this.openMystic.isEnabled()) {
            return;
        }
        if (this.target == null || !this.isValidTarget(this.target)) {
            this.target = this.findTarget();
            this.openTimer.reset();
        }
        if (this.target != null && this.openTimer.finished(200L)) {
            class_2338 pos = this.target.method_11016();
            class_243 hitVec = class_243.method_24953((class_2382)pos);
            Rotation rotation = RotationMath.getRotationTo(hitVec);
            Experiment.getInstance().getRotationHandler().rotate(rotation, MoveCorrection.NONE, 22.0f, 22.0f, 22.0f, RotationPriority.USE_ITEM);
            class_3965 hit = new class_3965(hitVec, class_2350.field_11036, pos, false);
            Stealer.mc.field_1761.method_2896(Stealer.mc.field_1724, class_1268.field_5808, hit);
            Stealer.mc.field_1724.method_6104(class_1268.field_5808);
            this.openTimer.reset();
        }
    }

    private boolean isValidTarget(class_2611 entity) {
        return Stealer.mc.field_1724.method_5707(entity.method_11016().method_46558()) < 16.0 && !this.blackList.contains(entity);
    }

    private class_2611 findTarget() {
        for (class_2586 entity : WorldUtility.blockEntities) {
            class_2611 e;
            if (!(entity instanceof class_2611) || !this.isValidTarget(e = (class_2611)entity)) continue;
            return e;
        }
        return null;
    }

    private boolean isEmpty(class_1707 handler) {
        class_1263 inv = handler.method_7629();
        for (int i = 0; i < inv.method_5439(); ++i) {
            if (inv.method_5438(i).method_7960()) continue;
            return false;
        }
        return true;
    }
}

