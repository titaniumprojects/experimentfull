/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2596
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2868
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.Comparator;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.game.ItemUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_2846;
import net.minecraft.class_2868;

@ModuleInfo(name="Auto Swap", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class AutoSwap
extends BaseModule {
    private final BindSetting button = new BindSetting(this, "modules.settings.auto_swap.button");
    private final ModeSetting itemMode = new ModeSetting(this, "modules.settings.auto_swap.item");
    private final ModeSetting.Value swapTal = new ModeSetting.Value(this.itemMode, "modules.settings.auto_swap.item.talisman").select();
    private final ModeSetting swapToMode = new ModeSetting(this, "modules.settings.auto_swap.swap_to");
    private final ModeSetting.Value swapToTal = new ModeSetting.Value(this.swapToMode, "modules.settings.auto_swap.swap_to.talisman").select();
    private final Timer timer = new Timer();
    private final EventListener<KeyPressEvent> onKeyPressEvent = event -> {
        if (event.getAction() != 1) {
            return;
        }
        if (this.button.isKey(event.getKey())) {
            this.swap();
        }
    };
    private final EventListener<MouseEvent> onMouseEvent = event -> {
        if (this.button.isKey(event.getButton())) {
            this.swap();
        }
    };

    public AutoSwap() {
        new ModeSetting.Value(this.swapToMode, "modules.settings.auto_swap.swap_to.orb");
        new ModeSetting.Value(this.itemMode, "modules.settings.auto_swap.item.orb");
    }

    private void swap() {
        HotbarSlot hotbarSlot;
        if (AutoSwap.mc.field_1755 != null || ServerUtility.isST() && !this.timer.finished(1000L)) {
            return;
        }
        SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar()).and(SlotGroups.offhand());
        List<ItemSlot> slots = slotsToSearch.findItems(this.swapTal.isSelected() ? class_1802.field_8288 : class_1802.field_8575);
        List<ItemSlot> slots1 = slotsToSearch.findItems(this.swapToTal.isSelected() ? class_1802.field_8288 : class_1802.field_8575);
        ItemSlot slot = slots.stream().min(Comparator.comparingInt(AutoSwap::lambda$swap$2)).orElse(null);
        ItemSlot slot1 = slots1.stream().filter(candidate -> AutoSwap.lambda$swap$3(slot, candidate)).min(Comparator.comparingInt(AutoSwap::lambda$swap$4)).orElse(null);
        if (slot == null || slot1 == null) {
            return;
        }
        boolean canSwap = true;
        if (AutoSwap.mc.field_1724.method_6079().method_7909() != slot.item() && AutoSwap.mc.field_1724.method_6079().method_7909() != slot1.item()) {
            InventoryUtility.moveToOffHand(slot);
            canSwap = false;
        } else if (slot instanceof HotbarSlot) {
            hotbarSlot = (HotbarSlot)slot;
            if (!AutoSwap.mc.field_1724.method_6115()) {
                AutoSwap.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(hotbarSlot.getSlotId()));
                AutoSwap.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                AutoSwap.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(AutoSwap.mc.field_1724.method_31548().field_7545));
                canSwap = false;
            }
        }
        if (canSwap) {
            if (slot1 instanceof HotbarSlot) {
                hotbarSlot = (HotbarSlot)slot1;
                if (!AutoSwap.mc.field_1724.method_6115()) {
                    AutoSwap.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(hotbarSlot.getSlotId()));
                    AutoSwap.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                    AutoSwap.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(AutoSwap.mc.field_1724.method_31548().field_7545));
                }
            }
            slot.swapTo(slot1);
        }
        this.timer.reset();
        Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.SUCCESS, this.getName(), AutoSwap.mc.field_1724.method_6079().method_7964().getString().replace("[", "").replace("] ", "").replace("xxx ", "").replace(" xxx", "").replace("123 ", "").replace(" 123", ""));
    }

    private static int lambda$swap$4(ItemSlot stack) {
        return ItemUtility.bestFactor(stack.itemStack()) - (stack.getIdForServer() == 45 ? 99 : 0);
    }

    private static boolean lambda$swap$3(ItemSlot slot, ItemSlot slotW) {
        return slot != slotW;
    }

    private static int lambda$swap$2(ItemSlot stack) {
        return ItemUtility.bestFactor(stack.itemStack()) - (stack.getIdForServer() == 45 ? 99 : 0);
    }
}

