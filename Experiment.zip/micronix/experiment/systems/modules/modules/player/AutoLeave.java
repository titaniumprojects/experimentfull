/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_7439
 */
package micronix.experiment.systems.modules.modules.player;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_7439;

@ModuleInfo(name="Auto Leave", category=ModuleCategory.PLAYER)
@Environment(value=EnvType.CLIENT)
public class AutoLeave
extends BaseModule {
    private final ModeSetting leave = new ModeSetting(this, "modules.settings.auto_leave.leave");
    private final ModeSetting.Value distLeave = new ModeSetting.Value(this.leave, "modules.settings.auto_leave.leave.distance");
    private final ModeSetting.Value healthLeave = new ModeSetting.Value(this.leave, "modules.settings.auto_leave.leave.health");
    private final ModeSetting.Value banLeave = new ModeSetting.Value(this.leave, "modules.settings.auto_leave.leave.ban");
    private final SliderSetting dist = new SliderSetting((SettingsContainer)this, "modules.settings.auto_leave.distance", () -> this.healthLeave.isSelected() || this.banLeave.isSelected()).suffix(number -> " %s".formatted(Localizator.translate("block")) + TextUtility.makeCountTranslated(number)).step(1.0f).min(1.0f).max(150.0f).currentValue(30.0f);
    private final SliderSetting health = new SliderSetting((SettingsContainer)this, "modules.settings.auto_leave.health", () -> this.distLeave.isSelected() || this.banLeave.isSelected()).step(1.0f).min(1.0f).max(20.0f).currentValue(10.0f);
    private final SliderSetting delay = new SliderSetting((SettingsContainer)this, "modules.settings.auto_leave.delay", () -> !this.banLeave.isSelected() || this.distLeave.isSelected() || this.healthLeave.isSelected()).suffix(Localizator.translate("sec") + ".").step(1.0f).min(1.0f).max(60.0f).currentValue(40.0f);
    private final Timer timer = new Timer();
    private boolean waiting;
    private final ModeSetting mode = new ModeSetting(this, "modules.settings.auto_leave.mode");
    private final ModeSetting.Value hub = new ModeSetting.Value(this.mode, "modules.settings.auto_leave.mode.hub");
    private final ModeSetting.Value serverLeave = new ModeSetting.Value(this.mode, "modules.settings.auto_leave.mode.server");
    private final ModeSetting.Value spawn = new ModeSetting.Value(this.mode, "modules.settings.auto_leave.mode.spawn");
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
        if (this.distLeave.isSelected()) {
            for (class_1657 e : AutoLeave.mc.field_1687.method_18456()) {
                if (e == null || e == AutoLeave.mc.field_1724 || e.method_5739((class_1297)e) > this.dist.getCurrentValue() || AutoLeave.mc.field_1724 == null || ServerUtility.hasCT || Experiment.getInstance().getFriendManager().isFriend(e.method_5477().getString())) continue;
                if (this.hub.isSelected()) {
                    AutoLeave.mc.field_1724.field_3944.method_45730("hub");
                } else if (this.serverLeave.isSelected()) {
                    AutoLeave.mc.field_1724.field_3944.method_48296().method_10747(class_2561.method_30163((String)Localizator.translate("modules.auto_leave.near_player")));
                } else if (this.spawn.isSelected()) {
                    AutoLeave.mc.field_1724.field_3944.method_45730("spawn");
                }
                this.toggle();
                break;
            }
        }
        if (this.healthLeave.isSelected() && AutoLeave.mc.field_1724 != null && AutoLeave.mc.field_1724.method_6032() + AutoLeave.mc.field_1724.method_6067() <= this.health.getCurrentValue()) {
            if (this.hub.isSelected()) {
                AutoLeave.mc.field_1724.field_3944.method_45730("hub");
            } else if (this.serverLeave.isSelected()) {
                AutoLeave.mc.field_1724.field_3944.method_48296().method_10747(class_2561.method_30163((String)Localizator.translate("modules.auto_leave.low_health")));
            } else if (this.spawn.isSelected()) {
                AutoLeave.mc.field_1724.field_3944.method_45730("spawn");
            }
            this.toggle();
        }
        if (!this.waiting) {
            return;
        }
        if (this.timer.finished((long)this.delay.getCurrentValue() * 1000L)) {
            AutoLeave.mc.field_1724.field_3944.method_45730("an" + ServerUtility.ftAn);
            this.waiting = false;
        }
    };
    private final EventListener<ReceivePacketEvent> onReceivePacketEvent = event -> {
        class_7439 packet;
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_7439 && (packet = (class_7439)patt0$temp).comp_763().getString().contains(Localizator.translate("modules.auto_leave.banned_word")) && this.banLeave.isSelected()) {
            AutoLeave.mc.field_1724.field_3944.method_45730("hub");
            this.timer.reset();
            this.waiting = true;
        }
    };
}

