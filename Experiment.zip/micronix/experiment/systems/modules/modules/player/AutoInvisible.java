/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1291
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_6880
 */
package micronix.experiment.systems.modules.modules.player;

import java.util.Map;
import java.util.TreeMap;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.utility.game.PotionUtility;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.OffhandSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_6880;

@ModuleInfo(name="Auto Invisible", category=ModuleCategory.PLAYER, desc="\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043f\u044c\u0435\u0442 \u0437\u0435\u043b\u044c\u0435 \u043d\u0435\u0432\u0438\u0434\u0438\u043c\u043e\u0441\u0442\u0438")
@Environment(value=EnvType.CLIENT)
public class AutoInvisible
extends BaseModule {
    private final Map<String, class_1293> effects = new TreeMap<String, class_1293>();
    private boolean isUsingPotion;
    private final BooleanSetting preDrink = new BooleanSetting(this, "\u041f\u0438\u0442\u044c \u0437\u0430\u0440\u0430\u043d\u0435\u0435");
    private final EventListener<ClientPlayerTickEvent> onClientPlayerTickEvent = event -> {
        boolean hasInvisibility = AutoInvisible.mc.field_1724.method_6059(class_1294.field_5905);
        class_1293 effect = hasInvisibility ? AutoInvisible.mc.field_1724.method_6112(class_1294.field_5905) : null;
        boolean shouldDrink = !hasInvisibility;
        boolean bl = shouldDrink;
        if (this.preDrink.isEnabled() && effect != null && effect.method_5584() <= 200) {
            shouldDrink = true;
        }
        if (shouldDrink) {
            class_1799 offhandItem = AutoInvisible.mc.field_1724.method_6079();
            boolean hasPotionInOffhand = this.isInvisibilityPotion(offhandItem);
            SlotGroup<ItemSlot> slotsToSearch = SlotGroups.inventory().and(SlotGroups.hotbar());
            ItemSlot potionSlot = slotsToSearch.findItem(this::isInvisibilityPotion);
            OffhandSlot offhandSlot = new OffhandSlot();
            if (potionSlot != null && !hasPotionInOffhand) {
                InventoryUtility.moveItem(potionSlot, offhandSlot);
            }
            if (hasPotionInOffhand) {
                this.isUsingPotion = true;
                AutoInvisible.mc.field_1690.field_1904.method_23481(true);
            }
        } else if (this.isUsingPotion) {
            AutoInvisible.mc.field_1690.field_1904.method_23481(false);
            this.isUsingPotion = false;
            class_1799 offhandItem = AutoInvisible.mc.field_1724.method_6079();
            if (offhandItem.method_7909() == class_1802.field_8469) {
                AutoInvisible.mc.field_1761.method_2906(0, 45, 1, class_1713.field_7795, (class_1657)AutoInvisible.mc.field_1724);
            }
        }
    };

    private boolean isInvisibilityPotion(class_1799 stack) {
        return PotionUtility.hasEffect(stack, (class_6880<class_1291>)class_1294.field_5905);
    }

    public Map<String, class_1293> getEffects() {
        return this.effects;
    }
}

