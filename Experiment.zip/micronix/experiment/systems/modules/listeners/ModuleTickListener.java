/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules.listeners;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.Module;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ModuleTickListener
implements EventListener<ClientPlayerTickEvent> {
    @Override
    public void onEvent(ClientPlayerTickEvent event) {
        for (Module module : Experiment.getInstance().getModuleManager().getModules()) {
            if (!module.isEnabled()) continue;
            module.tick();
        }
    }
}

