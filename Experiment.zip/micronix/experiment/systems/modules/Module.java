/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.modules;

import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.interfaces.Toggleable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface Module
extends Toggleable,
IMinecraft,
IScaledResolution,
SettingsContainer {
    public void disable();

    public void enable();

    public void tick();

    public ModuleInfo getInfo();

    public String getName();

    default public String getDescription() {
        String translationKey = "modules.descriptions.%s".formatted(this.getName().toLowerCase().replace(" ", "_"));
        return Localizator.translate(translationKey);
    }

    public int getKey();

    public ModuleCategory getCategory();

    public boolean isEnabled();

    public boolean isHidden();

    public Animation getKeybindsAnimation();

    public void setKey(int var1);

    public void setEnabled(boolean var1, boolean var2);
}

