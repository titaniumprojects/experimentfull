/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 */
package micronix.experiment.systems.ai;

import micronix.experiment.Experiment;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.modules.api.ModuleInfo;
import micronix.experiment.systems.modules.impl.BaseModule;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.rotations.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_746;

@ModuleInfo(name="Player", category=ModuleCategory.OTHER)
@Environment(value=EnvType.CLIENT)
public class RotationPlayer
extends BaseModule {
    private static final long LOG_WINDOW_MS = 2000L;
    private long lastSwingTimeMs;
    private class_1309 lastTarget;
    private final EventListener<AttackEvent> onAttackEvent = event -> {
        class_1309 tgt = (class_1309)event.getEntity();
        if (tgt != null) {
            this.lastTarget = tgt;
            this.lastSwingTimeMs = System.currentTimeMillis();
        }
    };
    private final EventListener<HudRenderEvent> onHudRender = event -> {
        long now = System.currentTimeMillis();
        if (this.lastTarget != null && now - this.lastSwingTimeMs <= 2000L) {
            event.getContext().drawCenteredText(Fonts.MEDIUM.getFont(8.0f), "Playing", sr.getScaledWidth() / 2.0f, 40.0f, ColorRGBA.WHITE);
        }
    };
    private final EventListener<ClientPlayerTickEvent> onPlayerTick = event -> {
        class_746 p = class_310.method_1551().field_1724;
        if (p == null || this.lastTarget == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastSwingTimeMs > 2000L) {
            this.lastTarget = null;
            return;
        }
        Rotation predicted = Experiment.getInstance().getAi().predictRotation(Experiment.getInstance().getRotationHandler().getPlayerRotation(), this.lastTarget);
        RotationPlayer.mc.field_1724.method_36456(predicted.getYaw());
        RotationPlayer.mc.field_1724.method_36457(predicted.getPitch());
    };

    private float normalizeAngle(float angle) {
        float f;
        angle %= 360.0f;
        if (f > 180.0f) {
            angle -= 360.0f;
        }
        if (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }

    private float calcTargetDeltaYaw(class_746 p, class_1297 t) {
        double dx = t.method_23317() - p.method_23317();
        double dz = t.method_23321() - p.method_23321();
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        return this.normalizeAngle(targetYaw - p.method_36454());
    }

    private float calcTargetDeltaPitch(class_746 p, class_1297 t) {
        double dx = t.method_23317() - p.method_23317();
        double dz = t.method_23321() - p.method_23321();
        double dy = t.method_23320() - p.method_23320();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return this.normalizeAngle(targetPitch - p.method_36455());
    }
}

