/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  ai.catboost.CatBoostError
 *  ai.catboost.CatBoostModel
 *  ai.catboost.CatBoostPredictions
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 */
package micronix.experiment.systems.ai;

import ai.catboost.CatBoostError;
import ai.catboost.CatBoostModel;
import ai.catboost.CatBoostPredictions;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.rotations.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;

@Environment(value=EnvType.CLIENT)
public class AIPredict
implements IMinecraft {
    private long lastSwingTimeMs;
    private CatBoostModel yawModel;
    private CatBoostModel pitchModel;
    private float prevYaw;
    private float prevPitch;
    private float prevTargetYaw;
    private float prevTargetPitch;
    private float prevDistance;
    private Rotation last = Rotation.ZERO;
    private final EventListener<AttackEvent> onAttackEvent = event -> {
        class_1297 tgt = event.getEntity();
        if (tgt != null) {
            this.lastSwingTimeMs = System.currentTimeMillis();
        }
    };

    public AIPredict() {
        try {
            this.yawModel = CatBoostModel.loadModel((String)"C:/Experiment/delta_yaw_model.cbm");
            this.pitchModel = CatBoostModel.loadModel((String)"C:/Experiment/delta_pitch_model.cbm");
        }
        catch (CatBoostError e) {
            e.printStackTrace();
        }
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public Rotation predictRotation(Rotation prev, class_1309 target) {
        long now = System.currentTimeMillis();
        double diffY = AIPredict.mc.field_1724.method_23318() - target.method_23318();
        float tdy = this.calcTargetDeltaYaw(prev, (class_1297)target);
        float tdp = this.calcTargetDeltaPitch(prev, (class_1297)target);
        float dist = AIPredict.mc.field_1724.method_5739((class_1297)target);
        float since = Math.min(500L, now - this.lastSwingTimeMs);
        float[][] features = new float[][]{{tdy, tdp, dist, since, AIPredict.mc.field_1724.field_6017, (float)diffY, this.prevTargetYaw, this.prevTargetPitch, this.prevYaw, this.prevPitch, this.prevDistance}};
        String[][] catFeatures = new String[features.length][0];
        try {
            CatBoostPredictions predsYaw = this.yawModel.predict((float[][])features, catFeatures);
            CatBoostPredictions predsPitch = this.pitchModel.predict((float[][])features, catFeatures);
            double predictedYaw = predsYaw.get(0, 0);
            double predictedPitch = predsPitch.get(0, 0);
            this.prevTargetYaw = tdy;
            this.prevTargetPitch = tdp;
            this.prevYaw = this.normalizeAngle(this.last.getYaw() - prev.getYaw());
            this.prevPitch = this.normalizeAngle(this.last.getPitch() - prev.getPitch());
            this.prevDistance = dist;
            this.last = new Rotation(prev.getYaw(), prev.getPitch());
            return new Rotation((float)((double)prev.getYaw() + predictedYaw), (float)((double)prev.getPitch() - predictedPitch));
        }
        catch (CatBoostError ex) {
            ex.printStackTrace();
            return prev;
        }
    }

    private float normalizeAngle(float angle) {
        float f;
        angle %= 360.0f;
        if (f > 180.0f) {
            angle -= 360.0f;
        }
        if (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }

    private float calcTargetDeltaYaw(Rotation rotation, class_1297 t) {
        double dx = t.method_23317() - AIPredict.mc.field_1724.method_23317();
        double dz = t.method_23321() - AIPredict.mc.field_1724.method_23321();
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        return this.normalizeAngle(targetYaw - rotation.getYaw());
    }

    private float calcTargetDeltaPitch(Rotation rotation, class_1297 t) {
        double dx = t.method_23317() - AIPredict.mc.field_1724.method_23317();
        double dz = t.method_23321() - AIPredict.mc.field_1724.method_23321();
        double dy = t.method_23320() - AIPredict.mc.field_1724.method_23320();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return this.normalizeAngle(targetPitch - rotation.getPitch());
    }
}

