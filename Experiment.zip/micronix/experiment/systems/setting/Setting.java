/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.setting;

import com.google.gson.JsonElement;
import java.util.function.BooleanSupplier;
import micronix.experiment.systems.setting.SettingsContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface Setting {
    public String getName();

    public String getDescription();

    public BooleanSupplier getHideCondition();

    public void register(SettingsContainer var1);

    default public boolean isVisible() {
        return !this.getHideCondition().getAsBoolean();
    }

    public JsonElement save();

    public void load(JsonElement var1);
}

