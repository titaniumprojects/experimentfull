/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  org.jetbrains.annotations.NotNull
 */
package micronix.experiment.systems.setting.impl;

import java.util.function.BooleanSupplier;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.systems.setting.SettingsContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.NotNull;

@Environment(value=EnvType.CLIENT)
public abstract class AbstractSetting
implements Setting {
    private final String name;
    @NotNull
    private final BooleanSupplier hideCondition;

    public AbstractSetting(@NotNull SettingsContainer parent, String name, @NotNull BooleanSupplier hideCondition) {
        this.name = name;
        this.hideCondition = hideCondition;
        this.register(parent);
    }

    public AbstractSetting(@NotNull SettingsContainer parent, String name) {
        this(parent, name, () -> false);
    }

    @Override
    public void register(SettingsContainer parent) {
        parent.getSettings().add(this);
    }

    @Override
    public String getDescription() {
        return this.getName() + ".description";
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    @NotNull
    public BooleanSupplier getHideCondition() {
        return this.hideCondition;
    }
}

