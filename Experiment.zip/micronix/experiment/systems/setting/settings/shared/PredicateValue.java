/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.systems.setting.settings.shared;

import java.util.function.Predicate;
import micronix.experiment.systems.setting.settings.SelectSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class PredicateValue<T>
extends SelectSetting.Value {
    private final Predicate<T> predicate;

    public PredicateValue(SelectSetting parent, String name, Predicate<T> predicate) {
        super(parent, name);
        this.predicate = predicate;
    }

    public PredicateValue(SelectSetting parent, String name, String description, Predicate<T> predicate) {
        super(parent, name, description);
        this.predicate = predicate;
    }

    public boolean predicated(T t) {
        return this.predicate.test(t) && this.isSelected();
    }
}

