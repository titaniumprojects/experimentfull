/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_241
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package micronix.experiment.systems.setting.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.function.BooleanSupplier;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.impl.AbstractSetting;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_241;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class BezierSetting
extends AbstractSetting {
    private class_241 start = class_241.field_1340;
    private class_241 end = new class_241(1.0f, 1.0f);

    public BezierSetting(@NotNull SettingsContainer parent, String name, String description, @Nullable BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public BezierSetting(@NotNull SettingsContainer parent, String name, @Nullable BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public BezierSetting(@NotNull SettingsContainer parent, String name, String description) {
        super(parent, name);
    }

    public BezierSetting(@NotNull SettingsContainer parent, String name) {
        super(parent, name);
    }

    public BezierSetting start(float startX, float startY) {
        this.start = new class_241(startX, startY);
        return this;
    }

    public BezierSetting end(float endX, float endY) {
        this.end = new class_241(endX, endY);
        return this;
    }

    public BezierSetting start(class_241 start) {
        this.start = start;
        return this;
    }

    public BezierSetting end(class_241 end) {
        this.end = end;
        return this;
    }

    public Easing easing() {
        return Easing.generate(this.start.field_1343, 1.0f - this.start.field_1342, this.end.field_1343, 1.0f - this.end.field_1342);
    }

    @Override
    public JsonElement save() {
        JsonObject object = new JsonObject();
        object.addProperty("start_x", (Number)Float.valueOf(this.start.field_1343));
        object.addProperty("start_y", (Number)Float.valueOf(this.start.field_1342));
        object.addProperty("end_x", (Number)Float.valueOf(this.end.field_1343));
        object.addProperty("end_y", (Number)Float.valueOf(this.end.field_1342));
        return object;
    }

    @Override
    public void load(JsonElement element) {
        if (!element.isJsonObject()) {
            return;
        }
        JsonObject object = element.getAsJsonObject();
        if (object.has("start_x") && object.has("start_y")) {
            this.start(new class_241(object.get("start_x").getAsFloat(), object.get("start_y").getAsFloat()));
        }
        if (object.has("end_x") && object.has("end_y")) {
            this.end(new class_241(object.get("end_x").getAsFloat(), object.get("end_y").getAsFloat()));
        }
    }

    public class_241 start() {
        return this.start;
    }

    public class_241 end() {
        return this.end;
    }
}

