/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  org.jetbrains.annotations.NotNull
 */
package micronix.experiment.systems.setting.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.function.BooleanSupplier;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.impl.AbstractSetting;
import micronix.experiment.utility.interfaces.Toggleable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.NotNull;

@Environment(value=EnvType.CLIENT)
public class BooleanSetting
extends AbstractSetting
implements Toggleable {
    private boolean enabled;

    public BooleanSetting(@NotNull SettingsContainer parent, String name, String description, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public BooleanSetting(@NotNull SettingsContainer parent, String name, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public BooleanSetting(@NotNull SettingsContainer parent, String name, String description) {
        super(parent, name);
    }

    public BooleanSetting(@NotNull SettingsContainer parent, String name) {
        super(parent, name);
    }

    public BooleanSetting enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public BooleanSetting enable() {
        this.enabled = true;
        return this;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(Boolean.valueOf(this.enabled));
    }

    @Override
    public void load(JsonElement element) {
        this.setEnabled(element.getAsBoolean());
    }

    @Override
    public void toggle() {
        this.enabled = !this.enabled;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}

