/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_3532
 *  org.jetbrains.annotations.NotNull
 */
package micronix.experiment.systems.setting.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.function.BooleanSupplier;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.impl.AbstractSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;

@Environment(value=EnvType.CLIENT)
public class SliderSetting
extends AbstractSetting {
    protected float min;
    protected float max;
    protected float step;
    protected float currentValue;
    private Suffix suffix = number -> "";

    public SliderSetting(@NotNull SettingsContainer parent, String name, String description, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public SliderSetting(@NotNull SettingsContainer parent, String name, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public SliderSetting(@NotNull SettingsContainer parent, String name, String description) {
        super(parent, name);
    }

    public SliderSetting(@NotNull SettingsContainer parent, String id) {
        super(parent, id);
    }

    public SliderSetting min(float min) {
        this.min = min;
        return this;
    }

    public SliderSetting max(float max) {
        this.max = max;
        return this;
    }

    public SliderSetting step(float step) {
        this.step = step;
        return this;
    }

    public SliderSetting suffix(Suffix suffix) {
        this.suffix = suffix;
        return this;
    }

    public SliderSetting suffix(String suffix) {
        this.suffix = number -> suffix;
        return this;
    }

    public SliderSetting currentValue(float currentValue) {
        this.setCurrentValue(currentValue);
        return this;
    }

    public String getSuffix() {
        return this.suffix.apply(this.getCurrentValue()).contains(" ") ? " " + Localizator.translate(this.suffix.apply(this.getCurrentValue()).replace(" ", "")) : Localizator.translate(this.suffix.apply(this.getCurrentValue()));
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive((Number)Float.valueOf(this.currentValue));
    }

    @Override
    public void load(JsonElement element) {
        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            this.setCurrentValue(element.getAsFloat());
        }
    }

    public void setCurrentValue(float currentValue) {
        this.currentValue = class_3532.method_15363((float)((float)((double)Math.round((double)currentValue * (1.0 / (double)this.step)) / (1.0 / (double)this.step))), (float)this.min, (float)this.max);
    }

    public float getMin() {
        return this.min;
    }

    public float getMax() {
        return this.max;
    }

    public float getStep() {
        return this.step;
    }

    public float getCurrentValue() {
        return this.currentValue;
    }

    @Environment(value=EnvType.CLIENT)
    public static interface Suffix {
        public String apply(float var1);
    }
}

