/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_3532
 *  org.jetbrains.annotations.NotNull
 */
package micronix.experiment.systems.setting.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.function.BooleanSupplier;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.impl.AbstractSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;

@Environment(value=EnvType.CLIENT)
public class RangeSetting
extends AbstractSetting {
    private float firstValue;
    private float secondValue;
    private float min;
    private float max;
    private float step;

    public RangeSetting(@NotNull SettingsContainer parent, String name, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public RangeSetting(@NotNull SettingsContainer parent, String name) {
        super(parent, name);
    }

    public RangeSetting firstValue(float firstValue) {
        this.firstValue = firstValue;
        return this;
    }

    public RangeSetting secondValue(float secondValue) {
        this.secondValue = secondValue;
        return this;
    }

    public RangeSetting min(float min) {
        this.min = min;
        return this;
    }

    public RangeSetting max(float max) {
        this.max = max;
        return this;
    }

    public RangeSetting step(float step) {
        this.step = step;
        return this;
    }

    @Override
    public JsonElement save() {
        JsonObject object = new JsonObject();
        object.addProperty("first", (Number)Float.valueOf(this.firstValue));
        object.addProperty("second", (Number)Float.valueOf(this.secondValue));
        return object;
    }

    @Override
    public void load(JsonElement element) {
        if (!element.isJsonObject()) {
            return;
        }
        JsonObject object = element.getAsJsonObject();
        if (object.has("first")) {
            this.setFirstValue(object.get("first").getAsFloat());
        }
        if (object.has("second")) {
            this.setSecondValue(object.get("second").getAsFloat());
        }
    }

    public void setFirstValue(float value) {
        this.firstValue = (float)class_3532.method_15350((double)((double)Math.round((double)value * (1.0 / (double)this.step)) / (1.0 / (double)this.step)), (double)this.min, (double)this.max);
    }

    public void setSecondValue(float value) {
        this.secondValue = (float)class_3532.method_15350((double)((double)Math.round((double)value * (1.0 / (double)this.step)) / (1.0 / (double)this.step)), (double)this.min, (double)this.max);
    }

    public float getFirstValue() {
        return this.firstValue;
    }

    public float getSecondValue() {
        return this.secondValue;
    }

    public float getMin() {
        return this.min;
    }

    public float getMax() {
        return this.max;
    }

    public float getStep() {
        return this.step;
    }

    public void setMin(float min) {
        this.min = min;
    }

    public void setMax(float max) {
        this.max = max;
    }

    public void setStep(float step) {
        this.step = step;
    }
}

