/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  org.jetbrains.annotations.NotNull
 */
package micronix.experiment.systems.setting.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.function.BooleanSupplier;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.impl.AbstractSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.render.penis.PenisPlayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.NotNull;

@Environment(value=EnvType.CLIENT)
public class ModeSetting
extends AbstractSetting {
    private final List<Value> values = new ArrayList<Value>();
    private Value value;

    public ModeSetting(@NotNull SettingsContainer parent, String name, String description, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public ModeSetting(@NotNull SettingsContainer parent, String name, @NotNull BooleanSupplier hideCondition) {
        super(parent, name, hideCondition);
    }

    public ModeSetting(@NotNull SettingsContainer parent, String name, String description) {
        super(parent, name);
    }

    public ModeSetting(@NotNull SettingsContainer parent, String name) {
        super(parent, name);
    }

    public void addMode(Value mode) {
        this.values.add(mode);
        if (this.value == null) {
            this.value = mode;
        }
    }

    public boolean is(Value otherValue) {
        return this.value == otherValue;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(this.value.getName());
    }

    public Value getRandomEnabledElement() {
        List<Value> enableValue = this.values.stream().filter(Value::isSelected).toList();
        if (!enableValue.isEmpty()) {
            Random random = new Random();
            return enableValue.get(random.nextInt(enableValue.size()));
        }
        return null;
    }

    @Override
    public void load(JsonElement element) {
        String name = element.getAsString();
        for (Value value : this.values) {
            if (!value.getName().equalsIgnoreCase(name)) continue;
            this.value = value;
            break;
        }
    }

    public List<Value> getValues() {
        return this.values;
    }

    public Value getValue() {
        return this.value;
    }

    public void setValue(Value value) {
        this.value = value;
    }

    public Value getSelected() {
        for (Value value : this.getValues()) {
            if (!value.isSelected()) continue;
            return value;
        }
        return null;
    }

    public String getSelected1() {
        for (Value value : this.getValues()) {
            if (!value.isSelected()) continue;
            return this.toString();
        }
        return null;
    }

    public String getSelectedName() {
        Value selected = this.getSelected();
        return selected != null ? selected.getName() : null;
    }

    @Environment(value=EnvType.CLIENT)
    public static class Value {
        private final ModeSetting parent;
        private final String name;
        private final String description;
        private final Animation hoverAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);
        private final Animation activeAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);
        private final BooleanSupplier hideCondition;
        private PenisPlayer enablePenis;
        private PenisPlayer disablePenis;
        private PenisPlayer currentPenis;
        private boolean lastState;

        public Value(ModeSetting parent, String name) {
            this(parent, name, "", () -> false);
        }

        public Value(ModeSetting parent, String name, String description) {
            this(parent, name, description, () -> false);
        }

        public Value(ModeSetting parent, String name, String description, BooleanSupplier hideCondition) {
            this.parent = parent;
            this.name = name;
            this.description = description;
            this.hideCondition = hideCondition;
            parent.addMode(this);
        }

        public boolean isHidden() {
            return this.hideCondition != null && this.hideCondition.getAsBoolean();
        }

        public Value select() {
            this.parent.setValue(this);
            return this;
        }

        public boolean isSelected() {
            return this.parent.getValue() == this;
        }

        public String toString() {
            return this.name;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (obj == null || obj.getClass() != this.getClass()) {
                return false;
            }
            Value that = (Value)obj;
            return Objects.equals(this.parent, that.parent) && Objects.equals(this.name, that.name) && Objects.equals(this.description, that.description);
        }

        public int hashCode() {
            return Objects.hash(this.parent, this.name, this.description);
        }

        public void setEnablePenis(PenisPlayer enablePenis) {
            this.enablePenis = enablePenis;
        }

        public void setDisablePenis(PenisPlayer disablePenis) {
            this.disablePenis = disablePenis;
        }

        public void setCurrentPenis(PenisPlayer currentPenis) {
            this.currentPenis = currentPenis;
        }

        public void setLastState(boolean lastState) {
            this.lastState = lastState;
        }

        public ModeSetting getParent() {
            return this.parent;
        }

        public String getName() {
            return this.name;
        }

        public String getDescription() {
            return this.description;
        }

        public Animation getHoverAnimation() {
            return this.hoverAnimation;
        }

        public Animation getActiveAnimation() {
            return this.activeAnimation;
        }

        public BooleanSupplier getHideCondition() {
            return this.hideCondition;
        }

        public PenisPlayer getEnablePenis() {
            return this.enablePenis;
        }

        public PenisPlayer getDisablePenis() {
            return this.disablePenis;
        }

        public PenisPlayer getCurrentPenis() {
            return this.currentPenis;
        }

        public boolean isLastState() {
            return this.lastState;
        }
    }
}

