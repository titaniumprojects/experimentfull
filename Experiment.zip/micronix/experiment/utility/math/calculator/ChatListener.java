/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2596
 *  net.minecraft.class_9449
 */
package micronix.experiment.utility.math.calculator;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.MathUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_9449;

@Environment(value=EnvType.CLIENT)
public class ChatListener
implements IMinecraft {
    private final EventListener<SendPacketEvent> onSendPacket = event -> {
        class_2596<?> patt0$temp = event.getPacket();
        if (patt0$temp instanceof class_9449) {
            class_9449 packet = (class_9449)patt0$temp;
            if (ChatListener.mc.field_1724 == null) {
                return;
            }
            String message = packet.comp_2532();
            if (message.startsWith("ah me")) {
                ChatListener.mc.field_1724.field_3944.method_45729("/ah " + ChatListener.mc.field_1724.method_5477().getString());
                event.cancel();
            }
            if (message.startsWith("ah sell ")) {
                String expression = message.replaceFirst("ah sell ", "");
                String result = MathUtility.calculate(expression);
                ChatListener.mc.field_1724.field_3944.method_45729("/ah sell " + Math.round(Float.parseFloat(result)));
                event.cancel();
            }
        }
    };

    public ChatListener() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }
}

