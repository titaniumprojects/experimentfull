/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.colors;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.utility.animation.types.ColorAnimation;
import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class Colors {
    public static final ColorRGBA RED = new ColorRGBA(255.0f, 0.0f, 0.0f);
    public static final ColorRGBA GREEN = new ColorRGBA(0.0f, 255.0f, 0.0f);
    public static final ColorRGBA BLUE = new ColorRGBA(0.0f, 0.0f, 255.0f);
    public static final ColorRGBA WHITE = new ColorRGBA(255.0f, 255.0f, 255.0f);
    public static final ColorRGBA BLACK = new ColorRGBA(0.0f, 0.0f, 0.0f);
    public static final ColorRGBA ACCENT = new ColorRGBA(151.0f, 71.0f, 255.0f);
    private static final long ANIMATION_DURATION = 500L;
    private static final ColorAnimation BACKGROUND_COLOR_ANIMATION = new ColorAnimation(500L);
    private static final ColorAnimation ADDITIONAL_COLOR_ANIMATION = new ColorAnimation(500L);
    private static final ColorAnimation TEXT_COLOR_ANIMATION = new ColorAnimation(500L);
    private static final ColorAnimation OUTLINE_COLOR_ANIMATION = new ColorAnimation(500L);
    private static final ColorAnimation FLAT_COLOR_ANIMATION = new ColorAnimation(500L);
    private static final ColorAnimation ACCENT_COLOR_ANIMATION = new ColorAnimation(500L);

    private static Theme getTheme() {
        return Experiment.getInstance().getThemeManager().getCurrentTheme();
    }

    public static ColorRGBA getBackgroundColor() {
        return Colors.getAnimatedColor(BACKGROUND_COLOR_ANIMATION, Colors.getTheme().getBackgroundColor());
    }

    public static ColorRGBA getAdditionalColor() {
        return Colors.getAnimatedColor(ADDITIONAL_COLOR_ANIMATION, Colors.getTheme().getAdditionalColor());
    }

    public static ColorRGBA getTextColor() {
        return Colors.getAnimatedColor(TEXT_COLOR_ANIMATION, Colors.getTheme().getTextColor());
    }

    public static ColorRGBA getOutlineColor() {
        return Colors.getAnimatedColor(OUTLINE_COLOR_ANIMATION, Colors.getTheme().getOutlineColor());
    }

    public static ColorRGBA getFlatColor() {
        return Colors.getAnimatedColor(FLAT_COLOR_ANIMATION, Colors.getTheme().getFlatColor());
    }

    public static ColorRGBA getSeparatorColor() {
        return ColorRGBA.BLACK.withAlpha(255.0f * (Colors.getTheme() == Theme.DARK ? 0.08f : 0.05f));
    }

    public static ColorRGBA getAccentColor() {
        Interface interfaceModule = Experiment.getInstance().getModuleManager().getModule(Interface.class);
        if (interfaceModule == null) {
            return ACCENT;
        }
        if (interfaceModule.getMinimalism().isSelected()) {
            ColorRGBA color = interfaceModule.getMinimalismMainColor().getColor();
            return Colors.getAnimatedColor(ACCENT_COLOR_ANIMATION, color);
        }
        if (interfaceModule.getLiquidGlass().isSelected()) {
            ColorRGBA color = interfaceModule.getLiquidClientColor().getColor();
            return Colors.getAnimatedColor(ACCENT_COLOR_ANIMATION, color);
        }
        return ACCENT;
    }

    public static ColorRGBA getHudTextColor() {
        return Colors.getTextColor();
    }

    public static ColorRGBA getLiquidGlassColor() {
        Interface interfaceModule = Experiment.getInstance().getModuleManager().getModule(Interface.class);
        return interfaceModule != null && interfaceModule.getLiquidGlassColor() != null ? interfaceModule.getLiquidGlassColor().getColor() : ColorRGBA.WHITE;
    }

    private static ColorRGBA getAnimatedColor(ColorAnimation animation, ColorRGBA color) {
        animation.update(color);
        return animation.getColor();
    }

    private Colors() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

