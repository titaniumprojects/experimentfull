/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1792
 *  net.minecraft.class_2886
 */
package micronix.experiment.utility.integration;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.modules.player.GuiMove;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.ItemSlot;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_2886;

@Environment(value=EnvType.CLIENT)
public class SwapIntegration
implements IMinecraft {
    private class_1792 itemToUse = null;
    private HotbarSlot originalSlot = null;
    private boolean isProcessingItem = false;
    private ItemSlot targetSlot = null;
    private final Timer itemUseTimer = new Timer();
    private ItemUseState currentState = ItemUseState.IDLE;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (this.isProcessingItem) {
            this.processItemUse();
        }
    };

    public SwapIntegration() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    private void processItemUse() {
        if (SwapIntegration.mc.field_1724 == null || SwapIntegration.mc.field_1687 == null || SwapIntegration.mc.field_1761 == null || SwapIntegration.mc.field_1724.method_7357() == null) {
            this.isProcessingItem = false;
            this.currentState = ItemUseState.IDLE;
            return;
        }
        if (!(this.targetSlot instanceof HotbarSlot)) {
            Experiment.getInstance().getModuleManager().getModule(GuiMove.class).setStay(true);
        }
        switch (this.currentState.ordinal()) {
            case 1: {
                if (this.targetSlot instanceof HotbarSlot) {
                    SwapIntegration.mc.field_1761.method_41931(SwapIntegration.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, SwapIntegration.mc.field_1724.method_36454(), SwapIntegration.mc.field_1724.method_36455()));
                    this.currentState = ItemUseState.RETURNING_SLOT;
                    break;
                }
                if (!Experiment.getInstance().getModuleManager().getModule(GuiMove.class).canSend()) break;
                SwapIntegration.mc.field_1761.method_41931(SwapIntegration.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, SwapIntegration.mc.field_1724.method_36454(), SwapIntegration.mc.field_1724.method_36455()));
                this.currentState = ItemUseState.RETURNING_SLOT;
                break;
            }
            case 2: {
                if (this.targetSlot instanceof HotbarSlot) {
                    InventoryUtility.selectHotbarSlot(this.originalSlot);
                    this.resetUseState();
                    break;
                }
                if (!Experiment.getInstance().getModuleManager().getModule(GuiMove.class).canSend()) break;
                HotbarSlot currentSlot = InventoryUtility.getCurrentHotbarSlot();
                InventoryUtility.hotbarSwap(this.targetSlot.getIdForServer(), this.originalSlot.getSlotId());
                this.resetUseState();
                break;
            }
            default: {
                this.isProcessingItem = false;
                this.currentState = ItemUseState.IDLE;
            }
        }
    }

    public void useItem(class_1792 itemType) {
        if (SwapIntegration.mc.field_1724 == null || SwapIntegration.mc.field_1687 == null || SwapIntegration.mc.field_1761 == null || SwapIntegration.mc.field_1755 != null) {
            return;
        }
        if (this.isProcessingItem) {
            return;
        }
        SlotGroup<ItemSlot> group = SlotGroups.hotbar().and(SlotGroups.inventory());
        ItemSlot itemSlot = group.findItem(itemType);
        if (itemSlot == null) {
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.ERROR, "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d", "\u0412\u0430\u043c \u043d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c\u043e \u0438\u043c\u0435\u0442\u044c " + itemType.method_63680().getString() + " \u0432 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u0435");
            return;
        }
        if (SwapIntegration.mc.field_1724.method_7357().method_7904(itemSlot.itemStack())) {
            return;
        }
        this.itemToUse = itemType;
        this.originalSlot = InventoryUtility.getCurrentHotbarSlot();
        this.targetSlot = itemSlot;
        this.isProcessingItem = true;
        this.currentState = ItemUseState.USING_ITEM;
        this.itemUseTimer.reset();
        if (itemSlot instanceof HotbarSlot) {
            HotbarSlot itemHotbarSlot = (HotbarSlot)itemSlot;
            if (InventoryUtility.getCurrentHotbarSlot().item() != itemType) {
                InventoryUtility.selectHotbarSlot(itemHotbarSlot);
            }
        } else if (itemSlot instanceof InventorySlot) {
            InventorySlot itemInventorySlot = (InventorySlot)itemSlot;
            HotbarSlot currentSlot = InventoryUtility.getCurrentHotbarSlot();
            InventoryUtility.hotbarSwap(itemInventorySlot.getIdForServer(), currentSlot.getSlotId());
        }
    }

    private void resetUseState() {
        this.isProcessingItem = false;
        this.currentState = ItemUseState.IDLE;
        this.itemToUse = null;
        this.originalSlot = null;
        this.targetSlot = null;
    }

    @Environment(value=EnvType.CLIENT)
    private static enum ItemUseState {
        IDLE,
        USING_ITEM,
        RETURNING_SLOT;

    }
}

