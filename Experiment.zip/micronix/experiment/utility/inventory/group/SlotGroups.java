/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.inventory.group;

import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.impl.ArmorSlotsGroup;
import micronix.experiment.utility.inventory.group.impl.HotbarSlotsGroup;
import micronix.experiment.utility.inventory.group.impl.InventorySlotsGroup;
import micronix.experiment.utility.inventory.group.impl.OffhandSlotGroup;
import micronix.experiment.utility.inventory.slots.ArmorSlot;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.inventory.slots.OffhandSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class SlotGroups {
    private SlotGroups() {
    }

    public static SlotGroup<HotbarSlot> hotbar() {
        return new HotbarSlotsGroup();
    }

    public static SlotGroup<InventorySlot> inventory() {
        return new InventorySlotsGroup();
    }

    public static SlotGroup<ArmorSlot> armor() {
        return new ArmorSlotsGroup();
    }

    public static SlotGroup<OffhandSlot> offhand() {
        return new OffhandSlotGroup();
    }
}

