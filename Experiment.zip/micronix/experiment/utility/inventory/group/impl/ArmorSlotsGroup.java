/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.inventory.group.impl;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.slots.ArmorSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ArmorSlotsGroup
extends SlotGroup<ArmorSlot> {
    public ArmorSlotsGroup() {
        super(ArmorSlotsGroup.createSlots());
    }

    private static List<ArmorSlot> createSlots() {
        ArrayList<ArmorSlot> slots = new ArrayList<ArmorSlot>();
        for (int i = 0; i < 4; ++i) {
            slots.add(new ArmorSlot(i));
        }
        return slots;
    }
}

