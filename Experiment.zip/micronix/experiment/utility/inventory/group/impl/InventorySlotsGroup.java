/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.inventory.group.impl;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class InventorySlotsGroup
extends SlotGroup<InventorySlot> {
    public InventorySlotsGroup() {
        super(InventorySlotsGroup.createSlots());
    }

    private static List<InventorySlot> createSlots() {
        ArrayList<InventorySlot> slots = new ArrayList<InventorySlot>();
        for (int i = 0; i < 27; ++i) {
            slots.add(new InventorySlot(i));
        }
        return slots;
    }
}

