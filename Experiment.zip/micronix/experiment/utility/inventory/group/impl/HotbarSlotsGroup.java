/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.inventory.group.impl;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class HotbarSlotsGroup
extends SlotGroup<HotbarSlot> {
    public HotbarSlotsGroup() {
        super(HotbarSlotsGroup.createSlots());
    }

    private static List<HotbarSlot> createSlots() {
        ArrayList<HotbarSlot> slots = new ArrayList<HotbarSlot>();
        for (int i = 0; i < 9; ++i) {
            slots.add(new HotbarSlot(i));
        }
        return slots;
    }
}

