/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.inventory.group.impl;

import java.util.List;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.slots.OffhandSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class OffhandSlotGroup
extends SlotGroup<OffhandSlot> {
    public OffhandSlotGroup() {
        super(List.of(new OffhandSlot()));
    }
}

