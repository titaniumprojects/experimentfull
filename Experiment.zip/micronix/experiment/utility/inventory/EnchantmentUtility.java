/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2IntArrayMap
 *  it.unimi.dsi.fastutil.objects.Object2IntMap
 *  it.unimi.dsi.fastutil.objects.Object2IntMap$Entry
 *  it.unimi.dsi.fastutil.objects.Object2IntMaps
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1887
 *  net.minecraft.class_5321
 *  net.minecraft.class_6880
 *  net.minecraft.class_9304
 *  net.minecraft.class_9334
 */
package micronix.experiment.utility.inventory;

import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

@Environment(value=EnvType.CLIENT)
public final class EnchantmentUtility {
    public static void getEnchantments(class_1799 itemStack, Object2IntMap<class_6880<class_1887>> enchantments) {
        enchantments.clear();
        if (!itemStack.method_7960()) {
            Set itemEnchantments = itemStack.method_7909() == class_1802.field_8598 ? ((class_9304)itemStack.method_57824(class_9334.field_49643)).method_57539() : itemStack.method_58657().method_57539();
            for (Object2IntMap.Entry entry : itemEnchantments) {
                enchantments.put((Object)((class_6880)entry.getKey()), entry.getIntValue());
            }
        }
    }

    @SafeVarargs
    public static boolean hasEnchantments(class_1799 itemStack, class_5321<class_1887> ... enchantments) {
        if (itemStack.method_7960()) {
            return false;
        }
        Object2IntArrayMap itemEnchantments = new Object2IntArrayMap();
        EnchantmentUtility.getEnchantments(itemStack, (Object2IntMap<class_6880<class_1887>>)itemEnchantments);
        for (class_5321<class_1887> enchantment : enchantments) {
            if (EnchantmentUtility.hasEnchantment((Object2IntMap<class_6880<class_1887>>)itemEnchantments, enchantment)) continue;
            return false;
        }
        return true;
    }

    public static int getEnchantmentLevel(class_1799 itemStack, class_5321<class_1887> enchantment) {
        if (itemStack.method_7960()) {
            return 0;
        }
        Object2IntArrayMap itemEnchantments = new Object2IntArrayMap();
        EnchantmentUtility.getEnchantments(itemStack, (Object2IntMap<class_6880<class_1887>>)itemEnchantments);
        return EnchantmentUtility.getEnchantmentLevel((Object2IntMap<class_6880<class_1887>>)itemEnchantments, enchantment);
    }

    public static int getEnchantmentLevel(Object2IntMap<class_6880<class_1887>> itemEnchantments, class_5321<class_1887> enchantment) {
        for (Object2IntMap.Entry entry : Object2IntMaps.fastIterable(itemEnchantments)) {
            if (!((class_6880)entry.getKey()).method_40225(enchantment)) continue;
            return entry.getIntValue();
        }
        return 0;
    }

    private static boolean hasEnchantment(Object2IntMap<class_6880<class_1887>> itemEnchantments, class_5321<class_1887> enchantmentKey) {
        for (class_6880 enchantment : itemEnchantments.keySet()) {
            if (!enchantment.method_40225(enchantmentKey)) continue;
            return true;
        }
        return false;
    }

    private EnchantmentUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

