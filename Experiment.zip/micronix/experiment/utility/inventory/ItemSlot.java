/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 */
package micronix.experiment.utility.inventory;

import java.util.function.Predicate;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.inventory.InventoryUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public abstract class ItemSlot
implements IMinecraft {
    public abstract class_1799 itemStack();

    public abstract int getIdForServer();

    public int syncId() {
        if (ItemSlot.mc.field_1724 == null || ItemSlot.mc.field_1724.field_7512 == null) {
            return 0;
        }
        return ItemSlot.mc.field_1724.field_7512.field_7763;
    }

    public class_1792 item() {
        return this.itemStack().method_7909();
    }

    public boolean isEmpty() {
        return this.itemStack().method_7960();
    }

    public boolean contains(class_1792 item) {
        return this.itemStack().method_7909() == item;
    }

    public boolean matches(Predicate<class_1799> predicate) {
        return predicate.test(this.itemStack());
    }

    public void swapTo(ItemSlot newSlot) {
        InventoryUtility.moveItem(this, newSlot);
    }

    public void moveToOffHand() {
        InventoryUtility.moveToOffHand(this);
    }

    public void click() {
        if (ItemSlot.mc.field_1761 == null) {
            return;
        }
        ItemSlot.mc.field_1761.method_2906(this.syncId(), this.getIdForServer(), 0, class_1713.field_7790, (class_1657)ItemSlot.mc.field_1724);
    }
}

