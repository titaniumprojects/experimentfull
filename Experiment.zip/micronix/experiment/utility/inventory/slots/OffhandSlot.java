/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 */
package micronix.experiment.utility.inventory.slots;

import micronix.experiment.utility.inventory.ItemSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class OffhandSlot
extends ItemSlot {
    @Override
    public class_1799 itemStack() {
        if (OffhandSlot.mc.field_1724 == null || OffhandSlot.mc.field_1724.method_31548() == null) {
            return class_1799.field_8037;
        }
        return (class_1799)OffhandSlot.mc.field_1724.method_31548().field_7544.getFirst();
    }

    @Override
    public int getIdForServer() {
        return 45;
    }
}

