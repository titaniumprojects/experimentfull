/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 */
package micronix.experiment.utility.inventory.slots;

import micronix.experiment.utility.inventory.ItemSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class HotbarSlot
extends ItemSlot {
    private final int slotId;

    public HotbarSlot(int slotId) {
        if (slotId < 0 || slotId > 8) {
            throw new IllegalArgumentException("Hotbar Slot ID must be between 0 and 8");
        }
        this.slotId = slotId;
    }

    @Override
    public class_1799 itemStack() {
        if (HotbarSlot.mc.field_1724 == null || HotbarSlot.mc.field_1724.method_31548() == null) {
            return class_1799.field_8037;
        }
        return HotbarSlot.mc.field_1724.method_31548().method_5438(this.slotId);
    }

    @Override
    public int getIdForServer() {
        return 36 + this.slotId;
    }

    public int getSlotId() {
        return this.slotId;
    }
}

