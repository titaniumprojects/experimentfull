/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 */
package micronix.experiment.utility.inventory.slots;

import micronix.experiment.utility.inventory.ItemSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class InventorySlot
extends ItemSlot {
    private final int slotId;

    public InventorySlot(int slotId) {
        if (slotId < 0 || slotId > 26) {
            throw new IllegalArgumentException("Inventory Slot ID must be between 0 and 26");
        }
        this.slotId = slotId;
    }

    @Override
    public class_1799 itemStack() {
        if (InventorySlot.mc.field_1724 == null || InventorySlot.mc.field_1724.method_31548() == null) {
            return class_1799.field_8037;
        }
        return InventorySlot.mc.field_1724.method_31548().method_5438(this.slotId + 9);
    }

    @Override
    public int getIdForServer() {
        return this.slotId + 9;
    }

    public int getSlotId() {
        return this.slotId;
    }
}

