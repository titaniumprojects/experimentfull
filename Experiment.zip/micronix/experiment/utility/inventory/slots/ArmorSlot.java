/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 */
package micronix.experiment.utility.inventory.slots;

import micronix.experiment.utility.inventory.ItemSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
public class ArmorSlot
extends ItemSlot {
    private final int armorSlotIndex;

    public ArmorSlot(int armorSlotIndex) {
        if (armorSlotIndex < 0 || armorSlotIndex > 3) {
            throw new IllegalArgumentException("Armor Slot Index must be between 0 and 3");
        }
        this.armorSlotIndex = armorSlotIndex;
    }

    @Override
    public class_1799 itemStack() {
        if (ArmorSlot.mc.field_1724 == null || ArmorSlot.mc.field_1724.method_31548() == null) {
            return class_1799.field_8037;
        }
        return ArmorSlot.mc.field_1724.method_31548().method_7372(this.armorSlotIndex);
    }

    @Override
    public int getIdForServer() {
        return 8 - this.armorSlotIndex;
    }

    public int getArmorSlotIndex() {
        return this.armorSlotIndex;
    }
}

