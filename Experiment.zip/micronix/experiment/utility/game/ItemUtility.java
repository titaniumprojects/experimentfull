/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2487
 *  net.minecraft.class_2520
 *  net.minecraft.class_2960
 *  net.minecraft.class_3298
 *  net.minecraft.class_3300
 *  net.minecraft.class_5455
 *  net.minecraft.class_7225$class_7874
 *  net.minecraft.class_9276
 *  net.minecraft.class_9288
 *  net.minecraft.class_9334
 */
package micronix.experiment.utility.game;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import micronix.experiment.utility.game.DonateItem;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_9276;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

@Environment(value=EnvType.CLIENT)
public final class ItemUtility
implements IMinecraft {
    public static List<class_1799> getItemsInShulker(class_1799 s) {
        ArrayList<class_1799> items = new ArrayList<class_1799>();
        class_9288 container = (class_9288)s.method_57824(class_9334.field_49622);
        if (container == null) {
            class_9276 container1 = (class_9276)s.method_57824(class_9334.field_49650);
            if (container1 == null) {
                return items;
            }
            for (class_1799 stack : container1.method_57421()) {
                items.add(stack);
            }
            return items;
        }
        for (class_1799 stack : container.method_59714()) {
            items.add(stack);
        }
        return items;
    }

    public static class_2487 getNBT(class_1799 stack) {
        class_2487 components;
        class_2487 compound;
        class_5455 registries = ItemUtility.mc.field_1687.method_30349();
        class_2520 nbt = stack.method_57375((class_7225.class_7874)registries);
        if (nbt instanceof class_2487 && (compound = (class_2487)nbt).method_10573("components", 10) && (components = compound.method_10562("components")).method_10573("minecraft:custom_data", 10)) {
            return components.method_10562("minecraft:custom_data");
        }
        return null;
    }

    public static boolean checkDonItem(class_1799 itemStack, String startWith) {
        class_2487 customData = ItemUtility.getNBT(itemStack);
        if (customData == null) {
            return false;
        }
        if (customData.method_10545("don-item")) {
            String donItemName = customData.method_10558("don-item");
            return donItemName.contains(startWith);
        }
        return false;
    }

    public static String findHashedModel(String hashedId) {
        String string;
        block9: {
            class_2960 modelPath;
            class_3300 resourceManager = mc.method_1478();
            Optional resource = resourceManager.method_14486(modelPath = class_2960.method_60655((String)"minecraft", (String)("models/item/" + hashedId.replace("minecraft:", "") + ".json")));
            if (!resource.isPresent()) {
                return null;
            }
            BufferedReader reader = ((class_3298)resource.get()).method_43039();
            try {
                string = reader.lines().collect(Collectors.joining("\n"));
                if (reader == null) break block9;
            }
            catch (Throwable throwable) {
                try {
                    if (reader != null) {
                        try {
                            reader.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException e) {
                    System.err.println("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u0438\u0438 \u0441\u0435\u0440\u0432\u0435\u0440\u043d\u043e\u0439 \u043c\u043e\u0434\u0435\u043b\u0438: " + e.getMessage());
                    return null;
                }
            }
            reader.close();
        }
        return string;
    }

    public static boolean isDonItem(class_1799 itemStack) {
        class_2487 customData = ItemUtility.getNBT(itemStack);
        if (customData == null) {
            return false;
        }
        return customData.method_10545("don-item");
    }

    public static String donNBT(class_1799 itemStack) {
        class_2487 customData = ItemUtility.getNBT(itemStack);
        if (customData == null) {
            return "";
        }
        class_2487 sphereEffect = customData.method_10562("sphereEffect");
        if (customData.method_10545("don-item")) {
            return customData.method_10558("don-item");
        }
        if (customData.method_10545("spooky-item")) {
            return customData.method_10558("spooky-item");
        }
        if (ServerUtility.is("holyworld") && customData.method_10573("sphereEffect", 10) && itemStack.method_7909() == class_1802.field_8288 && sphereEffect.method_10545("rank")) {
            if (sphereEffect.method_10558("rank").equals("ETERNITY")) {
                return sphereEffect.method_10558("name");
            }
            return sphereEffect.method_10558("rank");
        }
        return "";
    }

    public static DonateItem getDonateItem(class_1799 stack) {
        for (DonateItem item : DonateItem.values()) {
            for (String key : item.getNbt()) {
                if (!ItemUtility.donNBT(stack).equals(key)) continue;
                return item;
            }
        }
        return null;
    }

    public static int totemFactor(class_1799 stack) {
        if (stack.method_7942()) {
            for (DonateItem item : DonateItem.values()) {
                for (String key : item.getNbt()) {
                    if (!ItemUtility.donNBT(stack).equals(key)) continue;
                    return 12 - item.getTotem();
                }
            }
            return 0;
        }
        return -1;
    }

    public static int bestFactor(class_1799 stack) {
        if (stack.method_7942() || ItemUtility.isDonItem(stack)) {
            for (DonateItem item : DonateItem.values()) {
                for (String key : item.getNbt()) {
                    if (!ItemUtility.donNBT(stack).equals(key)) continue;
                    return 15 - item.getFactor();
                }
            }
            return 16;
        }
        return 17;
    }

    private ItemUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

