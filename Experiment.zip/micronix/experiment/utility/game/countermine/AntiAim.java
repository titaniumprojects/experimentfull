/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1007
 *  net.minecraft.class_1297
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2830
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_5498
 *  net.minecraft.class_897
 *  net.minecraft.class_898
 */
package micronix.experiment.utility.game.countermine;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.render.Render3DEvent;
import micronix.experiment.systems.modules.modules.other.CounterMine;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.countermine.RageBot;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.Utils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1007;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3959;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import net.minecraft.class_897;
import net.minecraft.class_898;

@Environment(value=EnvType.CLIENT)
public class AntiAim
implements IMinecraft {
    public static boolean FORCE;
    public float yaw;
    public float pitch;
    private BooleanSetting antiAim;
    private BooleanSetting freestand;
    private ModeSetting mode;
    private ModeSetting.Value statich;
    private ModeSetting.Value fake;
    private CounterMine counterMine;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (this.antiAim.isEnabled() && this.counterMine.getJumping().finished(1000L)) {
            float f;
            float fromYaw = RageBot.TARGET_YAW;
            int age = AntiAim.mc.field_1724.field_6012;
            float f2 = this.statich.isSelected() ? fromYaw - 180.0f : (f = (this.yaw = fromYaw - 90.0f - (float)(age % 5 == 0 ? 0 : (age % 5 == 1 ? 180 : 90))));
            if (this.freestand.isEnabled()) {
                class_243 eye = AntiAim.mc.field_1724.method_33571();
                float lfx = (float)MathUtility.cos(Math.toRadians(fromYaw));
                float lfz = (float)MathUtility.sin(Math.toRadians(fromYaw));
                float ltx = (float)(MathUtility.cos(Math.toRadians(fromYaw)) + MathUtility.cos(Math.toRadians(fromYaw + 90.0f)));
                float ltz = (float)(MathUtility.sin(Math.toRadians(fromYaw)) + MathUtility.sin(Math.toRadians(fromYaw + 90.0f)));
                float rfx = (float)MathUtility.cos(Math.toRadians(fromYaw - 180.0f));
                float rfz = (float)MathUtility.sin(Math.toRadians(fromYaw - 180.0f));
                float rtx = (float)(MathUtility.cos(Math.toRadians(fromYaw - 180.0f)) + MathUtility.cos(Math.toRadians(fromYaw + 90.0f)));
                float rtz = (float)(MathUtility.sin(Math.toRadians(fromYaw - 180.0f)) + MathUtility.sin(Math.toRadians(fromYaw + 90.0f)));
                boolean left = AntiAim.mc.field_1687.method_17742(new class_3959(eye.method_1031((double)lfx, 0.0, (double)lfz), eye.method_1031((double)ltx, 0.0, (double)ltz), class_3959.class_3960.field_23142, class_3959.class_242.field_1348, (class_1297)AntiAim.mc.field_1724)).method_17783() == class_239.class_240.field_1333;
                boolean right = AntiAim.mc.field_1687.method_17742(new class_3959(eye.method_1031((double)rfx, 0.0, (double)rfz), eye.method_1031((double)rtx, 0.0, (double)rtz), class_3959.class_3960.field_23142, class_3959.class_242.field_1348, (class_1297)AntiAim.mc.field_1724)).method_17783() == class_239.class_240.field_1333;
                boolean bl = right;
                if (left != right) {
                    this.yaw = left ? (this.statich.isSelected() ? fromYaw - 270.0f : fromYaw - 270.0f - (float)(age % 5 == 0 ? 180 : 0)) : (this.statich.isSelected() ? fromYaw - 90.0f : fromYaw - 90.0f - (float)(age % 5 == 0 ? 180 : 0));
                }
            }
            this.pitch = 90.0f;
            AntiAim.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(AntiAim.mc.field_1724.method_23317(), AntiAim.mc.field_1724.method_23318(), AntiAim.mc.field_1724.method_23321(), this.yaw, this.pitch, AntiAim.mc.field_1724.method_24828(), AntiAim.mc.field_1724.field_5976));
        }
    };
    private final EventListener<Render3DEvent> on3DRender = event -> {
        if (AntiAim.mc.field_1687 == null || AntiAim.mc.field_1724 == null || !this.antiAim.isEnabled()) {
            return;
        }
        class_4587 ms = event.getMatrices();
        class_4184 camera = AntiAim.mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        ms.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask((boolean)false);
        this.renderTransparentPlayer(ms, camera, event.getTickDelta());
        RenderSystem.depthMask((boolean)true);
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.disableDepthTest();
        ms.method_22909();
    };

    public AntiAim(CounterMine cm) {
        this.counterMine = cm;
        this.antiAim = new BooleanSetting(cm, "AntAim");
        this.mode = new ModeSetting((SettingsContainer)cm, "AA Mode", () -> !this.antiAim.isEnabled());
        this.statich = new ModeSetting.Value(this.mode, "Static");
        this.fake = new ModeSetting.Value(this.mode, "Fake");
        this.freestand = new BooleanSetting((SettingsContainer)cm, "AA FreeStand", () -> !this.antiAim.isEnabled());
    }

    public void renderTransparentPlayer(class_4587 matrices, class_4184 camera, float tickDelta) {
        if (AntiAim.mc.field_1724 == null || AntiAim.mc.field_1690.method_31044() == class_5498.field_26664) {
            return;
        }
        class_243 playerPos = AntiAim.mc.field_1724.method_19538();
        class_243 renderPos = Utils.getInterpolatedPos((class_1297)AntiAim.mc.field_1724, tickDelta);
        class_243 cameraPos = camera.method_19326();
        matrices.method_22903();
        double x = renderPos.field_1352 - cameraPos.field_1352;
        double y = renderPos.field_1351 - cameraPos.field_1351;
        double z = renderPos.field_1350 - cameraPos.field_1350;
        ColorRGBA c = Colors.ACCENT;
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor((float)(c.getRed() / 255.0f), (float)(c.getGreen() / 255.0f), (float)(c.getBlue() / 255.0f), (float)0.5f);
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        class_898 dispatcher = mc.method_1561();
        class_1007 playerRenderer = (class_1007)dispatcher.method_3953((class_1297)AntiAim.mc.field_1724);
        if (playerRenderer != null) {
            float originalYaw = AntiAim.mc.field_1724.method_36454();
            float originalPitch = AntiAim.mc.field_1724.method_36455();
            float originalHeadYaw = AntiAim.mc.field_1724.field_6241;
            float originalBodyYaw = AntiAim.mc.field_1724.field_6283;
            float originalPrevYaw = AntiAim.mc.field_1724.field_5982;
            float originalPrevPitch = AntiAim.mc.field_1724.field_6004;
            float originalPrevHeadYaw = AntiAim.mc.field_1724.field_6259;
            float originalPrevBodyYaw = AntiAim.mc.field_1724.field_6220;
            AntiAim.mc.field_1724.method_36456(this.yaw);
            AntiAim.mc.field_1724.method_36457(this.pitch);
            AntiAim.mc.field_1724.field_6241 = this.yaw;
            AntiAim.mc.field_1724.field_6283 = this.yaw;
            AntiAim.mc.field_1724.field_5982 = this.yaw;
            AntiAim.mc.field_1724.field_6004 = this.pitch;
            AntiAim.mc.field_1724.field_6259 = this.yaw;
            AntiAim.mc.field_1724.field_6220 = this.yaw;
            FORCE = true;
            try {
                dispatcher.method_3954((class_1297)AntiAim.mc.field_1724, x, y, z, tickDelta, matrices, (class_4597)mc.method_22940().method_23000(), 0xF000F0, (class_897)playerRenderer);
                mc.method_22940().method_23000().method_22993();
            }
            catch (Exception exception) {
                // empty catch block
            }
            FORCE = false;
            AntiAim.mc.field_1724.method_36456(originalYaw);
            AntiAim.mc.field_1724.method_36457(originalPitch);
            AntiAim.mc.field_1724.field_6241 = originalHeadYaw;
            AntiAim.mc.field_1724.field_6283 = originalBodyYaw;
            AntiAim.mc.field_1724.field_5982 = originalPrevYaw;
            AntiAim.mc.field_1724.field_6004 = originalPrevPitch;
            AntiAim.mc.field_1724.field_6259 = originalPrevHeadYaw;
            AntiAim.mc.field_1724.field_6220 = originalPrevBodyYaw;
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.disableBlend();
        matrices.method_22909();
    }

    public BooleanSetting getAntiAim() {
        return this.antiAim;
    }

    public BooleanSetting getFreestand() {
        return this.freestand;
    }
}

