/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1304$class_1305
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_243
 *  net.minecraft.class_2487
 *  net.minecraft.class_2520
 *  net.minecraft.class_2561
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3298
 *  net.minecraft.class_3300
 *  net.minecraft.class_5250
 *  net.minecraft.class_634
 *  net.minecraft.class_638
 *  net.minecraft.class_640
 *  net.minecraft.class_7225$class_7874
 *  net.minecraft.class_8113$class_8123
 *  net.minecraft.class_8828
 */
package micronix.experiment.utility.game.countermine;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.stream.Collectors;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.rotations.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5250;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_640;
import net.minecraft.class_7225;
import net.minecraft.class_8113;
import net.minecraft.class_8828;

@Environment(value=EnvType.CLIENT)
public final class CMUtility
implements IMinecraft {
    public static class_2561 removeTextFromComponent(class_2561 original, String textToRemove) {
        if (original instanceof class_5250) {
            class_5250 mutableText = (class_5250)original;
            return CMUtility.removeTextFromMutableText(mutableText.method_27661(), textToRemove);
        }
        return CMUtility.removeTextFromMutableText(original.method_27661(), textToRemove);
    }

    private static class_5250 removeTextFromMutableText(class_5250 text, String textToRemove) {
        class_8828 literalContent;
        String content;
        if (text instanceof class_8828 && (content = (literalContent = (class_8828)text).comp_737()).contains(textToRemove)) {
            String cleanedContent = content.replace(textToRemove, "");
            class_5250 newText = class_2561.method_43470((String)cleanedContent);
            newText.method_10862(text.method_10866());
            for (class_2561 sibling : text.method_10855()) {
                newText.method_10852(CMUtility.removeTextFromComponent(sibling, textToRemove));
            }
            return newText;
        }
        class_5250 result = class_2561.method_43473().method_10862(text.method_10866());
        result.method_10852((class_2561)text.method_27661());
        ArrayList<class_2561> cleanedSiblings = new ArrayList<class_2561>();
        for (class_2561 sibling : text.method_10855()) {
            class_2561 cleanedSibling = CMUtility.removeTextFromComponent(sibling, textToRemove);
            if (cleanedSibling.getString().isEmpty()) continue;
            cleanedSiblings.add(cleanedSibling);
        }
        class_5250 finalText = class_2561.method_43473().method_10862(text.method_10866());
        String mainContent = CMUtility.getMainContent((class_2561)text);
        if (!mainContent.isEmpty() && !(mainContent = mainContent.replace(textToRemove, "")).isEmpty()) {
            finalText.method_10852((class_2561)class_2561.method_43470((String)mainContent).method_10862(text.method_10866()));
        }
        for (class_2561 sibling : cleanedSiblings) {
            finalText.method_10852(sibling);
        }
        return finalText;
    }

    private static String getMainContent(class_2561 text) {
        if (text instanceof class_8828) {
            class_8828 literalContent = (class_8828)text;
            return literalContent.comp_737();
        }
        return "";
    }

    public static void removeAllArmor() {
        for (class_1297 entity : CMUtility.mc.field_1687.method_18456()) {
            if (!(entity instanceof class_1657)) continue;
            class_1657 livingEntity = (class_1657)entity;
            CMUtility.removeArmorFromEntity(livingEntity);
        }
    }

    private static void removeArmorFromPlayer(class_1657 player) {
        for (class_1304 slot : class_1304.values()) {
            class_1799 currentItem;
            if (slot.method_5925() != class_1304.class_1305.field_6178 && slot != class_1304.field_6173 && slot != class_1304.field_6171 || (currentItem = player.method_6118(slot)).method_7960()) continue;
            player.method_31548().method_7394(currentItem.method_7972());
            player.method_5673(slot, class_1799.field_8037);
        }
    }

    private static void removeArmorFromEntity(class_1657 entity) {
        for (class_1304 slot : class_1304.values()) {
            class_1799 currentArmor;
            if (slot.method_5925() != class_1304.class_1305.field_6178 || (currentArmor = entity.method_6118(slot)).method_7960()) continue;
            entity.method_31548().method_7394(currentArmor.method_7972());
            entity.method_5673(slot, class_1799.field_8037);
        }
    }

    public static boolean isPlayerOnline(String playerName) {
        class_310 client = class_310.method_1551();
        class_634 networkHandler = client.method_1562();
        if (networkHandler == null) {
            return false;
        }
        for (class_640 entry : networkHandler.method_2880()) {
            if (!entry.method_2966().getName().equals(playerName)) continue;
            return true;
        }
        return false;
    }

    public static String findHashedModel(String hashedId) {
        String string;
        block9: {
            class_2960 modelPath;
            class_3300 resourceManager = mc.method_1478();
            Optional resource = resourceManager.method_14486(modelPath = class_2960.method_60655((String)"minecraft", (String)("models/item/" + hashedId.replace("minecraft:", "") + ".json")));
            if (!resource.isPresent()) {
                return null;
            }
            BufferedReader reader = ((class_3298)resource.get()).method_43039();
            try {
                string = reader.lines().collect(Collectors.joining("\n"));
                if (reader == null) break block9;
            }
            catch (Throwable throwable) {
                try {
                    if (reader != null) {
                        try {
                            reader.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException e) {
                    System.err.println("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u0438\u0438 \u0441\u0435\u0440\u0432\u0435\u0440\u043d\u043e\u0439 \u043c\u043e\u0434\u0435\u043b\u0438: " + e.getMessage());
                    return null;
                }
            }
            reader.close();
        }
        return string;
    }

    public static String getModelIdFromNbt(class_1799 itemStack, class_7225.class_7874 registryManager) {
        class_2487 components;
        class_2487 compound;
        class_2520 nbt = itemStack.method_57375(registryManager);
        if (nbt instanceof class_2487 && (compound = (class_2487)nbt).method_10573("components", 10) && (components = compound.method_10562("components")).method_10573("minecraft:item_model", 8)) {
            return components.method_10558("minecraft:item_model");
        }
        return null;
    }

    public static boolean isHologramNearby(class_1297 entity, class_638 world, double searchRadius) {
        for (class_1297 nearbyEntity : world.method_18112()) {
            class_8113.class_8123 textDisplay;
            if (!(nearbyEntity instanceof class_8113.class_8123) || (textDisplay = (class_8113.class_8123)nearbyEntity).method_48915() == null || textDisplay.method_48915().getString().isEmpty() || !((double)entity.method_5739((class_1297)textDisplay) < searchRadius)) continue;
            return true;
        }
        return false;
    }

    public static Rotation calculateRotation(class_243 targetPos) {
        class_243 eyes = CMUtility.mc.field_1724.method_33571();
        double dx = targetPos.field_1352 - eyes.field_1352;
        double dy = targetPos.field_1351 - eyes.field_1351;
        double dz = targetPos.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return new Rotation(yaw, pitch);
    }

    private CMUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

