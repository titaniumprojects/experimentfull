/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 */
package micronix.experiment.utility.game.countermine;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;

@Environment(value=EnvType.CLIENT)
public class Point {
    class_1297 entity;
    boolean target;
    boolean isFriend;
    class_243 pos;

    public class_1297 getEntity() {
        return this.entity;
    }

    public boolean isTarget() {
        return this.target;
    }

    public boolean isFriend() {
        return this.isFriend;
    }

    public class_243 getPos() {
        return this.pos;
    }

    public Point(class_1297 entity, boolean target, boolean isFriend, class_243 pos) {
        this.entity = entity;
        this.target = target;
        this.isFriend = isFriend;
        this.pos = pos;
    }
}

