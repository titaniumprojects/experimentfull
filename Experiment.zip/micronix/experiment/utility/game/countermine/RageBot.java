/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2830
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 */
package micronix.experiment.utility.game.countermine;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.InputEvent;
import micronix.experiment.systems.modules.modules.other.CounterMine;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.target.TargetComparators;
import micronix.experiment.systems.target.TargetSettings;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.animation.types.RotationAnimation;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.countermine.CMUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.rotations.RotationPriority;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2846;

@Environment(value=EnvType.CLIENT)
public class RageBot
implements IMinecraft {
    public static float TARGET_YAW;
    private BooleanSetting aim;
    private BooleanSetting rage;
    private BooleanSetting silent;
    private BooleanSetting autoShoot;
    private BooleanSetting autoStop;
    private SliderSetting shootDelay;
    private boolean stopping;
    private int stopTicks = -1;
    private final Timer shootingTimer = new Timer();
    private final RotationAnimation anim = new RotationAnimation(100L, 100L, Easing.BAKEK);
    private CounterMine counterMine;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        this.stopping = false;
        int n = this.stopTicks = Math.abs(EntityUtility.getVelocity()) <= (double)0.1f ? (this.stopTicks = this.stopTicks + 1) : 0;
        if (!this.aim.isEnabled()) {
            return;
        }
        TARGET_YAW = RageBot.mc.field_1724.method_36454();
        TargetSettings settings = new TargetSettings.Builder().targetPlayers(true).requiredRange(200.0f).sortBy(TargetComparators.FOV).build();
        Experiment.getInstance().getTargetManager().update(settings);
        class_1297 targetEntity = Experiment.getInstance().getTargetManager().getCurrentTarget();
        if (targetEntity == null) {
            return;
        }
        class_243 pos = targetEntity.method_19538().method_1031(0.0, (double)0.2f, 0.0);
        Rotation toTarget = CMUtility.calculateRotation(pos);
        float yaw = toTarget.getYaw();
        float pitch = toTarget.getPitch();
        float deltaYaw = RotationMath.getAngleDifference(yaw, RageBot.mc.field_1724.method_36454());
        if (!this.rage.isEnabled() && deltaYaw > 145.0f) {
            return;
        }
        if (this.rage.isEnabled()) {
            if (this.silent.isEnabled()) {
                Experiment.getInstance().getRotationHandler().rotate(toTarget, MoveCorrection.NONE, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
            } else {
                RageBot.mc.field_1724.method_36456(yaw);
                RageBot.mc.field_1724.method_36457(pitch);
                RageBot.mc.field_1724.method_5847(yaw);
            }
        } else if (this.silent.isEnabled()) {
            if (!this.counterMine.getAntiAim().getAntiAim().isEnabled() && this.counterMine.getJumping().finished(1000L)) {
                RageBot.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(RageBot.mc.field_1724.method_23317(), RageBot.mc.field_1724.method_23318(), RageBot.mc.field_1724.method_23321(), RageBot.mc.field_1724.method_36454(), RageBot.mc.field_1724.method_36455(), RageBot.mc.field_1724.method_24828(), RageBot.mc.field_1724.method_24828()));
            }
            Experiment.getInstance().getRotationHandler().rotate(new Rotation(yaw, pitch), MoveCorrection.NONE, 180.0f, 180.0f, 180.0f, RotationPriority.TO_TARGET);
        } else {
            this.anim.setRotation(new Rotation(yaw, pitch));
            RageBot.mc.field_1724.method_36456(this.anim.getRotation().getYaw());
            RageBot.mc.field_1724.method_36457(this.anim.getRotation().getPitch());
            RageBot.mc.field_1724.method_5847(this.anim.getRotation().getYaw());
        }
        TARGET_YAW = yaw;
        if (!this.autoShoot.isEnabled() || (this.rage.isEnabled() ? !MathUtility.canShoot(pos) : !MathUtility.canSeen(pos)) || !this.shootingTimer.finished((long)this.shootDelay.getCurrentValue())) {
            return;
        }
        if (this.autoStop.isEnabled() && this.stopTicks <= 0) {
            this.stop();
            return;
        }
        if (RageBot.mc.field_1724.method_24828() || Math.abs(RageBot.mc.field_1724.method_18798().field_1351) < (double)0.05f) {
            this.shot();
            this.stop();
        }
    };
    private final EventListener<InputEvent> onMove = event -> {
        if (this.stopping) {
            event.setForward(0.0f);
            event.setStrafe(0.0f);
        }
    };

    public RageBot(CounterMine cm) {
        this.counterMine = cm;
        this.aim = new BooleanSetting(cm, "Aim");
        this.rage = new BooleanSetting((SettingsContainer)cm, "Rage", () -> !this.aim.isEnabled());
        this.silent = new BooleanSetting((SettingsContainer)cm, "Silent", () -> !this.aim.isEnabled());
        this.autoShoot = new BooleanSetting((SettingsContainer)cm, "AutoShoot", () -> !this.aim.isEnabled());
        this.autoStop = new BooleanSetting((SettingsContainer)cm, "AutoStop", () -> !this.aim.isEnabled() || !this.autoShoot.isEnabled());
        this.shootDelay = new SliderSetting(cm, "Shoot Delay").min(0.0f).max(2000.0f).step(50.0f).currentValue(1000.0f).suffix(number -> " ms");
    }

    private void shot() {
        RageBot.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, class_2338.field_10980, class_2350.field_11033));
        RageBot.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12971, class_2338.field_10980, class_2350.field_11033));
        this.shootingTimer.reset();
    }

    private void stop() {
        EntityUtility.setSpeed(0.0);
        this.stopping = true;
    }
}

