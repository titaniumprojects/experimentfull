/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 */
package micronix.experiment.utility.game.countermine;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.game.WorldChangeEvent;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.systems.modules.modules.other.CounterMine;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2596;

@Environment(value=EnvType.CLIENT)
public class BackTrack
implements IMinecraft {
    private final BooleanSetting backTrack;
    private final SliderSetting ticks;
    private final List<class_2596<?>> packets = new ArrayList();
    private final Timer timer = new Timer();
    private class_243 lastPos;
    private boolean replaying;
    private boolean unFreeze;
    private final EventListener<SendPacketEvent> sendListener = this::savePacket;
    private final EventListener<WorldChangeEvent> world = e -> {};

    public BackTrack(CounterMine cm) {
        this.backTrack = new BooleanSetting(cm, "BackTrack");
        this.ticks = new SliderSetting(cm, "BackTrack").min(0.0f).max(2000.0f).step(50.0f).currentValue(1000.0f).suffix(number -> " ms");
    }

    public void savePacket(SendPacketEvent e) {
        if (this.replaying || !EntityUtility.isInGame() || !this.backTrack.isEnabled()) {
            return;
        }
        System.out.println(e.getPacket());
        this.packets.add(e.getPacket());
        e.cancel();
        if (this.timer.finished((long)this.ticks.getCurrentValue())) {
            this.unFreeze = true;
            this.disable();
            this.enable();
            this.timer.reset();
        }
    }

    public void enable() {
        if (BackTrack.mc.field_1724 == null) {
            return;
        }
        this.packets.clear();
        this.lastPos = BackTrack.mc.field_1724.method_19538();
        this.timer.reset();
        this.replaying = false;
    }

    public void disable() {
        if (BackTrack.mc.field_1724 == null) {
            return;
        }
        this.replaying = true;
        for (class_2596<?> p : this.packets) {
            BackTrack.mc.field_1724.field_3944.method_52787(p);
        }
        this.replaying = false;
        this.packets.clear();
        this.lastPos = null;
    }

    public BooleanSetting getBackTrack() {
        return this.backTrack;
    }

    public boolean isUnFreeze() {
        return this.unFreeze;
    }

    public void setUnFreeze(boolean unFreeze) {
        this.unFreeze = unFreeze;
    }
}

