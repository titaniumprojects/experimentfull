/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2487
 *  net.minecraft.class_2499
 *  net.minecraft.class_7225$class_7874
 *  net.minecraft.class_8113$class_8122
 *  org.joml.Vector3f
 */
package micronix.experiment.utility.game.countermine;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.modules.other.CounterMine;
import micronix.experiment.utility.game.countermine.CMUtility;
import micronix.experiment.utility.game.countermine.Point;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.MathUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_7225;
import net.minecraft.class_8113;
import org.joml.Vector3f;

@Environment(value=EnvType.CLIENT)
public class PositionScanner
implements IMinecraft {
    private final List<Point> points = new ArrayList<Point>();
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        CounterMine cm = Experiment.getInstance().getModuleManager().getModule(CounterMine.class);
        this.points.clear();
        for (class_1297 entity : PositionScanner.mc.field_1687.method_18112()) {
            String modelJson;
            class_8113.class_8122 itemDisplay;
            String modelId;
            class_238 boundingBox = entity.method_5829();
            if (boundingBox.field_1320 != boundingBox.field_1323 || PositionScanner.mc.field_1724.method_5739(entity) < 2.0f || !entity.method_5477().getString().contains("\u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430")) continue;
            boolean hologramNearby = CMUtility.isHologramNearby(entity, PositionScanner.mc.field_1687, 2.5);
            if (!(entity instanceof class_8113.class_8122) || (modelId = CMUtility.getModelIdFromNbt((itemDisplay = (class_8113.class_8122)entity).method_48900(), (class_7225.class_7874)PositionScanner.mc.field_1724.method_56673())) == null || (modelJson = CMUtility.findHashedModel(modelId)) == null) continue;
            boolean sex = false;
            if (!modelJson.contains("{\"elements\":[{\"from\":[7.765625,8.0,7.765625]") && !modelJson.contains("{\"elements\":[{\"from\":[7.765625,8.0,7.8828125]") && !modelJson.contains("{\"elements\":[{\"from\":[7.9375,7.796875,7.875]") && !modelJson.contains("{\"elements\":[{\"from\":[7.921875,7.7421875,7.8828125]") && !modelJson.contains("{\"elements\":[{\"from\":[7.8828125,7.6484375,7.8828125]") && !modelJson.contains("{\"elements\":[{\"from\":[7.9003906,7.9003906,7.8691406]") && !modelJson.contains("{\"elements\":[{\"from\":[7.90625,7.7421875,7.8828125]") && !modelJson.contains("{\"elements\":[{\"from\":[7.9453125,7.6484375,7.8828125]") && !modelJson.contains("{\"elements\":[{\"from\":[7.8984375,7.8984375,7.8671875]")) continue;
            boolean dead = false;
            if (false) continue;
            if (modelJson.contains("{\"elements\":[{\"from\":[7.765625,8.0,7.765625]")) {
                class_2487 nbt = new class_2487();
                entity.method_5647(nbt);
                if (nbt.method_10545("transformation")) {
                    class_2487 transformation = nbt.method_10562("transformation");
                    if (transformation.method_10545("left_rotation")) {
                        class_2499 rotation = transformation.method_10554("left_rotation", 5);
                        float x = rotation.method_10604(0);
                        float y = rotation.method_10604(1);
                        float z = rotation.method_10604(2);
                        float w = rotation.method_10604(3);
                        class_243 tiltedPos = this.calculateTiltedPoint(entity.method_19538(), x, y, z, w, 0.25f);
                        if (Experiment.getInstance().getModuleManager().getModule(CounterMine.class).isMinDamage()) {
                            this.points.add(new Point(entity, x > -0.04f, hologramNearby, entity.method_19538().method_1031(0.0, (double)-0.4f, 0.0)));
                            continue;
                        }
                        this.points.add(new Point(entity, x > -0.04f, hologramNearby, tiltedPos));
                        continue;
                    }
                    this.points.add(new Point(entity, true, hologramNearby, entity.method_19538().method_1031(0.0, (double)0.4f, 0.0)));
                    continue;
                }
                this.points.add(new Point(entity, true, hologramNearby, entity.method_19538().method_1031(0.0, (double)0.4f, 0.0)));
                continue;
            }
            this.points.add(new Point(entity, false, hologramNearby, entity.method_19538()));
        }
    };

    public class_243 calculateTiltedPoint(class_243 entityPos, float x, float y, float z, float w, float heightOffset) {
        float norm = (float)Math.sqrt(x * x + y * y + z * z + w * w);
        if (norm > 0.0f) {
            x /= norm;
            y /= norm;
            z /= norm;
            w /= norm;
        }
        float rotationIntensity = Math.abs(x) + Math.abs(y) + Math.abs(z);
        float adjustedOffset = heightOffset * (1.0f + rotationIntensity);
        class_243 upVector = new class_243(0.0, (double)adjustedOffset, 0.0);
        class_243 rotatedVector = this.rotateVectorByQuaternion(upVector, x, y, z, w);
        return entityPos.method_1019(rotatedVector);
    }

    private class_243 rotateVectorByQuaternion(class_243 vector, float qx, float qy, float qz, float qw) {
        float norm = (float)Math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw);
        if (norm > 0.0f) {
            qx /= norm;
            qy /= norm;
            qz /= norm;
            qw /= norm;
        }
        float x = (float)vector.field_1352;
        float y = (float)vector.field_1351;
        float z = (float)vector.field_1350;
        float qx2 = qx * qx;
        float qy2 = qy * qy;
        float qz2 = qz * qz;
        float qw2 = qw * qw;
        float rotatedX = x * (qw2 + qx2 - qy2 - qz2) + 2.0f * y * (qx * qy - qw * qz) + 2.0f * z * (qx * qz + qw * qy);
        float rotatedY = 2.0f * x * (qx * qy + qw * qz) + y * (qw2 - qx2 + qy2 - qz2) + 2.0f * z * (qy * qz - qw * qx);
        float rotatedZ = 2.0f * x * (qx * qz - qw * qy) + 2.0f * y * (qy * qz + qw * qx) + z * (qw2 - qx2 - qy2 + qz2);
        return new class_243((double)rotatedX, (double)rotatedY, (double)rotatedZ);
    }

    public Vector3f quaternionToEuler(float x, float y, float z, float w) {
        float norm = (float)Math.sqrt(x * x + y * y + z * z + w * w);
        float yaw = (float)Math.atan2(2.0f * ((w /= norm) * (y /= norm) + (x /= norm) * (z /= norm)), 1.0f - 2.0f * (y * y + z * z));
        float pitch = (float)Math.asin(Math.max(-1.0f, Math.min(1.0f, 2.0f * (w * x - y * z))));
        float roll = (float)Math.atan2(2.0f * (w * z + x * y), 1.0f - 2.0f * (x * x + z * z));
        return new Vector3f((float)Math.toDegrees(pitch), (float)Math.toDegrees(yaw), (float)Math.toDegrees(roll));
    }

    public class_243 calculateTiltedPoint(class_243 entityPos, Vector3f eulerAngles, float heightOffset) {
        float pitch = (float)Math.toRadians(eulerAngles.x);
        float yaw = (float)Math.toRadians(eulerAngles.y);
        float roll = (float)Math.toRadians(eulerAngles.z);
        double dx = -MathUtility.sin(yaw) * MathUtility.cos(pitch) * (double)heightOffset;
        double dy = MathUtility.sin(pitch) * (double)heightOffset;
        double dz = MathUtility.cos(yaw) * MathUtility.cos(pitch) * (double)heightOffset;
        return new class_243(entityPos.field_1352 + dx, entityPos.field_1351 + dy, entityPos.field_1350 + dz);
    }

    public List<Point> getPoints() {
        return this.points;
    }
}

