/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1297$class_5529
 *  net.minecraft.class_638
 *  net.minecraft.class_745
 */
package micronix.experiment.utility.game;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_638;
import net.minecraft.class_745;

@Environment(value=EnvType.CLIENT)
public class FakePlayerEntity
extends class_745 {
    public FakePlayerEntity(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    public void spawn() {
        this.method_31482();
        this.field_17892.method_53875((class_1297)this);
    }

    public void remove() {
        this.field_17892.method_2945(this.method_5628(), class_1297.class_5529.field_26999);
        this.method_36209();
    }

    public void method_6005(double strength, double x, double z) {
    }
}

