/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_5250
 *  net.minecraft.class_5251
 */
package micronix.experiment.utility.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

@Environment(value=EnvType.CLIENT)
public final class LegacyTextHelper {
    private static final char LEGACY_PREFIX_SECTION = '\u00a7';
    private static final char LEGACY_PREFIX_AMP = '&';
    private static final char LEGACY_PREFIX_DOLLAR = '$';

    public static class_2561 resolve(class_2561 text, int defaultColor) {
        if (text == null) {
            return class_2561.method_43473();
        }
        int baseColor = defaultColor & 0xFFFFFF;
        String raw = LegacyTextHelper.extractRaw(text);
        if (LegacyTextHelper.containsLegacyCodes(raw)) {
            return LegacyTextHelper.parse(raw, baseColor);
        }
        if (LegacyTextHelper.hasExplicitColor(text)) {
            return text;
        }
        return LegacyTextHelper.applyDefaultColor(text, baseColor);
    }

    public static List<ColoredSegment> parseSegments(String input, int defaultColor) {
        int currentColor;
        ArrayList<ColoredSegment> segments = new ArrayList<ColoredSegment>();
        if (input == null || input.isEmpty()) {
            return segments;
        }
        StringBuilder buffer = new StringBuilder();
        int baseColor = currentColor = 0xFF000000 | defaultColor & 0xFFFFFF;
        int length = input.length();
        for (int i = 0; i < length; ++i) {
            char c = input.charAt(i);
            if (c == '<' || c == '{') {
                char end;
                char c2 = end = c == '<' ? (char)'>' : '}';
                if (LegacyTextHelper.isWrappedHexSequence(input, i, end)) {
                    LegacyTextHelper.flushSegment(buffer, segments, currentColor);
                    int rgb = LegacyTextHelper.parseHexColorPlain(input, i + 2);
                    currentColor = 0xFF000000 | rgb;
                    i += 8;
                    continue;
                }
            }
            if (LegacyTextHelper.isLegacyPrefix(c) && i + 1 < length) {
                char code = Character.toLowerCase(input.charAt(i + 1));
                if (code == 'x' && LegacyTextHelper.isValidHexSequence(input, i)) {
                    LegacyTextHelper.flushSegment(buffer, segments, currentColor);
                    int rgb = LegacyTextHelper.parseHexColorLegacy(input, i);
                    currentColor = 0xFF000000 | rgb;
                    i += 13;
                    continue;
                }
                if (code == '#' && LegacyTextHelper.isHexSequence(input, i + 2, 6)) {
                    LegacyTextHelper.flushSegment(buffer, segments, currentColor);
                    int rgb = LegacyTextHelper.parseHexColorPlain(input, i + 2);
                    currentColor = 0xFF000000 | rgb;
                    i += 7;
                    continue;
                }
                class_124 formatting = class_124.method_544((char)code);
                if (formatting != null) {
                    Integer rgb;
                    LegacyTextHelper.flushSegment(buffer, segments, currentColor);
                    if (formatting == class_124.field_1070) {
                        currentColor = baseColor;
                    } else if (formatting.method_543() && (rgb = formatting.method_532()) != null) {
                        currentColor = 0xFF000000 | rgb;
                    }
                    ++i;
                    continue;
                }
            }
            buffer.append(c);
        }
        LegacyTextHelper.flushSegment(buffer, segments, currentColor);
        return segments;
    }

    public static String extractRaw(class_2561 text) {
        if (text == null) {
            return "";
        }
        StringBuilder visited = new StringBuilder();
        text.method_27658((style, string) -> {
            if (style != null && style.method_10973() != null) {
                int rgb = style.method_10973().method_27716() & 0xFFFFFF;
                String hex = Integer.toHexString(rgb);
                visited.append("&#");
                for (int i = 0; i < 6 - hex.length(); ++i) {
                    visited.append('0');
                }
                visited.append(hex);
            }
            visited.append(string);
            return Optional.empty();
        }, class_2583.field_24360);
        return visited.toString();
    }

    public static boolean containsLegacyCodes(String input) {
        if (input == null || input.length() < 2) {
            return false;
        }
        int length = input.length();
        for (int i = 0; i < length - 1; ++i) {
            char c = input.charAt(i);
            if (c == '<' || c == '{') {
                if (!LegacyTextHelper.isWrappedHexSequence(input, i, c == '<' ? (char)'>' : '}')) continue;
                return true;
            }
            if (!LegacyTextHelper.isLegacyPrefix(c)) continue;
            char code = Character.toLowerCase(input.charAt(i + 1));
            if (LegacyTextHelper.isLegacyCode(code)) {
                return true;
            }
            if (code == 'x' && LegacyTextHelper.isValidHexSequence(input, i)) {
                return true;
            }
            if (code != '#' || !LegacyTextHelper.isHexSequence(input, i + 2, 6)) continue;
            return true;
        }
        return false;
    }

    public static class_2561 parse(String input, int defaultColor) {
        if (input == null || input.isEmpty()) {
            return class_2561.method_43473();
        }
        class_5250 result = class_2561.method_43473();
        StringBuilder buffer = new StringBuilder();
        int baseColor = defaultColor & 0xFFFFFF;
        class_2583 current = class_2583.field_24360.method_27703(class_5251.method_27717((int)baseColor));
        int length = input.length();
        for (int i = 0; i < length; ++i) {
            char c = input.charAt(i);
            if (c == '<' || c == '{') {
                char end;
                char c2 = end = c == '<' ? (char)'>' : '}';
                if (LegacyTextHelper.isWrappedHexSequence(input, i, end)) {
                    LegacyTextHelper.flush(buffer, result, current);
                    int rgb = LegacyTextHelper.parseHexColorPlain(input, i + 2);
                    current = current.method_27703(class_5251.method_27717((int)rgb));
                    i += 8;
                    continue;
                }
            }
            if (LegacyTextHelper.isLegacyPrefix(c) && i + 1 < length) {
                char code = Character.toLowerCase(input.charAt(i + 1));
                if (code == 'x' && LegacyTextHelper.isValidHexSequence(input, i)) {
                    LegacyTextHelper.flush(buffer, result, current);
                    int rgb = LegacyTextHelper.parseHexColorLegacy(input, i);
                    current = current.method_27703(class_5251.method_27717((int)rgb));
                    i += 13;
                    continue;
                }
                if (code == '#' && LegacyTextHelper.isHexSequence(input, i + 2, 6)) {
                    LegacyTextHelper.flush(buffer, result, current);
                    int rgb = LegacyTextHelper.parseHexColorPlain(input, i + 2);
                    current = current.method_27703(class_5251.method_27717((int)rgb));
                    i += 7;
                    continue;
                }
                class_124 formatting = class_124.method_544((char)code);
                if (formatting != null) {
                    LegacyTextHelper.flush(buffer, result, current);
                    current = formatting == class_124.field_1070 ? class_2583.field_24360.method_27703(class_5251.method_27717((int)baseColor)) : (formatting.method_543() ? class_2583.field_24360.method_27706(formatting) : current.method_27706(formatting));
                    ++i;
                    continue;
                }
            }
            buffer.append(c);
        }
        LegacyTextHelper.flush(buffer, result, current);
        return result;
    }

    private static void flush(StringBuilder buffer, class_5250 result, class_2583 style) {
        if (buffer.length() == 0) {
            return;
        }
        result.method_10852((class_2561)class_2561.method_43470((String)buffer.toString()).method_10862(style));
        buffer.setLength(0);
    }

    private static void flushSegment(StringBuilder buffer, List<ColoredSegment> segments, int color) {
        if (buffer.length() == 0) {
            return;
        }
        segments.add(new ColoredSegment(buffer.toString(), color));
        buffer.setLength(0);
    }

    private static boolean isLegacyPrefix(char c) {
        return c == '\u00a7' || c == '&' || c == '$';
    }

    private static boolean isLegacyCode(char code) {
        return code >= '0' && code <= '9' || code >= 'a' && code <= 'f' || code == 'k' || code == 'l' || code == 'm' || code == 'n' || code == 'o' || code == 'r';
    }

    private static boolean isValidHexSequence(String input, int startIndex) {
        int length = input.length();
        if (startIndex + 13 >= length) {
            return false;
        }
        for (int i = 0; i < 6; ++i) {
            int base = startIndex + 2 + i * 2;
            char prefix = input.charAt(base);
            char hex = input.charAt(base + 1);
            if (LegacyTextHelper.isLegacyPrefix(prefix) && LegacyTextHelper.isHexDigit(hex)) continue;
            return false;
        }
        return true;
    }

    private static int parseHexColorLegacy(String input, int startIndex) {
        StringBuilder hex = new StringBuilder(6);
        for (int i = 0; i < 6; ++i) {
            int base = startIndex + 2 + i * 2;
            hex.append(input.charAt(base + 1));
        }
        return Integer.parseInt(hex.toString(), 16);
    }

    private static int parseHexColorPlain(String input, int startIndex) {
        return Integer.parseInt(input.substring(startIndex, startIndex + 6), 16);
    }

    private static boolean isHexDigit(char c) {
        return c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F';
    }

    private static boolean isHexSequence(String input, int start, int length) {
        if (start < 0 || start + length > input.length()) {
            return false;
        }
        for (int i = 0; i < length; ++i) {
            if (LegacyTextHelper.isHexDigit(input.charAt(start + i))) continue;
            return false;
        }
        return true;
    }

    private static boolean isWrappedHexSequence(String input, int startIndex, char endChar) {
        if (startIndex + 8 >= input.length()) {
            return false;
        }
        if (input.charAt(startIndex + 1) != '#') {
            return false;
        }
        if (!LegacyTextHelper.isHexSequence(input, startIndex + 2, 6)) {
            return false;
        }
        return input.charAt(startIndex + 8) == endChar;
    }

    private static class_2561 applyDefaultColor(class_2561 text, int defaultColor) {
        if (LegacyTextHelper.hasExplicitColor(text)) {
            return text;
        }
        class_2583 base = class_2583.field_24360.method_27703(class_5251.method_27717((int)defaultColor));
        return class_2561.method_43470((String)"").method_10862(base).method_10852(text);
    }

    private static boolean hasExplicitColor(class_2561 text) {
        boolean[] hasColor = new boolean[]{false};
        text.method_27658((style, string) -> {
            if (style.method_10973() != null) {
                hasColor[0] = true;
                return Optional.of(true);
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return hasColor[0];
    }

    private LegacyTextHelper() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    @Environment(value=EnvType.CLIENT)
    public record ColoredSegment(String text, int color) {
    }
}

