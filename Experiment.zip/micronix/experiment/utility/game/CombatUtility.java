/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1743
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1819
 *  net.minecraft.class_1887
 *  net.minecraft.class_1893
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2868
 *  net.minecraft.class_2879
 *  net.minecraft.class_490
 *  net.minecraft.class_5321
 *  net.minecraft.class_9362
 */
package micronix.experiment.utility.game;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.modules.modules.combat.Criticals;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.inventory.EnchantmentUtility;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_490;
import net.minecraft.class_5321;
import net.minecraft.class_9362;

@Environment(value=EnvType.CLIENT)
public final class CombatUtility
implements IMinecraft {
    public static HotbarSlot getMace() {
        boolean useWindBurst = CombatUtility.mc.field_1724.field_6017 > 2.0f;
        class_5321 targetEnchantment = useWindBurst ? class_1893.field_50159 : class_1893.field_50158;
        SlotGroup<HotbarSlot> slotsToSearch = SlotGroups.hotbar();
        HotbarSlot slot = slotsToSearch.findItem(stack -> CombatUtility.hasMaceEnchantment(targetEnchantment, stack));
        if (slot == null) {
            slot = slotsToSearch.findItem(class_1802.field_49814);
        }
        return slot;
    }

    public static float getFallDistance(class_1309 target) {
        SlotGroup<HotbarSlot> slotsToSearch;
        HotbarSlot slot;
        if (CombatUtility.mc.field_1724.method_6047().method_7909() instanceof class_9362) {
            // empty if block
        }
        if ((slot = (slotsToSearch = SlotGroups.hotbar()).findItem(class_1802.field_49814)) != null) {
            return 0.7f;
        }
        return ServerUtility.isFS() || ServerUtility.isST() ? (Experiment.getInstance().getModuleManager().getModule(Aura.class).getAttacks() % 10 == 0 ? 0.4f : (Experiment.getInstance().getModuleManager().getModule(Aura.class).getAttacks() % 5 == 0 ? 0.2f : 0.0f)) : 0.0f;
    }

    public static boolean canPerformCriticalHit(class_1309 target, boolean ignoreSprint) {
        if (CombatUtility.mc.field_1687 == null) {
            return false;
        }
        if (CombatUtility.mc.field_1724 == null) {
            return false;
        }
        class_2248 blockAboveHead = CombatUtility.mc.field_1687.method_8320(CombatUtility.mc.field_1724.method_24515().method_10086(2)).method_26204();
        Aura aura = Experiment.getInstance().getModuleManager().getModule(Aura.class);
        if (CombatUtility.mc.field_1724.method_6101()) {
            return true;
        }
        if (EntityUtility.getBlock(0.0, 2.0, 0.0) != class_2246.field_10124 && (Experiment.getInstance().getModuleManager().getModule(Aura.class).getAttacks() % 10 == 0 || Experiment.getInstance().getModuleManager().getModule(Aura.class).getAttacks() % 5 == 0)) {
            if (ServerUtility.isST()) {
                return true;
            }
            if (ServerUtility.isFS()) {
                return true;
            }
        }
        if (CombatUtility.mc.field_1755 instanceof class_490) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_5799() && EntityUtility.getBlock(0.0, 1.0, 0.0) == class_2246.field_10382 && CombatUtility.mc.field_1724.field_6017 <= 0.0f) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_5681()) {
            return true;
        }
        if (CombatUtility.mc.field_1687.method_8320(CombatUtility.mc.field_1724.method_24515()).method_27852(class_2246.field_10343)) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_5771()) {
            return true;
        }
        if (aura.getFastPvp().isSelected()) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_6059(class_1294.field_5919)) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_6059(class_1294.field_5902)) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_6059(class_1294.field_5906)) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_5765()) {
            return true;
        }
        if (CombatUtility.mc.field_1724.method_6047().method_7909() instanceof class_9362 ? CombatUtility.mc.field_1724.field_6017 > 1.0f : CombatUtility.mc.field_1724.field_6017 > CombatUtility.getFallDistance(target)) {
            return true;
        }
        if (ServerUtility.isST() && Experiment.getInstance().getModuleManager().getModule(Aura.class).getAttacks() % 5 == 0 && EntityUtility.getBlock(0.0, 2.0, 0.0) != class_2246.field_10124) {
            return true;
        }
        return Experiment.getInstance().getModuleManager().getModule(Criticals.class).canCritical();
    }

    public static boolean canBreakShield(class_1309 target) {
        if (CombatUtility.mc.field_1724 == null || CombatUtility.mc.field_1724.method_29504()) {
            return false;
        }
        if (target.method_29504()) {
            return false;
        }
        HotbarSlot axeSlot = SlotGroups.hotbar().findItem(itemStack -> itemStack.method_7909() instanceof class_1743);
        if (axeSlot == null) {
            return false;
        }
        class_243 facingVector = target.method_5720();
        class_243 deltaPos = new class_243(target.method_19538().method_10216() - CombatUtility.mc.field_1724.method_19538().method_10216(), 0.0, target.method_19538().method_10215() - CombatUtility.mc.field_1724.method_19538().method_10215());
        return deltaPos.method_1026(facingVector) < 0.0;
    }

    public static boolean shouldBreakShield(class_1309 target) {
        return target.method_6115() && target.method_6030().method_7909() instanceof class_1819;
    }

    public static void tryBreakShield(class_1309 target) {
        if (CombatUtility.mc.field_1724 == null || CombatUtility.mc.field_1761 == null) {
            return;
        }
        SlotGroup<HotbarSlot> slotsToSearch = SlotGroups.hotbar();
        HotbarSlot slot = slotsToSearch.findItem(item -> item.method_7909() instanceof class_1743);
        if (slot != null && target instanceof class_1657 && target.method_6115() && target.method_6030().method_7909() instanceof class_1819) {
            CombatUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
            CombatUtility.mc.field_1761.method_2918((class_1657)CombatUtility.mc.field_1724, (class_1297)target);
            CombatUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
            CombatUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(CombatUtility.mc.field_1724.method_31548().field_7545));
        }
    }

    public static boolean stalin(class_1309 target) {
        class_243 pos = target.method_19538();
        class_238 hitbox = target.method_5829();
        float off = 0.05f;
        return !CombatUtility.isAir(hitbox.field_1323 - (double)off, pos.field_1351, hitbox.field_1321 - (double)off) || !CombatUtility.isAir(hitbox.field_1320 + (double)off, pos.field_1351, hitbox.field_1321 - (double)off) || !CombatUtility.isAir(hitbox.field_1323 - (double)off, pos.field_1351, hitbox.field_1324 + (double)off) || !CombatUtility.isAir(hitbox.field_1320 + (double)off, pos.field_1351, hitbox.field_1324 + (double)off);
    }

    private static boolean isAir(double x, double y, double z) {
        return CombatUtility.mc.field_1687.method_8320(new class_2338((int)x, (int)y, (int)z)).method_26204() == class_2246.field_10124;
    }

    private CombatUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    private static boolean hasMaceEnchantment(class_5321 targetEnchantment, class_1799 stack) {
        if (!(stack.method_7909() instanceof class_9362)) {
            return false;
        }
        return EnchantmentUtility.getEnchantmentLevel(stack, (class_5321<class_1887>)targetEnchantment) > 0;
    }
}

