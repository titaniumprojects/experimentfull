/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 */
package micronix.experiment.utility.game;

import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2583;

@Environment(value=EnvType.CLIENT)
public final class MessageUtility
implements IMinecraft {
    private static final class_2561 PREFIX = (class_2561)class_2561.method_30163((String)"[%s]".formatted("Experiment")).method_27661().method_36136(class_2583.field_24360.method_36139(new ColorRGBA(140.0f, 80.0f, 255.0f).getRGB())).getFirst();

    public static void overlay(LogLevel logLevel, class_2561 message) {
        MessageUtility.log(logLevel, message, true);
    }

    public static void info(class_2561 message) {
        if (MessageUtility.mc.field_1724 == null) {
            return;
        }
        MessageUtility.log(LogLevel.INFO, message, false);
    }

    public static void warn(class_2561 message) {
        MessageUtility.log(LogLevel.WARN, message, false);
    }

    public static void error(class_2561 message) {
        MessageUtility.log(LogLevel.ERROR, message, false);
    }

    private static void log(LogLevel level, class_2561 message, boolean overlay) {
        if (MessageUtility.mc.field_1724 == null) {
            return;
        }
        class_2561 styledMessage = (class_2561)message.method_27661().method_36136(class_2583.field_24360.method_36139(level.getColor().getRGB())).getFirst();
        MessageUtility.mc.field_1724.method_7353((class_2561)PREFIX.method_27661().method_27693(" ").method_10852(styledMessage), overlay);
    }

    private MessageUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    @Environment(value=EnvType.CLIENT)
    public static enum LogLevel {
        WARN("Warning", new ColorRGBA(247.0f, 206.0f, 59.0f)),
        ERROR("Error", new ColorRGBA(242.0f, 79.0f, 68.0f)),
        INFO("Info", new ColorRGBA(87.0f, 126.0f, 255.0f));

        private final String level;
        private final ColorRGBA color;

        public String getLevel() {
            return this.level;
        }

        public ColorRGBA getColor() {
            return this.color;
        }

        private LogLevel(String level, ColorRGBA color) {
            this.level = level;
            this.color = color;
        }
    }
}

