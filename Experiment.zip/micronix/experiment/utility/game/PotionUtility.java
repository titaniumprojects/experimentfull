/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1291
 *  net.minecraft.class_1293
 *  net.minecraft.class_1799
 *  net.minecraft.class_1812
 *  net.minecraft.class_1844
 *  net.minecraft.class_6880
 *  net.minecraft.class_9334
 */
package micronix.experiment.utility.game;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

@Environment(value=EnvType.CLIENT)
public final class PotionUtility {
    public static boolean hasEffect(class_1799 stack, class_6880<class_1291> effectType) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (!(stack.method_7909() instanceof class_1812)) {
            return false;
        }
        class_1844 potionContents = (class_1844)stack.method_57824(class_9334.field_49651);
        if (potionContents == null) {
            return false;
        }
        for (class_1293 effect : potionContents.method_57397()) {
            if (effect.method_5579() != effectType) continue;
            return true;
        }
        return false;
    }

    public static List<class_1293> effects(class_1799 stack) {
        ArrayList<class_1293> effects = new ArrayList<class_1293>();
        if (stack == null || stack.method_7960()) {
            return effects;
        }
        if (!(stack.method_7909() instanceof class_1812)) {
            return effects;
        }
        class_1844 potionContents = (class_1844)stack.method_57824(class_9334.field_49651);
        if (potionContents == null) {
            return effects;
        }
        potionContents.method_57397().forEach(effects::add);
        return effects;
    }

    private PotionUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

