/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2761
 *  net.minecraft.class_3532
 */
package micronix.experiment.utility.game.server;

import java.util.Arrays;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2761;
import net.minecraft.class_3532;

@Environment(value=EnvType.CLIENT)
public class TPSHandler {
    private final float[] tickRates = new float[20];
    private int nextIndex = 0;
    private long timeLastTimeUpdate = -1L;
    private final EventListener<ReceivePacketEvent> onReceivePacket = event -> {
        if (!(event.getPacket() instanceof class_2761)) {
            return;
        }
        if (this.timeLastTimeUpdate != -1L) {
            float timeElapsed = (float)(System.nanoTime() - this.timeLastTimeUpdate) / 1.0E9f;
            this.tickRates[this.nextIndex % this.tickRates.length] = class_3532.method_15363((float)(20.0f / timeElapsed), (float)0.0f, (float)20.0f);
            ++this.nextIndex;
        }
        this.timeLastTimeUpdate = System.nanoTime();
    };

    public TPSHandler() {
        Arrays.fill(this.tickRates, 0.0f);
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    public float getTPS() {
        float numTicks = 0.0f;
        float sumTickRates = 0.0f;
        for (float tickRate : this.tickRates) {
            if (!(tickRate > 0.0f)) continue;
            sumTickRates += tickRate;
            numTicks += 1.0f;
        }
        return class_3532.method_15363((float)(sumTickRates / numTicks), (float)0.0f, (float)20.0f);
    }
}

