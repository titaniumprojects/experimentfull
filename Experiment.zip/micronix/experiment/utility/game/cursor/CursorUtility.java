/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.game.cursor;

import micronix.experiment.utility.game.cursor.CursorType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class CursorUtility {
    private static CursorType currentType = CursorType.DEFAULT;
    private static CursorType prev = CursorType.HAND;

    public static void set(CursorType type) {
        currentType = type;
    }

    private CursorUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static CursorType getCurrentType() {
        return currentType;
    }

    public static CursorType getPrev() {
        return prev;
    }

    public static void setPrev(CursorType prev) {
        CursorUtility.prev = prev;
    }
}

