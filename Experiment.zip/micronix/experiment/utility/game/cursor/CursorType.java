/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  org.lwjgl.glfw.GLFW
 */
package micronix.experiment.utility.game.cursor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.glfw.GLFW;

@Environment(value=EnvType.CLIENT)
public enum CursorType {
    DEFAULT(GLFW.glfwCreateStandardCursor((int)221185)),
    HAND(GLFW.glfwCreateStandardCursor((int)221188)),
    ARROW_HORIZONTAL(GLFW.glfwCreateStandardCursor((int)221189)),
    ARROW_VERTICAL(GLFW.glfwCreateStandardCursor((int)221190)),
    TEXT(GLFW.glfwCreateStandardCursor((int)221186)),
    CROSSHAIR(GLFW.glfwCreateStandardCursor((int)221187)),
    BLOCK(GLFW.glfwCreateStandardCursor((int)221194)),
    RESIZE_ALL(GLFW.glfwCreateStandardCursor((int)221193));

    private final long code;

    public long getCode() {
        return this.code;
    }

    private CursorType(long code) {
        this.code = code;
    }
}

