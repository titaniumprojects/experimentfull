/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2586
 */
package micronix.experiment.utility.game;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2586;

@Environment(value=EnvType.CLIENT)
public final class WorldUtility {
    public static List<class_2586> blockEntities = new ArrayList<class_2586>();

    private WorldUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

