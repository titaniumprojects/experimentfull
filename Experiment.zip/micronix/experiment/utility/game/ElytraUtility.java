/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1735
 *  net.minecraft.class_1738
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2868
 *  net.minecraft.class_287
 *  net.minecraft.class_2886
 *  net.minecraft.class_4587
 *  net.minecraft.class_8051
 */
package micronix.experiment.utility.game;

import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.modules.modules.combat.ElytraTarget;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.CombatUtility;
import micronix.experiment.utility.game.prediction.ElytraPredictionSystem;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.inventory.InventoryUtility;
import micronix.experiment.utility.inventory.group.SlotGroup;
import micronix.experiment.utility.inventory.group.SlotGroups;
import micronix.experiment.utility.inventory.slots.HotbarSlot;
import micronix.experiment.utility.inventory.slots.InventorySlot;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.mixins.ArmorItemAddition;
import micronix.experiment.utility.render.Draw3DUtility;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationMath;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_287;
import net.minecraft.class_2886;
import net.minecraft.class_4587;
import net.minecraft.class_8051;

@Environment(value=EnvType.CLIENT)
public final class ElytraUtility
implements IMinecraft {
    private static class_243 lastVec;
    private static final Timer fireworkTimer;

    public static void swapInHotbar(boolean chestplate) {
        SlotGroup<HotbarSlot> slotsToSearch = SlotGroups.hotbar();
        HotbarSlot slot = chestplate ? slotsToSearch.findItem(itemStack -> {
            class_1738 armorItem;
            class_1792 patt0$temp = itemStack.method_7909();
            return patt0$temp instanceof class_1738 && ((ArmorItemAddition)(armorItem = (class_1738)patt0$temp)).experiment$getType() == class_8051.field_41935;
        }) : slotsToSearch.findItem(class_1802.field_8833);
        HotbarSlot hotbarSlot = slot;
        if (slot != null) {
            HotbarSlot currentItem = InventoryUtility.getCurrentHotbarSlot();
            ElytraUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
            InventoryUtility.selectHotbarSlot(slot);
            ElytraUtility.mc.field_1761.method_2919((class_1657)ElytraUtility.mc.field_1724, class_1268.field_5808);
            ((class_1735)ElytraUtility.mc.field_1724.field_7512.field_7761.get(6)).method_53512(new class_1799((class_1935)(chestplate ? class_1802.field_22028 : class_1802.field_8833)));
            InventoryUtility.selectHotbarSlot(currentItem);
            ElytraUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(ElytraUtility.mc.field_1724.method_31548().field_7545));
        }
    }

    public static void drawBoxes(class_4587 matrices, class_287 linesBuffer, class_238 box, ColorRGBA color) {
        Draw3DUtility.renderOutlinedBox(matrices, linesBuffer, box, color);
        Draw3DUtility.renderBoxInternalDiagonals(matrices, linesBuffer, box, color);
    }

    public static boolean leaving() {
        class_1657 player;
        class_1297 entity;
        Aura aura = Experiment.getInstance().getModuleManager().getModule(Aura.class);
        return !aura.isCooledDown() && (entity = Experiment.getInstance().getTargetManager().getCurrentTarget()) instanceof class_1657 && !ElytraPredictionSystem.isLeaving(player = (class_1657)entity) || CombatUtility.getMace() != null && !aura.getAttackTimer().finished(1500L);
    }

    public static void useFirework(float selectedSlot) {
        SlotGroup<HotbarSlot> slotsToSearch = SlotGroups.hotbar();
        HotbarSlot slot = slotsToSearch.findItem(class_1802.field_8639);
        if (slot != null) {
            class_1309 target = Experiment.getInstance().getTargetManager().getLivingTarget();
            Rotation rot = target == null ? Experiment.getInstance().getRotationHandler().getPlayerRotation() : RotationMath.getRotationTo(ElytraUtility.leaving() ? ElytraUtility.mc.field_1724.method_33571().method_1019(ElytraUtility.leaveVec(target)) : ElytraUtility.targetPoint(target));
            ElytraUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(slot.getSlotId()));
            ElytraUtility.mc.field_1761.method_41931(ElytraUtility.mc.field_1687, sequence -> new class_2886(class_1268.field_5808, sequence, rot.getYaw(), rot.getPitch()));
            ElytraUtility.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(ElytraUtility.mc.field_1724.method_31548().field_7545));
            fireworkTimer.reset();
            return;
        }
        SlotGroup<InventorySlot> search = SlotGroups.inventory();
        InventorySlot invSlot = search.findItem(class_1802.field_8639);
        if (invSlot != null) {
            InventoryUtility.hotbarSwap(invSlot.getIdForServer(), (int)(selectedSlot - 1.0f));
            fireworkTimer.reset();
        }
    }

    public static class_243 targetPoint(class_1309 target) {
        class_243 vec3d;
        if (Experiment.getInstance().getModuleManager().getModule(ElytraTarget.class).isEnabled() && target instanceof class_1657) {
            class_1657 player = (class_1657)target;
            vec3d = ElytraPredictionSystem.predictPlayerPosition(player);
        } else {
            vec3d = target.method_19538();
        }
        return RotationMath.getNearestPoint(target, vec3d);
    }

    public static class_243 leaveVec(class_1309 target) {
        List<class_243> leaveVectors = List.of(new class_243(0.0, 20.0, 0.0), new class_243(0.0, -20.0, 0.0), new class_243(20.0, 0.0, 0.0), new class_243(-20.0, 0.0, 0.0), new class_243(0.0, 0.0, 20.0), new class_243(0.0, 0.0, -20.0));
        if (CombatUtility.getMace() != null) {
            leaveVectors = List.of(new class_243(0.0, 20.0, 0.0));
        }
        class_243 leaveVec = class_243.field_1353;
        for (class_243 vector : leaveVectors) {
            if (!MathUtility.canSeen(target.method_33571().method_1019(vector)) || Experiment.getInstance().getModuleManager().getModule(ElytraTarget.class).getSwapVector().isEnabled() && vector.equals((Object)lastVec)) continue;
            leaveVec = vector;
            break;
        }
        return leaveVec;
    }

    public static float[] getLeftRightYaw45NotMultipleOf90(float yaw) {
        float nearest45;
        float baseYaw = yaw - yaw % 360.0f;
        float yawNormalized = yaw % 360.0f;
        if (yawNormalized < 0.0f) {
            yawNormalized += 360.0f;
            baseYaw -= 360.0f;
        }
        if ((nearest45 = (float)Math.round(yawNormalized / 45.0f) * 45.0f) % 90.0f == 0.0f) {
            float candidateLeft = (nearest45 - 45.0f) % 360.0f;
            float candidateRight = (nearest45 + 45.0f) % 360.0f;
            left = candidateLeft < yawNormalized ? candidateLeft : candidateLeft - 45.0f;
            right = candidateRight > yawNormalized ? candidateRight : candidateRight + 45.0f;
        } else if (nearest45 < yawNormalized) {
            left = nearest45;
            right = nearest45 + 90.0f;
        } else {
            left = nearest45 - 90.0f;
            right = nearest45;
        }
        return new float[]{left += baseYaw, right += baseYaw};
    }

    private ElytraUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static void setLastVec(class_243 lastVec) {
        ElytraUtility.lastVec = lastVec;
    }

    public static Timer getFireworkTimer() {
        return fireworkTimer;
    }

    static {
        fireworkTimer = new Timer();
    }
}

