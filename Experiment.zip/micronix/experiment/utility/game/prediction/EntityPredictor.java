/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 */
package micronix.experiment.utility.game.prediction;

import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;

@Environment(value=EnvType.CLIENT)
public final class EntityPredictor
implements IMinecraft {
    public static float predictDamage(class_1297 crystal, class_1657 target) {
        class_243 crystalPos = new class_243(crystal.method_23317(), crystal.method_23318(), crystal.method_23321());
        class_243 targetPos = target.method_5829().method_1005();
        double dist = targetPos.method_1022(crystalPos);
        if (dist < 0.5) {
            dist = 0.0;
        }
        double scaledImpact = 1.0 - class_3532.method_15350((double)(dist / 6.0), (double)0.0, (double)1.0);
        boolean blocked = target.method_37908().method_17742(new class_3959(crystalPos, targetPos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)target)).method_17783() != class_239.class_240.field_1333;
        float exposure = blocked ? 0.7f : 1.0f;
        return (float)((double)exposure * (scaledImpact * 24.0 + 1.0));
    }

    private EntityPredictor() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

