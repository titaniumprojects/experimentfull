/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1294
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1887
 *  net.minecraft.class_1893
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_5321
 *  net.minecraft.class_6880
 */
package micronix.experiment.utility.game.prediction;

import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.inventory.EnchantmentUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

@Environment(value=EnvType.CLIENT)
public final class FallPredictor
implements IMinecraft {
    private static class_6880<class_1887> FALL = null;
    private static final double GRAVITY = 0.08;
    private static final double DRAG = 0.98;

    public static float predictFallDamage(class_1657 player, int futureTicks) {
        float f;
        class_243 pos = player.method_19538();
        class_243 vel = player.method_18798();
        class_238 bbox = player.method_5829().method_989(0.0, 0.0, 0.0);
        double fallDist = 0.0;
        for (int t = 0; t < futureTicks; ++t) {
            vel = vel.method_1031(0.0, -0.08, 0.0).method_18805(0.98, 0.98, 0.98);
            pos = pos.method_1019(vel);
            if (!FallPredictor.mc.field_1687.method_18026((bbox = bbox.method_997(vel)).method_989(0.0, -0.001, 0.0))) break;
            if (!(vel.field_1351 < 0.0)) continue;
            fallDist -= vel.field_1351;
        }
        float raw = (float)fallDist;
        if (f <= 3.0f) {
            return 0.0f;
        }
        int distanceBlocks = class_3532.method_15375((float)(raw - 3.0f));
        float damage = distanceBlocks;
        class_1799 boots = player.method_31548().method_7372(0);
        int ffLevel = EnchantmentUtility.getEnchantmentLevel(boots, (class_5321<class_1887>)class_1893.field_9129);
        if (ffLevel > 0) {
            damage = Math.max(damage - damage * 0.15f * (float)ffLevel, 0.0f);
        }
        if (player.method_6059(class_1294.field_5906)) {
            return 0.0f;
        }
        return damage;
    }

    private FallPredictor() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

