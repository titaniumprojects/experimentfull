/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_746
 */
package micronix.experiment.utility.game.prediction;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_746;

@Environment(value=EnvType.CLIENT)
public class FallingPlayer {
    private final class_746 player;
    private double x;
    private double y;
    private double z;
    private double motionX;
    private double motionY;
    private double motionZ;
    private final float yaw;
    private int simulatedTicks;

    public FallingPlayer(class_746 player, double x, double y, double z, double motionX, double motionY, double motionZ, float yaw) {
        this.player = player;
        this.x = x;
        this.y = y;
        this.z = z;
        this.motionX = motionX;
        this.motionY = motionY;
        this.motionZ = motionZ;
        this.yaw = yaw;
        this.simulatedTicks = 0;
    }

    public static FallingPlayer fromPlayer(class_746 player) {
        return new FallingPlayer(player, player.method_19538().method_10216(), player.method_19538().method_10214(), player.method_19538().method_10215(), player.method_18798().field_1352, player.method_18798().field_1351, player.method_18798().field_1350, player.method_36454());
    }

    public boolean findFall(float fallDist) {
        class_243 rotationVec = this.player.method_5828(0.0f);
        double tempMotionX = this.motionX;
        double tempMotionY = this.motionY;
        double tempMotionZ = this.motionZ;
        double d = 0.08;
        float n = class_3532.method_15362((float)(this.player.method_36455() * ((float)Math.PI / 180)));
        n = (float)((double)(n * n) * Math.min(rotationVec.method_1033() / 0.4, 1.0));
        class_243 vec3d = new class_243(tempMotionX, tempMotionY, tempMotionZ).method_1031(0.0, d * (-1.0 + (double)n * 0.75), 0.0);
        tempMotionY = vec3d.field_1351 * (double)0.98f;
        return tempMotionY < (double)fallDist;
    }

    public boolean findFall(float fallDist, int ticks) {
        class_243 rotationVec = this.player.method_5828(0.0f);
        double tempMotionX = this.motionX;
        double tempMotionY = this.motionY;
        double tempMotionZ = this.motionZ;
        double d = 0.08;
        float n = class_3532.method_15362((float)(this.player.method_36455() * ((float)Math.PI / 180)));
        n = (float)((double)(n * n) * Math.min(rotationVec.method_1033() / 0.4, 1.0));
        for (int i = 0; i < ticks; ++i) {
            class_243 vec3d = new class_243(tempMotionX, tempMotionY, tempMotionZ).method_1031(0.0, d * (-1.0 + (double)n * 0.75), 0.0);
            tempMotionY = vec3d.field_1351 * (double)0.98f;
            if (!(tempMotionY >= (double)fallDist)) continue;
            return false;
        }
        return true;
    }
}

