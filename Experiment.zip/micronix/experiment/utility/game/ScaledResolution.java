/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.game;

import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ScaledResolution
implements IMinecraft {
    public Number getNumberScaledWidth() {
        return mc.method_22683().method_4486();
    }

    public Number getNumberScaledHeight() {
        return mc.method_22683().method_4502();
    }

    public Number getNumberScaleFactor() {
        return mc.method_22683().method_4495();
    }

    public float getScaledWidth() {
        return mc.method_22683().method_4486();
    }

    public float getScaledHeight() {
        return mc.method_22683().method_4502();
    }

    public double getScaleFactor() {
        return mc.method_22683().method_4495();
    }
}

