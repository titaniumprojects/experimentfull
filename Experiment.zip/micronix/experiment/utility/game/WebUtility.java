/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1011
 */
package micronix.experiment.utility.game;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;

@Environment(value=EnvType.CLIENT)
public final class WebUtility {
    public static String fetchJson(String usd) throws IOException {
        URL url = new URL(usd);
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();
        connection.setRequestProperty("User-Agent", "Mozilla/5.0");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(10000);
        try (InputStream in = connection.getInputStream();){
            String string;
            String string2 = string = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            return string2;
        }
    }

    public static String extractImageUrl(String json) {
        Pattern pattern = Pattern.compile("\"url\"\\s*:\\s*\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(json);
        return matcher.find() ? matcher.group(1).replace("\\/", "/") : null;
    }

    public static class_1011 bufferedImageToNativeImage(BufferedImage bufferedImage, boolean avatar) {
        int width = bufferedImage.getWidth();
        int height = bufferedImage.getHeight();
        class_1011 nativeImage = new class_1011(width, height, true);
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                int argb = bufferedImage.getRGB(x, y);
                nativeImage.method_61941(x, y, argb);
            }
        }
        return nativeImage;
    }

    private WebUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

