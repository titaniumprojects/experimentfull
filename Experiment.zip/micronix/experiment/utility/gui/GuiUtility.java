/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_5611
 */
package micronix.experiment.utility.gui;

import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.systems.setting.settings.BezierSetting;
import micronix.experiment.systems.setting.settings.BindSetting;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.setting.settings.ButtonSetting;
import micronix.experiment.systems.setting.settings.ColorSetting;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.setting.settings.RangeSetting;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.setting.settings.StringSetting;
import micronix.experiment.ui.menu.dropdown.components.settings.MenuSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.BezierSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.BindSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.BooleanSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.ButtonSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.ColorSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.ModeSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.RangeSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.SelectSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.SliderSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.StringSettingComponent;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.obj.Rect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_5611;

@Environment(value=EnvType.CLIENT)
public final class GuiUtility {
    public static float getMiddleOfBox(float objectHeight, float boxHeight) {
        return (float)Math.ceil(boxHeight / 2.0f - objectHeight / 2.0f);
    }

    public static double getMiddleOfBox(double objectHeight, double boxHeight) {
        return Math.ceil(boxHeight / 2.0 - objectHeight / 2.0);
    }

    public static boolean isHovered(double x, double y, double width, double height, int mouseX, int mouseY) {
        return (double)mouseX >= x && (double)mouseX < x + width && (double)mouseY >= y && (double)mouseY < y + height;
    }

    public static boolean isHovered(double x, double y, double width, double height, UIContext context) {
        return GuiUtility.isHovered(x, y, width, height, context.getMouseX(), context.getMouseY());
    }

    public static boolean isHovered(Rect rect, double mouseX, double mouseY) {
        return GuiUtility.isHovered((double)rect.getX(), (double)rect.getY(), (double)rect.getWidth(), (double)rect.getHeight(), mouseX, mouseY);
    }

    public static boolean isHovered(CustomComponent rect, double mouseX, double mouseY) {
        return GuiUtility.isHovered((double)rect.getX(), (double)rect.getY(), (double)rect.getWidth(), (double)rect.getHeight(), mouseX, mouseY);
    }

    public static boolean isHovered(double x, double y, double width, double height, double mouseX, double mouseY) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    public static float getSliderValue(float min, float max, float start, float size, double mouse) {
        return (float)(Math.min(1.0, Math.max(0.0, (mouse - (double)start) / (double)size)) * (double)(max - min)) + min;
    }

    public static float getSliderValueWithoutClamp(float min, float max, float start, float size, double mouse) {
        return (float)((mouse - (double)start) / (double)size * (double)(max - min)) + min;
    }

    public static float getPercent(float value, float min, float max) {
        return (value - min) / (max - min);
    }

    public static class_5611 getMouse() {
        return new class_5611((float)(IMinecraft.mc.field_1729.method_1603() / IScaledResolution.sr.getScaleFactor()), (float)(IMinecraft.mc.field_1729.method_1604() / IScaledResolution.sr.getScaleFactor()));
    }

    public static MenuSettingComponent settinge(Setting setting, CustomComponent parent) {
        MenuSettingComponent settingComponent = null;
        if (setting instanceof BooleanSetting) {
            BooleanSetting s = (BooleanSetting)setting;
            settingComponent = new BooleanSettingComponent(s, parent);
        } else if (setting instanceof BindSetting) {
            BindSetting s = (BindSetting)setting;
            settingComponent = new BindSettingComponent(s, parent);
        } else if (setting instanceof ColorSetting) {
            ColorSetting s = (ColorSetting)setting;
            settingComponent = new ColorSettingComponent(s, parent);
        } else if (setting instanceof ModeSetting) {
            ModeSetting s = (ModeSetting)setting;
            settingComponent = new ModeSettingComponent(s, parent);
        } else if (setting instanceof RangeSetting) {
            RangeSetting s = (RangeSetting)setting;
            settingComponent = new RangeSettingComponent(s, parent);
        } else if (setting instanceof BezierSetting) {
            BezierSetting s = (BezierSetting)setting;
            settingComponent = new BezierSettingComponent(s, parent);
        } else if (setting instanceof ButtonSetting) {
            ButtonSetting s = (ButtonSetting)setting;
            settingComponent = new ButtonSettingComponent(s, parent);
        } else if (setting instanceof SelectSetting) {
            SelectSetting s = (SelectSetting)setting;
            settingComponent = new SelectSettingComponent(s, parent);
        } else if (setting instanceof SliderSetting) {
            SliderSetting s = (SliderSetting)setting;
            settingComponent = new SliderSettingComponent(s, parent);
        } else if (setting instanceof StringSetting) {
            StringSetting s = (StringSetting)setting;
            settingComponent = new StringSettingComponent(s, parent);
        }
        if (settingComponent != null) {
            settingComponent.onInit();
        }
        return settingComponent;
    }

    private GuiUtility() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

