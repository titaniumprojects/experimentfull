/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 */
package micronix.experiment.utility.animation.types;

import lombok.NonNull;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;

@Environment(value=EnvType.CLIENT)
public class VectorAnimation {
    private static final Easing DEFAULT_EASING = Easing.CUBIC_IN_OUT;
    private final long duration;
    private final Animation x;
    private final Animation y;
    private final Animation z;

    public VectorAnimation(long duration, Easing easing) {
        this.duration = duration;
        this.x = new Animation(duration, easing);
        this.y = new Animation(duration, easing);
        this.z = new Animation(duration, easing);
    }

    public VectorAnimation(long duration) {
        this(duration, DEFAULT_EASING);
    }

    public VectorAnimation(long duration, class_243 initalVec, Easing easing) {
        this.duration = duration;
        this.x = new Animation(duration, (float)initalVec.method_10216(), easing);
        this.y = new Animation(duration, (float)initalVec.method_10214(), easing);
        this.z = new Animation(duration, (float)initalVec.method_10215(), easing);
    }

    public VectorAnimation(long duration, class_243 initalVec) {
        this(duration, initalVec, DEFAULT_EASING);
    }

    public void update(@NonNull class_243 vec) {
        if (vec == null) {
            throw new NullPointerException("vec is marked non-null but is null");
        }
        this.x.setValue((float)vec.method_10216());
        this.y.setValue((float)vec.method_10214());
        this.z.setValue((float)vec.method_10215());
    }

    public class_243 getVec() {
        return new class_243((double)((int)this.x.getValue()), (double)((int)this.y.getValue()), (double)((int)this.z.getValue()));
    }

    public void setEasing(Easing easing) {
        this.x.setEasing(easing);
        this.y.setEasing(easing);
        this.z.setEasing(easing);
    }

    public void setDuration(long duration) {
        this.x.setDuration(duration);
        this.y.setDuration(duration);
        this.z.setDuration(duration);
    }

    public void setVec(@NonNull class_243 vec) {
        if (vec == null) {
            throw new NullPointerException("vec is marked non-null but is null");
        }
        this.x.setValue((float)vec.method_10216());
        this.y.setValue((float)vec.method_10214());
        this.z.setValue((float)vec.method_10215());
    }
}

