/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.utility.animation.types;

import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ContinualAnimation {
    private float output;
    private float endpoint;
    private Animation animation = new Animation(0L, Easing.SMOOTH_STEP);

    public void animate(float destination, int ms) {
        this.output = this.endpoint - this.animation.getValue();
        this.endpoint = destination;
        if (this.output != this.endpoint - destination) {
            this.animation = new Animation(ms, this.endpoint - this.output, Easing.SMOOTH_STEP);
            this.animation.update(0.0f);
        }
    }

    public boolean isDone() {
        return this.output == this.endpoint || this.animation.isDone();
    }

    public float getValue() {
        this.output = this.endpoint - this.animation.getValue();
        return this.output;
    }

    public Animation getAnimation() {
        return this.animation;
    }
}

