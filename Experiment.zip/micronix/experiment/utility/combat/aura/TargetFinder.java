/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1308
 *  net.minecraft.class_1309
 *  net.minecraft.class_1429
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_3966
 */
package micronix.experiment.utility.combat.aura;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

@Environment(value=EnvType.CLIENT)
public class TargetFinder
implements IMinecraft {
    private class_1309 currentTarget;
    private List<class_1309> potentialTargets;

    public void lockTarget(class_1309 target) {
        if (this.currentTarget == null) {
            this.currentTarget = target;
        }
    }

    public void releaseTarget() {
        this.currentTarget = null;
    }

    public void searchTargets(float maxDistance, float maxFov, boolean ignoreWalls, List<String> targetTypes) {
        if (TargetFinder.mc.field_1724 == null || TargetFinder.mc.field_1687 == null) {
            this.potentialTargets = List.of();
            return;
        }
        if (this.currentTarget != null) {
            boolean targetInvalid;
            boolean bl = targetInvalid = !this.isTargetValid(this.currentTarget, maxDistance, ignoreWalls);
            if (targetInvalid) {
                this.releaseTarget();
            }
        }
        List entities = TargetFinder.mc.field_1687.method_8335((class_1297)TargetFinder.mc.field_1724, TargetFinder.mc.field_1724.method_5829().method_1014((double)maxDistance));
        this.potentialTargets = this.createStreamFromEntities(entities, maxDistance, 360.0f, ignoreWalls, targetTypes).toList();
    }

    public void validateTarget(Predicate<class_1309> predicate) {
        this.findFirstMatch(predicate).ifPresent(this::lockTarget);
        if (this.currentTarget != null && !predicate.test(this.currentTarget)) {
            this.releaseTarget();
        }
    }

    private Stream<class_1309> createStreamFromEntities(List<class_1297> entities, float maxDistance, float maxFov, boolean ignoreWalls, List<String> targetTypes) {
        return entities.stream().filter(class_1309.class::isInstance).map(class_1309.class::cast).filter(entity -> this.isValidTarget((class_1309)entity, targetTypes)).filter(entity -> TargetFinder.mc.field_1724.method_5739((class_1297)entity) <= maxDistance).filter(entity -> this.getFov((class_1309)entity) <= maxFov).filter(entity -> ignoreWalls || this.canSeeTarget((class_1309)entity)).sorted(Comparator.comparingDouble(entity -> TargetFinder.mc.field_1724.method_5739((class_1297)entity)));
    }

    private Optional<class_1309> findFirstMatch(Predicate<class_1309> predicate) {
        if (this.potentialTargets == null) {
            return Optional.empty();
        }
        return this.potentialTargets.stream().filter(predicate).findFirst();
    }

    private boolean isTargetValid(class_1309 target, float maxDistance, boolean ignoreWalls) {
        if (target == null || !target.method_5805() || target.method_6032() <= 0.0f) {
            return false;
        }
        if (TargetFinder.mc.field_1724.method_5739((class_1297)target) > maxDistance) {
            return false;
        }
        return ignoreWalls || this.canSeeTarget(target);
    }

    private float getFov(class_1309 target) {
        if (TargetFinder.mc.field_1724 == null || target == null) {
            return 180.0f;
        }
        class_243 playerPos = TargetFinder.mc.field_1724.method_33571();
        class_243 targetPos = target.method_5829().method_1005();
        class_243 direction = targetPos.method_1020(playerPos).method_1029();
        class_243 lookVec = TargetFinder.mc.field_1724.method_5828(1.0f);
        double dot = lookVec.method_1026(direction);
        double angle = Math.toDegrees(Math.acos(dot));
        return (float)angle;
    }

    private boolean canSeeTarget(class_1309 target) {
        class_243 targetPos;
        if (TargetFinder.mc.field_1724 == null || TargetFinder.mc.field_1687 == null || target == null) {
            return false;
        }
        class_243 eyes = TargetFinder.mc.field_1724.method_33571();
        class_3965 result = TargetFinder.mc.field_1687.method_17742(new class_3959(eyes, targetPos = target.method_5829().method_1005(), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)TargetFinder.mc.field_1724));
        return result.method_17783() == class_239.class_240.field_1333 || result.method_17783() == class_239.class_240.field_1331 && ((class_3966)result).method_17782() == target;
    }

    private boolean isValidTarget(class_1309 entity, List<String> targetTypes) {
        if (entity == TargetFinder.mc.field_1724) {
            return false;
        }
        if (!entity.method_5805() || entity.method_6032() <= 0.0f) {
            return false;
        }
        if (entity instanceof class_1657 && targetTypes.contains("Players")) {
            return true;
        }
        if (entity instanceof class_1308 && targetTypes.contains("Mobs")) {
            return true;
        }
        if (entity instanceof class_1429 && targetTypes.contains("Animals")) {
            return true;
        }
        return entity instanceof class_1531 && targetTypes.contains("Armor Stand");
    }

    public class_1309 getCurrentTarget() {
        return this.currentTarget;
    }

    public List<class_1309> getPotentialTargets() {
        return this.potentialTargets != null ? this.potentialTargets : List.of();
    }
}

