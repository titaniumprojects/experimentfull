/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.base;

import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public abstract class CustomComponent
implements IMinecraft {
    protected float x;
    protected float y;
    protected float width;
    protected float height;

    protected CustomComponent(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    protected CustomComponent() {
        this(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public void render(UIContext context) {
        this.update(context);
        this.renderComponent(context);
    }

    protected abstract void renderComponent(UIContext var1);

    public void onInit() {
    }

    public void update(UIContext context) {
    }

    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
    }

    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
    }

    public void onKeyPressed(int keyCode, int scanCode, int modifiers) {
    }

    public boolean charTyped(char chr, int modifiers) {
        return false;
    }

    public void onScroll(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
    }

    public void pos(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void set(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public boolean isHovered(float mouseX, float mouseY) {
        return GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, mouseX, mouseY);
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, mouseX, mouseY);
    }

    public boolean isHovered(UIContext context) {
        return this.isHovered(context.getMouseX(), context.getMouseY());
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setHeight(float height) {
        this.height = height;
    }
}

