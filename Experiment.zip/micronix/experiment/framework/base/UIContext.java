/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_332
 */
package micronix.experiment.framework.base;

import micronix.experiment.framework.base.CustomDrawContext;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(value=EnvType.CLIENT)
public class UIContext
extends CustomDrawContext {
    private final int mouseX;
    private final int mouseY;
    private final float delta;

    protected UIContext(class_332 originalContext, int mouseX, int mouseY, float delta) {
        super(originalContext);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        this.delta = delta;
    }

    public static UIContext of(class_332 originalContext, int mouseX, int mouseY, float delta) {
        return new UIContext(originalContext, mouseX, mouseY, delta);
    }

    public int getMouseX() {
        return this.mouseX;
    }

    public int getMouseY() {
        return this.mouseY;
    }

    public float getDelta() {
        return this.delta;
    }
}

