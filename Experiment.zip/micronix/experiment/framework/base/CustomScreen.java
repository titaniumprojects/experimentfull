/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 */
package micronix.experiment.framework.base;

import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.objects.MouseButton;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

@Environment(value=EnvType.CLIENT)
public abstract class CustomScreen
extends class_437 {
    protected CustomScreen() {
        super((class_2561)class_2561.method_43473());
    }

    public abstract void render(UIContext var1);

    public final void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        UIContext uiContext = UIContext.of(context, mouseX, mouseY, delta);
        this.render(uiContext);
    }

    public final boolean method_25402(double mouseX, double mouseY, int button) {
        MouseButton mouseButton = MouseButton.fromButtonIndex(button);
        this.onMouseClicked(mouseX, mouseY, mouseButton);
        return super.method_25402(mouseX, mouseY, button);
    }

    public final boolean method_25406(double mouseX, double mouseY, int button) {
        MouseButton mouseButton = MouseButton.fromButtonIndex(button);
        this.onMouseReleased(mouseX, mouseY, mouseButton);
        return super.method_25406(mouseX, mouseY, button);
    }

    public final boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        MouseButton mouseButton = MouseButton.fromButtonIndex(button);
        this.onMouseDragged(mouseX, mouseY, mouseButton, deltaX, deltaY);
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
    }

    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
    }

    public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {
    }
}

