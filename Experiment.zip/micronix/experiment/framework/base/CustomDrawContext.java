/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10444
 *  net.minecraft.class_128
 *  net.minecraft.class_129
 *  net.minecraft.class_1309
 *  net.minecraft.class_148
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1937
 *  net.minecraft.class_241
 *  net.minecraft.class_2561
 *  net.minecraft.class_2960
 *  net.minecraft.class_308
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_4608
 *  net.minecraft.class_742
 *  net.minecraft.class_811
 *  org.jetbrains.annotations.Nullable
 */
package micronix.experiment.framework.base;

import micronix.experiment.Experiment;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.MsdfRenderer;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.gradient.Gradient;
import micronix.experiment.mixin.accessors.DrawContextAccessor;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.obj.CustomSprite;
import micronix.experiment.utility.render.obj.Rect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_1309;
import net.minecraft.class_148;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class CustomDrawContext
extends class_332
implements IMinecraft {
    private final class_332 originalContext;

    protected CustomDrawContext(class_332 originalContext) {
        super(class_310.method_1551(), ((DrawContextAccessor)originalContext).getVertexConsumers());
        this.originalContext = originalContext;
    }

    public static CustomDrawContext of(class_332 originalContext) {
        return new CustomDrawContext(originalContext);
    }

    public void drawClientRect(float x, float y, float width, float height, float alpha, float dragAnim, float squircle) {
        if (Interface.showMinimalizm()) {
            this.drawBlurredRect(x, y, width, height, 45.0f, squircle, BorderRadius.all(6.0f), ColorRGBA.WHITE.withAlpha(255.0f * alpha * Interface.minimalizm()));
        }
        if (Interface.showGlass()) {
            this.drawLiquidGlass(x, y, width, height, squircle, 0.08f - 0.07f * dragAnim, BorderRadius.all(6.0f), ColorRGBA.WHITE.withAlpha(255.0f * alpha * Interface.glass()));
        }
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        this.drawSquircle(x, y, width, height, squircle, BorderRadius.all(6.0f), Colors.getBackgroundColor().withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f)));
    }

    public void pushMatrix() {
        this.method_51448().method_22903();
    }

    public void popMatrix() {
        this.method_51448().method_22909();
    }

    public void drawRect(float x, float y, float width, float height, ColorRGBA color) {
        DrawUtility.drawRect(this.method_51448(), x, y, width, height, color);
    }

    public void drawLine(class_241 from, class_241 to, ColorRGBA color) {
        DrawUtility.drawLine(this.method_51448(), from, to, color);
    }

    public void drawBezier(class_241 p0, class_241 p1, class_241 p2, class_241 p3, ColorRGBA color, int resolution) {
        DrawUtility.drawBezier(this.method_51448(), p0, p1, p2, p3, color, resolution);
    }

    public void drawSquircle(float x, float y, float width, float height, float squirt, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawSquircle(this.method_51448(), x, y, width, height, squirt, borderRadius, color);
    }

    public void drawRoundedRect(float x, float y, float width, float height, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawRoundedRect(this.method_51448(), x, y, width, height, borderRadius, color);
    }

    public void drawRoundedRect(float x, float y, float width, float height, BorderRadius borderRadius, Gradient gradient) {
        DrawUtility.drawRoundedRect(this.method_51448(), x, y, width, height, borderRadius, gradient);
    }

    public void drawLiquidGlass(float x, float y, float width, float height, float squirt, float power, BorderRadius borderRadius, ColorRGBA color) {
        borderRadius = new BorderRadius(borderRadius.topLeftRadius() * squirt / 2.0f, borderRadius.topRightRadius() * squirt / 2.0f, borderRadius.bottomLeftRadius() * squirt / 2.0f, borderRadius.bottomRightRadius() * squirt / 2.0f);
        DrawUtility.drawLiquidGlass(this.method_51448(), x - 5.0f * Interface.minimalizm(), y - 5.0f * Interface.minimalizm(), width + 10.0f * Interface.minimalizm(), height + 10.0f * Interface.minimalizm(), borderRadius, color, color.getAlpha() / 255.0f * Interface.glass(), (float)(height == 240.0f ? 100 : 50) * Interface.glass(), color.withAlpha(255.0f), 1.0f, true, 0.0f, power * Interface.glass(), squirt, false);
    }

    public void drawLiquidGlass(float x, float y, float width, float height, float squirt, BorderRadius borderRadius, ColorRGBA color, boolean clean) {
        borderRadius = new BorderRadius(borderRadius.topLeftRadius() * squirt / 2.0f, borderRadius.topRightRadius() * squirt / 2.0f, borderRadius.bottomLeftRadius() * squirt / 2.0f, borderRadius.bottomRightRadius() * squirt / 2.0f);
        DrawUtility.drawLiquidGlass(this.method_51448(), x, y, width, height, borderRadius, color, color.getAlpha() / 255.0f, height == 240.0f ? 100.0f : 50.0f, color.withAlpha(255.0f), 1.0f, true, 0.0f, 0.08f, squirt, clean);
    }

    public void drawLoadingRect(float x, float y, float width, float height, float progress, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawLoadingRect(this.method_51448(), x, y, width, height, progress, borderRadius, color);
    }

    public void drawRoundedBorder(float x, float y, float width, float height, float borderThickness, BorderRadius borderRadius, ColorRGBA borderColor) {
        DrawUtility.drawRoundedBorder(this.method_51448(), x, y, width, height, borderThickness, borderRadius, borderColor);
    }

    public void drawTexture(class_2960 identifier, Rect rect) {
        this.drawTexture(identifier, rect, ColorRGBA.WHITE);
    }

    public void drawTexture(class_2960 identifier, Rect rect, ColorRGBA color) {
        DrawUtility.drawTexture(this.method_51448(), identifier, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), color);
    }

    public void drawTexture(class_2960 identifier, float x, float y, float width, float height) {
        DrawUtility.drawTexture(this.method_51448(), identifier, x, y, width, height, ColorRGBA.WHITE);
    }

    public void drawTexture(class_2960 identifier, float x, float y, float width, float height, float u1, float u2, float v1, float v2, ColorRGBA color) {
        DrawUtility.drawTexture(this.method_51448(), identifier, x, y, width, height, u1, u2, v1, v2, color);
    }

    public void drawTexture(class_2960 identifier, float x, float y, float width, float height, ColorRGBA textureColor) {
        DrawUtility.drawTexture(this.method_51448(), identifier, x, y, width, height, textureColor);
    }

    public void drawSprite(CustomSprite sprite, float x, float y, float width, float height, ColorRGBA textureColor) {
        DrawUtility.drawSprite(this.method_51448(), sprite, x, y, width, height, textureColor);
    }

    public void drawRoundedTexture(class_2960 identifier, float x, float y, float width, float height, BorderRadius borderRadius) {
        DrawUtility.drawRoundedTexture(this.method_51448(), identifier, x, y, width, height, borderRadius);
    }

    public void drawRoundedTexture(class_2960 identifier, float x, float y, float width, float height, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawRoundedTexture(this.method_51448(), identifier, x, y, width, height, borderRadius, color);
    }

    public void drawShadow(float x, float y, float width, float height, float softness, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawShadow(this.method_51448(), x, y, width, height, softness, borderRadius, color);
    }

    public void drawBlurredRect(float x, float y, float width, float height, float blurRadius, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawBlur(this.method_51448(), x, y, width, height, blurRadius, borderRadius, color);
    }

    public void drawBlurredRect(float x, float y, float width, float height, float blurRadius, float squirt, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawBlur(this.method_51448(), x, y, width, height, blurRadius, squirt, borderRadius, color);
    }

    public void drawText(Font font, String text, float x, float y, ColorRGBA color) {
        MsdfRenderer.renderText(font.getFont(), text, font.getSize(), color.getRGB(), this.method_51448().method_23760().method_23761(), x, y, 0.0f);
    }

    public void drawText(Font font, class_2561 text, float x, float y) {
        MsdfRenderer.renderText(font.getFont(), text, font.getSize(), this.method_51448().method_23760().method_23761(), x, y, 0.0f);
    }

    public void drawFadeoutText(Font font, String text, float x, float y, ColorRGBA color, float fadeoutStart, float fadeoutEnd) {
        MsdfRenderer.renderText(font.getFont(), text, font.getSize(), color.getRGB(), this.method_51448().method_23760().method_23761(), x, y, 0.0f, true, fadeoutStart, fadeoutEnd);
    }

    public void drawFadeoutText(Font font, String text, float x, float y, ColorRGBA color, float fadeoutStart, float fadeoutEnd, float maxWidth) {
        MsdfRenderer.renderText(font.getFont(), text, font.getSize(), color.getRGB(), this.method_51448().method_23760().method_23761(), x, y, 0.0f, true, fadeoutStart, fadeoutEnd, maxWidth);
    }

    public void drawCenteredText(Font font, String text, float x, float y, ColorRGBA color) {
        this.drawText(font, text, x - font.getFont().getWidth(text, font.getSize()) / 2.0f, y, color);
    }

    public void drawRightText(Font font, String text, float x, float y, ColorRGBA color) {
        this.drawText(font, text, x - font.getFont().getWidth(text, font.getSize()), y, color);
    }

    public void drawItem(class_1792 item, float x, float y, float size) {
        this.drawItem(item.method_7854(), x, y, size);
    }

    public void drawItem(class_1799 item, float x, float y, float size) {
        this.method_51448().method_22903();
        this.method_51448().method_46416(x, y, 0.0f);
        this.method_51448().method_22905(size, size, size);
        class_308.method_24210();
        this.method_51427(item, 0, 0);
        class_308.method_24210();
        this.method_51448().method_22909();
    }

    public void drawHead(class_742 player, float x, float y, float size, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawPlayerHeadWithHat(this.method_51448(), player, x, y, size, borderRadius, color);
    }

    public void drawHead(class_1309 entity, float x, float y, float size, BorderRadius borderRadius, ColorRGBA color) {
        DrawUtility.drawEntityHeadWithHat(this.method_51448(), entity, x, y, size, borderRadius, color);
    }

    public void drawBatchItem(class_1799 item, int x, int y) {
        this.drawBatchItem((class_1309)CustomDrawContext.mc.field_1724, (class_1937)CustomDrawContext.mc.field_1687, item, x, y, 0);
    }

    private void drawBatchItem(@Nullable class_1309 entity, @Nullable class_1937 world, class_1799 stack, int x, int y, int seed) {
        this.drawBatchItem(entity, world, stack, x, y, seed, 0);
    }

    private void drawBatchItem(@Nullable class_1309 entity, @Nullable class_1937 world, class_1799 stack, int x, int y, int seed, int z) {
        class_4587 matrices = this.method_51448();
        class_10444 itemRenderState = ((DrawContextAccessor)this.originalContext).getItemRenderState();
        class_4597.class_4598 vertexConsumers = ((DrawContextAccessor)this.originalContext).getVertexConsumers();
        if (!stack.method_7960()) {
            mc.method_65386().method_65598(itemRenderState, stack, class_811.field_4317, false, world, entity, seed);
            matrices.method_22903();
            matrices.method_46416((float)(x + 8), (float)(y + 8), (float)(150 + (itemRenderState.method_65607() ? z : 0)));
            try {
                matrices.method_22905(16.0f, -16.0f, 16.0f);
                boolean bl = !itemRenderState.method_65608();
                boolean bl2 = bl;
                if (bl) {
                    class_308.method_24210();
                }
                itemRenderState.method_65604(matrices, (class_4597)vertexConsumers, 0xF000F0, class_4608.field_21444);
                if (bl) {
                    class_308.method_24211();
                }
            }
            catch (Throwable var11) {
                Throwable throwable = var11;
                class_128 crashReport = class_128.method_560((Throwable)throwable, (String)"Rendering item");
                class_129 crashReportSection = crashReport.method_562("Item being rendered");
                crashReportSection.method_577("Item Type", () -> String.valueOf(stack.method_7909()));
                crashReportSection.method_577("Item Components", () -> String.valueOf(stack.method_57353()));
                crashReportSection.method_577("Item Foil", () -> String.valueOf(stack.method_7958()));
                throw new class_148(crashReport);
            }
            matrices.method_22909();
        }
    }
}

