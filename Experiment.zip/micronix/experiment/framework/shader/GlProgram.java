/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10149
 *  net.minecraft.class_10151$class_10152
 *  net.minecraft.class_10156
 *  net.minecraft.class_284
 *  net.minecraft.class_293
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_4668$class_5942
 *  net.minecraft.class_5944
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package micronix.experiment.framework.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.mixin.accessors.ShaderProgramAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10149;
import net.minecraft.class_10151;
import net.minecraft.class_10156;
import net.minecraft.class_284;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4668;
import net.minecraft.class_5944;
import org.jetbrains.annotations.ApiStatus;

@Environment(value=EnvType.CLIENT)
public class GlProgram {
    private static final List<Runnable> REGISTERED_PROGRAMS = new ArrayList<Runnable>();
    protected class_5944 backingProgram;
    protected class_10156 programKey;

    public GlProgram(class_2960 id, class_293 vertexFormat) {
        this.programKey = new class_10156(id.method_45138("core/"), vertexFormat, class_10149.field_53930);
        REGISTERED_PROGRAMS.add(() -> {
            try {
                this.backingProgram = class_310.method_1551().method_62887().method_64062(this.programKey);
                this.setup();
            }
            catch (class_10151.class_10152 e) {
                throw new RuntimeException("Failed to initialize shader program", e);
            }
        });
    }

    public class_4668.class_5942 renderPhaseProgram() {
        return new class_4668.class_5942(this.programKey);
    }

    public class_5944 use() {
        return RenderSystem.setShader((class_10156)this.programKey);
    }

    protected void setup() {
    }

    public class_284 findUniform(String name) {
        return ((ShaderProgramAccessor)this.backingProgram).getUniformsByName().get(name);
    }

    @ApiStatus.Internal
    public static void loadAndSetupPrograms() {
        REGISTERED_PROGRAMS.forEach(Runnable::run);
    }
}

