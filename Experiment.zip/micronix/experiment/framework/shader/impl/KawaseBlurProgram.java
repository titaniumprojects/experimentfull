/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_284
 *  net.minecraft.class_290
 *  net.minecraft.class_2960
 */
package micronix.experiment.framework.shader.impl;

import micronix.experiment.framework.shader.GlProgram;
import micronix.experiment.utility.interfaces.IWindow;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_284;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import ru.kotopushka.compiler.sdk.annotations.CompileBytecode;

@Environment(value=EnvType.CLIENT)
public class KawaseBlurProgram
extends GlProgram
implements IWindow {
    private class_284 resolutionUniform;
    private class_284 offsetUniform;
    private class_284 saturationUniform;
    private class_284 tintIntensityUniform;
    private class_284 tintColorUniform;

    public KawaseBlurProgram(class_2960 identifier) {
        super(identifier, class_290.field_1575);
    }

    @CompileBytecode
    public void updateUniforms(float offset) {
        this.offsetUniform.method_1251(offset);
        this.resolutionUniform.method_1255(1.0f / (float)mw.method_4486(), 1.0f / (float)mw.method_4502());
        this.saturationUniform.method_1251(1.0f);
        this.tintIntensityUniform.method_1251(0.0f);
        this.tintColorUniform.method_1249(1.0f, 1.0f, 1.0f);
    }

    public void updateUniforms(float offset, int textureWidth, int textureHeight) {
        this.offsetUniform.method_1251(offset);
        float invW = textureWidth > 0 ? 1.0f / (float)textureWidth : 0.0f;
        float invH = textureHeight > 0 ? 1.0f / (float)textureHeight : 0.0f;
        this.resolutionUniform.method_1255(invW, invH);
        this.saturationUniform.method_1251(1.0f);
        this.tintIntensityUniform.method_1251(0.0f);
        this.tintColorUniform.method_1249(1.0f, 1.0f, 1.0f);
    }

    @Override
    protected void setup() {
        this.resolutionUniform = this.findUniform("Resolution");
        this.offsetUniform = this.findUniform("Offset");
        this.saturationUniform = this.findUniform("Saturation");
        this.tintIntensityUniform = this.findUniform("TintIntensity");
        this.tintColorUniform = this.findUniform("TintColor");
        super.setup();
    }
}

