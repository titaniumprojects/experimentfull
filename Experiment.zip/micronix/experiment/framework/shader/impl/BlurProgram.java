/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Supplier
 *  com.google.common.base.Suppliers
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_276
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_9801
 */
package micronix.experiment.framework.shader.impl;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.framework.shader.impl.KawaseBlurProgram;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IWindow;
import micronix.experiment.utility.render.CustomRenderTarget;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_9801;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class BlurProgram
implements IMinecraft,
IWindow {
    private static final class_276 MAIN_FBO = mc.method_1522();
    public static final Supplier<CustomRenderTarget> CACHE = Suppliers.memoize(() -> new CustomRenderTarget(false).setLinear());
    public static final Supplier<CustomRenderTarget> BUFFER = Suppliers.memoize(() -> new CustomRenderTarget(false).setLinear());
    private final Timer timer = new Timer();
    private static KawaseBlurProgram kawaseDownProgram;
    private static KawaseBlurProgram kawaseUpProgram;
    private float blurOffset = 1.0f;
    private float blurDownscale = 0.5f;

    @Compile
    public void initShaders() {
        kawaseDownProgram = new KawaseBlurProgram(Experiment.id("kawase_down/data"));
        kawaseUpProgram = new KawaseBlurProgram(Experiment.id("kawase_up/data"));
    }

    public void draw() {
        int step;
        int i;
        if (!this.timer.finished(25L)) {
            return;
        }
        this.blurOffset = 1.0f;
        CustomRenderTarget cache = (CustomRenderTarget)CACHE.get();
        CustomRenderTarget buffer = (CustomRenderTarget)BUFFER.get();
        cache.setDownscale(this.blurDownscale).setLinear();
        buffer.setDownscale(this.blurDownscale).setLinear();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        kawaseDownProgram.use();
        kawaseDownProgram.updateUniforms(this.blurOffset, BlurProgram.MAIN_FBO.field_1482, BlurProgram.MAIN_FBO.field_1481);
        cache.setup();
        MAIN_FBO.method_35610();
        RenderSystem.setShaderTexture((int)0, (int)MAIN_FBO.method_30277());
        this.drawQuad(0.0f, 0.0f, mw.method_4486(), mw.method_4502());
        cache.stop();
        CustomRenderTarget[] buffers = new CustomRenderTarget[]{cache, buffer};
        int steps = 3;
        for (i = 1; i < 3; ++i) {
            step = i % 2;
            buffers[step].setup();
            buffers[(step + 1) % 2].method_35610();
            RenderSystem.setShaderTexture((int)0, (int)buffers[(step + 1) % 2].method_30277());
            kawaseDownProgram.updateUniforms(this.blurOffset, buffers[(step + 1) % 2].field_1482, buffers[(step + 1) % 2].field_1481);
            this.drawQuad(0.0f, 0.0f, mw.method_4486(), mw.method_4502());
            buffers[(step + 1) % 2].method_1242();
            buffers[step].stop();
        }
        kawaseUpProgram.use();
        for (i = 0; i < 3; ++i) {
            step = i % 2;
            buffers[(step + 1) % 2].setup();
            buffers[step].method_35610();
            RenderSystem.setShaderTexture((int)0, (int)buffers[step].method_30277());
            kawaseUpProgram.updateUniforms(this.blurOffset, buffers[step].field_1482, buffers[step].field_1481);
            this.drawQuad(0.0f, 0.0f, mw.method_4486(), mw.method_4502());
            buffers[step].method_1242();
            buffers[step].stop();
        }
        MAIN_FBO.method_1242();
        MAIN_FBO.method_1235(false);
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.disableBlend();
    }

    private void drawQuad(float x, float y, float width, float height) {
        int color = -1;
        class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        builder.method_22912(x, y, 0.0f).method_22913(0.0f, 1.0f).method_39415(color);
        builder.method_22912(x, y + height, 0.0f).method_22913(0.0f, 0.0f).method_39415(color);
        builder.method_22912(x + width, y + height, 0.0f).method_22913(1.0f, 0.0f).method_39415(color);
        builder.method_22912(x + width, y, 0.0f).method_22913(1.0f, 1.0f).method_39415(color);
        class_286.method_43433((class_9801)builder.method_60800());
    }

    public static int getTexture() {
        return ((CustomRenderTarget)BUFFER.get()).method_30277();
    }

    public void setBlurOffset(float blurOffset) {
        this.blurOffset = blurOffset;
    }

    public void setBlurDownscale(float blurDownscale) {
        this.blurDownscale = blurDownscale;
    }
}

