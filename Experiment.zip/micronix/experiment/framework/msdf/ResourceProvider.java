/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3300
 */
package micronix.experiment.framework.msdf;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;
import micronix.experiment.Experiment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;

@Environment(value=EnvType.CLIENT)
public final class ResourceProvider {
    private static final class_3300 RESOURCE_MANAGER = class_310.method_1551().method_1478();
    private static final Gson GSON = new Gson();

    public static class_2960 getShaderIdentifier(String name) {
        return Experiment.id("core/" + name);
    }

    public static <T> T fromJsonToInstance(class_2960 identifier, Class<T> clazz) {
        return (T)GSON.fromJson(ResourceProvider.toString(identifier), clazz);
    }

    public static String toString(class_2960 identifier) {
        return ResourceProvider.toString(identifier, "\n");
    }

    public static String toString(class_2960 identifier, String delimiter) {
        String string;
        block14: {
            InputStream inputStream = RESOURCE_MANAGER.open(identifier);
            try {
                String string2;
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));){
                    string2 = reader.lines().collect(Collectors.joining(delimiter));
                }
                string = string2;
                if (inputStream == null) break block14;
            }
            catch (Throwable throwable) {
                try {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
            inputStream.close();
        }
        return string;
    }
}

