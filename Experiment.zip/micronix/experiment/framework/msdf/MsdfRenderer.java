/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10149
 *  net.minecraft.class_10156
 *  net.minecraft.class_2561
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4588
 *  net.minecraft.class_5944
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package micronix.experiment.framework.msdf;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.msdf.FormattedTextProcessor;
import micronix.experiment.framework.msdf.MsdfFont;
import micronix.experiment.framework.msdf.ResourceProvider;
import micronix.experiment.systems.modules.modules.other.NameProtect;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.batching.Batching;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10149;
import net.minecraft.class_10156;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4588;
import net.minecraft.class_5944;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

@Environment(value=EnvType.CLIENT)
public final class MsdfRenderer {
    public static final class_10156 MSDF_FONT_SHADER_KEY = new class_10156(ResourceProvider.getShaderIdentifier("msdf_font/data"), class_290.field_1575, class_10149.field_53930);

    public static void renderText(MsdfFont font, String text, float size, int color, Matrix4f matrix, float x, float y, float z) {
        MsdfRenderer.renderText(font, text, size, color, matrix, x, y, z, false, 0.0f, 1.0f, 0.0f);
    }

    public static void renderText(MsdfFont font, String text, float size, int color, Matrix4f matrix, float x, float y, float z, boolean enableFadeout, float fadeoutStart, float fadeoutEnd, float maxWidth) {
        text = text.replace("\u0456", "i").replace("\u0406", "I");
        float thickness = 0.05f;
        float smoothness = 0.5f;
        float spacing = -0.3f;
        NameProtect nameProtectModule = Experiment.getInstance().getModuleManager().getModule(NameProtect.class);
        if (nameProtectModule.isEnabled()) {
            text = nameProtectModule.patchName(text);
        }
        if (Batching.getActive() != null) {
            font.applyGlyphs(matrix, (class_4588)Batching.getActive().getBuilder(), text, size, thickness * 0.5f * size, spacing, x - 0.75f, y + size * 0.7f, z, color);
            return;
        }
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShaderTexture((int)0, (int)font.getTextureId());
        class_5944 shader = RenderSystem.setShader((class_10156)MSDF_FONT_SHADER_KEY);
        shader.method_34582("Range").method_1251(font.getAtlas().range());
        shader.method_34582("Thickness").method_1251(thickness);
        shader.method_34582("Smoothness").method_1251(smoothness);
        shader.method_34582("EnableFadeout").method_35649(enableFadeout ? 1 : 0);
        shader.method_34582("FadeoutStart").method_1251(fadeoutStart);
        shader.method_34582("FadeoutEnd").method_1251(fadeoutEnd);
        shader.method_34582("MaxWidth").method_1251(maxWidth);
        shader.method_34582("TextPosX").method_1251(x);
        class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        font.applyGlyphs(matrix, (class_4588)builder, text, size, thickness * 0.5f * size, spacing, x - 0.75f, y + size * 0.7f, z, color);
        class_9801 builtBuffer = builder.method_60794();
        if (builtBuffer != null) {
            class_286.method_43433((class_9801)builtBuffer);
        }
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void renderText(MsdfFont font, String text, float size, int color, Matrix4f matrix, float x, float y, float z, boolean enableFadeout, float fadeoutStart, float fadeoutEnd) {
        float maxWidth = font.getWidth(text, size) * 2.0f;
        MsdfRenderer.renderText(font, text, size, color, matrix, x, y, z, enableFadeout, fadeoutStart, fadeoutEnd, maxWidth);
    }

    public static void renderText(MsdfFont font, class_2561 text, float size, Matrix4f matrix, float x, float y, float z) {
        MsdfRenderer.renderText(font, text, size, matrix, x, y, z, false, 0.0f, 1.0f, 0.0f);
    }

    public static void renderText(MsdfFont font, class_2561 text, float size, Matrix4f matrix, float x, float y, float z, boolean enableFadeout, float fadeoutStart, float fadeoutEnd, float maxWidth) {
        float thickness = 0.05f;
        float smoothness = 0.5f;
        float spacing = -0.3f;
        List<FormattedTextProcessor.TextSegment> segments = FormattedTextProcessor.processText(text, Colors.WHITE.getRGB());
        float currentX = x;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShaderTexture((int)0, (int)font.getTextureId());
        class_5944 shader = RenderSystem.setShader((class_10156)MSDF_FONT_SHADER_KEY);
        shader.method_34582("Range").method_1251(font.getAtlas().range());
        shader.method_34582("Thickness").method_1251(thickness);
        shader.method_34582("Smoothness").method_1251(smoothness);
        shader.method_34582("EnableFadeout").method_35649(enableFadeout ? 1 : 0);
        shader.method_34582("FadeoutStart").method_1251(fadeoutStart);
        shader.method_34582("FadeoutEnd").method_1251(fadeoutEnd);
        shader.method_34582("MaxWidth").method_1251(maxWidth);
        shader.method_34582("TextPosX").method_1251(x);
        class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (FormattedTextProcessor.TextSegment segment : segments) {
            font.applyGlyphs(matrix, (class_4588)builder, segment.text, size, thickness * 0.5f * size, spacing - 0.3f, currentX - 0.75f, y + size * 0.7f, z, segment.color);
            currentX += font.getWidth(segment.text, size);
        }
        class_9801 builtBuffer = builder.method_60794();
        if (builtBuffer != null) {
            class_286.method_43433((class_9801)builtBuffer);
        }
        RenderSystem.setShaderTexture((int)0, (int)0);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void renderText(MsdfFont font, class_2561 text, float size, Matrix4f matrix, float x, float y, float z, boolean enableFadeout, float fadeoutStart, float fadeoutEnd) {
        float maxWidth = font.getTextWidth(text, size) * 2.0f;
        MsdfRenderer.renderText(font, text, size, matrix, x, y, z, enableFadeout, fadeoutStart, fadeoutEnd, maxWidth);
    }

    private MsdfRenderer() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

