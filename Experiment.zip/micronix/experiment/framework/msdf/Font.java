/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 */
package micronix.experiment.framework.msdf;

import micronix.experiment.framework.msdf.MsdfFont;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public class Font {
    private MsdfFont font;
    private float size;

    public float height() {
        return this.size * 0.7f;
    }

    public float width(String text) {
        return this.font.getWidth(text, this.size);
    }

    public float width(class_2561 text) {
        return this.font.getTextWidth(text, this.size);
    }

    public MsdfFont getFont() {
        return this.font;
    }

    public float getSize() {
        return this.size;
    }

    public Font(MsdfFont font, float size) {
        this.font = font;
        this.size = size;
    }
}

