/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.msdf;

import micronix.experiment.framework.msdf.MsdfFont;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class Fonts {
    public static final MsdfFont SYSTEMDLC = MsdfFont.builder().atlas("systemdlc").data("systemdlc").build();
    public static final MsdfFont ICONS = MsdfFont.builder().atlas("icons").data("icons").build();
    public static final MsdfFont BOLD = MsdfFont.builder().atlas("bold").data("bold").build();
    public static final MsdfFont MEDIUM = MsdfFont.builder().atlas("medium").data("medium").build();
    public static final MsdfFont REGULAR = MsdfFont.builder().atlas("regular").data("regular").build();
    public static final MsdfFont SEMIBOLD = MsdfFont.builder().atlas("semibold").data("semibold").build();
    public static final MsdfFont ROUND_BOLD = MsdfFont.builder().atlas("roundbold").data("roundbold").build();

    private Fonts() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

