/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_5251
 */
package micronix.experiment.framework.msdf;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5251;

@Environment(value=EnvType.CLIENT)
public class FormattedTextProcessor {
    public static List<TextSegment> processText(class_2561 text, int defaultColor) {
        ArrayList<TextSegment> segments = new ArrayList<TextSegment>();
        text.method_27658((style, string) -> {
            if (!string.isEmpty()) {
                int color = FormattedTextProcessor.extractColor(style, defaultColor);
                boolean bold = style.method_10984();
                boolean italic = style.method_10966();
                boolean underlined = style.method_10965();
                boolean strikethrough = style.method_10986();
                segments.add(new TextSegment(string, color, bold, italic, underlined, strikethrough));
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return segments;
    }

    private static int extractColor(class_2583 style, int defaultColor) {
        class_5251 textColor = style.method_10973();
        if (textColor != null) {
            return textColor.method_27716() | 0xFF000000;
        }
        return defaultColor;
    }

    @Environment(value=EnvType.CLIENT)
    public static class TextSegment {
        public final String text;
        public final int color;
        public final boolean bold;
        public final boolean italic;
        public final boolean underlined;
        public final boolean strikethrough;

        public TextSegment(String text, int color, boolean bold, boolean italic, boolean underlined, boolean strikethrough) {
            this.text = text;
            this.color = color;
            this.bold = bold;
            this.italic = italic;
            this.underlined = underlined;
            this.strikethrough = strikethrough;
        }

        public String getText() {
            return this.text;
        }

        public int getColor() {
            return this.color;
        }

        public boolean isBold() {
            return this.bold;
        }

        public boolean isItalic() {
            return this.italic;
        }

        public boolean isUnderlined() {
            return this.underlined;
        }

        public boolean isStrikethrough() {
            return this.strikethrough;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof TextSegment)) {
                return false;
            }
            TextSegment other = (TextSegment)o;
            if (!other.canEqual(this)) {
                return false;
            }
            if (this.getColor() != other.getColor()) {
                return false;
            }
            if (this.isBold() != other.isBold()) {
                return false;
            }
            if (this.isItalic() != other.isItalic()) {
                return false;
            }
            if (this.isUnderlined() != other.isUnderlined()) {
                return false;
            }
            if (this.isStrikethrough() != other.isStrikethrough()) {
                return false;
            }
            String this$text = this.getText();
            String other$text = other.getText();
            return !(this$text != null ? !this$text.equals(other$text) : other$text != null);
        }

        protected boolean canEqual(Object other) {
            return other instanceof TextSegment;
        }

        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            result = result * 59 + this.getColor();
            result = result * 59 + (this.isBold() ? 79 : 97);
            result = result * 59 + (this.isItalic() ? 79 : 97);
            result = result * 59 + (this.isUnderlined() ? 79 : 97);
            result = result * 59 + (this.isStrikethrough() ? 79 : 97);
            String $text = this.getText();
            result = result * 59 + ($text == null ? 43 : $text.hashCode());
            return result;
        }

        public String toString() {
            return "FormattedTextProcessor.TextSegment(text=" + this.getText() + ", color=" + this.getColor() + ", bold=" + this.isBold() + ", italic=" + this.isItalic() + ", underlined=" + this.isUnderlined() + ", strikethrough=" + this.isStrikethrough() + ")";
        }
    }
}

