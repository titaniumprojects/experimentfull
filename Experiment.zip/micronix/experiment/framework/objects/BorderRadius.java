/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.objects;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public record BorderRadius(float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius) {
    public static final BorderRadius ZERO = new BorderRadius(0.0f, 0.0f, 0.0f, 0.0f);

    public static BorderRadius all(float radius) {
        return new BorderRadius(radius, radius, radius, radius);
    }

    public static BorderRadius topLeft(float radius) {
        return new BorderRadius(radius, 0.0f, 0.0f, 0.0f);
    }

    public static BorderRadius topRight(float radius) {
        return new BorderRadius(0.0f, radius, 0.0f, 0.0f);
    }

    public static BorderRadius bottomRight(float radius) {
        return new BorderRadius(0.0f, 0.0f, radius, 0.0f);
    }

    public static BorderRadius bottomLeft(float radius) {
        return new BorderRadius(0.0f, 0.0f, 0.0f, radius);
    }

    public static BorderRadius top(float leftRadius, float rightRadius) {
        return new BorderRadius(leftRadius, rightRadius, 0.0f, 0.0f);
    }

    public static BorderRadius bottom(float leftRadius, float rightRadius) {
        return new BorderRadius(0.0f, 0.0f, rightRadius, leftRadius);
    }

    public static BorderRadius left(float topRadius, float bottomRadius) {
        return new BorderRadius(topRadius, 0.0f, 0.0f, bottomRadius);
    }

    public static BorderRadius right(float topRadius, float bottomRadius) {
        return new BorderRadius(0.0f, topRadius, bottomRadius, 0.0f);
    }

    public static BorderRadius sides(float radius) {
        return new BorderRadius(radius, radius, radius, radius);
    }

    @Override
    public String toString() {
        return "BorderRadius{topLeftRadius=" + this.topLeftRadius + ", topRightRadius=" + this.topRightRadius + ", bottomRightRadius=" + this.bottomRightRadius + ", bottomLeftRadius=" + this.bottomLeftRadius + "}";
    }
}

