/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.objects;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum MouseButton {
    LEFT(0),
    RIGHT(1),
    MIDDLE(2),
    BUTTON_4(3),
    BUTTON_5(4),
    BUTTON_6(5),
    BUTTON_7(6);

    private final int buttonIndex;

    public static MouseButton fromButtonIndex(int index) {
        for (MouseButton button : MouseButton.values()) {
            if (button.getButtonIndex() != index) continue;
            return button;
        }
        return LEFT;
    }

    private MouseButton(int buttonIndex) {
        this.buttonIndex = buttonIndex;
    }

    public int getButtonIndex() {
        return this.buttonIndex;
    }
}

