/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.objects.gradient.impl;

import micronix.experiment.framework.objects.gradient.Gradient;
import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class DiagonalGradient
extends Gradient {
    public DiagonalGradient(ColorRGBA startColor, ColorRGBA endColor) {
        super(startColor, endColor, endColor, startColor);
    }

    @Override
    public DiagonalGradient rotate() {
        return new DiagonalGradient(this.topRightColor, this.bottomLeftColor);
    }
}

