/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.objects.gradient.impl;

import micronix.experiment.framework.objects.gradient.Gradient;
import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class VerticalGradient
extends Gradient {
    public VerticalGradient(ColorRGBA startColor, ColorRGBA endColor) {
        super(startColor, endColor, startColor, endColor);
    }

    @Override
    public VerticalGradient rotate() {
        return new VerticalGradient(this.bottomRightColor, this.topLeftColor);
    }
}

