/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.framework.objects.gradient;

import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class Gradient {
    protected final ColorRGBA topLeftColor;
    protected final ColorRGBA bottomLeftColor;
    protected final ColorRGBA topRightColor;
    protected final ColorRGBA bottomRightColor;

    protected Gradient(ColorRGBA topLeftColor, ColorRGBA bottomLeftColor, ColorRGBA topRightColor, ColorRGBA bottomRightColor) {
        this.topLeftColor = topLeftColor;
        this.bottomLeftColor = bottomLeftColor;
        this.topRightColor = topRightColor;
        this.bottomRightColor = bottomRightColor;
    }

    public static Gradient of(ColorRGBA topLeftColor, ColorRGBA bottomLeftColor, ColorRGBA topRightColor, ColorRGBA bottomRightColor) {
        return new Gradient(topLeftColor, bottomLeftColor, topRightColor, bottomRightColor);
    }

    public Gradient rotate() {
        return this;
    }

    public ColorRGBA getTopLeftColor() {
        return this.topLeftColor;
    }

    public ColorRGBA getBottomLeftColor() {
        return this.bottomLeftColor;
    }

    public ColorRGBA getTopRightColor() {
        return this.topRightColor;
    }

    public ColorRGBA getBottomRightColor() {
        return this.bottomRightColor;
    }
}

