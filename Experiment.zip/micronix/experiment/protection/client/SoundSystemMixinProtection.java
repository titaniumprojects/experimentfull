/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1113
 *  net.minecraft.class_3417
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.protection.client;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.SoundEvent;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1113;
import net.minecraft.class_3417;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
public class SoundSystemMixinProtection {
    public static void playSound(class_1113 sound, CallbackInfo ci) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getBeacon().isSelected() && (sound.method_4775().equals((Object)class_3417.field_14703.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_15045.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_14891.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_19344.comp_3319()))) {
            ci.cancel();
        }
        if (removals.isEnabled() && removals.getWeatherSound().isSelected() && (sound.method_4775().equals((Object)class_3417.field_14946.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_15020.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_14865.comp_3319()))) {
            ci.cancel();
        }
        if (removals.isEnabled() && removals.getPhantoms().isSelected() && (sound.method_4775().equals((Object)class_3417.field_14957.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_14813.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_14729.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_14869.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_14974.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_15149.comp_3319()) || sound.method_4775().equals((Object)class_3417.field_15238.comp_3319()))) {
            ci.cancel();
        }
        Experiment.getInstance().getEventManager().triggerEvent(new SoundEvent(sound));
    }
}

