/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.protection.client;

import micronix.experiment.Experiment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.kotopushka.compiler.sdk.annotations.VMProtect;
import ru.kotopushka.compiler.sdk.enums.VMProtectType;

@Environment(value=EnvType.CLIENT)
public class MinecraftClientMixinProtection {
    @VMProtect(type=VMProtectType.MUTATION)
    public static void init() {
        Experiment.INSTANCE.initialize();
    }

    @VMProtect(type=VMProtectType.MUTATION)
    public static void shutdown() {
        Experiment.INSTANCE.shutdown();
    }

    public static void updateTitle(CallbackInfoReturnable<String> cir) {
        if (Experiment.INSTANCE.isPanic()) {
            return;
        }
        String title = "%s %s (%s)".formatted("Experiment Client", "2.0", "Beta");
        cir.setReturnValue((Object)title);
    }
}

