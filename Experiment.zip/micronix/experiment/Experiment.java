/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener
 *  net.fabricmc.fabric.api.resource.ResourceManagerHelper
 *  net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener
 *  net.minecraft.class_1043
 *  net.minecraft.class_1044
 *  net.minecraft.class_2960
 *  net.minecraft.class_3264
 *  net.minecraft.class_3300
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package micronix.experiment;

import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;
import micronix.experiment.framework.shader.GlProgram;
import micronix.experiment.systems.ai.AIPredict;
import micronix.experiment.systems.commands.CommandRegistry;
import micronix.experiment.systems.config.ConfigDropHandler;
import micronix.experiment.systems.config.ConfigManager;
import micronix.experiment.systems.discord.DiscordManager;
import micronix.experiment.systems.event.EventIntegration;
import micronix.experiment.systems.event.EventManager;
import micronix.experiment.systems.event.handlers.ServerConnectionHandler;
import micronix.experiment.systems.file.FileManager;
import micronix.experiment.systems.friends.FriendManager;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.ModuleManager;
import micronix.experiment.systems.modules.constructions.swinganim.SwingManager;
import micronix.experiment.systems.modules.constructions.swinganim.presets.SwingPresetManager;
import micronix.experiment.systems.modules.listeners.ModuleTickListener;
import micronix.experiment.systems.modules.listeners.ModuleWidgetRenderer;
import micronix.experiment.systems.notifications.NotificationManager;
import micronix.experiment.systems.poshalko.PoshalkoHandler;
import micronix.experiment.systems.target.TargetManager;
import micronix.experiment.systems.theme.ThemeManager;
import micronix.experiment.systems.waypoints.WayPointsManager;
import micronix.experiment.ui.account.AccountManager;
import micronix.experiment.ui.hud.Hud;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.utility.game.TitleBarHelper;
import micronix.experiment.utility.game.WebUtility;
import micronix.experiment.utility.game.server.TPSHandler;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.calculator.ChatListener;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationUpdateListener;
import micronix.experiment.utility.sounds.MusicTracker;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.kotopushka.compiler.sdk.annotations.Compile;
import ru.kotopushka.compiler.sdk.annotations.CompileBytecode;
import ru.kotopushka.compiler.sdk.annotations.Initialization;

@Environment(value=EnvType.CLIENT)
public enum Experiment implements IMinecraft
{
    INSTANCE;

    public static final String NAME = "Experiment";
    public static final String BUILD_TYPE = "Beta";
    public static final String VERSION = "2.0";
    public static final String MOD_ID;
    public static final Logger LOGGER;
    private EventManager eventManager;
    private ThemeManager themeManager;
    private ModuleManager moduleManager;
    private CommandRegistry commandManager;
    private FriendManager friendManager;
    private DiscordManager discordManager;
    private RotationHandler rotationHandler;
    private TargetManager targetManager;
    private MusicTracker musicTracker;
    private FileManager fileManager;
    private NotificationManager notificationManager;
    private ConfigManager configManager;
    private SwingManager swingManager;
    private TPSHandler tpsHandler;
    private AIPredict ai;
    private Hud hud;
    private ServerConnectionHandler serverConnectionHandler;
    private PoshalkoHandler poshalkoHandler;
    private WayPointsManager wayPointsManager;
    private SwingPresetManager swingPresetManager;
    private AccountManager accountManager;
    private MenuScreen menuScreen;
    private ChatListener chatListener;
    private boolean panic;

    public AccountManager getAccountManager() {
        return this.accountManager;
    }

    @Compile
    @Initialization
    public void initialize() {
        LOGGER.info("Initializing {}...", (Object)NAME);
        this.musicTracker = new MusicTracker();
        this.accountManager = new AccountManager();
        this.wayPointsManager = new WayPointsManager();
        this.eventManager = new EventManager();
        this.friendManager = new FriendManager();
        this.themeManager = new ThemeManager();
        this.discordManager = new DiscordManager();
        this.rotationHandler = new RotationHandler(new RotationUpdateListener());
        this.targetManager = new TargetManager();
        this.fileManager = new FileManager();
        this.moduleManager = new ModuleManager(new ModuleTickListener(), new ModuleWidgetRenderer());
        this.hud = new Hud();
        this.tpsHandler = new TPSHandler();
        this.notificationManager = new NotificationManager();
        this.fileManager.registerClientFiles();
        this.moduleManager.registerModules();
        this.moduleManager.enableModules();
        this.configManager = new ConfigManager();
        this.configManager.handle();
        this.commandManager = new CommandRegistry();
        this.commandManager.initCommands();
        this.swingManager = new SwingManager();
        this.swingPresetManager = new SwingPresetManager();
        this.swingPresetManager.handle();
        this.fileManager.loadClientFiles();
        ResourceManagerHelper.get((class_3264)class_3264.field_14188).registerReloadListener((IdentifiableResourceReloadListener)new SimpleSynchronousResourceReloadListener(this){

            public class_2960 getFabricId() {
                return Experiment.id("after_shader_load");
            }

            public void method_14491(class_3300 manager) {
                GlProgram.loadAndSetupPrograms();
            }
        });
        DrawUtility.initializeShaders();
        Localizator.loadTranslations();
        this.chatListener = new ChatListener();
        this.serverConnectionHandler = new ServerConnectionHandler();
        this.poshalkoHandler = new PoshalkoHandler();
        String osName = System.getProperty("os.name");
        String pcName = System.getProperty("user.name");
        if (osName.toLowerCase().contains("windows") && !pcName.equals("sheluvparis")) {
            this.discordManager.connect();
        }
        ConfigDropHandler.init();
        TitleBarHelper.setDarkTitleBar();
        new EventIntegration();
        this.createAvatar();
        LOGGER.info("{} initialized", (Object)NAME);
    }

    public void shutdown() {
        LOGGER.info("Shutting down...");
        this.fileManager.saveClientFiles();
        if (!this.isPanic()) {
            this.configManager.getAutoSaveConfig().save();
        }
        if (!this.isPanic()) {
            this.swingPresetManager.getAutoSavePreset().save();
        }
        this.setPanic(false);
    }

    public static Experiment getInstance() {
        return INSTANCE;
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655((String)MOD_ID, (String)path);
    }

    @CompileBytecode
    private void createAvatar() {
        try {
            BufferedImage bufferedImage = ImageIO.read(new URL("https://experiment.pub/api/avatars/ConeTin.jpg?t=1754613855632"));
            if (bufferedImage == null) {
                return;
            }
            class_2960 id = Experiment.id("temp/avatar");
            mc.method_1531().method_4616(id, (class_1044)new class_1043(WebUtility.bufferedImageToNativeImage(bufferedImage, true)));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public EventManager getEventManager() {
        return this.eventManager;
    }

    public ThemeManager getThemeManager() {
        return this.themeManager;
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    public CommandRegistry getCommandManager() {
        return this.commandManager;
    }

    public FriendManager getFriendManager() {
        return this.friendManager;
    }

    public DiscordManager getDiscordManager() {
        return this.discordManager;
    }

    public RotationHandler getRotationHandler() {
        return this.rotationHandler;
    }

    public TargetManager getTargetManager() {
        return this.targetManager;
    }

    public MusicTracker getMusicTracker() {
        return this.musicTracker;
    }

    public FileManager getFileManager() {
        return this.fileManager;
    }

    public NotificationManager getNotificationManager() {
        return this.notificationManager;
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public SwingManager getSwingManager() {
        return this.swingManager;
    }

    public TPSHandler getTpsHandler() {
        return this.tpsHandler;
    }

    public AIPredict getAi() {
        return this.ai;
    }

    public Hud getHud() {
        return this.hud;
    }

    public ServerConnectionHandler getServerConnectionHandler() {
        return this.serverConnectionHandler;
    }

    public PoshalkoHandler getPoshalkoHandler() {
        return this.poshalkoHandler;
    }

    public WayPointsManager getWayPointsManager() {
        return this.wayPointsManager;
    }

    public SwingPresetManager getSwingPresetManager() {
        return this.swingPresetManager;
    }

    public MenuScreen getMenuScreen() {
        return this.menuScreen;
    }

    public ChatListener getChatListener() {
        return this.chatListener;
    }

    public boolean isPanic() {
        return this.panic;
    }

    public void setMenuScreen(MenuScreen menuScreen) {
        this.menuScreen = menuScreen;
    }

    public void setPanic(boolean panic) {
        this.panic = panic;
    }

    static {
        MOD_ID = NAME.toLowerCase();
        LOGGER = LoggerFactory.getLogger((String)MOD_ID);
    }
}

