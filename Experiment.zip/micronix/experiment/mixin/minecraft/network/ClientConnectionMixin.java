/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2535
 *  net.minecraft.class_2547
 *  net.minecraft.class_2596
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.network;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.network.ReceivePacketEvent;
import micronix.experiment.systems.event.impl.network.SendPacketEvent;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_2535.class})
public class ClientConnectionMixin
implements IMinecraft {
    @Unique
    private static boolean stackOverflowFix;

    @Inject(method={"method_10759"}, at={@At(value="HEAD")}, cancellable=true)
    private static <T extends class_2547> void triggerReceivePacketEvent(class_2596<T> packet, class_2547 listener, CallbackInfo ci) {
        ReceivePacketEvent event = new ReceivePacketEvent(packet);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_10743"}, at={@At(value="HEAD")}, cancellable=true)
    public void triggerSendPacketEvent(class_2596<?> packet, CallbackInfo ci) {
        class_2596<?> newPacket;
        SendPacketEvent event = new SendPacketEvent(packet);
        if (stackOverflowFix) {
            return;
        }
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
        if ((newPacket = event.getPacket()) != packet) {
            ci.cancel();
            stackOverflowFix = true;
            mc.method_1562().method_52787(newPacket);
            stackOverflowFix = false;
        }
    }
}

