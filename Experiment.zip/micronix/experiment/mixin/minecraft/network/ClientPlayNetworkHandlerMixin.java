/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_2684
 *  net.minecraft.class_634
 *  net.minecraft.class_638
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.network;

import micronix.experiment.Experiment;
import micronix.experiment.mixin.accessors.EntityS2CPacketAccessor;
import micronix.experiment.systems.modules.modules.combat.BackTrack;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.mixins.BacktrackableEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2684;
import net.minecraft.class_634;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_634.class})
public class ClientPlayNetworkHandlerMixin
implements IMinecraft {
    @Inject(method={"method_11155"}, at={@At(value="TAIL")})
    public void onEntity(class_2684 packet, CallbackInfo ci) {
        class_634 self = (class_634)this;
        class_638 world = self.method_2890();
        if (world == null || !Experiment.getInstance().getModuleManager().getModule(BackTrack.class).isEnabled()) {
            return;
        }
        int id = ((EntityS2CPacketAccessor)packet).getId();
        class_1297 entity = world.method_8469(id);
        if (entity == null) {
            return;
        }
        double dx = (double)packet.method_36150() / 4096.0;
        double dy = (double)packet.method_36151() / 4096.0;
        double dz = (double)packet.method_36152() / 4096.0;
        class_243 newPos = entity.method_19538().method_1031(dx, dy, dz);
        if (entity instanceof BacktrackableEntity) {
            BacktrackableEntity backtrackable = (BacktrackableEntity)entity;
            backtrackable.experiment2_0$getBackTracks().add(new BackTrack.Position(newPos, System.currentTimeMillis()));
        }
    }
}

