/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10017
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 *  net.minecraft.class_897
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.entity;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Nametags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_897.class})
public abstract class EntityRendererMixin<T extends class_1297, S extends class_10017> {
    @Inject(method={"method_62426"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderLabel(T entity, CallbackInfoReturnable<class_2561> cir) {
        if (!(entity instanceof class_1657)) {
            return;
        }
        class_1657 player = (class_1657)entity;
        Nametags nameTags = Experiment.getInstance().getModuleManager().getModule(Nametags.class);
        if (nameTags.isEnabled()) {
            if (nameTags.getOffFriends().isEnabled() && Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString())) {
                return;
            }
            cir.setReturnValue(null);
        }
    }
}

