/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.entity;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.AttackEvent;
import micronix.experiment.systems.event.impl.game.PostAttackEvent;
import micronix.experiment.systems.event.impl.player.SlowDownEvent;
import micronix.experiment.systems.modules.modules.player.NoPush;
import micronix.experiment.utility.rotations.RotationHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1657.class})
public class PlayerEntityMixin {
    @Inject(method={"method_7324"}, at={@At(value="HEAD")}, cancellable=true)
    private void attackAHook2(class_1297 target, CallbackInfo ci) {
        AttackEvent event = new AttackEvent(target);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_7324"}, at={@At(value="RETURN")}, cancellable=true)
    private void attackAHook(class_1297 target, CallbackInfo ci) {
        PostAttackEvent event = new PostAttackEvent(target);
        Experiment.getInstance().getEventManager().triggerEvent(event);
    }

    @Inject(method={"method_5675"}, at={@At(value="HEAD")}, cancellable=true)
    private void removePushFromFluids(CallbackInfoReturnable<Boolean> cir) {
        NoPush noPush = Experiment.getInstance().getModuleManager().getModule(NoPush.class);
        class_1657 player = (class_1657)this;
        if (player == class_310.method_1551().field_1724 && noPush.isEnabled() && noPush.getFluids().isSelected()) {
            cir.setReturnValue((Object)false);
        }
    }

    @Redirect(method={"method_6091"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1657;method_5720()Lnet/minecraft/class_243;"))
    private class_243 redirectGetRotationVectorInTravel(class_1657 instance) {
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        return rotationHandler.isIdling() ? instance.method_5720() : rotationHandler.getCurrentRotation().getRotationVector();
    }

    @Redirect(method={"method_6091"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1657;method_6115()Z"), require=0)
    private boolean onIsUsingItemInTravel(class_1657 player) {
        if (player == class_310.method_1551().field_1724) {
            SlowDownEvent slowDownEvent = new SlowDownEvent();
            Experiment.getInstance().getEventManager().triggerEvent(slowDownEvent);
            return player.method_6115() && !slowDownEvent.isCancelled();
        }
        return player.method_6115();
    }
}

