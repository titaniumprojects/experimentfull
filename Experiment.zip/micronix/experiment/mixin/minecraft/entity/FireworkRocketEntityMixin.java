/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1309
 *  net.minecraft.class_1671
 *  net.minecraft.class_243
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package micronix.experiment.mixin.minecraft.entity;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.FireworkEvent;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.rotations.Rotation;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1671.class})
public abstract class FireworkRocketEntityMixin
implements IMinecraft {
    @Redirect(method={"method_5773"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1309;method_18799(Lnet/minecraft/class_243;)V"))
    private void redirectSetVelocity(class_1309 shooter, class_243 velocity) {
        class_1671 rocketEntity = (class_1671)this;
        FireworkEvent event = new FireworkEvent(shooter, velocity, rocketEntity);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        shooter.method_18799(event.getVelocity());
    }

    @Redirect(method={"method_5773"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1309;method_5720()Lnet/minecraft/class_243;"))
    private class_243 redirectGetRotationVector(class_1309 instance) {
        RotationHandler rotationHandler;
        if (instance == FireworkRocketEntityMixin.mc.field_1724 && (rotationHandler = Experiment.getInstance().getRotationHandler()) != null && rotationHandler.getState() != RotationState.IDLE) {
            Rotation currentRotation = rotationHandler.getCurrentRotation();
            return class_243.method_1030((float)currentRotation.getPitch(), (float)currentRotation.getYaw());
        }
        return instance.method_5720();
    }
}

