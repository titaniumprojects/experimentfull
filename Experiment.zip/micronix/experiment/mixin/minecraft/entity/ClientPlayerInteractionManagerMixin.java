/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_310
 *  net.minecraft.class_3965
 *  net.minecraft.class_636
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.entity;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.BlockBreakEvent;
import micronix.experiment.systems.event.impl.game.InternalAttackEvent;
import micronix.experiment.systems.event.impl.game.StartBreakBlockEvent;
import micronix.experiment.systems.modules.modules.player.NoInteract;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_636.class})
public class ClientPlayerInteractionManagerMixin {
    @Shadow
    @Final
    private class_310 field_3712;

    @Inject(method={"method_2918"}, at={@At(value="HEAD")}, cancellable=true)
    private void experiment$critPre(class_1657 player, class_1297 target, CallbackInfo ci) {
        InternalAttackEvent event = new InternalAttackEvent(target);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_2899"}, at={@At(value="RETURN")}, cancellable=true)
    public void breakBlockHook(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        BlockBreakEvent event = new BlockBreakEvent(pos);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            cir.setReturnValue((Object)false);
        }
    }

    @Inject(method={"method_2910"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAttackBlock(class_2338 blockPos, class_2350 direction, CallbackInfoReturnable<Boolean> info) {
        StartBreakBlockEvent event = new StartBreakBlockEvent(blockPos);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method={"method_2896"}, at={@At(value="HEAD")}, cancellable=true)
    public void preventInteraction(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (this.field_3712.field_1687 == null) {
            return;
        }
        NoInteract noInteractModule = Experiment.getInstance().getModuleManager().getModule(NoInteract.class);
        class_2248 block = this.field_3712.field_1687.method_8320(hitResult.method_17777()).method_26204();
        if (noInteractModule.isEnabled() && noInteractModule.shouldPreventInteract(block)) {
            cir.setReturnValue((Object)class_1269.field_5811);
        }
    }
}

