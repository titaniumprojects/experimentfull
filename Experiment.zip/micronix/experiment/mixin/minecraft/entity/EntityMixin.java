/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_238
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.combat.BackTrack;
import micronix.experiment.systems.modules.modules.combat.Hitboxes;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.mixins.BacktrackableEntity;
import micronix.experiment.utility.rotations.MoveCorrection;
import micronix.experiment.utility.rotations.RotationHandler;
import micronix.experiment.utility.rotations.RotationTask;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1297.class})
public class EntityMixin
implements IMinecraft,
BacktrackableEntity {
    private class_238 field_6005;
    @Unique
    private final List<BackTrack.Position> backTracks = new ArrayList<BackTrack.Position>();

    @ModifyExpressionValue(method={"method_5784"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1297;method_65038()Z")})
    public boolean fixFalldistanceValue(boolean original) {
        if ((class_1297)this == EntityMixin.mc.field_1724) {
            return false;
        }
        return original;
    }

    @Inject(method={"method_5829"}, at={@At(value="HEAD")}, cancellable=true)
    public final void getBoundingBox(CallbackInfoReturnable<class_238> cir) {
        Hitboxes hitbox = Experiment.getInstance().getModuleManager().getModule(Hitboxes.class);
        class_1297 entity = (class_1297)this;
        if (entity instanceof class_1309) {
            class_1309 livingEntity = (class_1309)entity;
            if (hitbox.isEnabled() && hitbox.shouldModifyHitbox(livingEntity) && entity.method_5628() != EntityMixin.mc.field_1724.method_5628()) {
                cir.setReturnValue((Object)new class_238(this.field_6005.field_1323 - (double)hitbox.getScale().getCurrentValue(), this.field_6005.field_1322, this.field_6005.field_1321 - (double)hitbox.getScale().getCurrentValue(), this.field_6005.field_1320 + (double)hitbox.getScale().getCurrentValue(), this.field_6005.field_1325, this.field_6005.field_1324 + (double)hitbox.getScale().getCurrentValue()));
            }
        }
    }

    @Redirect(method={"method_5724"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1297;method_36454()F"))
    public float movementCorrection(class_1297 instance) {
        RotationHandler rotationHandler = Experiment.INSTANCE.getRotationHandler();
        RotationTask currentTask = rotationHandler.getCurrentTask();
        if (currentTask != null && currentTask.getMoveCorrection() != MoveCorrection.NONE && instance instanceof class_746) {
            return rotationHandler.getCurrentRotation().getYaw();
        }
        return instance.method_36454();
    }

    @Override
    public List<BackTrack.Position> experiment2_0$getBackTracks() {
        return this.backTracks;
    }
}

