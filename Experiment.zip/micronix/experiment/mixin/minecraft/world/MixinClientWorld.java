/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_638
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.world;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Ambience;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_638.class})
public class MixinClientWorld {
    @Inject(method={"method_23777"}, at={@At(value="RETURN")}, cancellable=true)
    private void onGetSkyColor(class_243 cameraPos, float tickDelta, CallbackInfoReturnable<Integer> cir) {
        Ambience ambience = Experiment.getInstance().getModuleManager().getModule(Ambience.class);
        if (ambience != null && ambience.isEnabled() && ambience.getCustomSkyColor().isEnabled()) {
            int originalColor = (Integer)cir.getReturnValue();
            class_243 vecColor = new class_243((double)(originalColor >> 16 & 0xFF) / 255.0, (double)(originalColor >> 8 & 0xFF) / 255.0, (double)(originalColor & 0xFF) / 255.0);
            class_243 customVecColor = ambience.getSkyColor(vecColor);
            int customColor = (int)(customVecColor.field_1352 * 255.0) << 16 | (int)(customVecColor.field_1351 * 255.0) << 8 | (int)(customVecColor.field_1350 * 255.0);
            cir.setReturnValue((Object)customColor);
        }
    }
}

