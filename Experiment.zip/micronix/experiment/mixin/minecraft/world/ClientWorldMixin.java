/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2680
 *  net.minecraft.class_638
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.world;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.XRay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_638.class})
public abstract class ClientWorldMixin {
    @Inject(method={"method_41928"}, at={@At(value="HEAD")})
    private void onHandleBlockUpdate(class_2338 pos, class_2680 state, int flags, CallbackInfo ci) {
        XRay xrayModule = Experiment.getInstance().getModuleManager().getModule(XRay.class);
        if (xrayModule == null || !xrayModule.isEnabled()) {
            return;
        }
        class_2248 block = state.method_26204();
        class_2338 immutablePos = pos.method_10062();
        if (xrayModule.isBlockEnabled(block)) {
            xrayModule.getCachedBlocks().add(immutablePos);
        } else {
            xrayModule.getCachedBlocks().remove(immutablePos);
        }
    }
}

