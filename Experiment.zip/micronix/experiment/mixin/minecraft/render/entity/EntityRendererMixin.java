/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_4604
 *  net.minecraft.class_8113$class_8122
 *  net.minecraft.class_897
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.render.entity;

import micronix.experiment.systems.modules.modules.other.CounterMine;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_8113;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_897.class})
public class EntityRendererMixin<T extends class_1297> {
    @Inject(method={"method_3933"}, at={@At(value="HEAD")}, cancellable=true)
    private void onShouldRender(T entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        class_8113.class_8122 itemDisplay;
        if (entity instanceof class_8113.class_8122 && CounterMine.shouldHideEntity(itemDisplay = (class_8113.class_8122)entity)) {
            cir.setReturnValue((Object)false);
        }
    }
}

