/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10017
 *  net.minecraft.class_10042
 *  net.minecraft.class_1297
 *  net.minecraft.class_1531
 *  net.minecraft.class_1921
 *  net.minecraft.class_2960
 *  net.minecraft.class_3887
 *  net.minecraft.class_4587
 *  net.minecraft.class_4588
 *  net.minecraft.class_583
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 */
package micronix.experiment.mixin.minecraft.render.entity.feature;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.AntiInvisible;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.mixins.EntityRenderStateAddition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_3887.class})
public abstract class FeatureRendererMixin {
    @Unique
    private static final AntiInvisible ANTI_INVISIBLE_MODULE = Experiment.getInstance().getModuleManager().getModule(AntiInvisible.class);

    @WrapOperation(method={"method_23199"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_583;method_62100(Lnet/minecraft/class_4587;Lnet/minecraft/class_4588;III)V")})
    private static void changeModelColor(class_583<?> instance, class_4587 matrixStack, class_4588 vertexConsumer, int light, int overlay, int color, Operation<Void> original, @Local(argsOnly=true) class_10042 state) {
        if (ANTI_INVISIBLE_MODULE.isEnabled() && ANTI_INVISIBLE_MODULE.shouldModifyOpacity((class_10017)state)) {
            class_1297 entity = ((EntityRenderStateAddition)state).experiment$getEntity();
            color = entity instanceof class_1531 ? Colors.WHITE.withAlpha(0.0f).getRGB() : Colors.WHITE.withAlpha(ANTI_INVISIBLE_MODULE.getOpacity().getCurrentValue() / 100.0f * 255.0f).getRGB();
        }
        original.call(new Object[]{instance, matrixStack, vertexConsumer, light, overlay, color});
    }

    @WrapOperation(method={"method_23199"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1921;method_23578(Lnet/minecraft/class_2960;)Lnet/minecraft/class_1921;")})
    private static class_1921 changeModelRenderLayer(class_2960 texture, Operation<class_1921> original, @Local(argsOnly=true) class_10042 state) {
        if (ANTI_INVISIBLE_MODULE.isEnabled() && ANTI_INVISIBLE_MODULE.shouldModifyOpacity((class_10017)state)) {
            return class_1921.method_29379((class_2960)texture);
        }
        return (class_1921)original.call(new Object[]{texture});
    }
}

