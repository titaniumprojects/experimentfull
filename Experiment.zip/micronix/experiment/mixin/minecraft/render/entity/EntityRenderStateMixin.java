/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10017
 *  net.minecraft.class_1297
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package micronix.experiment.mixin.minecraft.render.entity;

import micronix.experiment.utility.mixins.EntityRenderStateAddition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_10017.class})
public abstract class EntityRenderStateMixin
implements EntityRenderStateAddition {
    @Unique
    private class_1297 experiment$entity;

    @Override
    @Unique
    public void experiment$setEntity(class_1297 entity) {
        this.experiment$entity = entity;
    }

    @Override
    @Unique
    public class_1297 experiment$getEntity() {
        return this.experiment$entity;
    }
}

