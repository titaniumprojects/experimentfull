/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1306
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_742
 *  net.minecraft.class_759
 *  net.minecraft.class_811
 *  net.minecraft.class_918
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.render.item;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.render.HandRenderEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_759.class})
public abstract class HeldItemRendererMixin {
    @Shadow
    @Final
    private class_918 field_4044;

    @Shadow
    protected abstract void method_3218(class_4587 var1, float var2, class_1306 var3, class_1799 var4, class_1657 var5);

    @Shadow
    protected abstract void method_49340(class_4587 var1, float var2, class_1306 var3, class_1799 var4, class_1657 var5, float var6);

    @Inject(method={"method_3228"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        boolean isMainHand = hand == class_1268.field_5808;
        class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
        boolean isRightArm = arm == class_1306.field_6183;
        matrices.method_22903();
        HandRenderEvent event = new HandRenderEvent(arm, hand, swingProgress, item, equipProgress, matrices);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
            float f = -0.4f * class_3532.method_15374((float)(class_3532.method_15355((float)0.0f) * (float)Math.PI));
            float g = 0.2f * class_3532.method_15374((float)(class_3532.method_15355((float)0.0f) * ((float)Math.PI * 2)));
            float h = -0.2f * class_3532.method_15374((float)0.0f);
            matrices.method_46416((float)(arm == class_1306.field_6183 ? 1 : -1) * f, g, h);
            int i = arm == class_1306.field_6183 ? 1 : -1;
            matrices.method_46416((float)i * 0.56f, -0.52f, -0.72f);
            if (!item.method_7960()) {
                class_759 rendererInstance = (class_759)this;
                rendererInstance.method_3233((class_1309)player, item, isRightArm ? class_811.field_4322 : class_811.field_4321, !isRightArm, matrices, vertexConsumers, light);
            }
            matrices.method_22909();
        }
    }

    @Inject(method={"method_3228"}, at={@At(value="RETURN")})
    private void onRenderFirstPersonItemEnd(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        matrices.method_22909();
    }
}

