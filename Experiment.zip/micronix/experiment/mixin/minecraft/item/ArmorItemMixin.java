/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1738
 *  net.minecraft.class_1741
 *  net.minecraft.class_1792$class_1793
 *  net.minecraft.class_8051
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.item;

import micronix.experiment.utility.mixins.ArmorItemAddition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_8051;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1738.class})
public abstract class ArmorItemMixin
implements ArmorItemAddition {
    @Unique
    private class_8051 experiment$type;
    @Unique
    private class_1741 experiment$material;

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    public void saveArgs(class_1741 material, class_8051 type, class_1792.class_1793 settings, CallbackInfo ci) {
        this.experiment$type = type;
        this.experiment$material = material;
    }

    @Override
    public class_1741 experiment$getMaterial() {
        return this.experiment$material;
    }

    @Override
    public class_8051 experiment$getType() {
        return this.experiment$type;
    }
}

