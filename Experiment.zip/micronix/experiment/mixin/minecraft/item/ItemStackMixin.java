/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1937
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.item;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.FinishEatEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1799.class})
public abstract class ItemStackMixin {
    @Inject(method={"method_7910"}, at={@At(value="TAIL")})
    private void onFinishUsing(class_1937 world, class_1309 user, CallbackInfoReturnable<class_1799> cir) {
        if (user instanceof class_1657) {
            class_1657 player = (class_1657)user;
            Experiment.getInstance().getEventManager().triggerEvent(new FinishEatEvent(player, (class_1799)this));
        }
    }
}

