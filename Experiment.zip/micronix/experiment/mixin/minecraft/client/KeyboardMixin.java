/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_309
 *  net.minecraft.class_408
 *  net.minecraft.class_437
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.window.KeyPressEvent;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_309;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_309.class})
public class KeyboardMixin
implements IMinecraft {
    @Inject(method={"method_1466"}, at={@At(value="HEAD")})
    public void triggerKeyEvent(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (key == -1) {
            return;
        }
        Experiment.getInstance().getEventManager().triggerEvent(new KeyPressEvent(action, key));
        if (KeyboardMixin.mc.field_1755 != null) {
            return;
        }
        if (key == 46 && action == 1) {
            mc.method_1507((class_437)new class_408(""));
        }
    }
}

