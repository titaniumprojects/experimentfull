/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1293
 *  net.minecraft.class_310
 *  net.minecraft.class_6880
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client;

import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.ui.components.animated.AnimatedNumber;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.mixins.StatusEffectInstanceAddition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1293.class})
public class StatusEffectInstanceMixin
implements StatusEffectInstanceAddition {
    @Unique
    private final Animation potionStatusAnimation = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    @Unique
    private AnimatedNumber timeAnimation;

    @Inject(method={"<init>(Lnet/minecraft/class_6880;IIZZZLnet/minecraft/class_1293;)V"}, at={@At(value="TAIL")})
    public void onInit(class_6880<?> effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon, class_1293 hiddenEffect, CallbackInfo ci) {
        if (class_310.method_1551() == null || class_310.method_1551().field_1724 == null) {
            return;
        }
        this.timeAnimation = new AnimatedNumber(Fonts.REGULAR.getFont(7.0f), 3.0f, 300L, Easing.FIGMA_EASE_IN_OUT);
    }

    @Override
    public Animation experiment$getAnimPotion() {
        return this.potionStatusAnimation;
    }

    @Override
    public AnimatedNumber experiment$getTimeAnimation() {
        return this.timeAnimation;
    }
}

