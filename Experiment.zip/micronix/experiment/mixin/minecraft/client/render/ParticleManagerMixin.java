/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_2680
 *  net.minecraft.class_702
 *  net.minecraft.class_703
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client.render;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_702.class})
public abstract class ParticleManagerMixin {
    @Inject(method={"method_3046"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAddBlockBreakParticles(class_2338 blockPos, class_2680 state, CallbackInfo info) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getBreakParticles().isSelected()) {
            info.cancel();
        }
    }

    @Inject(method={"method_3054"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAddBlockBreakingParticles(class_2338 blockPos, class_2350 direction, CallbackInfo info) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getBreakParticles().isSelected()) {
            info.cancel();
        }
    }

    @Inject(method={"method_3056"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAddParticle(class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<class_703> cir) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getWeather().isSelected() && parameters.method_10295() == class_2398.field_11242) {
            cir.cancel();
        }
    }
}

