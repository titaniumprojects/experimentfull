/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10017
 *  net.minecraft.class_10042
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 *  net.minecraft.class_1921
 *  net.minecraft.class_2960
 *  net.minecraft.class_4587
 *  net.minecraft.class_4588
 *  net.minecraft.class_572
 *  net.minecraft.class_583
 *  net.minecraft.class_746
 *  net.minecraft.class_922
 *  org.joml.Vector3f
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 */
package micronix.experiment.mixin.minecraft.client.render.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import micronix.experiment.Experiment;
import micronix.experiment.mixin.accessors.BipedEntityModelAccessor;
import micronix.experiment.systems.modules.modules.visuals.AntiInvisible;
import micronix.experiment.systems.modules.modules.visuals.FriendMarkers;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.countermine.AntiAim;
import micronix.experiment.utility.mixins.EntityRenderStateAddition;
import micronix.experiment.utility.rotations.RotationHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_746;
import net.minecraft.class_922;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_922.class})
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
    @Unique
    private static final AntiInvisible ANTI_INVISIBLE_MODULE = Experiment.getInstance().getModuleManager().getModule(AntiInvisible.class);

    @Shadow
    public abstract class_2960 method_3885(S var1);

    @ModifyExpressionValue(method={"method_62355"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_922;method_62482(Lnet/minecraft/class_1309;FF)F")})
    public float changeYaw(float oldValue, class_1309 entity) {
        if (!(entity instanceof class_746) || AntiAim.FORCE) {
            return oldValue;
        }
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        float yaw = rotationHandler.isIdling() ? oldValue : rotationHandler.getRenderRotation().getYaw();
        rotationHandler.getServerRotation().setYaw(yaw);
        return yaw;
    }

    @ModifyExpressionValue(method={"method_62355"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_3532;method_17821(FFF)F")})
    public float changeHeadYaw(float oldValue, class_1309 entity) {
        if (!(entity instanceof class_746) || AntiAim.FORCE) {
            return oldValue;
        }
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        float yaw = rotationHandler.isIdling() ? oldValue : rotationHandler.getRenderRotation().getYaw();
        rotationHandler.getServerRotation().setYaw(yaw);
        return yaw;
    }

    @ModifyExpressionValue(method={"method_62355"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1309;method_61414(F)F")})
    public float changePitch(float oldValue, class_1309 entity) {
        if (!(entity instanceof class_746) || AntiAim.FORCE) {
            return oldValue;
        }
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        float pitch = rotationHandler.isIdling() ? oldValue : rotationHandler.getRenderRotation().getPitch();
        rotationHandler.getServerRotation().setYaw(pitch);
        return pitch;
    }

    @WrapOperation(method={"method_4054"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_583;method_62100(Lnet/minecraft/class_4587;Lnet/minecraft/class_4588;III)V")})
    private void changeModelColor(class_583<?> instance, class_4587 matrixStack, class_4588 vertexConsumer, int light, int overlay, int color, Operation<Void> original, @Local(argsOnly=true) S livingEntityRenderState) {
        class_1297 entity;
        if (ANTI_INVISIBLE_MODULE.isEnabled() && ANTI_INVISIBLE_MODULE.shouldModifyOpacity((class_10017)livingEntityRenderState)) {
            entity = ((EntityRenderStateAddition)livingEntityRenderState).experiment$getEntity();
            color = entity instanceof class_1531 ? Colors.WHITE.withAlpha(0.0f).getRGB() : Colors.WHITE.withAlpha(ANTI_INVISIBLE_MODULE.getOpacity().getCurrentValue() / 100.0f * 255.0f).getRGB();
        }
        entity = ((EntityRenderStateAddition)livingEntityRenderState).experiment$getEntity();
        FriendMarkers markers = Experiment.getInstance().getModuleManager().getModule(FriendMarkers.class);
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (instance instanceof class_572) {
                class_572 model = (class_572)instance;
                if (markers.isEnabled() && markers.getHeads().isSelected() && Experiment.getInstance().getFriendManager().isFriend(player.method_5477().getString())) {
                    BipedEntityModelAccessor accessor = (BipedEntityModelAccessor)model;
                    float scale = 1.09f;
                    accessor.experiment$getHead().method_41924(new Vector3f(scale, scale, scale));
                    original.call(new Object[]{instance, matrixStack, vertexConsumer, light, overlay, color});
                }
            }
        }
        original.call(new Object[]{instance, matrixStack, vertexConsumer, light, overlay, color});
    }

    @ModifyReturnValue(method={"method_24302"}, at={@At(value="RETURN")})
    private class_1921 changeRenderLayer(class_1921 original, S state, boolean showBody, boolean translucent, boolean showOutline) {
        if (ANTI_INVISIBLE_MODULE.isEnabled() && !showBody && !translucent && !showOutline) {
            ((class_10042)state).field_53333 = false;
            return class_1921.method_29379((class_2960)this.method_3885(state));
        }
        return original;
    }
}

