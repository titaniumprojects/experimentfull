/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_243
 *  net.minecraft.class_761
 *  net.minecraft.class_9909
 *  net.minecraft.class_9958
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.render;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_761;
import net.minecraft.class_9909;
import net.minecraft.class_9958;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_761.class})
public abstract class WeatherRendererMixin {
    @Inject(method={"method_62203"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderWeather(class_9909 frameGraphBuilder, class_243 pos, float tickDelta, class_9958 fog, CallbackInfo ci) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getWeather().isSelected()) {
            ci.cancel();
        }
    }
}

