/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_7172
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client.option;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Ambience;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_7172.class})
public class SimpleOptionMixin<T> {
    @Shadow
    @Final
    class_2561 field_38280;
    @Shadow
    T field_37868;

    @Inject(method={"method_41753"}, at={@At(value="HEAD")}, cancellable=true)
    public void getGammaValue(CallbackInfoReturnable<Double> cir) {
        if (Experiment.getInstance().getModuleManager() == null) {
            return;
        }
        Ambience ambienceModule = Experiment.getInstance().getModuleManager().getModule(Ambience.class);
        if (ambienceModule.isEnabled() && ambienceModule.getBright().isEnabled() && this.field_38280.equals((Object)class_2561.method_43471((String)"options.gamma"))) {
            cir.setReturnValue((Object)1337.0);
        }
    }

    @Inject(method={"method_41748"}, at={@At(value="HEAD")}, cancellable=true)
    public void setGammaValue(T value, CallbackInfo ci) {
        if (this.field_38280.equals((Object)class_2561.method_43471((String)"options.gamma"))) {
            this.field_37868 = value;
            ci.cancel();
        }
    }
}

