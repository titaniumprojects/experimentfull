/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 *  net.minecraft.class_542
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client;

import micronix.experiment.Experiment;
import micronix.experiment.protection.client.MinecraftClientMixinProtection;
import micronix.experiment.systems.event.impl.game.GameTickEvent;
import micronix.experiment.systems.modules.modules.player.NoDelay;
import micronix.experiment.utility.render.penis.PenisAtlas;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_310.class})
public class MinecraftClientMixin {
    @Shadow
    private int field_1752;

    @Inject(method={"method_1574"}, at={@At(value="HEAD")})
    public void tick(CallbackInfo ci) {
        Experiment.getInstance().getEventManager().triggerEvent(new GameTickEvent());
    }

    @Inject(method={"<init>"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_310;method_15993()V")})
    public void initializeClient(class_542 args, CallbackInfo ci) {
        MinecraftClientMixinProtection.init();
    }

    @Inject(method={"<init>"}, at={@At(value="RETURN")})
    public void endInitialize(class_542 args, CallbackInfo ci) {
        PenisAtlas atlas = PenisAtlas.getOrCreateAtlasFor(16, 16);
        atlas.registerAnimationFromPenisFile(Experiment.id("penises/combat.penis"));
        atlas.registerAnimationFromPenisFile(Experiment.id("penises/movement.penis"));
        atlas.registerAnimationFromPenisFile(Experiment.id("penises/visuals.penis"));
        atlas.registerAnimationFromPenisFile(Experiment.id("penises/player.penis"));
        atlas.registerAnimationFromPenisFile(Experiment.id("penises/other.penis"));
        atlas.registerAnimationFromPenisFile(Experiment.id("penises/search.penis"));
        atlas.buildAtlas();
        PenisAtlas atlas12 = PenisAtlas.getOrCreateAtlasFor(12, 12);
        atlas12.registerAnimationFromPenisFile(Experiment.id("penises/check_enable.penis"));
        atlas12.registerAnimationFromPenisFile(Experiment.id("penises/check_disable.penis"));
        atlas12.buildAtlas();
    }

    @Inject(method={"method_1490"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_310;close()V", shift=At.Shift.AFTER)})
    public void shutdownClient(CallbackInfo ci) {
        MinecraftClientMixinProtection.shutdown();
    }

    @Inject(method={"method_24287"}, at={@At(value="HEAD")}, cancellable=true)
    public void changeWindowTitle(CallbackInfoReturnable<String> cir) {
        MinecraftClientMixinProtection.updateTitle(cir);
    }

    @Inject(method={"method_1583"}, at={@At(value="TAIL")})
    private void resetItemUseCooldown(CallbackInfo ci) {
        NoDelay noDelayModule = Experiment.getInstance().getModuleManager().getModule(NoDelay.class);
        if (noDelayModule.isEnabled() && noDelayModule.getRightClick().isEnabled()) {
            this.field_1752 = 0;
        }
    }
}

