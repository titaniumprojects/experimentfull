/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10185
 *  net.minecraft.class_744
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package micronix.experiment.mixin.minecraft.client.input;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_744.class})
public interface InputAccessor {
    @Accessor(value="field_3905")
    public float getMovementForward();

    @Accessor(value="field_3905")
    public void setMovementForward(float var1);

    @Accessor(value="field_3907")
    public float getMovementSideways();

    @Accessor(value="field_3907")
    public void setMovementSideways(float var1);

    @Accessor(value="field_54155")
    public class_10185 getInput();

    @Accessor(value="field_54155")
    public void setInput(class_10185 var1);
}

