/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_10185
 *  net.minecraft.class_743
 *  net.minecraft.class_744
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.input;

import micronix.experiment.Experiment;
import micronix.experiment.mixin.minecraft.client.input.InputAccessor;
import micronix.experiment.systems.event.impl.player.InputEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_743.class})
public abstract class KeyboardInputMixin {
    @Inject(method={"method_3129"}, at={@At(value="TAIL")})
    private void onTick(CallbackInfo ci) {
        class_744 input = (class_744)this;
        InputAccessor accessor = (InputAccessor)input;
        class_10185 keys = accessor.getInput();
        float movementForward = accessor.getMovementForward();
        float movementSideways = accessor.getMovementSideways();
        boolean jumping = accessor.getInput().comp_3163();
        boolean sneaking = accessor.getInput().comp_3164();
        boolean sprint = accessor.getInput().comp_3165();
        InputEvent event = new InputEvent(movementForward, movementSideways, jumping, sneaking, sprint);
        Experiment.getInstance().getEventManager().triggerEvent(event);
        accessor.setMovementForward(event.getForward());
        accessor.setMovementSideways(event.getStrafe());
        boolean forwardKey = event.getForward() > 0.0f;
        boolean backwardKey = event.getForward() < 0.0f;
        boolean leftKey = event.getStrafe() > 0.0f;
        boolean rightKey = event.getStrafe() < 0.0f;
        accessor.setInput(new class_10185(forwardKey, backwardKey, leftKey, rightKey, event.isJump(), event.isSneak(), event.isSprint()));
    }
}

