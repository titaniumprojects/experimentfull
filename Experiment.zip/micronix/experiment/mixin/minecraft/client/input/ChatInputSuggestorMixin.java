/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.suggestion.Suggestions
 *  javax.annotation.Nullable
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_342
 *  net.minecraft.class_4717
 *  net.minecraft.class_4717$class_464
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.input;

import com.mojang.brigadier.suggestion.Suggestions;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import javax.annotation.Nullable;
import micronix.experiment.Experiment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_342;
import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_4717.class})
public abstract class ChatInputSuggestorMixin {
    @Shadow
    @Final
    class_342 field_21599;
    @Shadow
    private CompletableFuture<Suggestions> field_21611;
    @Shadow
    @Nullable
    private class_4717.class_464 field_21612;

    @Shadow
    public abstract void method_23920(boolean var1);

    @Inject(method={"method_23934"}, at={@At(value="INVOKE", target="Lcom/mojang/brigadier/StringReader;canRead()Z", remap=false)}, cancellable=true)
    private void injectAutoCompletion(CallbackInfo ci) {
        String prefix;
        String text = this.field_21599.method_1882();
        if (text.startsWith(prefix = Experiment.getInstance().getCommandManager().getPrefix())) {
            this.field_21611 = Experiment.getInstance().getCommandManager().autoComplete(text, this.field_21599.method_1881());
            this.field_21611.thenRun(() -> {
                try {
                    if (this.field_21611.isDone() && !this.field_21611.get().isEmpty() && this.field_21612 == null) {
                        this.method_23920(false);
                        ci.cancel();
                    }
                }
                catch (InterruptedException | ExecutionException exception) {
                    // empty catch block
                }
            });
        }
    }
}

