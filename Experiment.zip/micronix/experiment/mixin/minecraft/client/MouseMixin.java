/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_312
 *  org.lwjgl.glfw.GLFW
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.window.MouseEvent;
import micronix.experiment.systems.event.impl.window.MouseScrollEvent;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_312;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_312.class})
public class MouseMixin
implements IMinecraft {
    @Inject(method={"method_55793"}, at={@At(value="RETURN")})
    private void tick(CallbackInfo ci) {
        if (CursorUtility.getCurrentType() != CursorUtility.getPrev()) {
            GLFW.glfwSetCursor((long)mc.method_22683().method_4490(), (long)CursorUtility.getCurrentType().getCode());
        }
        CursorUtility.setPrev(CursorUtility.getCurrentType());
        CursorUtility.set(CursorType.DEFAULT);
    }

    @Inject(method={"method_1601"}, at={@At(value="HEAD")})
    private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (action == 1) {
            Experiment.getInstance().getEventManager().triggerEvent(new MouseEvent(button, action));
        }
    }

    @Inject(method={"method_1598"}, at={@At(value="HEAD")})
    private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (vertical != 0.0) {
            Experiment.getInstance().getEventManager().triggerEvent(new MouseScrollEvent(vertical));
        }
    }
}

