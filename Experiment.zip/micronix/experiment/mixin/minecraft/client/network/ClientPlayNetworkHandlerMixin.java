/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1542
 *  net.minecraft.class_2338
 *  net.minecraft.class_2535
 *  net.minecraft.class_2586
 *  net.minecraft.class_2622
 *  net.minecraft.class_2672
 *  net.minecraft.class_2678
 *  net.minecraft.class_2708
 *  net.minecraft.class_2775
 *  net.minecraft.class_2818
 *  net.minecraft.class_310
 *  net.minecraft.class_634
 *  net.minecraft.class_8673
 *  net.minecraft.class_8675
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.network;

import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.PickupEvent;
import micronix.experiment.systems.event.impl.game.WorldChangeEvent;
import micronix.experiment.systems.modules.modules.visuals.XRay;
import micronix.experiment.utility.game.WorldUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.rotations.Rotation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_2338;
import net.minecraft.class_2535;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2672;
import net.minecraft.class_2678;
import net.minecraft.class_2708;
import net.minecraft.class_2775;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_634.class})
public abstract class ClientPlayNetworkHandlerMixin
extends class_8673
implements IMinecraft {
    @Unique
    private Rotation oldRotation = Rotation.ZERO;

    protected ClientPlayNetworkHandlerMixin(class_310 client, class_2535 connection, class_8675 connectionState) {
        super(client, connection, connectionState);
    }

    @Inject(method={"method_11150"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_638;method_8469(I)Lnet/minecraft/class_1297;", ordinal=0)})
    private void onItemPickupAnimation(class_2775 packet, CallbackInfo info) {
        class_1297 itemEntity = this.field_45588.field_1687.method_8469(packet.method_11915());
        class_1297 entity = this.field_45588.field_1687.method_8469(packet.method_11912());
        if (itemEntity instanceof class_1542 && entity == this.field_45588.field_1724) {
            Experiment.getInstance().getEventManager().triggerEvent(new PickupEvent(((class_1542)itemEntity).method_6983(), packet.method_11913()));
        }
    }

    @Inject(method={"method_11094"}, at={@At(value="TAIL")})
    private void onBlockEntityUpdate(class_2622 packet, CallbackInfo ci) {
        if (ClientPlayNetworkHandlerMixin.mc.field_1687 == null) {
            return;
        }
        class_2338 pos = packet.method_11293();
        class_2586 blockEntity = ClientPlayNetworkHandlerMixin.mc.field_1687.method_8321(pos);
        if (blockEntity != null && !WorldUtility.blockEntities.contains(blockEntity)) {
            WorldUtility.blockEntities.add(blockEntity);
        }
    }

    @Inject(method={"method_11128"}, at={@At(value="TAIL")})
    private void onChunkData(class_2672 packet, CallbackInfo ci) {
        if (ClientPlayNetworkHandlerMixin.mc.field_1687 == null) {
            return;
        }
        class_2818 chunk = ClientPlayNetworkHandlerMixin.mc.field_1687.method_8497(packet.method_11523(), packet.method_11524());
        chunk.method_12214().values().forEach(be -> {
            if (!WorldUtility.blockEntities.contains(be)) {
                WorldUtility.blockEntities.add((class_2586)be);
            }
        });
        XRay xray = Experiment.getInstance().getModuleManager().getModule(XRay.class);
        class_310 mc = class_310.method_1551();
        if (xray == null || !xray.isEnabled() || mc.field_1687 == null) {
            return;
        }
        new Thread(() -> xray.scanChunk(chunk)).start();
    }

    @Inject(method={"method_11120"}, at={@At(value="TAIL")})
    private void onGameJoin(class_2678 packet, CallbackInfo ci) {
        WorldUtility.blockEntities.clear();
        Experiment.getInstance().getEventManager().triggerEvent(new WorldChangeEvent());
    }

    @Inject(method={"method_11157"}, at={@At(value="HEAD")})
    public void savePlayerRotation(class_2708 packet, CallbackInfo ci) {
        if (ClientPlayNetworkHandlerMixin.mc.field_1724 == null) {
            return;
        }
        this.oldRotation = new Rotation(ClientPlayNetworkHandlerMixin.mc.field_1724.method_36454(), ClientPlayNetworkHandlerMixin.mc.field_1724.method_36455());
    }

    @Inject(method={"method_11157"}, at={@At(value="RETURN")})
    public void modifyPlayerRotation(class_2708 packet, CallbackInfo ci) {
        if (ClientPlayNetworkHandlerMixin.mc.field_1724 == null) {
            return;
        }
        Rotation realServerRotation = new Rotation(packet.comp_3228().comp_3150(), packet.comp_3228().comp_3151());
    }
}

