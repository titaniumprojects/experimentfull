/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.v2.WrapWithCondition
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client.network;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import micronix.experiment.Experiment;
import micronix.experiment.systems.event.impl.game.CloseScreenEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEndEvent;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.event.impl.player.SlowDownEvent;
import micronix.experiment.systems.modules.modules.combat.Aura;
import micronix.experiment.systems.modules.modules.player.InvUtils;
import micronix.experiment.systems.modules.modules.player.NoPush;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.mixins.ClientPlayerEntityAddition;
import micronix.experiment.utility.rotations.RotationHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_746.class})
public class ClientPlayerEntityMixin
implements ClientPlayerEntityAddition,
IMinecraft {
    @Unique
    private int groundTicks = 0;
    @Unique
    private final Aura aura = Experiment.getInstance().getModuleManager().getModule(Aura.class);

    @Redirect(method={"method_6007"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_746;method_6115()Z"), require=0)
    private boolean onIsUsingItemRedirect(class_746 player) {
        SlowDownEvent slowDownEvent = new SlowDownEvent();
        Experiment.getInstance().getEventManager().triggerEvent(slowDownEvent);
        return player.method_6115() && player.method_5854() == null && !slowDownEvent.isCancelled();
    }

    @ModifyExpressionValue(method={"method_6007"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_304;method_1434()Z")})
    public boolean unpressSprintKey(boolean original) {
        if (this.aura.isEnabled() && this.aura.shouldPreventSprinting()) {
            return false;
        }
        return original;
    }

    @ModifyExpressionValue(method={"method_6007"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_746;method_46743()Z")})
    private boolean disallowSprinting(boolean original) {
        if (this.aura.isEnabled() && this.aura.shouldPreventSprinting()) {
            return false;
        }
        return original;
    }

    @WrapWithCondition(method={"method_3137"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_310;method_1507(Lnet/minecraft/class_437;)V")})
    private boolean preventCloseScreen(class_310 instance, class_437 screen) {
        Experiment.getInstance().getEventManager().triggerEvent(new CloseScreenEvent(screen));
        return true;
    }

    @Inject(method={"method_30673"}, at={@At(value="HEAD")}, cancellable=true)
    public void removePushOutFromBlocks(double x, double z, CallbackInfo ci) {
        NoPush noPush = Experiment.getInstance().getModuleManager().getModule(NoPush.class);
        if (noPush.isEnabled() && noPush.getBlocks().isSelected()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_5773"}, at={@At(value="HEAD")})
    public void triggerTickEvent(CallbackInfo ci) {
        Experiment.getInstance().getEventManager().triggerEvent(new ClientPlayerTickEvent());
    }

    @Inject(method={"method_5773"}, at={@At(value="RETURN")})
    public void triggerTickEndEvent(CallbackInfo ci) {
        Experiment.getInstance().getEventManager().triggerEvent(new ClientPlayerTickEndEvent());
    }

    @Inject(method={"method_6007"}, at={@At(value="HEAD")})
    public void updateOnGroundTicks(CallbackInfo ci) {
        this.groundTicks = ClientPlayerEntityMixin.mc.field_1724 != null && ClientPlayerEntityMixin.mc.field_1724.method_24828() ? (this.groundTicks = this.groundTicks + 1) : 0;
    }

    @Redirect(method={"method_3136"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_746;method_36454()F"))
    public float replaceMovePacketYaw(class_746 instance) {
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        float yaw = rotationHandler.isIdling() ? instance.method_36454() : rotationHandler.getCurrentRotation().getYaw();
        rotationHandler.getServerRotation().setYaw(yaw);
        return yaw;
    }

    @Redirect(method={"method_3136"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_746;method_36455()F"))
    public float replaceMovePacketPitch(class_746 instance) {
        RotationHandler rotationHandler = Experiment.getInstance().getRotationHandler();
        float pitch = rotationHandler.isIdling() ? instance.method_36455() : rotationHandler.getCurrentRotation().getPitch();
        rotationHandler.getServerRotation().setYaw(pitch);
        return pitch;
    }

    @Inject(method={"method_7290"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDropSelectedItem(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
        InvUtils slotLock = Experiment.getInstance().getModuleManager().getModule(InvUtils.class);
        if (slotLock.isEnabled() && slotLock.getSlotLock().isSelected() && slotLock.isLocked(ClientPlayerEntityMixin.mc.field_1724.method_31548().field_7545)) {
            cir.setReturnValue((Object)false);
            cir.cancel();
        }
    }

    @Override
    public int experiment$getOnGroundTicks() {
        return this.groundTicks;
    }
}

