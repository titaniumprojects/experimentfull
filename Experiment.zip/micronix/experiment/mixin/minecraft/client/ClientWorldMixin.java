/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_5294
 *  net.minecraft.class_5294$class_5295
 *  net.minecraft.class_638
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client;

import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Ambience;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_5294;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_638.class})
public class ClientWorldMixin {
    @Unique
    private final class_5294 endSky = new class_5294.class_5295();

    @Inject(method={"method_28103"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetSkyProperties(CallbackInfoReturnable<class_5294> info) {
        if (Experiment.getInstance().getModuleManager().getModule(Ambience.class).isEnabled() && Experiment.getInstance().getModuleManager().getModule(Ambience.class).getEndSky().isEnabled()) {
            info.setReturnValue((Object)this.endSky);
        }
    }
}

