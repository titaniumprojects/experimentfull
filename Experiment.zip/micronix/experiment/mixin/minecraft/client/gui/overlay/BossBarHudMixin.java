/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_332
 *  net.minecraft.class_337
 *  net.minecraft.class_345
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.gui.overlay;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import micronix.experiment.ui.hud.impl.island.DynamicIsland;
import micronix.experiment.ui.hud.impl.island.impl.PVPStatus;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_337;
import net.minecraft.class_345;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_337.class})
public class BossBarHudMixin
implements IMinecraft {
    @Shadow
    @Final
    private Map<UUID, class_345> field_2060;
    @Unique
    private static final Pattern PVP_TIME_PATTERN = Pattern.compile("(\\d+)\\s*[\u0441c][\u0435e][\u043ak](?=$|\\s|\\p{Punct})", 66);
    private static final String FILTERED_TEXT = "\ub445\ua223\ua203\ub444\ua223\ua205";
    private final Map<UUID, String> lastProcessedNames = new HashMap<UUID, String>();

    @Inject(method={"method_1796"}, at={@At(value="HEAD")})
    private void onRenderHead(class_332 context, CallbackInfo ci) {
        int ctTimer = 0;
        for (class_345 bossBar : this.field_2060.values()) {
            String name;
            if (bossBar.method_5414() == null || !(name = bossBar.method_5414().getString().toLowerCase()).contains("\u0431\u043e\u0439") && !name.contains("pvp")) continue;
            Matcher matcher = PVP_TIME_PATTERN.matcher(bossBar.method_5414().getString());
            if (!matcher.find()) break;
            ctTimer = Integer.parseInt(matcher.group(1));
            break;
        }
        ServerUtility.setHasCT(ctTimer > 0);
        ServerUtility.setCtTime(ctTimer);
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getBossBar().isSelected()) {
            return;
        }
        if (!(!Experiment.getInstance().getHud().getIsland().isShowing() || this.field_2060.isEmpty() || removals.isEnabled() && removals.getBossBar().isSelected() || ServerUtility.isCM())) {
            DynamicIsland island = Experiment.getInstance().getHud().getIsland();
            boolean islandShowingPvp = island.isShowing() && island.statuses().stream().anyMatch(status -> status instanceof PVPStatus);
            boolean bl = islandShowingPvp;
            if (removals.isEnabled() && removals.getBossBar().isSelected() || ServerUtility.hasCT && islandShowingPvp) {
                return;
            }
            context.method_51448().method_22903();
            context.method_51448().method_46416(0.0f, Experiment.getInstance().getHud().getIsland().getSize().height + 7.0f, 0.0f);
        }
    }

    @Inject(method={"method_1796"}, at={@At(value="HEAD")}, cancellable=true)
    private void render(CallbackInfo ci) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        DynamicIsland island = Experiment.getInstance().getHud().getIsland();
        boolean islandShowingPvp = island.isShowing() && island.statuses().stream().anyMatch(status -> status instanceof PVPStatus);
        boolean bl = islandShowingPvp;
        if (removals.isEnabled() && removals.getBossBar().isSelected() || ServerUtility.hasCT && islandShowingPvp) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1796"}, at={@At(value="RETURN")})
    private void onRenderReturn(class_332 context, CallbackInfo ci) {
        int j = 19 * this.field_2060.size();
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getBossBar().isSelected()) {
            return;
        }
        if (!(!Experiment.getInstance().getHud().getIsland().isShowing() || this.field_2060.isEmpty() || removals.isEnabled() && removals.getBossBar().isSelected() || ServerUtility.isCM())) {
            context.method_51448().method_22909();
        }
    }
}

