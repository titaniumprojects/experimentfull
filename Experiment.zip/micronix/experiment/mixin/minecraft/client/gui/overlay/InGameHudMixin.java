/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_266
 *  net.minecraft.class_329
 *  net.minecraft.class_332
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArgs
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.invoke.arg.Args
 */
package micronix.experiment.mixin.minecraft.client.gui.overlay;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.render.PostHudRenderEvent;
import micronix.experiment.systems.event.impl.render.PreHudRenderEvent;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import micronix.experiment.ui.hud.Hud;
import micronix.experiment.ui.hud.impl.HotbarHud;
import micronix.experiment.ui.hud.impl.ScoreboardHud;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.render.DrawUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_266;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_329.class})
public class InGameHudMixin
implements IMinecraft {
    @Inject(method={"method_1757"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderScoreboardSidebarHook(class_332 context, class_266 objective, CallbackInfo ci) {
        Removals removals;
        if (objective.method_1114().getString().contains("\u0410\u043d\u0430\u0440\u0445\u0438\u044f") && (ServerUtility.isFT() || ServerUtility.isST())) {
            try {
                ServerUtility.ftAn = Integer.parseInt(objective.method_1114().getString().split("-")[1].trim());
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if ((removals = Experiment.getInstance().getModuleManager().getModule(Removals.class)).isEnabled() && removals.getScoreboard().isSelected()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1757"}, at={@At(value="HEAD")}, cancellable=true)
    private void hideScoreboard(class_332 context, class_266 objective, CallbackInfo ci) {
        ScoreboardHud scoreboardHud;
        Hud hud = Experiment.getInstance().getHud();
        if (hud != null && (scoreboardHud = (ScoreboardHud)hud.getElementByName("\u0421\u043a\u043e\u0440\u0431\u043e\u0440\u0434")) != null && scoreboardHud.isShowing() && scoreboardHud.show()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1759"}, at={@At(value="HEAD")}, cancellable=true)
    private void hideHotbar(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        HotbarHud hotbarHud;
        Hud hud = Experiment.getInstance().getHud();
        if (hud != null && (hotbarHud = (HotbarHud)hud.getElementByName("hud.hotbar")) != null && hotbarHud.isShowing()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1746"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderPortalOverlayHook(class_332 context, float nauseaStrength, CallbackInfo ci) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getPortal().isSelected()) {
            ci.cancel();
        }
    }

    @ModifyArgs(method={"method_55798"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_329;method_31977(Lnet/minecraft/class_332;Lnet/minecraft/class_2960;F)V", ordinal=0))
    private void onRenderPumpkinOverlay(Args args) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getPumpkin().isSelected()) {
            args.set(2, (Object)Float.valueOf(0.0f));
        }
    }

    @Inject(method={"method_1753"}, at={@At(value="HEAD")})
    public void triggerPreHudRenderEvent(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        CustomDrawContext customDrawContext = CustomDrawContext.of(context);
        Experiment.getInstance().getEventManager().triggerEvent(new PreHudRenderEvent(customDrawContext, tickCounter.method_60637(false)));
    }

    @Inject(method={"method_1753"}, at={@At(value="RETURN")})
    public void triggerPostHudRenderEvent(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        CustomDrawContext customDrawContext = CustomDrawContext.of(context);
        Experiment.getInstance().getEventManager().triggerEvent(new PostHudRenderEvent(customDrawContext, tickCounter.method_60637(false)));
    }

    @Inject(method={"method_55805"}, at={@At(value="TAIL")})
    private void triggerHudRenderEvent(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        CustomDrawContext customDrawContext = CustomDrawContext.of(context);
        DrawUtility.blurProgram.draw();
        Experiment.getInstance().getEventManager().triggerEvent(new HudRenderEvent(customDrawContext, tickCounter.method_60637(false)));
    }
}

