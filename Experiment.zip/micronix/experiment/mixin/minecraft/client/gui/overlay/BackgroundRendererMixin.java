/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  net.minecraft.class_6854
 *  net.minecraft.class_758
 *  net.minecraft.class_758$class_4596
 *  net.minecraft.class_9958
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client.gui.overlay;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.CustomFog;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import micronix.experiment.utility.colors.ColorRGBA;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_6854;
import net.minecraft.class_758;
import net.minecraft.class_9958;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_758.class})
public class BackgroundRendererMixin {
    @Inject(method={"method_42588"}, at={@At(value="HEAD")}, cancellable=true)
    private static void onGetFogModifier(class_1297 entity, float tickDelta, CallbackInfoReturnable<Object> info) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getBlindness().isSelected()) {
            info.setReturnValue(null);
        }
    }

    @ModifyReturnValue(method={"method_3211"}, at={@At(value="RETURN")})
    private static class_9958 modifyFogProperties(class_9958 original, @Local(argsOnly=true) class_4184 camera, @Local(argsOnly=true) class_758.class_4596 fogType, @Local(argsOnly=true, ordinal=0) float viewDistance) {
        CustomFog customFogModule = Experiment.getInstance().getModuleManager().getModule(CustomFog.class);
        if (customFogModule.shouldModifyFog(camera) && fogType == class_758.class_4596.field_20946) {
            float start = class_3532.method_15363((float)customFogModule.getDistance().getFirstValue(), (float)-8.0f, (float)viewDistance);
            float end = class_3532.method_15363((float)customFogModule.getDistance().getSecondValue(), (float)0.0f, (float)viewDistance);
            ColorRGBA color = customFogModule.getFogColor().getColor();
            class_6854 shape = class_6854.field_36350;
            float r = color.getRed() / 255.0f;
            float g = color.getGreen() / 255.0f;
            float b = color.getBlue() / 255.0f;
            float a = color.getAlpha() / 255.0f;
            return new class_9958(start, end, shape, r, g, b, a);
        }
        return original;
    }
}

