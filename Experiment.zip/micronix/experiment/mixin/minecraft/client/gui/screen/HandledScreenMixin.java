/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_2371
 *  net.minecraft.class_332
 *  net.minecraft.class_3675
 *  net.minecraft.class_465
 *  org.lwjgl.glfw.GLFW
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client.gui.screen;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.event.impl.render.ScreenRenderEvent;
import micronix.experiment.systems.event.impl.window.ContainerClickEvent;
import micronix.experiment.systems.event.impl.window.ContainerReleaseEvent;
import micronix.experiment.systems.modules.modules.player.InvUtils;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2371;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_465.class})
public abstract class HandledScreenMixin
implements IMinecraft {
    @Unique
    private final Timer timer = new Timer();

    @Shadow
    protected abstract boolean method_2387(class_1735 var1, double var2, double var4);

    @Shadow
    protected abstract void method_2383(class_1735 var1, int var2, int var3, class_1713 var4);

    @Inject(method={"method_25394"}, at={@At(value="TAIL")})
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        CustomDrawContext customDrawContext = CustomDrawContext.of(context);
        Experiment.getInstance().getEventManager().triggerEvent(new ScreenRenderEvent(customDrawContext, delta));
        class_2371 slots = HandledScreenMixin.mc.field_1724.field_7512.field_7761;
        for (class_1735 slot : slots) {
            InvUtils invUtils = Experiment.getInstance().getModuleManager().getModule(InvUtils.class);
            if (!this.method_2387(slot, mouseX, mouseY) || !slot.method_7682() || !invUtils.isEnabled() || !invUtils.getScroller().isSelected() || !this.timer.finished((long)invUtils.getScrollDelay().getCurrentValue()) || !class_3675.method_15987((long)mc.method_22683().method_4490(), (int)340) || GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)0) != 1) continue;
            this.method_2383(slot, slot.field_7874, 0, class_1713.field_7794);
            this.timer.reset();
        }
    }

    @Inject(method={"method_25402"}, at={@At(value="HEAD")})
    private void onMouseClick(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        Experiment.getInstance().getEventManager().triggerEvent(new ContainerClickEvent((float)mouseX, (float)mouseY, button));
    }

    @Inject(method={"method_25406"}, at={@At(value="HEAD")})
    public void mouseReleased(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        Experiment.getInstance().getEventManager().triggerEvent(new ContainerReleaseEvent((float)mouseX, (float)mouseY, button));
    }
}

