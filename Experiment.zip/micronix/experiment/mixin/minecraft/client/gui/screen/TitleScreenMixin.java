/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  net.minecraft.class_442
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.gui.screen;

import micronix.experiment.Experiment;
import micronix.experiment.ui.mainmenu.CustomTitleScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_442.class})
public class TitleScreenMixin {
    @Inject(method={"method_25426"}, at={@At(value="HEAD")}, cancellable=true)
    public void setCustomScreen(CallbackInfo ci) {
        if (Experiment.INSTANCE.isPanic()) {
            return;
        }
        ci.cancel();
        class_310.method_1551().method_1507((class_437)new CustomTitleScreen());
    }
}

