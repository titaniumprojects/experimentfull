/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_342
 *  net.minecraft.class_408
 *  net.minecraft.class_437
 *  net.minecraft.class_4717
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package micronix.experiment.mixin.minecraft.client.gui.screen;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.event.impl.render.ChatRenderEvent;
import micronix.experiment.systems.event.impl.window.ChatClickEvent;
import micronix.experiment.systems.event.impl.window.ChatReleaseEvent;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_408.class})
public class ChatScreenMixin
extends class_437
implements IMinecraft {
    @Shadow
    protected class_342 field_2382;
    @Shadow
    private class_4717 field_21616;

    protected ChatScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"method_44056"}, at={@At(value="HEAD")}, cancellable=true)
    private void onSendMessage(String text, boolean addToHistory, CallbackInfo ci) {
        if (Experiment.getInstance().getCommandManager().dispatch(text)) {
            ChatScreenMixin.mc.field_1705.method_1743().method_1803(text);
            ci.cancel();
        }
    }

    @Inject(method={"method_25394"}, at={@At(value="RETURN")})
    public void render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatRenderEvent(CustomDrawContext.of(context), delta));
    }

    @Inject(method={"method_25402"}, at={@At(value="HEAD")})
    private void onMouseClick(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatClickEvent((float)mouseX, (float)mouseY, button));
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatReleaseEvent((float)mouseX, (float)mouseY, button));
        return true;
    }
}

