/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_757
 *  net.minecraft.class_9779
 *  org.joml.Matrix4f
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package micronix.experiment.mixin.minecraft.client.gui.screen;

import com.llamalad7.mixinextras.sugar.Local;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.modules.visuals.Removals;
import micronix.experiment.utility.render.Utils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_757.class})
public abstract class GameRendererMixin {
    @Inject(method={"method_3188"}, at={@At(value="INVOKE_STRING", target="Lnet/minecraft/class_3695;method_15405(Ljava/lang/String;)V", args={"ldc=hand"})})
    private void onRenderWorld(class_9779 tickCounter, CallbackInfo ci, @Local(ordinal=0) Matrix4f projection, @Local(ordinal=2) Matrix4f view, @Local(ordinal=1) float tickDelta, @Local class_4587 matrices) {
        Utils.onRender(view, projection);
    }

    @Inject(method={"method_3198"}, at={@At(value="HEAD")}, cancellable=true)
    private void tiltViewWhenHurtHook(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getHurtCam().isSelected()) {
            ci.cancel();
        }
    }

    @Redirect(method={"method_3188"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_3532;method_16439(FFF)F"))
    private float renderWorldHook(float delta, float first, float second) {
        Removals removals = Experiment.getInstance().getModuleManager().getModule(Removals.class);
        if (removals.isEnabled() && removals.getNausea().isSelected()) {
            return 0.0f;
        }
        return class_3532.method_16439((float)delta, (float)first, (float)second);
    }
}

