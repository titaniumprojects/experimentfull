/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1041
 *  net.minecraft.class_3262
 *  net.minecraft.class_7367
 *  net.minecraft.class_8518
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package micronix.experiment.mixin.minecraft.client.util;

import java.io.InputStream;
import java.util.List;
import micronix.experiment.Experiment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import net.minecraft.class_3262;
import net.minecraft.class_7367;
import net.minecraft.class_8518;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1041.class})
public class WindowMixin {
    @Redirect(method={"method_4491"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_8518;method_51418(Lnet/minecraft/class_3262;)Ljava/util/List;"))
    public List<class_7367<InputStream>> setCustomIcon(class_8518 instance, class_3262 resourcePack) {
        if (Experiment.getInstance().isPanic()) {
            try {
                return instance.method_51418(resourcePack);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        InputStream icon16x = Experiment.class.getResourceAsStream("/assets/%s/icons/window/icon16x16.png".formatted(Experiment.MOD_ID));
        InputStream icon32x = Experiment.class.getResourceAsStream("/assets/%s/icons/window/icon32x32.png".formatted(Experiment.MOD_ID));
        return List.of(() -> icon16x, () -> icon32x);
    }
}

