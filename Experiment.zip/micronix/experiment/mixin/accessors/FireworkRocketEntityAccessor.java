/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1671
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package micronix.experiment.mixin.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1671;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1671.class})
public interface FireworkRocketEntityAccessor {
    @Accessor(value="field_7613")
    public int getLife();

    @Accessor(value="field_7613")
    public void setLife(int var1);

    @Accessor(value="field_7612")
    public int getLifeTime();

    @Accessor(value="field_7612")
    public void setLifeTime(int var1);
}

