/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 *  net.minecraft.class_4011
 *  net.minecraft.class_425
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package micronix.experiment.mixin.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_425.class})
public interface SplashOverlayAccessor {
    @Accessor(value="field_17767")
    public class_4011 getReload();

    @Accessor(value="field_18217")
    public class_310 getClient();

    @Accessor(value="field_17771")
    public long getReloadCompleteTime();

    @Accessor(value="field_17771")
    public void setReloadCompleteTime(long var1);
}

