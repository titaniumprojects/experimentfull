/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2743
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Mutable
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package micronix.experiment.mixin.accessors;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_2743.class})
public interface EntityVelocityUpdateAccessor {
    @Mutable
    @Accessor(value="field_12563")
    public void setVelocityX(int var1);

    @Mutable
    @Accessor(value="field_12562")
    public void setVelocityY(int var1);

    @Mutable
    @Accessor(value="field_12561")
    public void setVelocityZ(int var1);
}

