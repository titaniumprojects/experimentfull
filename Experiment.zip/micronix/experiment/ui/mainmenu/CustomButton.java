/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.mainmenu;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.render.obj.Rect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class CustomButton
extends Rect {
    private final String icon;
    private final float iconSize;
    private final Runnable onClick;
    private final ColorRGBA backgroundColor = new ColorRGBA(0.0f, 0.0f, 0.0f);
    private final ColorRGBA backgroundOutlineColor = new ColorRGBA(255.0f, 255.0f, 255.0f);
    private final Animation activeAnim = new Animation(400L, 0.0f, Easing.BAKEK);
    private final Animation hoverAnim = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);

    @Compile
    public void draw(UIContext context) {
        if (this.hovered(context.getMouseX(), context.getMouseY()) && this.activeAnim.getValue() == 1.0f) {
            CursorUtility.set(CursorType.HAND);
        }
        this.hoverAnim.update(this.hovered(context.getMouseX(), context.getMouseY()) && this.activeAnim.getValue() == 1.0f);
        context.drawRoundedRect(this.x, this.y, this.width, this.height, BorderRadius.all(15.0f), this.backgroundColor.withAlpha(255.0f * (0.33f * this.activeAnim.getValue() + 0.2f * this.hoverAnim.getValue())));
        context.drawRoundedBorder(this.x, this.y, this.width, this.height, 0.0f, BorderRadius.all(15.0f), this.backgroundOutlineColor.withAlpha(80.0f * (0.33f * this.activeAnim.getValue() + 0.2f * this.hoverAnim.getValue())));
        context.drawTexture(Experiment.id(this.icon), this.x + (this.width - this.iconSize) / 2.0f, this.y + (this.height - this.iconSize) / 2.0f, this.iconSize, this.iconSize, ColorRGBA.WHITE.withAlpha(255.0f * this.activeAnim.getValue()));
    }

    @Compile
    public void click(double mouseX, double mouseY, int button) {
        if (this.hovered(mouseX, mouseY) && button == 0 && this.activeAnim.getValue() == 1.0f) {
            this.onClick.run();
        }
    }

    public CustomButton(String icon, float iconSize, Runnable onClick) {
        this.icon = icon;
        this.iconSize = iconSize;
        this.onClick = onClick;
    }

    public Animation getActiveAnim() {
        return this.activeAnim;
    }
}

