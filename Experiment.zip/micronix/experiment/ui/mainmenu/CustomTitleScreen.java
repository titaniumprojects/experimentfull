/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 *  net.minecraft.class_429
 *  net.minecraft.class_437
 *  net.minecraft.class_500
 *  net.minecraft.class_526
 */
package micronix.experiment.ui.mainmenu;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomScreen;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.framework.objects.gradient.impl.VerticalGradient;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.ui.account.AccountSwitcherScreen;
import micronix.experiment.ui.mainmenu.CustomButton;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.obj.Rect;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;
import ru.kotopushka.compiler.sdk.annotations.Compile;
import ru.kotopushka.compiler.sdk.annotations.VMProtect;
import ru.kotopushka.compiler.sdk.enums.VMProtectType;

@Environment(value=EnvType.CLIENT)
public class CustomTitleScreen
extends CustomScreen
implements IMinecraft {
    private static boolean once;
    private static final List<CustomButton> buttons;
    private boolean active;
    private final Animation activeAnimation = new Animation(1000L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final ColorRGBA dateColor = new ColorRGBA(171.0f, 254.0f, 255.0f);
    private final ColorRGBA timeColor = new ColorRGBA(203.0f, 254.0f, 255.0f);
    private boolean showWidgetMenu = false;
    private boolean watermarkEnabled = false;
    private float menuX;
    private float menuY;
    private float mouseX;
    private float mouseY;
    private boolean draggingWatermark = false;
    private float dragOffsetX;
    private float dragOffsetY;
    private boolean changelogOpen = false;
    private final Animation changelogAnim = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);

    @Compile
    @VMProtect(type=VMProtectType.MUTATION)
    protected void method_25426() {
        String basePath = "image/mainmenu/icons/";
        if (!once) {
            if (Experiment.getInstance().getModuleManager().getModule(Sounds.class).isEnabled()) {
                ClientSounds.WELCOME.play(Experiment.getInstance().getModuleManager().getModule(Sounds.class).getVolume().getCurrentValue());
            }
            buttons.add(new CustomButton(basePath + "single.png", 17.0f, () -> mc.method_1507((class_437)new class_526((class_437)this))));
            buttons.add(new CustomButton(basePath + "multi.png", 17.0f, () -> mc.method_1507((class_437)new class_500((class_437)this))));
            buttons.add(new CustomButton(basePath + "account.png", 17.0f, () -> mc.method_1507((class_437)new AccountSwitcherScreen(this, Experiment.getInstance().getAccountManager()))));
            buttons.add(new CustomButton(basePath + "settings.png", 17.0f, () -> mc.method_1507((class_437)new class_429((class_437)this, CustomTitleScreen.mc.field_1690))));
            buttons.add(new CustomButton(basePath + "quit.png", 18.0f, () -> mc.method_1490()));
            once = true;
        }
        super.method_25426();
    }

    @Override
    public void render(UIContext context) {
        Font experimentFont = Fonts.SYSTEMDLC.getFont(17.0f);
        Font dateFont = Fonts.MEDIUM.getFont(13.0f);
        Font unlockFont = Fonts.REGULAR.getFont(15.0f);
        Font timeFont = Fonts.REGULAR.getFont(15.0f);
        Font tgFont = Fonts.REGULAR.getFont(10.0f);
        float textAlpha = 255.0f * (0.5f + 0.5f * this.activeAnimation.getValue());
        float timeOffset = MathUtility.interpolate((float)this.field_22790 / 2.0f - 0.0f, 80.0, this.activeAnimation.getValue());
        float logoOffset = MathUtility.interpolate((float)this.field_22790 / 2.0f - 0.0f, 80.0, this.activeAnimation.getValue());
        float logoAlpha = MathUtility.interpolate(0.0, 155.0, this.activeAnimation.getValue());
        Rect rect = new Rect((float)(-this.field_22789) / 2.0f, (float)(-this.field_22789) / 3.0f, (float)this.field_22789 * 1.5f, this.field_22789);
        this.activeAnimation.update(this.active);
        ColorRGBA accent = Colors.getAccentColor();
        ColorRGBA darker = new ColorRGBA(accent.getRed() * 0.5f, accent.getGreen() * 0.5f, accent.getBlue() * 0.5f, accent.getAlpha());
        context.drawRoundedRect(0.0f, 0.0f, (float)this.field_22789, (float)this.field_22790, BorderRadius.ZERO, new VerticalGradient(darker, new ColorRGBA(0.0f, 0.0f, 0.0f)));
        RenderUtility.scale(context.method_51448(), (float)this.field_22789 / 2.0f, (float)this.field_22790 / 2.0f, 1.1f - 0.1f * this.activeAnimation.getValue());
        context.drawRoundedRect((float)this.field_22789 / 2.0f + -175.0f, (float)this.field_22790 / 2.0f + -175.0f, 350.0f, 280.0f, BorderRadius.all(10.0f), new ColorRGBA(0.0f, 0.0f, 0.0f, -50.0f + logoAlpha));
        context.drawRoundedBorder((float)this.field_22789 / 2.0f + -175.0f, (float)this.field_22790 / 2.0f + -175.0f, 350.0f, 280.0f, 0.01f, BorderRadius.all(10.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, -80.0f + logoAlpha));
        context.drawTexture(Experiment.id("image/mainmenu/background.png"), rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
        RenderUtility.end(context.method_51448());
        context.drawTexture(Experiment.id("image/mainmenu/logo.png"), (float)this.field_22789 / 2.0f + -30.0f, (float)this.field_22790 / 2.0f + -140.0f, 60.0f, 60.0f, ColorRGBA.WHITE.withAlpha(logoAlpha));
        context.drawCenteredText(dateFont, Localizator.translate("mainmenu.welcome"), (float)this.field_22789 / 2.0f, (float)this.field_22790 / 2.0f + -40.0f, ColorRGBA.WHITE.withAlpha(logoAlpha));
        context.drawCenteredText(experimentFont, "Experiment Client 2.0", (float)this.field_22789 / 2.0f, (float)this.field_22790 / 2.0f + -67.0f, ColorRGBA.WHITE.withAlpha(logoAlpha));
        context.drawCenteredText(unlockFont, Localizator.translate("mainmenu.next"), (float)this.field_22789 / 2.0f, (float)this.field_22790 / 2.0f + 3.0f, ColorRGBA.WHITE.withAlpha(155.0f * (1.0f - this.activeAnimation.getValue())));
        context.drawCenteredText(tgFont, "t.me/experimentproduct", (float)this.field_22789 / 2.0f, this.field_22790 - 15, ColorRGBA.WHITE.withAlpha(155.0f));
        context.drawCenteredText(timeFont, TextUtility.getCurrentTime(), (float)this.field_22789 / 2.0f, (float)this.field_22790 / 2.0f + 40.0f, ColorRGBA.WHITE.withAlpha(100.0f * this.activeAnimation.getValue()));
        DrawUtility.blurProgram.draw();
        float buttonWidth = 40.0f;
        float spacing = 6.0f;
        float totalWidth = (float)buttons.size() * buttonWidth + (float)(buttons.size() - 1) * spacing;
        float animValue = this.activeAnimation.getValue();
        float startX = ((float)this.field_22789 - totalWidth) / 2.0f;
        float offset = 0.0f;
        float rectPadding = 5.0f;
        float rectX = startX - rectPadding;
        float shiftY = -20.0f;
        float rectY = (this.field_22790 > 500 ? (float)this.field_22790 / 2.0f : (float)this.field_22790 / 1.25f) - 5.0f - rectPadding - 10.0f * this.activeAnimation.getValue();
        float rectHeight = buttonWidth + 2.0f * rectPadding;
        float rectWidth = totalWidth + 2.0f * rectPadding;
        float rectAlpha = 100.0f * animValue;
        float rectOutlineAlpha = 40.0f * animValue;
        context.drawRoundedRect(rectX, rectY, rectWidth, rectHeight, BorderRadius.all(15.0f), new ColorRGBA(0.0f, 0.0f, 0.0f, rectAlpha));
        context.drawRoundedBorder(rectX, rectY, rectWidth, rectHeight, 0.0f, BorderRadius.all(15.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, rectOutlineAlpha));
        for (CustomButton button : buttons) {
            button.getActiveAnim().update((float)(buttons.size() - buttons.indexOf(button)) > (1.0f - this.activeAnimation.getValue()) * (float)buttons.size() + 0.5f);
            float x = startX + offset;
            float y = (this.field_22790 > 500 ? (float)this.field_22790 / 2.0f : (float)this.field_22790 / 1.25f) - 5.0f - 10.0f * button.getActiveAnim().getValue();
            button.set(x, y, buttonWidth, buttonWidth);
            button.draw(context);
            offset += buttonWidth + spacing;
        }
        if (this.shouldShowIsland()) {
            Experiment.getInstance().getHud().getIsland().render(context);
        }
        Font changelogFont = Fonts.REGULAR.getFont(11.0f);
        float btnX = 6.0f;
        float btnY = 6.0f;
        float btnW = 80.0f;
        float btnH = 25.0f;
        context.drawRoundedRect(btnX, btnY, btnW, btnH, BorderRadius.all(10.0f), new ColorRGBA(0.0f, 0.0f, 0.0f, logoAlpha));
        context.drawRoundedBorder(btnX, btnY, btnW, btnH, 0.01f, BorderRadius.all(10.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, -80.0f + logoAlpha));
        context.drawText(changelogFont, "Change-Log", btnX + 10.0f, btnY + 8.0f, ColorRGBA.WHITE.withAlpha(logoAlpha));
        context.drawText(changelogFont, "Change-Log", btnX + 10.0f, btnY + 8.0f, ColorRGBA.WHITE.withAlpha(logoAlpha));
        this.changelogAnim.update(this.changelogOpen);
        float panelWidth = 250.0f;
        float panelX = -panelWidth + 6.0f + panelWidth * this.changelogAnim.getValue();
        float panelY = 40.0f;
        float panelHeight = 480.0f;
        context.drawRoundedRect(panelX, panelY, panelWidth, panelHeight, BorderRadius.all(10.0f), new ColorRGBA(0.0f, 0.0f, 0.0f, 120.0f * this.changelogAnim.getValue()));
        context.drawRoundedBorder(panelX, panelY, panelWidth, panelHeight, 0.01f, BorderRadius.all(10.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, 20.0f * this.changelogAnim.getValue()));
        if (this.changelogAnim.getValue() > 0.05f) {
            context.drawText(changelogFont, "[ = ] \u041d\u0430\u043a\u043e\u043d\u0435\u0446-\u0442\u043e \u0438\u0441\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0430 \u0444\u0443\u043d\u043a\u0446\u0438\u044f", panelX + 10.0f, panelY + 13.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
            context.drawText(changelogFont, "AppleFarm, \u0442\u0435\u043f\u0435\u0440\u044c \u043e\u043d \u043d\u043e\u0440\u043c\u0430\u043b\u044c\u043d\u043e", panelX + 10.0f, panelY + 33.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
            context.drawText(changelogFont, "\u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442", panelX + 10.0f, panelY + 53.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
            context.drawText(changelogFont, "[ + ] \u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0430 \u0444\u0443\u043d\u043a\u0446\u0438\u044f PvPSafe", panelX + 10.0f, panelY + 73.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
            context.drawText(changelogFont, "[ + ] \u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0430 \u0440\u043e\u0442\u0430\u0446\u0438\u044f Funtime (beta)", panelX + 10.0f, panelY + 93.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
            context.drawText(changelogFont, "[ + ] \u0418\u0437\u043c\u0435\u043d\u0435\u043d \u0446\u0432\u0435\u0442 \u0437\u043d\u0430\u0447\u043a\u043e\u0432 \u043d\u0430 ClickGUI,", panelX + 10.0f, panelY + 113.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
            context.drawText(changelogFont, "\u0442\u0435\u043f\u0435\u0440\u044c \u043e\u043d \u043e\u043a\u0440\u0430\u0448\u0438\u0432\u0430\u0435\u0442\u0441\u044f \u043f\u043e\u0434 \u0446\u0432\u0435\u0442 \u0442\u0435\u043c\u044b", panelX + 10.0f, panelY + 133.0f, ColorRGBA.WHITE.withAlpha(255.0f * this.changelogAnim.getValue()));
        }
    }

    @Override
    @Compile
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (this.shouldShowIsland() && Experiment.getInstance().getHud().getIsland().handleClick((float)mouseX, (float)mouseY, button.getButtonIndex())) {
            return;
        }
        for (CustomButton customButton : buttons) {
            if (!customButton.hovered(mouseX, mouseY) || customButton.getActiveAnim().getValue() != 1.0f) continue;
            customButton.click(mouseX, mouseY, button.getButtonIndex());
            return;
        }
        if (mouseX >= 16.0 && mouseX <= 96.0 && mouseY >= 16.0 && mouseY <= 30.0) {
            this.changelogOpen = !this.changelogOpen;
            return;
        }
        this.active = !this.active;
        this.mouseX = (float)mouseX;
        this.mouseY = (float)mouseY;
        super.onMouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        this.draggingWatermark = false;
    }

    public void onMouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!this.draggingWatermark || this.watermarkEnabled) {
            // empty if block
        }
    }

    @Compile
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 69) {
            Experiment.getInstance().getThemeManager().switchTheme();
        }
        if (class_437.method_25441() && keyCode == 82) {
            class_310.method_1551().method_1507((class_437)new class_500((class_437)this));
        }
        if (class_437.method_25441() && keyCode == 84) {
            class_310.method_1551().method_1507((class_437)new class_526((class_437)this));
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private boolean shouldShowIsland() {
        return Experiment.getInstance().getMusicTracker().haveActiveSession();
    }

    public boolean method_25422() {
        return false;
    }

    static {
        buttons = new ArrayList<CustomButton>();
    }
}

