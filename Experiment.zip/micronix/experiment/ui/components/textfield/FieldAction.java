/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.components.textfield;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class FieldAction {
    private final Runnable enter;
    private final Runnable tab;

    public Runnable getEnter() {
        return this.enter;
    }

    public Runnable getTab() {
        return this.tab;
    }

    public FieldAction(Runnable enter, Runnable tab) {
        this.enter = enter;
        this.tab = tab;
    }
}

