/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.components.popup.list;

import micronix.experiment.framework.base.UIContext;
import micronix.experiment.ui.components.popup.PopupComponent;
import micronix.experiment.utility.colors.Colors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class Separator
extends PopupComponent {
    @Override
    protected void renderComponent(UIContext context) {
        context.drawRect(this.x, this.y, this.width, this.height, Colors.getSeparatorColor());
    }

    @Override
    public float getHeight() {
        this.height = 4.0f;
        return 4.0f;
    }
}

