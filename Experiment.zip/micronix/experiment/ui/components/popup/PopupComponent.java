/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.components.popup;

import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class PopupComponent
extends CustomComponent {
    @Override
    protected void renderComponent(UIContext context) {
    }
}

