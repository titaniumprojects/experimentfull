/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class GridLine {
    private final Type type;
    private final float pos;
    private boolean active;

    public Type getType() {
        return this.type;
    }

    public float getPos() {
        return this.pos;
    }

    public boolean isActive() {
        return this.active;
    }

    public GridLine(Type type, float pos) {
        this.type = type;
        this.pos = pos;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Environment(value=EnvType.CLIENT)
    public static enum Type {
        HORIZONTAL,
        VERTICAL;

    }
}

