/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 *  net.minecraft.class_408
 */
package micronix.experiment.ui.hud;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.ChatRenderEvent;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.event.impl.window.ChatClickEvent;
import micronix.experiment.systems.event.impl.window.ChatKeyPressEvent;
import micronix.experiment.systems.event.impl.window.ChatReleaseEvent;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.ui.components.animated.AnimatedText;
import micronix.experiment.ui.components.popup.Popup;
import micronix.experiment.ui.hud.Grid;
import micronix.experiment.ui.hud.HudEditorScreen;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.ui.hud.HudHistoryManager;
import micronix.experiment.ui.hud.HudList;
import micronix.experiment.ui.hud.impl.ArmorHud;
import micronix.experiment.ui.hud.impl.Effects;
import micronix.experiment.ui.hud.impl.HotbarHud;
import micronix.experiment.ui.hud.impl.InventoryHud;
import micronix.experiment.ui.hud.impl.KeyBinds;
import micronix.experiment.ui.hud.impl.ScoreboardHud;
import micronix.experiment.ui.hud.impl.StaffList;
import micronix.experiment.ui.hud.impl.TargetHud;
import micronix.experiment.ui.hud.impl.Watermark;
import micronix.experiment.ui.hud.impl.island.DynamicIsland;
import micronix.experiment.ui.menu.visuals.VisualsScreen;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_408;
import ru.kotopushka.compiler.sdk.annotations.CompileBytecode;

@Environment(value=EnvType.CLIENT)
public class Hud
implements IMinecraft,
IScaledResolution {
    private final List<HudElement> elements = new ArrayList<HudElement>();
    private final List<Popup> popups = new ArrayList<Popup>();
    public DynamicIsland island;
    private final HudHistoryManager historyManager = new HudHistoryManager();
    private final Grid grid = new Grid();
    private String desc = "";
    private AnimatedText descText;
    private final Timer timer = new Timer();
    private final EventListener<HudRenderEvent> onHud = event -> {
        UIContext context = UIContext.of(event.getContext(), Hud.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32118(), Hud.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32119(), class_310.method_1551().method_61966().method_60637(false));
        if (this.descText == null) {
            this.descText = new AnimatedText(Fonts.REGULAR.getFont(10.0f), 10.0f, 300L, Easing.BAKEK).centered();
        }
        this.desc = "";
        this.grid.draw(context);
        this.grid.update();
        for (HudElement element : this.elements) {
            element.render(context);
            if (!(element.getSelecting().getValue() >= 0.0f)) continue;
            float anim = element.getAnimation().getValue() * element.getVisible().getValue();
            float scale = 0.5f + anim * 0.5f - 0.05f * element.getSelecting().getValue();
            element.getLoadingAnim().setDuration(1500L);
            element.getLoadingAnim().update(1.0f);
            if (element.getLoadingAnim().getValue() == 1.0f) {
                element.getLoadingAnim().setValue(0.0f);
            }
            RenderUtility.scale(context.method_51448(), element.getX() + element.getWidth() / 2.0f, element.getY() + element.getHeight() / 2.0f, scale);
            context.drawLoadingRect(element.getX(), element.getY(), element.getWidth(), element instanceof HudList ? Math.max(20.0f, element.getHeight()) : element.getHeight(), element.getLoadingAnim().getValue() * 2.2f - 0.5f, BorderRadius.all(element instanceof DynamicIsland ? 7.0f : 6.0f), ColorRGBA.WHITE.withAlpha(100.0f * element.getSelecting().getValue()));
            RenderUtility.end(context.method_51448());
        }
        this.descText.pos(sr.getScaledWidth() / 2.0f, 30.0f);
        if (!this.desc.contains(".description")) {
            this.descText.update(this.desc);
            this.descText.render(context);
        }
        for (Popup popup : this.popups) {
            if (Hud.mc.field_1755 instanceof class_408 || Hud.mc.field_1755 instanceof HudEditorScreen) continue;
            popup.setShowing(false);
        }
        if (!(Hud.mc.field_1755 instanceof class_408) && !(Hud.mc.field_1755 instanceof HudEditorScreen)) {
            CursorUtility.set(CursorType.DEFAULT);
        }
        this.popups.removeIf(popupx -> popupx.getAnimation().getValue() == 0.0f && !popupx.isShowing());
    };
    private final EventListener<ChatRenderEvent> onPostHud = event -> {
        UIContext context = UIContext.of(event.getContext(), Hud.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32118(), Hud.mc.field_1755 == null ? -1 : (int)GuiUtility.getMouse().method_32119(), class_310.method_1551().method_61966().method_60637(false));
        context.method_51448().method_22903();
        context.method_51448().method_46416(0.0f, 0.0f, 2000.0f);
        for (Popup popup : this.popups) {
            if (popup.getY() + popup.getHeight() > sr.getScaledHeight()) {
                popup.setY(sr.getScaledHeight() - 10.0f - popup.getHeight());
            }
            popup.render(context);
        }
        context.method_51448().method_22909();
    };
    private final EventListener<ChatKeyPressEvent> onKeyPress = event -> {
        int modifiers = event.getModifiers();
        int keyCode = event.getKeyCode();
        if (keyCode == 90 && (modifiers & 2) != 0) {
            Experiment.getInstance().getHud().getHistoryManager().undo();
        } else if (keyCode == 89 && (modifiers & 2) != 0) {
            Experiment.getInstance().getHud().getHistoryManager().redo();
        }
    };
    private final EventListener<ChatClickEvent> onClick = event -> {
        for (Popup popup : this.popups) {
            popup.onMouseClicked(event.getX(), event.getY(), MouseButton.fromButtonIndex(event.getButton()));
            if (popup.isHovered(event.getX(), event.getY())) {
                return;
            }
            popup.setShowing(false);
        }
        for (HudElement element : this.elements) {
            element.onMouseClicked(event.getX(), event.getY(), MouseButton.fromButtonIndex(event.getButton()));
            if ((!element.isHovered(event.getX(), event.getY()) || !element.isShowing()) && !element.isDragging()) continue;
            return;
        }
        if (event.getButton() == 1 && !this.disabledElements().isEmpty() && !(Hud.mc.field_1755 instanceof VisualsScreen)) {
            Popup popup = new Popup(event.getX(), event.getY(), 90.0f, 6.0f).title("\u0427\u0442\u043e \u0434\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u043c?").separator();
            for (HudElement elementx : this.disabledElements()) {
                popup.button(Localizator.translate(elementx.getName()), elementx.getIcon(), popup1 -> {
                    elementx.pos(event.getX(), event.getY());
                    elementx.setShowing(true);
                    popup1.setShowing(false);
                    Experiment.getInstance().getFileManager().writeFile("client");
                });
            }
            this.popups.add(popup);
        } else if (event.getButton() == 1 && this.disabledElements().isEmpty() && this.timer.finished(600L)) {
            Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.ERROR, "\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u043e\u0432 \u043d\u0435\u0442", "\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b \u0437\u0430\u043a\u043e\u043d\u0447\u0438\u043b\u0438\u0441\u044c, \u0434\u043e\u0431\u0430\u0432\u043b\u044f\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435 \u043d\u0435\u0447\u0435\u0433\u043e");
            this.timer.reset();
        }
    };
    private final EventListener<ChatReleaseEvent> onRelease = event -> {
        for (Popup popup : this.popups) {
            popup.onMouseReleased(event.getX(), event.getY(), MouseButton.fromButtonIndex(event.getButton()));
            if (!popup.isHovered(event.getX(), event.getY())) continue;
            return;
        }
        for (HudElement element : this.elements) {
            element.onMouseReleased(event.getX(), event.getY(), MouseButton.fromButtonIndex(event.getButton()));
        }
    };

    @CompileBytecode
    private void initialize() {
        Experiment.getInstance().getEventManager().subscribe(this);
        DynamicIsland dynamicIsland = new DynamicIsland();
        Effects effects = new Effects();
        KeyBinds keyBinds = new KeyBinds();
        TargetHud targetHud = new TargetHud();
        ArmorHud armorHud = new ArmorHud();
        InventoryHud inventoryHud = new InventoryHud();
        this.island = new DynamicIsland();
        HotbarHud hotbarhud = new HotbarHud();
        Watermark watermark = new Watermark();
        ScoreboardHud scoreboardHud = new ScoreboardHud();
        StaffList staffList = new StaffList();
        this.elements.addAll(List.of(dynamicIsland, effects, keyBinds, targetHud, armorHud, inventoryHud, hotbarhud, watermark, scoreboardHud, staffList));
    }

    public Hud() {
        this.initialize();
    }

    public List<HudElement> enabledElements() {
        return this.elements.stream().filter(HudElement::isShowing).toList();
    }

    public List<HudElement> disabledElements() {
        return this.elements.stream().filter(element -> !element.isShowing()).toList();
    }

    public <T extends HudElement> T getElementByName(String name) {
        return (T)((HudElement)this.elements.stream().filter(element -> element.getName().equalsIgnoreCase(name)).findFirst().orElse(null));
    }

    public List<HudElement> getElements() {
        return this.elements;
    }

    public List<Popup> getPopups() {
        return this.popups;
    }

    public DynamicIsland getIsland() {
        return this.island;
    }

    public HudHistoryManager getHistoryManager() {
        return this.historyManager;
    }

    public Grid getGrid() {
        return this.grid;
    }

    public String getDesc() {
        return this.desc;
    }

    public AnimatedText getDescText() {
        return this.descText;
    }

    public Timer getTimer() {
        return this.timer;
    }

    public EventListener<HudRenderEvent> getOnHud() {
        return this.onHud;
    }

    public EventListener<ChatRenderEvent> getOnPostHud() {
        return this.onPostHud;
    }

    public EventListener<ChatKeyPressEvent> getOnKeyPress() {
        return this.onKeyPress;
    }

    public EventListener<ChatClickEvent> getOnClick() {
        return this.onClick;
    }

    public EventListener<ChatReleaseEvent> getOnRelease() {
        return this.onRelease;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}

