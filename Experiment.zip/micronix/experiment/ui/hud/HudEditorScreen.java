/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 */
package micronix.experiment.ui.hud;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.event.impl.render.ChatRenderEvent;
import micronix.experiment.systems.event.impl.window.ChatClickEvent;
import micronix.experiment.systems.event.impl.window.ChatKeyPressEvent;
import micronix.experiment.systems.event.impl.window.ChatReleaseEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

@Environment(value=EnvType.CLIENT)
public class HudEditorScreen
extends class_437 {
    public HudEditorScreen() {
        super((class_2561)class_2561.method_43470((String)"HUD Editor"));
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatRenderEvent(CustomDrawContext.of(context), delta));
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"HUD Editor - \u041f\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u0435 \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u044b \u043c\u044b\u0448\u044c\u044e"), context.method_51421() / 2, 10, 0xFFFFFF);
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"ESC \u0438\u043b\u0438 Right Shift - \u0432\u044b\u0445\u043e\u0434"), context.method_51421() / 2, 22, 0xAAAAAA);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatClickEvent((float)mouseX, (float)mouseY, button));
        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatReleaseEvent((float)mouseX, (float)mouseY, button));
        return super.method_25406(mouseX, mouseY, button);
    }

    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        Experiment.getInstance().getEventManager().triggerEvent(new ChatKeyPressEvent(keyCode, scanCode, modifiers));
        if (keyCode != 256 && keyCode != 340) {
            return super.method_25404(keyCode, scanCode, modifiers);
        }
        this.method_25419();
        return true;
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }
}

