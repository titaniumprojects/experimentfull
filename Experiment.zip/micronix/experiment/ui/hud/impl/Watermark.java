/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_640
 */
package micronix.experiment.ui.hud.impl;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_640;

@Environment(value=EnvType.CLIENT)
public class Watermark
extends HudElement {
    private final BooleanSetting showRole = new BooleanSetting(this, "hud.watermark.show_role").enabled(true);
    private final BooleanSetting showPing = new BooleanSetting(this, "hud.watermark.show_ping").enabled(true);
    private final BooleanSetting showFps = new BooleanSetting(this, "hud.watermark.show_fps").enabled(true);

    public void renderWidget(UIContext context) {
        this.update(context);
        this.renderComponent(context);
    }

    public Watermark() {
        super("hud.watermark", "icons/hud/watermark.png");
    }

    @Override
    public void update(UIContext context) {
        float padding = 8.0f;
        float iconTextGap = 6.0f;
        float separatorSpacing = 6.0f;
        this.height = 22.0f;
        float calculatedWidth = padding;
        if (this.showRole.isEnabled()) {
            float dotSize = 7.0f;
            float roleFont = 8.0f;
            String role = "Experiment Client | 2.0               ";
            calculatedWidth = padding + (dotSize + iconTextGap);
            calculatedWidth += Fonts.REGULAR.getFont(roleFont).width(role) + separatorSpacing;
        }
        if (this.showPing.isEnabled()) {
            calculatedWidth += Fonts.ICONS.getFont(8.0f).width("H") + separatorSpacing;
            int ping = this.getPing();
            String pingText = ping + " ms";
            float textFont = 7.5f;
            calculatedWidth += Fonts.SYSTEMDLC.getFont(textFont).width(pingText) + separatorSpacing;
        }
        if (this.showFps.isEnabled()) {
            calculatedWidth += Fonts.ICONS.getFont(8.0f).width("3") + separatorSpacing;
            int fps = mc.method_47599();
            String fpsText = fps + " fps";
            float textFont = 7.5f;
            calculatedWidth += Fonts.SYSTEMDLC.getFont(textFont).width(fpsText);
        }
        this.width = calculatedWidth + padding;
        super.update(context);
    }

    @Override
    public void renderComponent(UIContext context) {
        float textHeight;
        float textFont;
        float padding = 8.0f;
        float itemSpacing = 8.0f;
        float iconTextGap = 6.0f;
        float separatorSpacing = 6.0f;
        this.height = 22.0f;
        float currentX = this.x + padding;
        float centerY = this.y + this.height / 2.0f;
        context.drawClientRect(this.x, this.y, this.width, this.height, this.animation.getValue(), this.dragAnim.getValue(), 6.0f);
        context.drawRoundedBorder(this.x, this.y, this.width, this.height, 0.01f, BorderRadius.all(5.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, 40.0f));
        if (this.showRole.isEnabled()) {
            String role = "Experiment Client | 2.0               ";
            float dotSize = 10.0f;
            float logoSize = 10.0f;
            float roleFont = 8.0f;
            float roleTextHeight = Fonts.REGULAR.getFont(roleFont).height();
            context.drawRoundedRect(currentX, centerY - dotSize / 2.0f, dotSize, dotSize, BorderRadius.all(dotSize / 2.0f), Colors.getAccentColor().withAlpha(0.0f));
            context.drawTexture(Experiment.id("icons/hud/logo.png"), currentX, centerY - dotSize / 2.0f, logoSize, logoSize, Colors.getAccentColor());
            context.drawText(Fonts.SYSTEMDLC.getFont(roleFont), role, currentX += dotSize + iconTextGap, centerY - roleTextHeight / 2.0f, Colors.getTextColor());
            currentX += Fonts.MEDIUM.getFont(roleFont).width(role) + separatorSpacing;
        }
        if (this.showPing.isEnabled()) {
            float separatorHeight = Fonts.REGULAR.getFont(8.0f).height();
            context.drawText(Fonts.ICONS.getFont(8.0f), "H", currentX, centerY - separatorHeight / 2.0f, Colors.getAccentColor().withAlpha(255.0f));
            int ping = this.getPing();
            String pingText = ping + " ms";
            textFont = 7.5f;
            textHeight = Fonts.SYSTEMDLC.getFont(textFont).height();
            context.drawText(Fonts.SYSTEMDLC.getFont(textFont), pingText, currentX += Fonts.ICONS.getFont(8.0f).width("H") + separatorSpacing, centerY - textHeight / 2.0f, Colors.getTextColor());
            currentX += Fonts.SYSTEMDLC.getFont(textFont).width(pingText) + separatorSpacing;
        }
        if (this.showFps.isEnabled()) {
            float separatorHeight = Fonts.REGULAR.getFont(8.0f).height();
            context.drawText(Fonts.ICONS.getFont(8.0f), "3", currentX, centerY - separatorHeight / 2.0f, Colors.getAccentColor().withAlpha(255.0f));
            int fps = mc.method_47599();
            String fpsText = fps + " fps";
            textFont = 7.5f;
            textHeight = Fonts.SYSTEMDLC.getFont(textFont).height();
            context.drawText(Fonts.SYSTEMDLC.getFont(textFont), fpsText, currentX += Fonts.ICONS.getFont(8.0f).width("3") + separatorSpacing, centerY - textHeight / 2.0f, Colors.getTextColor());
            currentX += Fonts.SYSTEMDLC.getFont(textFont).width(fpsText);
        }
    }

    private int getPing() {
        class_640 playerListEntry;
        if (Watermark.mc.field_1724 != null && mc.method_1562() != null && (playerListEntry = mc.method_1562().method_2871(Watermark.mc.field_1724.method_5667())) != null) {
            return playerListEntry.method_2959();
        }
        return 0;
    }
}

