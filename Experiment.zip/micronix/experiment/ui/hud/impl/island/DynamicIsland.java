/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1657
 *  net.minecraft.class_337
 *  net.minecraft.class_408
 *  net.minecraft.class_437
 *  net.minecraft.class_490
 */
package micronix.experiment.ui.hud.impl.island;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.player.ClientPlayerTickEvent;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudEditorScreen;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.ui.hud.impl.island.ExtandableStatus;
import micronix.experiment.ui.hud.impl.island.IslandSize;
import micronix.experiment.ui.hud.impl.island.IslandStatus;
import micronix.experiment.ui.hud.impl.island.impl.DefaultStatus;
import micronix.experiment.ui.hud.impl.island.impl.EventStatus;
import micronix.experiment.ui.hud.impl.island.impl.MineStatus;
import micronix.experiment.ui.hud.impl.island.impl.MusicStatus;
import micronix.experiment.ui.hud.impl.island.impl.NotificationStatus;
import micronix.experiment.ui.hud.impl.island.impl.PVPStatus;
import micronix.experiment.ui.menu.dropdown.DropDownScreen;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.animation.types.ColorAnimation;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.ScissorUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_337;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_490;

@Environment(value=EnvType.CLIENT)
public class DynamicIsland
extends HudElement
implements IMinecraft,
IScaledResolution {
    private final SelectSetting statuses = new SelectSetting(this, "hud.dynamic_island.statuses").draggable();
    private final IslandSize size = new IslandSize(48.0f, 15.0f);
    private boolean extended;
    private final Animation extendingAnim = new Animation(200L, 0.0f, Easing.LINEAR);
    private final Animation widthAnim = new Animation(500L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation heightAnim = new Animation(500L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation bossBarAnim = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation showPing = new Animation(500L, 0.0f, Easing.BAKEK);
    private final ColorAnimation backgroundColor = new ColorAnimation(300L, new ColorRGBA(0.0f, 0.0f, 0.0f), Easing.FIGMA_EASE_IN_OUT);
    private final ColorAnimation adaptColor = new ColorAnimation(300L, new ColorRGBA(255.0f, 255.0f, 255.0f), Easing.LINEAR);
    private final Timer timer = new Timer();
    private boolean dark;
    private boolean useDark;
    private IslandStatus last;
    private final EventListener<ClientPlayerTickEvent> onTick = event -> {
        if (!(this.active() instanceof MusicStatus) || DynamicIsland.mc.field_1724.field_6012 % 2 == 0) {
            // empty if block
        }
    };

    public DynamicIsland() {
        super("hud.dynamic_island", "icons/hud/island.png");
        new NotificationStatus(this.statuses);
        new PVPStatus(this.statuses);
        new EventStatus(this.statuses);
        new MineStatus(this.statuses);
        new MusicStatus(this.statuses);
        new DefaultStatus(this.statuses).alwaysEnabled();
        Experiment.getInstance().getFileManager().readFile("client");
        Experiment.getInstance().getEventManager().subscribe(this);
    }

    @Override
    protected void renderComponent(UIContext context) {
        this.width = this.size.width;
        this.height = this.size.height;
        this.x = sr.getScaledWidth() / 2.0f - this.width / 2.0f;
        boolean hasBossBar = false;
        try {
            Field field = class_337.class.getDeclaredField("bossBars");
            field.setAccessible(true);
            Map map = (Map)field.get(DynamicIsland.mc.field_1705.method_1740());
            hasBossBar = !map.isEmpty();
        }
        catch (Exception field) {
            // empty catch block
        }
        this.y = 7.0f;
        BorderRadius radius = BorderRadius.all(5.0f + 8.0f * this.extendingAnim.getValue());
        String time = TextUtility.getCurrentTime();
        if (this.timer.finished(500L)) {
            boolean check;
            float pixelY;
            float pixelX = (float)mc.method_22683().method_4480() / 2.0f;
            ColorRGBA pixel = ColorRGBA.fromPixel(pixelX, pixelY = (float)mc.method_22683().method_4507() - (this.y + 5.0f));
            this.useDark = check = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3.0f > 70.0f;
            this.timer.reset();
        }
        this.adaptColor.update(this.useDark ? new ColorRGBA(0.0f, 0.0f, 0.0f) : new ColorRGBA(255.0f, 255.0f, 255.0f));
        boolean themeDark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        ColorRGBA bgColor = Colors.getBackgroundColor().withAlpha(255.0f * (themeDark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
        this.dark = this.useDark;
        ColorRGBA elmtColor = this.adaptColor.getColor().withAlpha(255.0f * (1.0f - this.extendingAnim.getValue()));
        if (DynamicIsland.mc.field_1724 != null) {
            context.drawText(Fonts.MEDIUM.getFont(7.0f), time, this.x - Fonts.MEDIUM.getFont(9.0f).width(time) - 4.0f, this.y + 8.0f, elmtColor);
            if (!mc.method_1542() && DynamicIsland.mc.field_1724.field_3944.method_2871(DynamicIsland.mc.field_1724.method_5667()) != null) {
                int i;
                this.showPing.update(GuiUtility.isHovered(this.x + this.width + 4.0f + 4.0f * this.showPing.getValue(), this.y + 8.0f, 12.8f, 7.0, context));
                int ping = DynamicIsland.mc.field_1724.field_3944.method_2871(DynamicIsland.mc.field_1724.method_5667()).method_2959();
                int[] pings = new int[]{450, 300, 150, 75};
                context.drawText(Fonts.MEDIUM.getFont(7.0f), ping + " ms", this.x + this.width + 4.0f + 4.0f * this.showPing.getValue(), this.y + 8.0f, elmtColor.mulAlpha(this.showPing.getValue()));
                for (i = 0; i < 4; ++i) {
                    context.drawRoundedRect(this.x + this.width + 9.0f + (float)i * 2.7f + 4.0f * this.showPing.getValue(), this.y + 10.0f - (float)i, 2.0f, (float)(3 + i), BorderRadius.all(0.1f), elmtColor.withAlpha(elmtColor.getAlpha() * 0.2f * (1.0f - this.showPing.getValue())));
                }
                for (i = 0; i < 4; ++i) {
                    if (ping >= pings[i]) continue;
                    context.drawRoundedRect(this.x + this.width + 9.0f + (float)i * 2.7f + 4.0f * this.showPing.getValue(), this.y + 10.0f - (float)i, 2.0f, (float)(3 + i), BorderRadius.all(0.1f), elmtColor.mulAlpha(1.0f - this.showPing.getValue()));
                }
            } else {
                context.drawTexture(Experiment.id("icons/airplane.png"), this.x + this.width + 8.0f, this.y + 7.0f, 8.0f, 8.0f, elmtColor);
            }
        }
        IslandStatus status = this.active();
        this.backgroundColor.update(status.getColor());
        if (Interface.showMinimalizm()) {
            context.drawBlurredRect(this.x, this.y, this.width, this.height, 11.25f, 2.0f + 2.0f * this.extendingAnim.getValue(), radius, ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue() * Interface.minimalizm()));
        }
        if (Interface.showGlass()) {
            context.drawLiquidGlass(this.x, this.y, this.width, this.height, 7.0f, Interface.getDistortion() - 0.07f * this.dragAnim.getValue(), radius, Colors.getLiquidGlassColor().withAlpha(255.0f * Interface.glass()));
        }
        context.drawSquircle(this.x, this.y, this.width, this.height, 2.0f + 5.0f * this.extendingAnim.getValue(), radius, bgColor);
        for (SelectSetting.Value islandStatus : this.statuses.getValues()) {
            ((IslandStatus)islandStatus).getAnimation().update(status == islandStatus ? 1.0f : 0.0f);
        }
        ScissorUtility.push(context.method_51448(), this.x, this.y, this.width, this.height);
        if (status.getAnimation().getValue() == 1.0f) {
            status.draw(context);
        } else {
            for (SelectSetting.Value islandStatus : this.statuses.getValues()) {
                if (!(((IslandStatus)islandStatus).getAnimation().getValue() > 0.0f)) continue;
                ((IslandStatus)islandStatus).drawWithAlpha(context);
            }
        }
        ScissorUtility.pop();
        this.widthAnim.update(status.size.width);
        this.heightAnim.update(status.size.height);
        this.size.width = this.widthAnim.getValue();
        this.size.height = this.heightAnim.getValue();
        this.extendingAnim.update(this.extended ? 1.0f : 0.0f);
        if (!(status instanceof ExtandableStatus)) {
            this.extended = false;
        }
        if (!(DynamicIsland.mc.field_1755 instanceof class_408) && !(DynamicIsland.mc.field_1755 instanceof DropDownScreen) && !(DynamicIsland.mc.field_1755 instanceof HudEditorScreen) && DynamicIsland.mc.field_1724 != null || this.select) {
            this.extended = false;
        }
        if (!this.extended && status instanceof ExtandableStatus && GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, GuiUtility.getMouse().method_32118(), GuiUtility.getMouse().method_32119())) {
            CursorUtility.set(CursorType.HAND);
        }
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        super.onMouseClicked(mouseX, mouseY, button);
        this.handleClick((float)mouseX, (float)mouseY, button.getButtonIndex());
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        float dragDistance;
        if (this.dragging && button == MouseButton.LEFT && (dragDistance = (float)Math.sqrt(Math.pow(this.x - this.startDragX, 2.0) + Math.pow(this.y - this.startDragY, 2.0))) > 5.0f && DynamicIsland.mc.field_1724 != null && DynamicIsland.mc.field_1755 == null) {
            mc.method_1507((class_437)new class_490((class_1657)DynamicIsland.mc.field_1724));
        }
        super.onMouseReleased(mouseX, mouseY, button);
    }

    public boolean handleClick(float mouseX, float mouseY, int button) {
        float x = sr.getScaledWidth() / 2.0f - this.size.width / 2.0f;
        float y = 7.0f;
        if (this.extended) {
            if (!GuiUtility.isHovered((double)x, (double)y, (double)this.size.width, (double)this.size.height, mouseX, mouseY)) {
                this.extended = false;
            } else {
                this.active().click(mouseX, mouseY, button);
            }
            return true;
        }
        if (GuiUtility.isHovered((double)x, (double)y, (double)this.size.width, (double)this.size.height, mouseX, mouseY) && this.active() instanceof ExtandableStatus) {
            this.extended = true;
            return true;
        }
        return false;
    }

    public IslandStatus active() {
        return this.statuses().getLast();
    }

    public List<IslandStatus> statuses() {
        return this.statuses.getValues().stream().filter(islandStatus -> ((IslandStatus)islandStatus).canShow() && islandStatus.isSelected()).map(islandStatus -> (IslandStatus)islandStatus).toList().reversed();
    }

    public SelectSetting getStatuses() {
        return this.statuses;
    }

    public IslandSize getSize() {
        return this.size;
    }

    public boolean isExtended() {
        return this.extended;
    }

    public Animation getExtendingAnim() {
        return this.extendingAnim;
    }

    @Override
    public Animation getWidthAnim() {
        return this.widthAnim;
    }

    @Override
    public Animation getHeightAnim() {
        return this.heightAnim;
    }

    public Animation getShowPing() {
        return this.showPing;
    }

    public ColorAnimation getBackgroundColor() {
        return this.backgroundColor;
    }

    public ColorAnimation getAdaptColor() {
        return this.adaptColor;
    }

    public Timer getTimer() {
        return this.timer;
    }

    public boolean isDark() {
        return this.dark;
    }

    public boolean isUseDark() {
        return this.useDark;
    }

    public IslandStatus getLast() {
        return this.last;
    }

    public EventListener<ClientPlayerTickEvent> getOnTick() {
        return this.onTick;
    }
}

