/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.impl.island.impl;

import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.ui.hud.impl.island.TimerStatus;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.server.ServerUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class PVPStatus
extends TimerStatus {
    public PVPStatus(SelectSetting setting) {
        super(setting, "pvp");
    }

    @Override
    public void draw(CustomDrawContext context) {
        this.update("s", ServerUtility.ctTime, "\u0412\u044b \u0432 PVP \u0440\u0435\u0436\u0438\u043c\u0435", new ColorRGBA(185.0f, 28.0f, 28.0f));
        super.draw(context);
    }

    @Override
    public boolean canShow() {
        return ServerUtility.hasCT;
    }
}

