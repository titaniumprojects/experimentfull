/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.impl.island.impl;

import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.notifications.Notification;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.ui.hud.impl.island.DynamicIsland;
import micronix.experiment.ui.hud.impl.island.IslandStatus;
import micronix.experiment.utility.colors.Colors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class NotificationStatus
extends IslandStatus {
    public NotificationStatus(SelectSetting setting) {
        super(setting, "alerts");
    }

    @Override
    public void draw(CustomDrawContext context) {
        DynamicIsland island = Experiment.getInstance().getHud().getIsland();
        List<Notification> notifications = Experiment.getInstance().getNotificationManager().getNotifications();
        if (!notifications.isEmpty()) {
            Notification active = notifications.getLast();
            float padding = 8.0f;
            float dotSize = 7.0f;
            float iconTextGap = 6.0f;
            this.size.height = 22.0f;
            float textWidth = notifications.stream().filter(n -> n.getShowing().getValue() > 0.0f).map(n -> Float.valueOf(Fonts.SYSTEMDLC.getFont(7.0f).width(n.getText()))).max(Float::compareTo).orElse(Float.valueOf(Fonts.SYSTEMDLC.getFont(7.0f).width(active.getText()))).floatValue();
            this.size.width = padding + dotSize + iconTextGap + textWidth + padding + -5.0f;
            float x = sr.getScaledWidth() / 2.0f - this.size.width / 2.0f;
            float y = 7.0f;
            float centerY = y + this.size.height / 2.0f;
            float currentX = x + padding;
            for (Notification notification : notifications) {
                notification.getShowing().setDuration(500L);
                notification.getShowing().update(active == notification);
                float alpha = 255.0f * notification.getShowing().getValue();
                float animOffset = 10.0f * (1.0f - notification.getShowing().getValue());
                context.drawRoundedRect(currentX - animOffset, centerY - dotSize / 2.0f, dotSize, dotSize, BorderRadius.all(dotSize / 2.0f), notification.getType().getColor().withAlpha(alpha));
                float textHeight = Fonts.SYSTEMDLC.getFont(7.0f).height();
                context.drawText(Fonts.SYSTEMDLC.getFont(7.0f), notification.getText(), currentX + dotSize + iconTextGap + animOffset, centerY - textHeight / 2.0f, Colors.getTextColor().withAlpha(alpha));
            }
        }
    }

    @Override
    public boolean canShow() {
        List<Notification> notifications = Experiment.getInstance().getNotificationManager().getNotifications();
        return !notifications.isEmpty() && !notifications.getLast().getTimer().finished(notifications.getLast().getDuration());
    }
}

