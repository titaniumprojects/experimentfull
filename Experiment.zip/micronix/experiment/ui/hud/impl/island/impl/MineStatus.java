/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1531
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 */
package micronix.experiment.ui.hud.impl.island.impl;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.ui.hud.impl.island.TimerStatus;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_243;
import net.minecraft.class_2561;

@Environment(value=EnvType.CLIENT)
public class MineStatus
extends TimerStatus
implements IMinecraft {
    private class_243 vec = new class_243(-52.0, 87.0, 3.0);

    public MineStatus(SelectSetting setting) {
        super(setting, "mine");
    }

    @Override
    public void draw(CustomDrawContext context) {
        if (MineStatus.mc.field_1687 != null && MineStatus.mc.field_1724 != null && ServerUtility.spawn()) {
            String time = "";
            String mineType = "";
            List<String> hw_types = List.of("\u043e\u0431\u044b\u0447\u043d\u0430\u044f", "\u0440\u0435\u0434\u043a\u0430\u044f", "\u044d\u043f\u0438\u0447\u0435\u0441\u043a\u0430\u044f", "\u043b\u0435\u0433\u0435\u043d\u0434\u0430\u0440\u043d\u0430\u044f", "\u043c\u0438\u0444\u0438\u0447\u0435\u0441\u043a\u0430\u044f");
            ArrayList<class_1531> nearbyStands = new ArrayList<class_1531>();
            for (class_1297 entity : MineStatus.mc.field_1687.method_18112()) {
                class_1531 armorStand;
                if (!(entity instanceof class_1531) || !this.near(armorStand = (class_1531)entity, new class_243(-52.0, 87.0, 3.0))) continue;
                nearbyStands.add(armorStand);
            }
            nearbyStands.sort((a, b) -> Double.compare(b.method_23318(), a.method_23318()));
            for (int i = 0; i < nearbyStands.size(); ++i) {
                String nextNameStr;
                class_1531 nextStand;
                class_2561 nextName;
                class_1531 armorStand = (class_1531)nearbyStands.get(i);
                class_2561 customName = armorStand.method_5797();
                if (customName == null) continue;
                String name = customName.getString().trim();
                if (name.matches("\\d{1,2}:\\d{2}")) {
                    time = name.replaceFirst("^0", "");
                } else if (name.contains("\u043e\u0441\u0442\u0430\u043b\u043e\u0441\u044c:")) {
                    int index = name.indexOf(58);
                    if (index != -1 && index + 2 < name.length()) {
                        String timeStr = name.substring(index + 2).trim();
                        int minIndex = timeStr.indexOf(" \u043c\u0438\u043d.");
                        int secIndex = timeStr.indexOf(" \u0441\u0435\u043a.");
                        if (minIndex != -1 && secIndex != -1) {
                            int min = Integer.parseInt(timeStr.substring(0, minIndex).trim());
                            int sec = Integer.parseInt(timeStr.substring(minIndex + 5, secIndex).trim());
                            time = String.format("%d:%02d", min, sec);
                        }
                    }
                } else if (name.startsWith("\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0430\u044f:")) {
                    int index = name.indexOf(58);
                    if (index != -1 && index + 2 < name.length()) {
                        mineType = name.substring(index + 2).trim();
                    }
                } else if (name.equals("\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0430\u044f \u0448\u0430\u0445\u0442\u0430:") && i + 1 < nearbyStands.size() && (nextName = (nextStand = (class_1531)nearbyStands.get(i + 1)).method_5797()) != null && hw_types.contains((nextNameStr = nextName.getString().trim()).toLowerCase().trim())) {
                    mineType = nextNameStr;
                }
                if (!time.isEmpty() && !mineType.isEmpty()) break;
            }
            if (!time.isEmpty() && !mineType.isEmpty()) {
                ColorRGBA color;
                if (ServerUtility.is("holyworld")) {
                    String var19;
                    color = switch (var19 = mineType.trim().toLowerCase()) {
                        case "\u043b\u0435\u0433\u0435\u043d\u0434\u0430\u0440\u043d\u0430\u044f" -> new ColorRGBA(0.0f, 128.0f, 250.0f);
                        case "\u044d\u043f\u0438\u0447\u0435\u0441\u043a\u0430\u044f" -> new ColorRGBA(231.0f, 0.0f, 250.0f);
                        default -> new ColorRGBA(243.0f, 151.0f, 250.0f);
                    };
                } else {
                    String var20;
                    color = switch (var20 = mineType.trim().toLowerCase()) {
                        case "\u043b\u0435\u0433\u0435\u043d\u0434\u0430\u0440\u043d\u0430\u044f" -> new ColorRGBA(84.0f, 152.0f, 152.0f);
                        case "\u043c\u0438\u0444\u0438\u0447\u0435\u0441\u043a\u0430\u044f" -> new ColorRGBA(252.0f, 84.0f, 252.0f);
                        default -> new ColorRGBA(252.0f, 168.0f, 0.0f);
                    };
                }
                this.update(Integer.parseInt(time.split(":")[0]) + ":", "", Integer.parseInt(time.split(":")[1]), mineType, color);
                super.draw(context);
                this.timeAnim.settings(true, ColorRGBA.WHITE);
            }
        }
    }

    @Override
    public boolean canShow() {
        if (MineStatus.mc.field_1687 != null && MineStatus.mc.field_1724 != null && ServerUtility.spawn()) {
            this.vec = ServerUtility.is("holyworld") ? new class_243(23.0, 41.0, -156.0) : new class_243(-52.0, 87.0, 3.0);
            for (class_1297 entity : MineStatus.mc.field_1687.method_18112()) {
                class_1531 armorStand;
                if (!(entity instanceof class_1531) || !(armorStand = (class_1531)entity).method_5805() || !this.near(armorStand, this.vec)) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    private boolean near(class_1531 a, class_243 v) {
        return Math.abs(a.method_23317() - v.field_1352) <= 2.0 && Math.abs(a.method_23318() - v.field_1351) <= 2.0 && Math.abs(a.method_23321() - v.field_1350) <= 2.0;
    }
}

