/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_640
 */
package micronix.experiment.ui.hud.impl.island.impl;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.ui.hud.impl.island.DynamicIsland;
import micronix.experiment.ui.hud.impl.island.IslandStatus;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_640;

@Environment(value=EnvType.CLIENT)
public class DefaultStatus
extends IslandStatus {
    public DefaultStatus(SelectSetting setting) {
        super(setting, "default");
    }

    @Override
    public void draw(CustomDrawContext context) {
        DynamicIsland island = Experiment.getInstance().getHud().getIsland();
        float y = 7.0f;
        float padding = 8.0f;
        float iconTextGap = 6.0f;
        float separatorSpacing = 6.0f;
        this.size.height = 22.0f;
        float calculatedWidth = padding + -143.0f;
        float dotSize = 10.0f;
        float logoSize = 10.0f;
        float roleFont = 8.0f;
        String role = "Experiment Client | 2.0";
        calculatedWidth += dotSize + iconTextGap;
        calculatedWidth += Fonts.SYSTEMDLC.getFont(roleFont).width(role) + separatorSpacing;
        calculatedWidth += Fonts.ICONS.getFont(8.0f).width("H") + separatorSpacing;
        int ping = this.getPing();
        String pingText = ping + " ms";
        float textFont = 7.5f;
        calculatedWidth += Fonts.SYSTEMDLC.getFont(textFont).width(pingText) + separatorSpacing;
        calculatedWidth += Fonts.ICONS.getFont(8.0f).width("3") + separatorSpacing;
        int fps = IMinecraft.mc.method_47599();
        String fpsText = fps + " fps";
        calculatedWidth += Fonts.SYSTEMDLC.getFont(textFont).width(fpsText);
        calculatedWidth += dotSize + iconTextGap;
        this.size.width = (calculatedWidth += Fonts.SYSTEMDLC.getFont(roleFont).width(role) + separatorSpacing) + padding;
        float x = sr.getScaledWidth() / 2.0f - this.size.width / 2.0f;
        float currentX = x + padding;
        float centerY = y + this.size.height / 2.0f;
        currentX = x + padding;
        centerY = y + this.size.height / 2.0f;
        context.drawRoundedRect(currentX, centerY - dotSize / 2.0f, dotSize, dotSize, BorderRadius.all(dotSize / 2.0f), Colors.getAccentColor().withAlpha(0.0f));
        context.drawTexture(Experiment.id("icons/hud/logo.png"), currentX, centerY - dotSize / 2.0f, logoSize, logoSize, Colors.getAccentColor());
        float roleTextHeight = Fonts.SYSTEMDLC.getFont(roleFont).height();
        context.drawText(Fonts.SYSTEMDLC.getFont(roleFont), role, currentX += dotSize + iconTextGap, centerY - roleTextHeight / 2.0f, Colors.getTextColor());
        float iconHeight = Fonts.REGULAR.getFont(8.0f).height();
        context.drawText(Fonts.ICONS.getFont(8.0f), "H", currentX += Fonts.SYSTEMDLC.getFont(roleFont).width(role) + separatorSpacing, centerY - iconHeight / 2.0f, Colors.getAccentColor().withAlpha(255.0f));
        context.drawText(Fonts.SYSTEMDLC.getFont(textFont), pingText, currentX += Fonts.ICONS.getFont(8.0f).width("H") + separatorSpacing, centerY - Fonts.SYSTEMDLC.getFont(textFont).height() / 2.0f, Colors.getTextColor());
        context.drawText(Fonts.ICONS.getFont(8.0f), "3", currentX += Fonts.SYSTEMDLC.getFont(textFont).width(pingText) + separatorSpacing, centerY - iconHeight / 2.0f, Colors.getAccentColor().withAlpha(255.0f));
        context.drawText(Fonts.SYSTEMDLC.getFont(textFont), fpsText, currentX += Fonts.ICONS.getFont(8.0f).width("3") + separatorSpacing, centerY - Fonts.SYSTEMDLC.getFont(textFont).height() / 2.0f, Colors.getTextColor());
    }

    private int getPing() {
        class_640 playerListEntry;
        if (IMinecraft.mc.field_1724 != null && IMinecraft.mc.method_1562() != null && (playerListEntry = IMinecraft.mc.method_1562().method_2871(IMinecraft.mc.field_1724.method_5667())) != null) {
            return playerListEntry.method_2959();
        }
        return 0;
    }

    @Override
    public boolean canShow() {
        return true;
    }
}

