/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.impl.island;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class IslandSize {
    public float width;
    public float height;

    public void update(float width, float height) {
        this.width = width;
        this.height = height;
    }

    public IslandSize(float width, float height) {
        this.width = width;
        this.height = height;
    }
}

