/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.impl.island;

import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.ui.hud.impl.island.IslandStatus;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ExtandableStatus
extends IslandStatus {
    public ExtandableStatus(SelectSetting setting, String name) {
        super(setting, name);
    }

    @Override
    public boolean canShow() {
        return false;
    }
}

