/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_408
 */
package micronix.experiment.ui.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudEditorScreen;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.gui.GuiUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_408;

@Environment(value=EnvType.CLIENT)
public class InventoryHud
extends HudElement {
    private final BooleanSetting alwaysDisplay = new BooleanSetting(this, "hud.always_display");
    private final Animation content = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation[][] itemAnims = new Animation[3][9];

    public InventoryHud() {
        super("hud.inventory", "icons/hud/inventory.png");
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                this.itemAnims[row][col] = new Animation(300L, 0.0f, Easing.BAKEK);
            }
        }
    }

    @Override
    public void update(UIContext context) {
        super.update(context);
        int rows = 3;
        this.width = 147.0f;
        this.height = 23.0f + (float)rows * 13.0f + (float)(rows - 1) * 2.0f + 7.0f;
    }

    @Override
    protected void renderComponent(UIContext context) {
        if (InventoryHud.mc.field_1724 != null) {
            Font font = Fonts.SYSTEMDLC.getFont(7.0f);
            boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
            ColorRGBA bgColor = Colors.getBackgroundColor().withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
            this.content.update(this.animation.getValue() * this.visible.getValue() >= 1.0f);
            if (this.animation.getValue() != 0.0f) {
                float prev = RenderSystem.getShaderColor()[3];
                context.drawShadow(this.x - 5.0f, this.y - 5.0f, this.width + 10.0f, this.height + 10.0f, 15.0f, BorderRadius.all(5.0f), ColorRGBA.BLACK.withAlpha(63.75f * this.dragAnim.getValue()));
                if (Interface.showMinimalizm()) {
                    context.drawBlurredRect(this.x, this.y, this.width, this.height, 11.25f, 7.0f, BorderRadius.all(5.0f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue() * Interface.minimalizm()));
                }
                if (Interface.showGlass()) {
                    context.drawLiquidGlass(this.x, this.y, this.width, this.height, 7.0f, Interface.getDistortion() - 0.07f * this.dragAnim.getValue(), BorderRadius.all(5.0f), Colors.getLiquidGlassColor().withAlpha(255.0f * this.animation.getValue() * Interface.glass()));
                }
                context.drawSquircle(this.x, this.y, this.width, this.height, 7.0f, BorderRadius.all(6.0f), bgColor);
                float alpha = 255.0f * this.content.getValue();
                float headerHeight = 18.0f;
                float iconSize = 10.0f;
                context.drawTexture(Experiment.id(this.icon), this.x + 6.0f, this.y + 4.0f, iconSize, iconSize, Colors.getAccentColor().withAlpha(alpha));
                context.drawText(font, Localizator.translate("hud.inventory"), this.x + 10.0f + iconSize, this.y + GuiUtility.getMiddleOfBox(font.height(), headerHeight) + 0.5f, Colors.getTextColor().withAlpha(alpha));
                context.drawRect(this.x, this.y + headerHeight, this.width, 0.5f, Colors.getTextColor().withAlpha(30.0f * this.content.getValue()));
                float startY = this.y + headerHeight + 4.5f;
                float startX = this.x + 7.0f;
                float itemSize = 13.0f;
                float gap = 2.0f;
                for (int row = 0; row < 3; ++row) {
                    for (int col = 0; col < 9; ++col) {
                        int slotIndex = 9 + row * 9 + col;
                        class_1799 stack = InventoryHud.mc.field_1724.method_31548().method_5438(slotIndex);
                        boolean hasItem = !stack.method_7960();
                        this.itemAnims[row][col].update(true);
                        float itemAnim = this.content.getValue() * this.itemAnims[row][col].getValue();
                        if (!(itemAnim > 0.0f)) continue;
                        float itemX = startX + (float)col * (itemSize + gap);
                        float itemY = startY + (float)row * (itemSize + gap);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(prev * itemAnim));
                        context.drawBlurredRect(itemX, itemY, itemSize, itemSize, 1.25f, BorderRadius.all(1.5f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue()));
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                        ColorRGBA slotBgColor = hasItem ? bgColor : bgColor.mix(ColorRGBA.BLACK, 0.4f);
                        context.drawRoundedRect(itemX, itemY, itemSize, itemSize, BorderRadius.all(1.5f), slotBgColor.withAlpha(slotBgColor.getAlpha() * itemAnim));
                        context.drawRoundedBorder(itemX, itemY, itemSize, itemSize, 0.3f, BorderRadius.all(1.5f), Colors.getTextColor().withAlpha(50.0f * itemAnim));
                        if (!hasItem) continue;
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(prev * itemAnim));
                        context.drawItem(stack, itemX - 11.0f + itemSize / 2.0f + 5.5f, itemY, 0.7f);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                        if (stack.method_7947() <= 1) continue;
                        String count = String.valueOf(stack.method_7947());
                        Font countFont = Fonts.REGULAR.getFont(6.0f);
                        context.drawRightText(countFont, count, itemX + itemSize - 2.0f, itemY + itemSize - countFont.height() - 1.0f, Colors.WHITE.withAlpha(alpha * itemAnim));
                    }
                }
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            }
        }
    }

    @Override
    public boolean show() {
        if (InventoryHud.mc.field_1724 == null) {
            return false;
        }
        if (!(InventoryHud.mc.field_1755 instanceof class_408) && !(InventoryHud.mc.field_1755 instanceof HudEditorScreen)) {
            if (this.alwaysDisplay.isEnabled()) {
                return true;
            }
            for (int i = 9; i < 36; ++i) {
                if (InventoryHud.mc.field_1724.method_31548().method_5438(i).method_7960()) continue;
                return true;
            }
            return false;
        }
        return true;
    }
}

