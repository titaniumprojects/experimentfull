/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_408
 */
package micronix.experiment.ui.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudEditorScreen;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_408;

@Environment(value=EnvType.CLIENT)
public class ArmorHud
extends HudElement {
    private final BooleanSetting alwaysDisplay = new BooleanSetting(this, "hud.always_display").enabled(true);

    public ArmorHud() {
        super("hud.armor", "icons/hud/armor.png");
    }

    @Override
    public void update(UIContext context) {
        this.width = 81.0f;
        this.height = 15.0f;
        super.update(context);
    }

    @Override
    protected void renderComponent(UIContext context) {
        if (ArmorHud.mc.field_1724 != null && ArmorHud.mc.field_1687 != null) {
            int i;
            Font font = Fonts.SEMIBOLD.getFont(5.5f);
            boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
            ColorRGBA bgColor = Colors.getBackgroundColor().withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
            float slotWidth = 18.0f;
            float slotHeight = 15.0f;
            float spacing = 3.0f;
            float startX = this.x;
            float slotY = this.y;
            float prev = RenderSystem.getShaderColor()[3];
            class_1799[] armorItems = new class_1799[4];
            for (i = 0; i < 4; ++i) {
                armorItems[i] = ArmorHud.mc.field_1724.method_31548().method_7372(3 - i);
            }
            for (i = 0; i < 4; ++i) {
                class_1799 stack = armorItems[i];
                float slotX = startX + (float)i * (slotWidth + spacing);
                context.drawShadow(slotX - 5.0f, slotY - 5.0f, slotWidth + 10.0f, slotHeight + 10.0f, 15.0f, BorderRadius.all(4.0f), ColorRGBA.BLACK.withAlpha(63.75f * this.dragAnim.getValue()));
                if (Interface.showMinimalizm()) {
                    context.drawBlurredRect(slotX, slotY, slotWidth, slotHeight, 11.25f, 7.0f, BorderRadius.all(4.0f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue() * Interface.minimalizm()));
                }
                if (Interface.showGlass()) {
                    context.drawLiquidGlass(slotX, slotY, slotWidth, slotHeight, 7.0f, Interface.getDistortion() - 0.07f * this.dragAnim.getValue(), BorderRadius.all(4.0f), Colors.getLiquidGlassColor().withAlpha(255.0f * this.animation.getValue() * Interface.glass()));
                }
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                context.drawRoundedRect(slotX, slotY, slotWidth, slotHeight, BorderRadius.all(4.0f), bgColor);
                if (stack.method_7960()) continue;
                float itemSize = 0.75f;
                float itemWidth = 16.0f * itemSize;
                float itemOffsetX = (slotWidth - itemWidth) / 2.0f;
                float itemOffsetY = (slotHeight - itemWidth) / 2.0f;
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                context.drawItem(stack, slotX + itemOffsetX, slotY + itemOffsetY, itemSize);
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                int maxDamage = stack.method_7936();
                if (maxDamage <= 0) continue;
                int damage = stack.method_7919();
                int durability = maxDamage - damage;
                int percentage = durability * 100 / maxDamage;
                String percentText = percentage + "%";
                float textWidth = font.width(percentText);
                float textHeight = font.height();
                float textX = slotX + (slotWidth - textWidth) / 2.0f;
                float textY = slotY + (slotHeight - textHeight) / 2.0f;
                context.drawText(font, percentText, textX + 0.5f, textY + 0.5f, ColorRGBA.BLACK.withAlpha(150.0f));
                ColorRGBA textColor = percentage > 50 ? ColorRGBA.WHITE : (percentage > 25 ? new ColorRGBA(255.0f, 200.0f, 0.0f, 255.0f) : new ColorRGBA(255.0f, 50.0f, 50.0f, 255.0f));
                context.drawText(font, percentText, textX, textY, textColor);
            }
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    @Override
    public boolean show() {
        if (ArmorHud.mc.field_1724 == null || ArmorHud.mc.field_1687 == null) {
            return false;
        }
        if (!(ArmorHud.mc.field_1755 instanceof class_408) && !(ArmorHud.mc.field_1755 instanceof HudEditorScreen)) {
            boolean hasArmor = false;
            for (int i = 0; i < 4; ++i) {
                if (ArmorHud.mc.field_1724.method_31548().method_7372(i).method_7960()) continue;
                hasArmor = true;
                break;
            }
            return hasArmor || this.alwaysDisplay.isEnabled();
        }
        return true;
    }
}

