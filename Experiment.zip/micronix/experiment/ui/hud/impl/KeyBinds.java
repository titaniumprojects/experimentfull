/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_408
 */
package micronix.experiment.ui.hud.impl;

import java.util.ArrayList;
import java.util.Comparator;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.ui.hud.HudEditorScreen;
import micronix.experiment.ui.hud.HudList;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.render.obj.CustomSprite;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_408;

@Environment(value=EnvType.CLIENT)
public class KeyBinds
extends HudList {
    int lastSize = -1;
    private final BooleanSetting alwaysDisplay = new BooleanSetting(this, "hud.always_display");

    public KeyBinds() {
        super("hud.keybinds", "icons/hud/keybinds.png");
    }

    @Override
    public void update(UIContext context) {
        this.width = 92.0f;
        this.height = 18.0f;
        for (Module module : Experiment.getInstance().getModuleManager().getModules()) {
            boolean forward = module.isEnabled() && module.getKey() != -1;
            module.getKeybindsAnimation().update(forward);
            module.getKeybindsAnimation().setEasing(Easing.BAKEK);
            if (module.getKeybindsAnimation().getValue() > 0.0f) {
                float textWidth = Fonts.REGULAR.getFont(7.0f).width(module.getName() + " " + TextUtility.getKeyName(module.getKey()));
                this.width = Math.max(textWidth + 45.0f, this.width);
            }
            this.height += 18.0f * module.getKeybindsAnimation().getValue();
        }
        if (this.height > 18.0f) {
            this.height += 5.0f;
        }
        super.update(context);
    }

    @Override
    protected void renderComponent(UIContext context) {
        Font font = Fonts.REGULAR.getFont(7.0f);
        ArrayList<Module> modules = new ArrayList<Module>(Experiment.getInstance().getModuleManager().getModules());
        if (this.lastSize == modules.size()) {
            modules.sort(Comparator.comparingDouble(m -> font.width(m.getName())));
            this.lastSize = modules.size();
        }
        context.drawClientRect(this.x, this.y, this.width, Math.max(20.0f, this.height), this.animation.getValue(), this.dragAnim.getValue(), 7.0f);
        context.drawRoundedBorder(this.x, this.y, this.width, Math.max(20.0f, this.height), 0.01f, BorderRadius.all(5.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, 40.0f));
        float headerHeight = 18.0f;
        float iconSize = 8.0f;
        context.drawTexture(Experiment.id(this.icon), this.x + 6.0f, this.y + 6.0f, iconSize, iconSize, Colors.getAccentColor());
        context.drawText(Fonts.SYSTEMDLC.getFont(7.0f), Localizator.translate("hud.keybinds"), this.x + 7.0f + iconSize + 4.0f, this.y + GuiUtility.getMiddleOfBox(font.height(), headerHeight) + 0.5f, Colors.getTextColor());
        if (this.height >= 23.0f) {
            context.drawRect(this.x, this.y + headerHeight, this.width, 0.5f, Colors.getTextColor().withAlpha(30.0f));
        }
        float offset = headerHeight + 4.5f;
        for (Module module : modules) {
            Animation anim = module.getKeybindsAnimation();
            if (anim.getValue() == 0.0f) continue;
            float itemHeight = 18.0f;
            float alpha = anim.getValue();
            float moduleIconSize = 10.0f;
            CustomSprite categorySprite = this.getCategorySprite(module.getCategory());
            context.drawSprite(categorySprite, this.x + 5.0f, this.y + offset + GuiUtility.getMiddleOfBox(moduleIconSize, itemHeight), moduleIconSize, moduleIconSize, Colors.getTextColor().withAlpha(255.0f * alpha));
            float separatorX = this.x + 5.0f + moduleIconSize + 4.0f;
            context.drawText(font, "|", separatorX, this.y + offset + GuiUtility.getMiddleOfBox(font.height(), itemHeight), Colors.getTextColor().withAlpha(80.0f * alpha));
            float nameX = separatorX + 6.0f;
            context.drawText(font, module.getName(), nameX, this.y + offset + GuiUtility.getMiddleOfBox(font.height(), itemHeight), Colors.getTextColor().withAlpha(255.0f * alpha));
            String keyName = TextUtility.getKeyName(module.getKey());
            Font keyFont = Fonts.MEDIUM.getFont(6.5f);
            float keyWidth = keyFont.width(keyName) + 10.0f;
            float keyHeight = 13.0f;
            float keyX = this.x + this.width - 5.0f - keyWidth;
            float keyY = this.y + offset + (itemHeight - keyHeight) / 2.0f;
            context.drawRoundedRect(keyX, keyY, keyWidth, keyHeight, BorderRadius.all(4.0f), Colors.getTextColor().withAlpha(10.0f * alpha));
            float textX = keyX + (keyWidth - keyFont.width(keyName)) / 2.0f + 1.0f;
            float textY = keyY + (keyHeight - keyFont.height()) / 2.0f;
            context.drawText(keyFont, keyName, textX, textY, Colors.getTextColor().withAlpha(255.0f * alpha));
            offset += itemHeight * anim.getValue();
        }
    }

    private CustomSprite getCategorySprite(ModuleCategory category) {
        return switch (category) {
            default -> throw new MatchException(null, null);
            case ModuleCategory.COMBAT -> CustomSprite.BIG_COMBAT;
            case ModuleCategory.MOVEMENT -> CustomSprite.BIG_MOVEMENT;
            case ModuleCategory.VISUALS -> CustomSprite.BIG_VISUALS;
            case ModuleCategory.PLAYER -> CustomSprite.BIG_PLAYER;
            case ModuleCategory.OTHER -> CustomSprite.BIG_OTHER;
        };
    }

    @Override
    public boolean show() {
        return !Experiment.getInstance().getModuleManager().getModules().stream().filter(module -> module.isEnabled() && module.getKey() != -1).toList().isEmpty() || KeyBinds.mc.field_1755 instanceof class_408 || KeyBinds.mc.field_1755 instanceof HudEditorScreen || this.alwaysDisplay.isEnabled();
    }
}

