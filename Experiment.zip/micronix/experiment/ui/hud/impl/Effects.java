/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1058
 *  net.minecraft.class_1291
 *  net.minecraft.class_1293
 *  net.minecraft.class_290
 *  net.minecraft.class_408
 *  net.minecraft.class_4081
 */
package micronix.experiment.ui.hud.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.notifications.NotificationType;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.ui.components.animated.AnimatedNumber;
import micronix.experiment.ui.hud.HudList;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.server.ServerUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.mixins.StatusEffectInstanceAddition;
import micronix.experiment.utility.render.batching.Batching;
import micronix.experiment.utility.render.batching.impl.FontBatching;
import micronix.experiment.utility.render.batching.impl.IconBatching;
import micronix.experiment.utility.render.batching.impl.RectBatching;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_290;
import net.minecraft.class_408;
import net.minecraft.class_4081;

@Environment(value=EnvType.CLIENT)
public class Effects
extends HudList {
    private final BooleanSetting alwaysDisplay = new BooleanSetting(this, "hud.always_display");
    int lastSize = -1;
    private final Map<String, class_1293> effects = new TreeMap<String, class_1293>();
    private final Map<class_1291, Boolean> ended = new HashMap<class_1291, Boolean>();
    private final Animation content = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    private final BooleanSetting alert = new BooleanSetting(this, "hud.effects.alert");

    public Effects() {
        super("hud.effects", "icons/hud/potion.png");
    }

    @Override
    public void update(UIContext context) {
        this.width = 92.0f;
        this.height = 18.0f;
        Collection original = Effects.mc.field_1724.method_6026();
        this.content.update(true);
        for (class_1293 eff : original) {
            class_1291 potion = (class_1291)eff.method_5579().comp_349();
            String realName = potion.method_5560().getString();
            if (realName == null || ServerUtility.isCM()) continue;
            if (this.effects.containsKey(realName)) {
                this.effects.replace(realName, eff);
                Animation anim = ((StatusEffectInstanceAddition)eff).experiment$getAnimPotion();
                if (anim.getValue() != 0.0f) continue;
                anim.setValue(1.0f);
                continue;
            }
            this.effects.put(realName, eff);
        }
        if (!this.effects.isEmpty()) {
            this.height += 5.0f;
        }
        for (class_1293 effx : this.effects.values()) {
            Animation anim = ((StatusEffectInstanceAddition)effx).experiment$getAnimPotion();
            class_1291 potion = (class_1291)effx.method_5579().comp_349();
            if (this.alert.isEnabled()) {
                String effectName = potion.method_5560().getString() + " " + String.valueOf(effx.method_5578() > 0 ? Integer.valueOf(effx.method_5578() + 1) : "");
                if (!Effects.mc.field_1724.method_6059(effx.method_5579())) {
                    if (!this.ended.getOrDefault(potion, false).booleanValue() && !potion.method_18792().equals((Object)class_4081.field_18272)) {
                        Experiment.getInstance().getNotificationManager().addNotificationOther(NotificationType.INFO, "\u042d\u0444\u0444\u0435\u043a\u0442 " + effectName + " \u0437\u0430\u043a\u043e\u043d\u0447\u0438\u043b\u0441\u044f", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u044d\u0444\u0444\u0435\u043a\u0442\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u043e");
                        this.ended.put(potion, true);
                    }
                } else {
                    this.ended.put(potion, false);
                }
            }
            anim.update(original.contains(effx));
            anim.setEasing(Easing.BAKEK);
            this.width = Math.max(Fonts.REGULAR.getFont(7.0f).width(potion.method_5560().getString()) + 60.0f, this.width);
            this.height += 18.0f * anim.getValue();
        }
        super.update(context);
    }

    @Override
    protected void renderComponent(UIContext context) {
        if (Effects.mc.field_1724 != null && Effects.mc.field_1687 != null) {
            class_1291 potion;
            Font font = Fonts.REGULAR.getFont(7.0f);
            float offset = 22.0f;
            float alpha = 255.0f * this.content.getValue();
            float iconSize = 8.0f;
            context.drawClientRect(this.x, this.y, this.width, Math.max(20.0f, this.height), this.animation.getValue(), this.dragAnim.getValue(), 6.0f);
            context.drawRoundedBorder(this.x, this.y, this.width, Math.max(20.0f, this.height), 0.01f, BorderRadius.all(5.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, 40.0f));
            context.drawTexture(Experiment.id(this.icon), this.x + 6.0f, this.y + 6.0f, iconSize, iconSize, Colors.getAccentColor().withAlpha(alpha));
            float headerHeight = 18.0f;
            Font headerFont = Fonts.SYSTEMDLC.getFont(7.0f);
            String headerText = Localizator.translate("hud.effects");
            float textWidth = headerFont.width(headerText);
            float textX = this.x + 11.0f + iconSize;
            context.drawText(headerFont, headerText, textX, this.y + GuiUtility.getMiddleOfBox(font.height(), headerHeight) + 0.5f, Colors.getTextColor());
            if (this.height >= 23.0f) {
                context.drawRect(this.x, this.y + headerHeight, this.width, 0.5f, Colors.getTextColor().withAlpha(30.0f));
            }
            class_1293 toRemove = null;
            RectBatching split = new RectBatching(class_290.field_1576, context.method_51448());
            for (class_1293 class_12932 : this.effects.values()) {
                Animation anim = ((StatusEffectInstanceAddition)class_12932).experiment$getAnimPotion();
                if (anim.getValue() == 0.0f) {
                    toRemove = class_12932;
                    continue;
                }
                float off = -4.5f + 4.5f * anim.getValue();
                if (offset != 22.0f) {
                    context.drawRect(this.x, this.y + offset + off, this.width, 0.5f, Colors.getTextColor().withAlpha(5.1f * anim.getValue()));
                }
                offset += 18.0f * anim.getValue();
            }
            ((Batching)split).draw();
            offset = 22.0f;
            IconBatching texture = new IconBatching(class_290.field_1575, context.method_51448());
            for (class_1293 effx : this.effects.values()) {
                Animation anim = ((StatusEffectInstanceAddition)effx).experiment$getAnimPotion();
                if (anim.getValue() == 0.0f) continue;
                float off = -4.5f + 4.5f * anim.getValue();
                class_1058 sprite = mc.method_18505().method_18663(effx.method_5579());
                context.drawTexture(sprite.method_45852(), this.x + 5.0f, this.y + offset + off + GuiUtility.getMiddleOfBox(iconSize, 18.0f), iconSize, iconSize, sprite.method_4594(), sprite.method_4577(), sprite.method_4593(), sprite.method_4575(), ColorRGBA.WHITE.withAlpha(255.0f * anim.getValue()));
                offset += 18.0f * anim.getValue();
            }
            ((Batching)texture).draw();
            offset = 22.0f;
            for (class_1293 effxx : this.effects.values()) {
                float timeWidth;
                String timeText;
                Animation anim = ((StatusEffectInstanceAddition)effxx).experiment$getAnimPotion();
                AnimatedNumber timeAnimation = ((StatusEffectInstanceAddition)effxx).experiment$getTimeAnimation();
                potion = (class_1291)effxx.method_5579().comp_349();
                if (anim.getValue() == 0.0f) continue;
                float off = -4.5f + 4.5f * anim.getValue();
                float itemHeight = 18.0f;
                Font timeFont = Fonts.MEDIUM.getFont(6.5f);
                float timeHeight = 13.0f;
                if (!effxx.method_48559() && effxx.method_5584() < 999999999) {
                    int totalSeconds = effxx.method_5584() / 20;
                    int minutes = totalSeconds / 60;
                    int seconds = totalSeconds % 60;
                    timeText = String.format("%02d:%02d", minutes, seconds);
                    timeWidth = timeFont.width(timeText) + 10.0f;
                } else {
                    timeText = "**:**";
                    timeWidth = timeFont.width(timeText) + 10.0f;
                }
                float timeX = this.x + this.width - 5.0f - timeWidth;
                float timeY = this.y + offset + off + (itemHeight - timeHeight) / 2.0f;
                context.drawRoundedRect(timeX, timeY, timeWidth, timeHeight, BorderRadius.all(4.0f), Colors.getTextColor().withAlpha(10.0f * anim.getValue()));
                if (!effxx.method_48559() && effxx.method_5584() < 999999999) {
                    int totalSeconds = effxx.method_5584() / 20;
                    int minutes = totalSeconds / 60;
                    int seconds = totalSeconds % 60;
                    String timeStr = String.format("%02d:%02d", minutes, seconds);
                    String minutesAndSeparator = String.format("%02d:", minutes);
                    float minutesWidth = timeFont.width(minutesAndSeparator);
                    float totalWidth = timeFont.width(timeStr);
                    float timeStartX = timeX + (timeWidth - totalWidth) / 2.0f + 1.0f;
                    float timeTextY = timeY + (timeHeight - timeFont.height()) / 2.0f;
                    context.drawText(timeFont, minutesAndSeparator, timeStartX, timeTextY, Colors.getTextColor().withAlpha(255.0f * anim.getValue()));
                    timeAnimation.settings(true, Colors.getTextColor().withAlpha(255.0f * anim.getValue()));
                    timeAnimation.update(seconds);
                    timeAnimation.pos(timeStartX + minutesWidth, timeTextY);
                    timeAnimation.render(context);
                } else {
                    float timeTextX = timeX + (timeWidth - timeFont.width(timeText)) / 2.0f + 1.0f;
                    float timeTextY = timeY + (timeHeight - timeFont.height()) / 2.0f;
                    context.drawText(timeFont, timeText, timeTextX, timeTextY, Colors.getTextColor().withAlpha(255.0f * anim.getValue()));
                }
                offset += 18.0f * anim.getValue();
            }
            FontBatching fontBatching = new FontBatching(class_290.field_1575, font.getFont());
            offset = 22.0f;
            for (class_1293 effxxx : this.effects.values()) {
                Animation anim = ((StatusEffectInstanceAddition)effxxx).experiment$getAnimPotion();
                potion = (class_1291)effxxx.method_5579().comp_349();
                if (anim.getValue() == 0.0f) continue;
                float offx = -4.5f + 4.5f * anim.getValue();
                String effectName = potion.method_5560().getString() + " " + String.valueOf(effxxx.method_5578() > 0 ? Integer.valueOf(effxxx.method_5578() + 1) : "");
                float separatorX = this.x + 5.0f + iconSize + 4.0f;
                context.drawText(font, "|", separatorX, this.y + offset + offx + GuiUtility.getMiddleOfBox(font.height(), 18.0f), Colors.getTextColor().withAlpha(80.0f * anim.getValue()));
                float nameX = separatorX + 6.0f;
                context.drawText(font, effectName, nameX, this.y + offset + offx + GuiUtility.getMiddleOfBox(font.height(), 18.0f), Colors.getTextColor().withAlpha(255.0f * anim.getValue()));
                offset += 18.0f * anim.getValue();
            }
            ((Batching)fontBatching).draw();
        }
    }

    @Override
    public boolean show() {
        if (Effects.mc.field_1724 == null || Effects.mc.field_1687 == null) {
            return false;
        }
        return (!Effects.mc.field_1724.method_6026().isEmpty() || Effects.mc.field_1755 instanceof class_408 || this.alwaysDisplay.isEnabled()) && !ServerUtility.isCM();
    }
}

