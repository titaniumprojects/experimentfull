/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_408
 *  net.minecraft.class_742
 *  net.minecraft.class_9334
 */
package micronix.experiment.ui.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.EntityUtility;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.ScissorUtility;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_408;
import net.minecraft.class_742;
import net.minecraft.class_9334;

@Environment(value=EnvType.CLIENT)
public class TargetHud
extends HudElement {
    private final ModeSetting armor = new ModeSetting(this, "hud.targethud.armor");
    private final ModeSetting.Value armorNone = new ModeSetting.Value(this.armor, "hud.targethud.armor.none");
    private final ModeSetting.Value armorIcon = new ModeSetting.Value(this.armor, "hud.targethud.armor.icon").select();
    private final Animation content = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation health = new Animation(300L, 0.0f, Easing.BAKEK);
    private final Animation golden = new Animation(300L, 0.0f, Easing.BAKEK);
    private final Animation number = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final Animation itemsX = new Animation(300L, 0.0f, Easing.BAKEK);
    private final Animation copy = new Animation(300L, 0.0f, Easing.BAKEK);
    private final Animation success = new Animation(500L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation eatingPulse = new Animation(150L, 0.0f, Easing.BAKEK);
    private final Animation pulseIntensity = new Animation(50L, 0.0f, Easing.SINE_IN_OUT);
    private final Animation[] items = new Animation[4];
    private class_1309 target;
    private final Timer copyTimer = new Timer();
    private boolean copied;

    public TargetHud() {
        super("hud.targethud", "icons/hud/target.png");
        for (int i = 0; i < this.items.length; ++i) {
            this.items[i] = new Animation(300L, 0.0f, Easing.BAKEK);
        }
    }

    @Override
    public void update(UIContext context) {
        super.update(context);
        this.width = 100.0f;
        this.height = 32.0f;
    }

    @Override
    protected void renderComponent(UIContext context) {
        class_1309 target = this.getTarget();
        if (target != null) {
            this.target = target;
        }
        if (this.target != null) {
            float f;
            float f2;
            Font regular7 = Fonts.REGULAR.getFont(7.0f);
            Font semibold6 = Fonts.SEMIBOLD.getFont(6.0f);
            boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
            ColorRGBA bgColor = Colors.getBackgroundColor().withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
            boolean hover = GuiUtility.isHovered(this.x + 30.0f, this.y + 3.0f + 6.0f * this.content.getValue(), 60.0, 6.0, context);
            if (!hover || this.copyTimer.finished(1000L)) {
                this.copied = false;
            }
            boolean isEating = this.target.method_6115() && this.target.method_6030().method_57826(class_9334.field_50075);
            this.eatingPulse.update(isEating);
            if (isEating) {
                float pulse = (float)Math.sin((double)System.currentTimeMillis() / 100.0) * 0.5f + 0.5f;
                this.pulseIntensity.setValue(pulse);
            }
            this.copy.update(hover);
            this.success.update(this.copied);
            this.content.update(this.animation.getValue() * this.visible.getValue() >= 1.0f);
            class_1309 class_13092 = this.target;
            if (class_13092 instanceof class_1657) {
                class_1657 player = (class_1657)class_13092;
                f2 = EntityUtility.getHealth(player);
            } else {
                f2 = this.target.method_6032();
            }
            this.health.update(f2 / this.target.method_6063());
            this.golden.update(this.target.method_6067() / 20.0f);
            class_1309 class_13093 = this.target;
            if (class_13093 instanceof class_1657) {
                class_1657 playerx = (class_1657)class_13093;
                f = EntityUtility.getHealth(playerx);
            } else {
                f = this.target.method_6032();
            }
            float healthNum = f;
            this.number.update(healthNum);
            if (this.animation.getValue() != 0.0f) {
                if (!this.armorNone.isSelected()) {
                    float prev = RenderSystem.getShaderColor()[3];
                    RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                    context.drawItem(class_1802.field_8058, -992.0f, 994.0f, 1.0f);
                    RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                    float animOff = 0.0f;
                    int i = 0;
                    class_1799[] handItems = new class_1799[]{this.target.method_6047(), this.target.method_6079()};
                    for (class_1799[] itemStack : this.target.method_5661()) {
                        if (itemStack.method_7960()) continue;
                        animOff += 13.0f;
                    }
                    float itemSize = 11.0f;
                    if (this.armorIcon.isSelected()) {
                        for (class_1799 handItem : handItems) {
                            if (handItem.method_7960()) continue;
                            animOff += 13.0f;
                        }
                    }
                    this.itemsX.update(animOff - 2.0f);
                    float xOffset = -this.itemsX.getValue() / 2.0f;
                    for (class_1799 itemStackx : this.target.method_5661()) {
                        this.items[i].update(!itemStackx.method_7960());
                        float anim = this.content.getValue() * this.items[i].getValue();
                        float panelWidth = 11.0f;
                        float panelHeight = 11.0f;
                        float panelX = this.x + this.width / 2.0f + xOffset;
                        float panelY = this.y + this.height - 4.0f + 6.0f * anim;
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(prev * anim));
                        context.drawBlurredRect(panelX, panelY, panelWidth, panelHeight, 1.25f, BorderRadius.all(1.5f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue()));
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                        context.drawRoundedRect(panelX, panelY, panelWidth, panelHeight, BorderRadius.all(1.5f), bgColor.withAlpha(bgColor.getAlpha() * anim));
                        ScissorUtility.push(context.method_51448(), panelX, panelY, panelWidth, panelHeight);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(prev * anim * 0.5f));
                        context.drawItem(itemStackx, panelX - 11.0f + panelWidth / 2.0f + 5.5f, panelY, 0.7f);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                        ScissorUtility.pop();
                        xOffset += (panelWidth + 2.0f) * anim;
                        ++i;
                    }
                    float handX = xOffset;
                    for (class_1799 handItemx : handItems) {
                        if (handItemx.method_7960()) continue;
                        float handItemX = this.x + this.width / 2.0f + handX;
                        float handItemY = this.y + this.height - 4.0f + 6.0f * this.content.getValue();
                        float alpha = this.content.getValue() * (isEating && this.target.method_6030() == handItemx ? 0.5f + 0.7f * this.pulseIntensity.getValue() : 1.0f);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(prev * alpha));
                        context.drawBlurredRect(handItemX, handItemY, itemSize, itemSize, 1.25f, BorderRadius.all(1.5f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue()));
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                        context.drawRoundedRect(handItemX, handItemY, itemSize, itemSize, BorderRadius.all(1.5f), bgColor.withAlpha(bgColor.getAlpha() * alpha));
                        ScissorUtility.push(context.method_51448(), handItemX, handItemY, itemSize, itemSize);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(prev * alpha));
                        context.drawItem(handItemx, handItemX - 11.0f + itemSize / 2.0f + 5.5f, handItemY, 0.7f);
                        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                        ScissorUtility.pop();
                        handX += itemSize + 2.0f;
                        xOffset += (itemSize + 2.0f) * this.content.getValue();
                    }
                }
                context.drawShadow(this.x - 5.0f, this.y - 5.0f, this.width + 10.0f, this.height + 10.0f, 15.0f, BorderRadius.all(5.0f), ColorRGBA.BLACK.withAlpha(63.75f * this.dragAnim.getValue()));
                if (Interface.showMinimalizm()) {
                    context.drawBlurredRect(this.x, this.y, this.width, this.height, 11.25f, 7.0f, BorderRadius.all(5.0f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue() * Interface.minimalizm()));
                    context.drawRoundedBorder(this.x, this.y, this.width, this.height, 0.01f, BorderRadius.all(5.0f), new ColorRGBA(255.0f, 255.0f, 255.0f, 40.0f));
                }
                if (Interface.showGlass()) {
                    context.drawLiquidGlass(this.x, this.y, this.width, this.height, 7.0f, Interface.getDistortion() - 0.07f * this.dragAnim.getValue(), BorderRadius.all(5.0f), Colors.getLiquidGlassColor().withAlpha(255.0f * this.animation.getValue() * Interface.glass()));
                }
                context.drawSquircle(this.x, this.y, this.width, this.height, 7.0f, BorderRadius.all(5.0f), bgColor);
                float alpha = 255.0f * this.content.getValue();
                ScissorUtility.push(context.method_51448(), this.x, this.y, this.width, this.height);
                class_1309 i = this.target;
                if (i instanceof class_742) {
                    class_742 playerxx = (class_742)i;
                    context.drawHead(playerxx, this.x + 4.0f, this.y + 3.5f, 18.0f, BorderRadius.all(2.0f), Colors.WHITE.withAlpha(alpha));
                } else {
                    context.drawRoundedTexture(Experiment.id(Interface.glassSelected() ? "icons/hud/whoglass.png" : (Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK ? "icons/hud/whodark.png" : "icons/hud/who.png")), this.x + 4.0f, this.y + 3.5f, 18.0f, 18.0f, BorderRadius.all(2.0f), Colors.WHITE.withAlpha(alpha));
                }
                String numberText = healthNum == 1000.0f ? "?" : TextUtility.formatNumber(this.number.getValue()).replace(",", ".");
                boolean isInvisible = this.target.method_5767();
                String displayName = isInvisible ? "\u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u044b\u0439" : this.target.method_5477().getString();
                String displayHealth = isInvisible ? "?" : numberText;
                context.drawFadeoutText(regular7, displayName, this.x + 26.0f + 8.0f * this.copy.getValue(), this.y + 2.0f + 6.0f * this.content.getValue(), Colors.getTextColor().withAlpha(alpha), 0.7f, 1.0f, this.width - 36.0f - 8.0f * this.copy.getValue());
                RenderUtility.rotate(context.method_51448(), this.x + 24.0f + 5.0f * this.copy.getValue(), this.y + 5.0f + 6.0f * this.content.getValue(), 90.0f * this.success.getValue());
                context.drawTexture(Experiment.id("icons/hud/copy.png"), this.x + 21.0f + 5.0f * this.copy.getValue(), this.y + 2.0f + 6.0f * this.content.getValue(), 6.0f, 6.0f, Colors.getTextColor().withAlpha(alpha * this.copy.getValue() * (1.0f - this.success.getValue())));
                RenderUtility.end(context.method_51448());
                RenderUtility.rotate(context.method_51448(), this.x + 24.0f + 5.0f * this.copy.getValue(), this.y + 5.0f + 6.0f * this.content.getValue(), -90.0f + 90.0f * this.success.getValue());
                context.drawTexture(Experiment.id("icons/check.png"), this.x + 21.0f + 5.0f * this.copy.getValue(), this.y + 2.0f + 6.0f * this.content.getValue(), 6.0f, 6.0f, Colors.GREEN.withAlpha(alpha * this.copy.getValue() * this.success.getValue()));
                RenderUtility.end(context.method_51448());
                String hpText = "HP: " + displayHealth;
                context.drawText(semibold6, hpText, this.x + 26.0f, this.y + 11.0f + 6.0f * this.content.getValue(), Colors.getTextColor().withAlpha(alpha * 0.7f));
                float barHeight = 2.4f;
                float barX = this.x + 4.0f;
                float barY = this.y + 25.0f;
                float barWidth = 92.0f;
                context.drawSquircle(barX, barY, barWidth, barHeight, 3.0f, BorderRadius.sides(0.5f), Colors.getAdditionalColor().withAlpha(alpha * (1.0f - 0.7f * Interface.glass())));
                float healthWidth = barWidth * Math.clamp(this.health.getValue(), 0.0f, 1.0f);
                ColorRGBA glowColor = Colors.getAccentColor();
                context.drawRoundedRect(barX - 2.0f, barY - 2.0f, healthWidth + 4.0f, barHeight + 4.0f, BorderRadius.sides(1.5f), glowColor.withAlpha(alpha * 0.05f));
                context.drawRoundedRect(barX - 1.5f, barY - 1.5f, healthWidth + 3.0f, barHeight + 3.0f, BorderRadius.sides(1.25f), glowColor.withAlpha(alpha * 0.1f));
                context.drawRoundedRect(barX - 1.0f, barY - 1.0f, healthWidth + 2.0f, barHeight + 2.0f, BorderRadius.sides(1.0f), glowColor.withAlpha(alpha * 0.15f));
                context.drawRoundedRect(barX - 0.5f, barY - 0.5f, healthWidth + 1.0f, barHeight + 1.0f, BorderRadius.sides(0.75f), glowColor.withAlpha(alpha * 0.2f));
                ColorRGBA accentColor = Colors.getAccentColor();
                context.drawRoundedRect(barX, barY, healthWidth, barHeight, BorderRadius.sides(0.5f), accentColor.withAlpha(alpha));
                ScissorUtility.pop();
            }
        }
    }

    private class_1309 getTarget() {
        class_1309 mainTarget;
        class_1297 current = Experiment.getInstance().getTargetManager().getCurrentTarget();
        class_1309 class_13092 = mainTarget = current instanceof class_1309 ? (class_1309)current : null;
        if (mainTarget != null) {
            return mainTarget;
        }
        class_1297 class_12972 = TargetHud.mc.field_1692;
        if (class_12972 instanceof class_1309) {
            class_1309 livingEntity = (class_1309)class_12972;
            return livingEntity;
        }
        return TargetHud.mc.field_1755 instanceof class_408 ? TargetHud.mc.field_1724 : null;
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (GuiUtility.isHovered((double)(this.x + 30.0f), (double)(this.y + 3.0f + 6.0f * this.content.getValue()), 60.0, 6.0, mouseX, mouseY)) {
            TextUtility.copyText(TargetHud.mc.field_1724.method_5477().getString());
            this.copyTimer.reset();
            this.copied = true;
        } else {
            super.onMouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public boolean show() {
        class_1309 target = this.getTarget();
        return target != null && !target.method_5767();
    }
}

