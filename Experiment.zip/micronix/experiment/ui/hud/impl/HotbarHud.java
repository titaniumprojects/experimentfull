/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1799
 *  net.minecraft.class_408
 */
package micronix.experiment.ui.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudEditorScreen;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.interfaces.IScaledResolution;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_408;

@Environment(value=EnvType.CLIENT)
public class HotbarHud
extends HudElement {
    public HotbarHud() {
        super("hud.hotbar", "icons/hud/hotbar.png");
    }

    @Override
    public void update(UIContext context) {
        boolean hasOffhand = HotbarHud.mc.field_1724 != null && !HotbarHud.mc.field_1724.method_6079().method_7960();
        float offhandBlockWidth = hasOffhand ? 26.0f : 0.0f;
        float hotbarBlockWidth = 194.0f;
        float gapBetweenBlocks = hasOffhand ? 8.0f : 0.0f;
        this.width = offhandBlockWidth + gapBetweenBlocks + hotbarBlockWidth;
        this.height = 22.0f;
        if (!(HotbarHud.mc.field_1755 instanceof class_408) && !(HotbarHud.mc.field_1755 instanceof HudEditorScreen)) {
            float hotbarCenterX = IScaledResolution.sr.getScaledWidth() / 2.0f;
            float hotbarBlockX = hotbarCenterX - hotbarBlockWidth / 2.0f;
            this.x = hasOffhand ? hotbarBlockX - gapBetweenBlocks - offhandBlockWidth : hotbarBlockX;
            this.y = IScaledResolution.sr.getScaledHeight() - this.height - 1.0f;
        }
        super.update(context);
    }

    @Override
    protected void renderComponent(UIContext context) {
        if (HotbarHud.mc.field_1724 != null && HotbarHud.mc.field_1687 != null) {
            Font font = Fonts.SEMIBOLD.getFont(5.5f);
            boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
            ColorRGBA bgColor = Colors.getBackgroundColor().withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
            float slotWidth = 20.0f;
            float slotHeight = 20.0f;
            float spacing = 1.0f;
            float paddingX = 3.0f;
            float paddingY = 1.5f;
            float offhandPaddingX = 3.0f;
            class_1799 offhandStack = HotbarHud.mc.field_1724.method_6079();
            boolean hasOffhand = !offhandStack.method_7960();
            float offhandBlockWidth = slotWidth + offhandPaddingX * 2.0f;
            float offhandBlockX = this.x;
            float hotbarBlockWidth = 9.0f * slotWidth + 8.0f * spacing + 6.0f;
            float hotbarBlockX = hasOffhand ? offhandBlockX + offhandBlockWidth + 8.0f : this.x;
            float offhandX = offhandBlockX + offhandPaddingX;
            float hotbarStartX = hotbarBlockX + paddingX;
            float slotY = this.y + paddingY;
            float prev = RenderSystem.getShaderColor()[3];
            if (hasOffhand) {
                context.drawShadow(offhandBlockX - 5.0f, this.y - 5.0f, offhandBlockWidth + 10.0f, this.height + 10.0f, 15.0f, BorderRadius.all(6.0f), ColorRGBA.BLACK.withAlpha(63.75f * this.dragAnim.getValue()));
                if (Interface.showMinimalizm()) {
                    context.drawBlurredRect(offhandBlockX, this.y, offhandBlockWidth, this.height, 11.25f, 7.0f, BorderRadius.all(6.0f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue() * Interface.minimalizm()));
                }
                if (Interface.showGlass()) {
                    context.drawLiquidGlass(offhandBlockX, this.y, offhandBlockWidth, this.height, 7.0f, Interface.getDistortion() - 0.07f * this.dragAnim.getValue(), BorderRadius.all(6.0f), Colors.getLiquidGlassColor().withAlpha(255.0f * this.animation.getValue() * Interface.glass()));
                }
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                context.drawRoundedRect(offhandBlockX, this.y, offhandBlockWidth, this.height, BorderRadius.all(6.0f), bgColor);
                float itemSize = 0.85f;
                float itemWidth = 16.0f * itemSize;
                float itemOffsetX = (slotWidth - itemWidth) / 2.0f;
                float itemOffsetY = (slotHeight - itemWidth) / 2.0f;
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                context.drawItem(offhandStack, offhandX + itemOffsetX, slotY + itemOffsetY, itemSize);
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                if (offhandStack.method_7947() > 1) {
                    String count = String.valueOf(offhandStack.method_7947());
                    Font countFont = Fonts.REGULAR.getFont(6.0f);
                    float textX = offhandX + slotWidth - countFont.width(count) - 2.0f;
                    float textY = slotY + slotHeight - countFont.height() - 1.0f;
                    context.drawText(countFont, count, textX + 0.5f, textY + 0.5f, ColorRGBA.BLACK.withAlpha(150.0f));
                    context.drawText(countFont, count, textX, textY, ColorRGBA.WHITE);
                }
            }
            context.drawShadow(hotbarBlockX - 5.0f, this.y - 5.0f, hotbarBlockWidth + 10.0f, this.height + 10.0f, 15.0f, BorderRadius.all(6.0f), ColorRGBA.BLACK.withAlpha(63.75f * this.dragAnim.getValue()));
            if (Interface.showMinimalizm()) {
                context.drawBlurredRect(hotbarBlockX, this.y, hotbarBlockWidth, this.height, 11.25f, 7.0f, BorderRadius.all(6.0f), ColorRGBA.WHITE.withAlpha(255.0f * this.animation.getValue() * Interface.minimalizm()));
            }
            if (Interface.showGlass()) {
                context.drawLiquidGlass(hotbarBlockX, this.y, hotbarBlockWidth, this.height, 7.0f, Interface.getDistortion() - 0.07f * this.dragAnim.getValue(), BorderRadius.all(6.0f), Colors.getLiquidGlassColor().withAlpha(255.0f * this.animation.getValue() * Interface.glass()));
            }
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
            context.drawRoundedRect(hotbarBlockX, this.y, hotbarBlockWidth, this.height, BorderRadius.all(6.0f), bgColor);
            int selectedSlot = HotbarHud.mc.field_1724.method_31548().field_7545;
            for (int i = 0; i < 9; ++i) {
                boolean isSelected;
                class_1799 stack = HotbarHud.mc.field_1724.method_31548().method_5438(i);
                float slotX = hotbarStartX + (float)i * (slotWidth + spacing);
                boolean bl = isSelected = i == selectedSlot;
                if (isSelected) {
                    context.drawRoundedRect(slotX, slotY, slotWidth, slotHeight, BorderRadius.all(6.0f), ColorRGBA.BLACK.withAlpha(80.0f));
                }
                if (stack.method_7960()) continue;
                float itemSize = 0.85f;
                float itemWidth = 16.0f * itemSize;
                float itemOffsetX = (slotWidth - itemWidth) / 2.0f;
                float itemOffsetY = (slotHeight - itemWidth) / 2.0f;
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                context.drawItem(stack, slotX + itemOffsetX, slotY + itemOffsetY, itemSize);
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)prev);
                if (stack.method_7947() <= 1) continue;
                String count = String.valueOf(stack.method_7947());
                Font countFont = Fonts.REGULAR.getFont(6.0f);
                float textX = slotX + slotWidth - countFont.width(count) - 2.0f;
                float textY = slotY + slotHeight - countFont.height() - 1.0f;
                context.drawText(countFont, count, textX + 0.5f, textY + 0.5f, ColorRGBA.BLACK.withAlpha(150.0f));
                context.drawText(countFont, count, textX, textY, ColorRGBA.WHITE);
            }
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    @Override
    public boolean show() {
        if (HotbarHud.mc.field_1724 == null || HotbarHud.mc.field_1687 == null) {
            return false;
        }
        return !(HotbarHud.mc.field_1755 instanceof class_408) && !(HotbarHud.mc.field_1755 instanceof HudEditorScreen) ? true : true;
    }
}

