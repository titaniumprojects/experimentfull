/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1934
 *  net.minecraft.class_408
 *  net.minecraft.class_640
 */
package micronix.experiment.ui.hud.impl;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.ui.hud.HudList;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1934;
import net.minecraft.class_408;
import net.minecraft.class_640;

@Environment(value=EnvType.CLIENT)
public class StaffList
extends HudList {
    private final Map<String, Long> spectatorStartTime = new HashMap<String, Long>();
    private final Map<String, Animation> hoverAnimations = new HashMap<String, Animation>();
    private String hoveredPlayer = null;

    public StaffList() {
        super("hud.stafflist", "icons/hud/staff.png");
    }

    @Override
    public void update(UIContext context) {
        this.width = 100.0f;
        this.height = 18.0f;
        Font font = Fonts.REGULAR.getFont(7.0f);
        List<class_640> staffMembers = this.getStaffMembers();
        if (!staffMembers.isEmpty()) {
            for (class_640 entry : staffMembers) {
                String name2 = entry.method_2966().getName();
                if (!this.spectatorStartTime.containsKey(name2)) {
                    this.spectatorStartTime.put(name2, System.currentTimeMillis());
                }
                if (!this.hoverAnimations.containsKey(name2)) {
                    this.hoverAnimations.put(name2, new Animation(200L, Easing.CUBIC_OUT));
                }
                this.height += 20.0f;
            }
            this.height += 4.0f;
        }
        this.spectatorStartTime.keySet().removeIf(name -> staffMembers.stream().noneMatch(e -> e.method_2966().getName().equals(name)));
        this.hoverAnimations.keySet().removeIf(name -> staffMembers.stream().noneMatch(e -> e.method_2966().getName().equals(name)));
        super.update(context);
    }

    @Override
    protected void renderComponent(UIContext context) {
        super.renderComponent(context);
        Font font = Fonts.REGULAR.getFont(7.0f);
        List<class_640> staffMembers = this.getStaffMembers();
        float currentY = 22.0f;
        this.hoveredPlayer = null;
        for (class_640 entry : staffMembers) {
            Animation hoverAnim;
            boolean isHovered;
            float rowY = this.y + currentY;
            String name = entry.method_2966().getName();
            String role = this.getPlayerRole(name);
            ColorRGBA roleColor = this.getRoleColor(name);
            double mouseX = context.getMouseX();
            double mouseY = context.getMouseY();
            boolean bl = isHovered = mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)rowY && mouseY <= (double)(rowY + 20.0f);
            if (isHovered) {
                this.hoveredPlayer = name;
            }
            if ((hoverAnim = this.hoverAnimations.get(name)) != null) {
                hoverAnim.update(isHovered ? 1.0f : 0.0f);
            }
            float animValue = hoverAnim != null ? hoverAnim.getValue() : 0.0f;
            float roleX = this.x + 8.0f;
            context.drawText(font, role, roleX, rowY + 8.0f, roleColor.withAlpha(255.0f));
            float roleWidth = font.width(role);
            float nameX = roleX + roleWidth + 4.0f;
            context.drawText(font, name, nameX, rowY + 8.0f, Colors.getAccentColor().withAlpha(255.0f));
            float dotSize = 6.0f;
            float dotX = this.x + this.width - 10.0f;
            float dotY = rowY + 10.0f;
            ColorRGBA dotColor = new ColorRGBA(76.0f, 217.0f, 100.0f, 255.0f);
            context.drawRoundedRect(dotX, dotY, dotSize, dotSize, BorderRadius.all(dotSize / 2.0f), dotColor);
            if (animValue > 0.01f) {
                String spectatorTime = this.getSpectatorTime(name);
                float timeWidth = font.width(spectatorTime);
                float nameWidth = font.width(name);
                float timeX = nameX + nameWidth + 8.0f;
                float timeAlpha = 255.0f * animValue;
                context.drawText(font, spectatorTime, timeX, rowY + 8.0f, Colors.getTextColor().withAlpha((int)timeAlpha));
            }
            currentY += 20.0f;
        }
    }

    private List<class_640> getStaffMembers() {
        return mc.method_1562().method_2880().stream().filter(entry -> entry.method_2958() == class_1934.field_9219).sorted(Comparator.comparing(entry -> entry.method_2966().getName())).collect(Collectors.toList());
    }

    private String getPlayerRole(String playerName) {
        if (playerName.toLowerCase().contains("admin") || this.isAdmin(playerName)) {
            return "[Admin]";
        }
        if (playerName.toLowerCase().contains("moder") || this.isModerator(playerName)) {
            return "[Moder]";
        }
        if (playerName.toLowerCase().contains("helper") || this.isHelper(playerName)) {
            return "[Helper]";
        }
        if (playerName.toLowerCase().contains("owner") || this.isOwner(playerName)) {
            return "[Owner]";
        }
        return "[Staff]";
    }

    private ColorRGBA getRoleColor(String playerName) {
        String role;
        switch (role = this.getPlayerRole(playerName)) {
            case "[Owner]": {
                return new ColorRGBA(255.0f, 0.0f, 0.0f, 255.0f);
            }
            case "[Admin]": {
                return new ColorRGBA(255.0f, 85.0f, 85.0f, 255.0f);
            }
            case "[Moder]": {
                return new ColorRGBA(85.0f, 255.0f, 85.0f, 255.0f);
            }
            case "[Helper]": {
                return new ColorRGBA(85.0f, 170.0f, 255.0f, 255.0f);
            }
        }
        return new ColorRGBA(170.0f, 170.0f, 170.0f, 255.0f);
    }

    private boolean isOwner(String playerName) {
        return false;
    }

    private boolean isAdmin(String playerName) {
        return false;
    }

    private boolean isModerator(String playerName) {
        return false;
    }

    private boolean isHelper(String playerName) {
        return false;
    }

    private String getSpectatorTime(String playerName) {
        Long startTime = this.spectatorStartTime.get(playerName);
        if (startTime == null) {
            return "0\u0441";
        }
        long elapsedMs = System.currentTimeMillis() - startTime;
        long seconds = elapsedMs / 1000L;
        long minutes = seconds / 60L;
        long hours = minutes / 60L;
        if (hours > 0L) {
            return hours + "\u0447 " + minutes % 60L + "\u043c";
        }
        if (minutes > 0L) {
            return minutes + "\u043c " + seconds % 60L + "\u0441";
        }
        return seconds + "\u0441";
    }

    @Override
    public boolean show() {
        return !this.getStaffMembers().isEmpty() || StaffList.mc.field_1755 instanceof class_408;
    }
}

