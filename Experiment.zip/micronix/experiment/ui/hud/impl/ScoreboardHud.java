/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_266
 *  net.minecraft.class_268
 *  net.minecraft.class_269
 *  net.minecraft.class_270
 *  net.minecraft.class_5250
 *  net.minecraft.class_8646
 *  net.minecraft.class_9011
 *  net.minecraft.class_9022
 *  net.minecraft.class_9025
 */
package micronix.experiment.ui.hud.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.msdf.FormattedTextProcessor;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.gradient.impl.HorizontalGradient;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.settings.SliderSetting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.LegacyTextHelper;
import micronix.experiment.utility.interfaces.IScaledResolution;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_270;
import net.minecraft.class_5250;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.class_9022;
import net.minecraft.class_9025;

@Environment(value=EnvType.CLIENT)
public class ScoreboardHud
extends HudElement
implements IScaledResolution {
    private static final float TITLE_SIZE = 8.8f;
    private static final float LINE_SIZE = 7.8f;
    private static final float PAD_X = 16.0f;
    private static final float PAD_Y = 7.0f;
    private static final float LINE_GAP = 5.0f;
    private static final float VALUE_GAP = 16.0f;
    private boolean initialPos;
    private float lastSavedX = Float.NaN;
    private float lastSavedY = Float.NaN;
    private final SliderSetting scaleSetting = new SliderSetting(this, "\u0420\u0430\u0437\u043c\u0435\u0440").min(0.7f).max(1.4f).step(0.05f).currentValue(1.0f);

    public ScoreboardHud() {
        super("\u0421\u043a\u043e\u0440\u0431\u043e\u0430\u0440\u0434", "icons/hud/world.png");
    }

    @Override
    public void update(UIContext context) {
        Layout layout = this.buildLayout();
        this.width = layout.width;
        this.height = layout.height;
        if (!this.initialPos && this.x == 0.0f && this.y == 0.0f) {
            this.x = Math.max(0.0f, sr.getScaledWidth() - this.width - 40.0f);
            this.y = 40.0f;
            this.initialPos = true;
        }
        if (!(this.isDragging() || this.x == this.lastSavedX && this.y == this.lastSavedY)) {
            this.lastSavedX = this.x;
            this.lastSavedY = this.y;
            Experiment.getInstance().getFileManager().writeFile("client");
        }
        super.update(context);
    }

    @Override
    protected void renderComponent(UIContext context) {
        Layout layout = this.buildLayout();
        float x = this.x;
        float y = this.y;
        Font titleFont = this.getTitleFont();
        Font lineFont = this.getLineFont();
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        ColorRGBA bgColor = Colors.getBackgroundColor().withAlpha(255.0f * (dark ? 0.8f - 0.6f * Interface.glass() : 0.7f));
        context.drawShadow(x - 5.0f, y - 5.0f, layout.width + 10.0f, layout.height + 10.0f, 15.0f, BorderRadius.all(6.0f), ColorRGBA.BLACK.withAlpha(63.75f));
        if (Interface.showMinimalizm()) {
            context.drawBlurredRect(x, y, layout.width, layout.height, 45.0f, 7.0f, BorderRadius.all(6.0f), ColorRGBA.WHITE.withAlpha(255.0f * Interface.minimalizm()));
        }
        if (Interface.showGlass()) {
            context.drawLiquidGlass(x, y, layout.width, layout.height, 7.0f, 0.08f, BorderRadius.all(6.0f), ColorRGBA.WHITE.withAlpha(255.0f * Interface.glass()));
        }
        context.drawSquircle(x, y, layout.width, layout.height, 7.0f, BorderRadius.all(6.0f), bgColor);
        float lineH = Math.max(1.0f, 1.4f * layout.scale);
        ColorRGBA accent = Colors.ACCENT.withAlpha(170.0f);
        ColorRGBA secondary = Colors.ACCENT.withAlpha(50.0f);
        context.drawRoundedRect(x + layout.padX * 0.6f, y + layout.headerHeight - lineH - layout.padY * 0.3f, layout.width - layout.padX * 1.2f, lineH, BorderRadius.all(lineH / 2.0f), new HorizontalGradient(accent, secondary));
        float titleX = x + 16.0f;
        for (Segment segment : layout.title.segments) {
            context.drawText(titleFont, segment.text, titleX, y + 7.0f, ColorRGBA.fromInt(segment.color));
            titleX += titleFont.width(segment.text);
        }
        float lineY = y + layout.headerHeight;
        for (EntryLine line : layout.lines) {
            float rowY = lineY + (layout.lineHeight - lineFont.height()) / 2.0f;
            float valueWidth = line.value.width;
            float nameX = x + 16.0f;
            for (Segment segment : line.name.segments) {
                context.drawText(lineFont, segment.text, nameX, rowY, ColorRGBA.fromInt(segment.color));
                nameX += lineFont.width(segment.text);
            }
            float valueX = x + layout.width - 16.0f - valueWidth;
            for (Segment segment : line.value.segments) {
                context.drawText(lineFont, segment.text, valueX, rowY, ColorRGBA.fromInt(segment.color));
                valueX += lineFont.width(segment.text);
            }
            lineY += layout.lineHeight;
        }
    }

    @Override
    public boolean show() {
        return this.getObjective() != null;
    }

    private Layout buildLayout() {
        int defaultTextColor = Colors.getTextColor().getRGB() & 0xFFFFFF;
        float scale = this.scaleSetting.getCurrentValue();
        Font titleFont = this.getTitleFont();
        Font lineFont = this.getLineFont();
        class_266 objective = this.getObjective();
        if (objective == null) {
            return new Layout(new Segments(List.of(), 0.0f), List.of(), 0.0f, 0.0f, 0.0f, 0.0f, scale, 16.0f, 7.0f);
        }
        class_2561 titleSource = objective.method_1114();
        Segments title = this.buildSegments(titleSource, titleFont, defaultTextColor);
        float maxWidth = title.width;
        List<EntryLine> lines = objective.method_1117().method_1184(objective).stream().filter(entry -> entry != null && !entry.method_55385()).sorted(Comparator.comparingInt(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String::compareToIgnoreCase)).limit(25L).map(entry -> {
            Segments name = this.buildSegments(this.resolveNameText(objective.method_1117(), (class_9011)entry), lineFont, defaultTextColor);
            Segments value = this.buildSegments(this.resolveValueText(objective, (class_9011)entry), lineFont, defaultTextColor);
            return new EntryLine(name, value);
        }).toList();
        for (EntryLine line : lines) {
            float rowWidth = line.name.width + line.value.width + 16.0f;
            maxWidth = Math.max(maxWidth, rowWidth);
        }
        float headerHeight = titleFont.height() + 14.0f;
        float lineHeight = lineFont.height() + 5.0f;
        float totalHeight = headerHeight + (float)lines.size() * lineHeight + 7.0f;
        float extraWidth = 16.0f;
        float totalWidth = maxWidth + 32.0f + extraWidth;
        return new Layout(title, lines, headerHeight *= scale, lineHeight *= scale, totalWidth *= scale, totalHeight *= scale, scale, 16.0f, 7.0f);
    }

    private Segments buildSegments(class_2561 text, Font font, int defaultColor) {
        String raw = LegacyTextHelper.extractRaw(text);
        class_2561 source = LegacyTextHelper.containsLegacyCodes(raw) ? LegacyTextHelper.parse(raw, defaultColor) : text;
        boolean hasLegacy = LegacyTextHelper.containsLegacyCodes(raw);
        List<Segment> segments = hasLegacy ? LegacyTextHelper.parseSegments(raw, defaultColor).stream().map(segment -> new Segment(segment.text(), segment.color())).toList() : FormattedTextProcessor.processText(source, defaultColor).stream().map(segment -> new Segment(segment.text, segment.color)).toList();
        float width = 0.0f;
        ArrayList<Segment> sanitized = new ArrayList<Segment>();
        for (Segment segment2 : segments) {
            String cleaned = segment2.text;
            if (cleaned.isEmpty()) continue;
            sanitized.add(new Segment(cleaned, segment2.color));
            width += font.width(cleaned);
        }
        return new Segments(sanitized, width);
    }

    private Font getTitleFont() {
        return Fonts.MEDIUM.getFont(8.8f * this.scaleSetting.getCurrentValue());
    }

    private Font getLineFont() {
        return Fonts.REGULAR.getFont(7.8f * this.scaleSetting.getCurrentValue());
    }

    private class_266 getObjective() {
        if (ScoreboardHud.mc.field_1687 == null) {
            return null;
        }
        return ScoreboardHud.mc.field_1687.method_8428().method_1189(class_8646.field_45157);
    }

    private class_2561 resolveNameText(class_269 scoreboard, class_9011 entry) {
        class_2561 display = entry.comp_2129();
        if (display != null) {
            return display;
        }
        String owner = entry.comp_2127();
        if (owner == null) {
            return class_2561.method_43473();
        }
        class_268 team = this.resolveTeam(scoreboard, owner);
        class_5250 base = class_2561.method_43470((String)owner);
        return team != null ? class_268.method_1142((class_270)team, (class_2561)base) : base;
    }

    private class_2561 resolveValueText(class_266 objective, class_9011 entry) {
        class_5250 formatted = entry.method_55386(objective.method_55380((class_9022)class_9025.field_47566));
        if (formatted != null) {
            return formatted;
        }
        return class_2561.method_43470((String)Integer.toString(entry.comp_2128()));
    }

    private class_268 resolveTeam(class_269 scoreboard, String owner) {
        if (scoreboard == null || owner == null) {
            return null;
        }
        return scoreboard.method_1164(owner);
    }

    @Environment(value=EnvType.CLIENT)
    private record Layout(Segments title, List<EntryLine> lines, float headerHeight, float lineHeight, float width, float height, float scale, float padX, float padY) {
    }

    @Environment(value=EnvType.CLIENT)
    private record Segments(List<Segment> segments, float width) {
    }

    @Environment(value=EnvType.CLIENT)
    private record Segment(String text, int color) {
    }

    @Environment(value=EnvType.CLIENT)
    private record EntryLine(Segments name, Segments value) {
    }
}

