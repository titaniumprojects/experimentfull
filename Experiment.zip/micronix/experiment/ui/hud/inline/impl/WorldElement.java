/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.inline.impl;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.ui.hud.inline.InlineElement;
import micronix.experiment.ui.hud.inline.InlineValue;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.game.server.ServerUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class WorldElement
extends InlineElement {
    private final InlineValue cords;
    private final InlineValue server;
    private final InlineValue tps;
    private final BooleanSetting shortName;

    public WorldElement() {
        super("hud.world", "icons/hud/world.png");
        this.cords = new InlineValue(this.elements, "coords");
        this.server = new InlineValue(this.elements, "server");
        this.tps = new InlineValue(this.elements, "TPS", "TPS");
        this.shortName = new BooleanSetting(this, "hud.world.compact_server").enable();
    }

    @Override
    public void update(UIContext context) {
        super.update(context);
        this.cords.update(String.format("%s %s %s", Math.round(WorldElement.mc.field_1724.method_23317()), Math.round(WorldElement.mc.field_1724.method_23318()), Math.round(WorldElement.mc.field_1724.method_23321())));
        this.server.update(ServerUtility.getServerName(this.shortName.isEnabled()), ServerUtility.getIP());
        this.tps.update(TextUtility.formatNumber(Experiment.getInstance().getTpsHandler().getTPS()).replace(",", ".").replace(".0", ""));
    }
}

