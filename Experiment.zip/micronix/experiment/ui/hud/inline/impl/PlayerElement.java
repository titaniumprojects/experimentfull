/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.inline.impl;

import micronix.experiment.framework.base.UIContext;
import micronix.experiment.systems.setting.settings.BooleanSetting;
import micronix.experiment.ui.hud.inline.InlineElement;
import micronix.experiment.ui.hud.inline.InlineValue;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class PlayerElement
extends InlineElement {
    private final InlineValue fps;
    private final InlineValue speed;
    private final BooleanSetting ySpeed;
    private final Animation animation;

    public PlayerElement() {
        super("hud.player", "icons/hud/player.png");
        this.fps = new InlineValue(this.elements, "FPS", "FPS");
        this.speed = new InlineValue(this.elements, "speed", "BPS");
        this.ySpeed = new BooleanSetting(this, "hud.player.speedY").enable();
        this.animation = new Animation(300L, 0.0f, Easing.SMOOTH_STEP);
    }

    @Override
    public void update(UIContext context) {
        super.update(context);
        double motion = !this.ySpeed.isEnabled() ? Math.hypot(PlayerElement.mc.field_1724.method_23317() - PlayerElement.mc.field_1724.field_6014, PlayerElement.mc.field_1724.method_23321() - PlayerElement.mc.field_1724.field_5969) : Math.hypot(PlayerElement.mc.field_1724.method_23318() - PlayerElement.mc.field_1724.field_6036, Math.hypot(PlayerElement.mc.field_1724.method_23317() - PlayerElement.mc.field_1724.field_6014, PlayerElement.mc.field_1724.method_23321() - PlayerElement.mc.field_1724.field_5969));
        this.speed.update(String.format("%.2f", motion * 20.0).replace(",", "."));
        this.fps.update("" + Math.round(this.animation.update(mc.method_47599())));
    }
}

