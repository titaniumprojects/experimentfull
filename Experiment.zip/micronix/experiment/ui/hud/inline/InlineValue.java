/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud.inline;

import micronix.experiment.systems.setting.settings.SelectSetting;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class InlineValue
extends SelectSetting.Value {
    private String text = "?";
    private String copy = "";
    private final String suffix;
    private boolean copied;
    private final Timer copyTimer = new Timer();
    private final Animation copyAnim = new Animation(300L, 0.0f, Easing.BAKEK);
    private final Animation successAnim = new Animation(500L, 0.0f, Easing.BAKEK_SIZE);

    public InlineValue(SelectSetting parent, String name, String suffix) {
        super(parent, name);
        this.select();
        this.suffix = " " + suffix;
    }

    public InlineValue(SelectSetting parent, String name) {
        super(parent, name);
        this.select();
        this.suffix = "";
    }

    public void update(String text, String copy) {
        if (this.isSelected()) {
            this.text = text;
            this.copy = copy;
        }
    }

    public void update(String text) {
        if (this.isSelected()) {
            this.text = text;
        }
    }

    public String text() {
        return this.text;
    }

    public String copy() {
        return this.copy;
    }

    public String suffix() {
        return this.suffix;
    }

    public boolean copied() {
        return this.copied;
    }

    public Timer copyTimer() {
        return this.copyTimer;
    }

    public Animation copyAnim() {
        return this.copyAnim;
    }

    public Animation successAnim() {
        return this.successAnim;
    }

    public InlineValue copied(boolean copied) {
        this.copied = copied;
        return this;
    }
}

