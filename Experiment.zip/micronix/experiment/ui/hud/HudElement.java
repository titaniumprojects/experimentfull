/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.hud;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.systems.setting.SettingsContainer;
import micronix.experiment.ui.components.popup.Popup;
import micronix.experiment.ui.hud.GridLine;
import micronix.experiment.ui.hud.impl.island.DynamicIsland;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.RenderUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public abstract class HudElement
implements SettingsContainer,
IMinecraft {
    protected float x;
    protected float y;
    protected float width;
    protected float height;
    protected final Animation animation = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    protected final Animation visible = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    protected final Animation selecting = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    protected final Animation dragAnim = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final Animation blurAnim = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final Animation loadingAnim = new Animation(700L, 0.0f, Easing.SMOOTH_STEP);
    private final Animation widthAnim = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    private final Animation heightAnim = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    protected boolean showing;
    protected boolean select;
    private List<Setting> settings = new ArrayList<Setting>();
    protected boolean dragging;
    private float dragX;
    private float dragY;
    protected float startDragX;
    protected float startDragY;
    protected final String name;
    protected final String icon;

    public HudElement(String name, String icon) {
        this.name = name;
        this.icon = icon;
    }

    private void saveClientData() {
        try {
            Experiment.getInstance().getFileManager().saveClientFiles();
        }
        catch (Exception var2) {
            Experiment.LOGGER.error("Failed to save HUD element data: {}", (Object)var2.getMessage());
        }
    }

    public void render(UIContext context) {
        this.update(context);
        float anim = this.animation.getValue() * this.visible.getValue();
        if (anim != 0.0f) {
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)Math.min(1.0f, anim));
            float scale = 0.5f + anim * 0.5f - 0.05f * this.selecting.getValue();
            RenderUtility.scale(context.method_51448(), this.x + this.width / 2.0f, this.y + this.height / 2.0f, scale);
            this.renderComponent(context);
            RenderUtility.end(context.method_51448());
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    protected abstract void renderComponent(UIContext var1);

    public void update(UIContext context) {
        boolean isLeftSide;
        float oldWidth = this.widthAnim.getValue();
        this.widthAnim.update(this.width);
        float newWidth = this.widthAnim.getValue();
        float widthDelta = newWidth - oldWidth;
        boolean bl = isLeftSide = this.x + this.width / 2.0f < IScaledResolution.sr.getScaledWidth() / 2.0f;
        if (!isLeftSide && widthDelta != 0.0f && this.showing && this.visible.getValue() > 0.5f) {
            this.x -= widthDelta;
        }
        if (widthDelta != 0.0f && this.showing && this.visible.getValue() > 0.5f) {
            for (HudElement otherElement : Experiment.getInstance().getHud().getElements()) {
                float distanceToOther;
                float verticalOverlap;
                if (otherElement == this || !otherElement.isShowing() || !(otherElement.visible.getValue() > 0.5f) || (verticalOverlap = Math.min(this.y + this.height, otherElement.y + otherElement.height) - Math.max(this.y, otherElement.y)) <= 0.0f) continue;
                if (isLeftSide) {
                    float rightEdge = this.x + newWidth;
                    distanceToOther = otherElement.x - rightEdge;
                    if (!(distanceToOther >= -5.0f) || !(distanceToOther <= 25.0f)) continue;
                    otherElement.x += widthDelta;
                    otherElement.x = Math.max(0.0f, Math.min(otherElement.x, IScaledResolution.sr.getScaledWidth() - otherElement.width));
                    continue;
                }
                float leftEdge = this.x;
                distanceToOther = leftEdge - (otherElement.x + otherElement.width);
                if (!(distanceToOther >= -5.0f) || !(distanceToOther <= 25.0f)) continue;
                otherElement.x -= widthDelta;
                otherElement.x = Math.max(0.0f, Math.min(otherElement.x, IScaledResolution.sr.getScaledWidth() - otherElement.width));
            }
        }
        this.width = newWidth;
        this.dragAnim.update(this.dragging);
        this.animation.setEasing(this.showing ? Easing.BAKEK : Easing.BAKEK_BACK);
        this.animation.update(this.showing);
        this.visible.setEasing(this.show() ? Easing.BAKEK : Easing.BAKEK_BACK);
        this.visible.update(this.show());
        this.selecting.update(this.select);
        this.blurAnim.update(this.animation.getValue() >= 0.6f);
        if (this.dragging) {
            this.x = Math.clamp((float)context.getMouseX() - this.dragX, 0.0f, IScaledResolution.sr.getScaledWidth() - this.width);
            this.y = Math.clamp((float)context.getMouseY() - this.dragY, 0.0f, IScaledResolution.sr.getScaledHeight() - this.height);
            if (!(this instanceof DynamicIsland)) {
                for (GridLine line : Experiment.getInstance().getHud().getGrid().getLines()) {
                    if (line.getType() == GridLine.Type.VERTICAL) {
                        this.x = this.snapToLine(line, this.x, List.of(Float.valueOf(0.0f), Float.valueOf(this.width), Float.valueOf(this.width / 2.0f)), List.of(Float.valueOf(0.0f), Float.valueOf(-this.width), Float.valueOf(-this.width / 2.0f)));
                        continue;
                    }
                    this.y = this.snapToLine(line, this.y, List.of(Float.valueOf(0.0f), Float.valueOf(this.height)), List.of(Float.valueOf(0.0f), Float.valueOf(-this.height)));
                }
            }
        }
        if (this.isHovered(context) && this.animation.getValue() >= 1.0f) {
            CursorUtility.set(CursorType.HAND);
        }
    }

    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (this.isHovered(mouseX, mouseY) && this.showing) {
            if (button == MouseButton.LEFT) {
                this.dragging = true;
                this.dragX = (float)(mouseX - (double)this.x);
                this.dragY = (float)(mouseY - (double)this.y);
                this.startDragX = this.x;
                this.startDragY = this.y;
            } else if (button == MouseButton.RIGHT) {
                this.select = true;
                this.loadingAnim.setValue(0.0f);
                Popup popup = new Popup((float)mouseX, (float)mouseY, 110.0f, 6.0f).title(this.settings.isEmpty() ? "actions" : "settings").separator();
                for (Setting setting : this.settings) {
                    popup.setting(setting);
                }
                popup.button(Localizator.translate("remove"), "icons/hud/trash.png", popup1 -> {
                    this.showing = false;
                    popup1.setShowing(false);
                    Experiment.getInstance().getFileManager().writeFile("client");
                }).onClose(() -> {
                    this.select = false;
                });
                Experiment.getInstance().getHud().getPopups().add(popup);
            }
        }
    }

    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        if (this.dragging && button == MouseButton.LEFT) {
            this.dragging = false;
            if (this.x != this.startDragX || this.y != this.startDragY) {
                Experiment.getInstance().getHud().getHistoryManager().registerMove(this, this.startDragX, this.startDragY, this.x, this.y);
            }
            Experiment.getInstance().getFileManager().writeFile("client");
        }
    }

    private float snapToLine(GridLine line, float pos, List<Float> offsets, List<Float> adjustments) {
        for (int i = 0; i < offsets.size(); ++i) {
            float distance = Math.abs(pos + offsets.get(i).floatValue() - line.getPos());
            if (distance < 25.0f) {
                line.setActive(true);
            }
            if (!(distance < 5.0f)) continue;
            pos = line.getPos() + adjustments.get(i).floatValue();
        }
        return pos;
    }

    public boolean show() {
        return true;
    }

    public boolean isHovered(float mouseX, float mouseY) {
        return GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, mouseX, mouseY);
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, mouseX, mouseY);
    }

    public boolean isHovered(UIContext context) {
        return this.isHovered(context.getMouseX(), context.getMouseY());
    }

    public void pos(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }

    public Animation getAnimation() {
        return this.animation;
    }

    public Animation getVisible() {
        return this.visible;
    }

    public Animation getSelecting() {
        return this.selecting;
    }

    public Animation getDragAnim() {
        return this.dragAnim;
    }

    public Animation getBlurAnim() {
        return this.blurAnim;
    }

    public Animation getLoadingAnim() {
        return this.loadingAnim;
    }

    public Animation getWidthAnim() {
        return this.widthAnim;
    }

    public Animation getHeightAnim() {
        return this.heightAnim;
    }

    public boolean isShowing() {
        return this.showing;
    }

    public boolean isSelect() {
        return this.select;
    }

    @Override
    public List<Setting> getSettings() {
        return this.settings;
    }

    public boolean isDragging() {
        return this.dragging;
    }

    public float getDragX() {
        return this.dragX;
    }

    public float getDragY() {
        return this.dragY;
    }

    public float getStartDragX() {
        return this.startDragX;
    }

    public float getStartDragY() {
        return this.startDragY;
    }

    public String getName() {
        return this.name;
    }

    public String getIcon() {
        return this.icon;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public void setShowing(boolean showing) {
        if (this.showing != showing) {
            this.showing = showing;
            this.saveClientData();
        }
    }

    public void setSelect(boolean select) {
        this.select = select;
    }

    public void setSettings(List<Setting> settings) {
        this.settings = settings;
    }

    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }

    public void setDragX(float dragX) {
        this.dragX = dragX;
    }

    public void setDragY(float dragY) {
        this.dragY = dragY;
    }

    public void setStartDragX(float startDragX) {
        this.startDragX = startDragX;
    }

    public void setStartDragY(float startDragY) {
        this.startDragY = startDragY;
    }
}

