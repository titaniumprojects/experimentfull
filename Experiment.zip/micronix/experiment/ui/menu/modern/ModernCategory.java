/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.modern;

import java.util.List;
import micronix.experiment.ui.menu.api.MenuCategory;
import micronix.experiment.ui.menu.modern.components.ModernModule;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.render.penis.PenisPlayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ModernCategory {
    private final MenuCategory category;
    private final List<ModernModule> modules;
    private final Animation selected = new Animation(500L, Easing.BAKEK);
    private PenisPlayer penis;
    private float y;

    public MenuCategory getCategory() {
        return this.category;
    }

    public List<ModernModule> getModules() {
        return this.modules;
    }

    public Animation getSelected() {
        return this.selected;
    }

    public PenisPlayer getPenis() {
        return this.penis;
    }

    public float getY() {
        return this.y;
    }

    public ModernCategory(MenuCategory category, List<ModernModule> modules) {
        this.category = category;
        this.modules = modules;
    }

    public void setPenis(PenisPlayer penis) {
        this.penis = penis;
    }

    public void setY(float y) {
        this.y = y;
    }
}

