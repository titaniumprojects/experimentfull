/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_290
 *  net.minecraft.class_304
 *  net.minecraft.class_332
 *  net.minecraft.class_3675
 *  net.minecraft.class_437
 */
package micronix.experiment.ui.menu.modern;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.modules.modules.visuals.MenuModule;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.components.ColorPicker;
import micronix.experiment.ui.components.textfield.FieldAction;
import micronix.experiment.ui.components.textfield.TextField;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.ui.menu.api.MenuCategory;
import micronix.experiment.ui.menu.dropdown.components.MenuPanel;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.BezierSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.BindSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.BooleanSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.ButtonSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.ColorSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.ModeSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.RangeSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.SliderSettingComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.impl.StringSettingComponent;
import micronix.experiment.ui.menu.modern.ModernCategory;
import micronix.experiment.ui.menu.modern.components.ModernModule;
import micronix.experiment.ui.menu.modern.components.ModernSettings;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.gui.ScrollHandler;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.ScissorUtility;
import micronix.experiment.utility.render.batching.impl.FadeOutBatching;
import micronix.experiment.utility.render.batching.impl.FontBatching;
import micronix.experiment.utility.render.batching.impl.IconBatching;
import micronix.experiment.utility.render.batching.impl.RoundedRectBatching;
import micronix.experiment.utility.render.batching.impl.SquircleBatching;
import micronix.experiment.utility.render.obj.Rect;
import micronix.experiment.utility.render.penis.PenisPlayer;
import micronix.experiment.utility.sounds.ClientSounds;
import micronix.experiment.utility.time.Timer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_290;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class ModernScreen
extends MenuScreen
implements IMinecraft,
IScaledResolution {
    private final Rect menuWindow;
    private float dragX;
    private float dragY;
    private boolean drag;
    private final ScrollHandler scrollHandler = new ScrollHandler();
    private MenuCategory current = MenuCategory.COMBAT;
    private final List<ColorPicker> colorPickers = new LinkedList<ColorPicker>();
    private final List<ModernCategory> categories = new ArrayList<ModernCategory>();
    private final List<ModernSettings> windows = new LinkedList<ModernSettings>();
    private final Animation currentCategory = new Animation(300L, Easing.BAKEK_SMALLER);
    private final TextField searchField;
    private final PenisPlayer searchPenis;
    private boolean prevFocused;
    Timer timer = new Timer();

    public ModernScreen() {
        float width = 500.0f;
        float height = 343.0f;
        this.menuWindow = new Rect(sr.getScaledWidth() / 2.0f - width / 2.0f, sr.getScaledHeight() / 2.0f - height / 2.0f, width, height);
        this.categories.clear();
        for (MenuCategory category : MenuCategory.values()) {
            LinkedList<ModernModule> filteredModules = new LinkedList<ModernModule>();
            ModernCategory modern = new ModernCategory(category, filteredModules);
            try {
                modern.setPenis(new PenisPlayer(Experiment.id("penises/" + category.getName().toLowerCase() + ".penis")));
            }
            catch (RuntimeException runtimeException) {
                // empty catch block
            }
            this.categories.add(modern);
            filteredModules.addAll(Experiment.getInstance().getModuleManager().getModules().stream().sorted(Comparator.comparing(Module::getName)).filter(module -> module.getCategory().equals((Object)category.getCategory())).filter(module -> !module.isHidden()).map(module -> new ModernModule((Module)module, modern)).toList());
        }
        this.searchField = new TextField(Fonts.MEDIUM.getFont(6.0f));
        HashMap<String, FieldAction> append = new HashMap<String, FieldAction>();
        for (Module module2 : Experiment.getInstance().getModuleManager().getModules()) {
            if (module2.isHidden()) continue;
            FieldAction action = new FieldAction(module2::toggle, () -> this.categories.forEach(panel -> panel.getModules().stream().filter(component -> component.getModule() == module2).forEach(modernModule -> System.out.println("poka pichego"))));
            append.put(module2.getName().replace(" ", ""), action);
            append.put(module2.getName(), action);
        }
        this.searchField.setAppend(append);
        this.searchField.setPreview("\u041f\u043e\u0438\u0441\u043a");
        this.searchPenis = new PenisPlayer(Experiment.id("penises/search.penis"));
        this.searchPenis.stop();
    }

    @Compile
    protected void method_25426() {
        this.closing = false;
        for (ModernCategory category : this.categories) {
            if (category.getPenis() == null) continue;
            category.getPenis().stop();
        }
        super.method_25426();
    }

    public void method_25393() {
        this.handleMovementKeys();
        super.method_25393();
    }

    @Override
    public void render(UIContext context) {
        this.menuAnimation.update(this.closing ? 0.0f : 1.0f);
        this.menuAnimation.setEasing(!this.closing ? Easing.BAKEK : Easing.BAKEK_BACK);
        this.menuAnimation.setDuration(400L);
        this.scrollHandler.update();
        if (this.drag) {
            this.menuWindow.setX((float)context.getMouseX() - this.dragX);
            this.menuWindow.setY((float)context.getMouseY() - this.dragY);
        }
        if (this.searchField.isFocused() && !this.prevFocused) {
            this.searchPenis.playOnce();
        }
        this.prevFocused = this.searchField.isFocused();
        float scroll = (float)(-this.scrollHandler.getValue());
        float alpha = Math.min(1.0f, this.menuAnimation.getValue());
        for (ModernCategory category : this.categories) {
            if (!((double)(category.getY() - scroll) <= -this.scrollHandler.getTargetValue()) || this.current == category.getCategory()) continue;
            this.current = category.getCategory();
        }
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        RenderUtility.scale(context.method_51448(), this.menuWindow.getX() + this.menuWindow.getWidth() / 2.0f, this.menuWindow.getY() + this.menuWindow.getHeight() / 2.0f, 0.5f + 0.5f * this.menuAnimation.getValue());
        context.drawBlurredRect(this.menuWindow.getX(), this.menuWindow.getY(), this.menuWindow.getWidth(), this.menuWindow.getHeight(), 45.0f, 5.0f, BorderRadius.all(16.0f), Colors.WHITE);
        context.drawSquircle(this.menuWindow.getX(), this.menuWindow.getY(), this.menuWindow.getWidth(), this.menuWindow.getHeight(), 5.0f, BorderRadius.all(16.0f), dark ? Colors.getAdditionalColor().mulAlpha(0.98f) : Colors.getBackgroundColor().mulAlpha(0.95f));
        context.drawShadow(this.menuWindow.getX() + 5.0f, this.menuWindow.getY() + 5.0f, 109.0f, 333.0f, 20.0f, BorderRadius.all(14.0f), Colors.BLACK.mulAlpha(0.2f));
        context.drawBlurredRect(this.menuWindow.getX() + 5.0f, this.menuWindow.getY() + 5.0f, 109.0f, 333.0f, 45.0f, BorderRadius.all(12.0f), Colors.WHITE);
        context.drawRoundedRect(this.menuWindow.getX() + 5.0f, this.menuWindow.getY() + 5.0f, 109.0f, 333.0f, BorderRadius.all(12.0f), Colors.getBackgroundColor().mulAlpha(dark ? 0.85f : 0.65f));
        float x = this.menuWindow.getX();
        float y = this.menuWindow.getY();
        float yOff = 0.0f;
        float xOff = 0.0f;
        float moduleWidth = 177.0f;
        context.drawRoundedRect(x + 13.0f, y + 13.0f, 93.0f, 14.0f, BorderRadius.all(3.0f), dark ? Colors.getAdditionalColor().mulAlpha(0.6f) : Colors.getBackgroundColor().mulAlpha(0.6f));
        DrawUtility.drawAnimationSprite(context.method_51448(), this.searchPenis.getCurrentSprite(), x + 16.0f, y + 16.0f, 8.0f, 8.0f, Colors.getTextColor().mulAlpha(0.5f));
        this.searchField.set(x + 21.0f, y + 13.0f, 80.0f, 14.0f);
        this.searchField.setTextColor(Colors.getTextColor().mulAlpha(0.5f));
        this.searchField.render(context);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        FontBatching regularBatching = new FontBatching(class_290.field_1575, Fonts.REGULAR);
        context.drawText(Fonts.REGULAR.getFont(6.0f), "\u0424\u0443\u043d\u043a\u0446\u0438\u0438", x + 14.0f, y + 35.0f, Colors.getTextColor().mulAlpha(0.3f));
        regularBatching.draw();
        for (ModernCategory modernCategory : this.categories) {
            this.currentCategory.setDuration(150L);
            this.currentCategory.setEasing(Easing.QUAD_OUT);
            if (modernCategory.getCategory() == this.current) {
                this.currentCategory.update(yOff);
            }
            if (GuiUtility.isHovered(x + 12.0f, y + 43.0f + yOff, 95.0, 16.0, context)) {
                CursorUtility.set(CursorType.HAND);
            }
            yOff += 18.0f;
        }
        context.drawSquircle(x + 12.0f, y + 43.0f + this.currentCategory.getValue(), 95.0f, 16.0f, 10.0f, BorderRadius.all(4.0f), Colors.getAccentColor());
        yOff = 0.0f;
        IconBatching iconBatchingCat = new IconBatching(class_290.field_1575, context.method_51448());
        for (ModernCategory modernCategory : this.categories) {
            modernCategory.getSelected().update(modernCategory.getCategory() == this.current);
            if (modernCategory.getPenis() == null) {
                context.drawSprite(modernCategory.getCategory().getMenuSprite(), x + 18.0f, y + 47.0f + yOff, 8.0f, 8.0f, Colors.getTextColor().mix(Colors.WHITE, modernCategory.getSelected().getValue()));
            }
            yOff += 18.0f;
        }
        iconBatchingCat.draw();
        yOff = 0.0f;
        IconBatching iconBatching = new IconBatching(class_290.field_1575, context.method_51448());
        for (ModernCategory modernCategory : this.categories) {
            modernCategory.getSelected().update(modernCategory.getCategory() == this.current);
            if (modernCategory.getPenis() != null) {
                DrawUtility.drawAnimationSprite(context.method_51448(), modernCategory.getPenis().getCurrentSprite(), x + 18.0f, y + 47.0f + yOff, 8.0f, 8.0f, Colors.getTextColor().mix(Colors.WHITE, modernCategory.getSelected().getValue()));
            }
            yOff += 18.0f;
        }
        iconBatching.draw();
        yOff = 0.0f;
        FontBatching fontBatching = new FontBatching(class_290.field_1575, Fonts.MEDIUM);
        for (ModernCategory modernCategory : this.categories) {
            context.drawText(Fonts.MEDIUM.getFont(7.0f), modernCategory.getCategory().getName(), x + 32.0f, y + 48.5f + yOff, Colors.getTextColor().mix(Colors.WHITE, modernCategory.getSelected().getValue()));
            yOff += 18.0f;
        }
        fontBatching.draw();
        yOff = scroll;
        ScissorUtility.push(context.method_51448(), this.menuWindow.getX(), this.menuWindow.getY() + 1.0f, this.menuWindow.getWidth(), this.menuWindow.getHeight() - 2.0f);
        SquircleBatching squircleBatching = new SquircleBatching(5.0f);
        for (ModernCategory modernCategory : this.categories) {
            float prev = yOff;
            modernCategory.setY(yOff);
            for (ModernModule modernModule : modernCategory.getModules()) {
                boolean cond = !this.opened(modernModule);
                modernModule.getVisible().update(cond);
                modernModule.getOffset().update(cond);
                if (this.visibleCheck(modernModule)) continue;
                modernModule.set(x + 127.0f + xOff, y + 33.0f + yOff, moduleWidth, 28.0f);
                if (GuiUtility.isHovered((double)x, (double)(y - modernModule.getHeight()), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + modernModule.getHeight()), modernModule.getX(), modernModule.getY())) {
                    modernModule.render(context);
                    if (GuiUtility.isHovered(modernModule.getX(), modernModule.getY(), modernModule.getWidth(), modernModule.getHeight(), context)) {
                        CursorUtility.set(CursorType.HAND);
                    }
                }
                if (!((xOff += (modernModule.getWidth() + 6.5f) * modernModule.getOffset().getValue()) > this.menuWindow.getWidth() - 139.0f)) continue;
                yOff += 34.0f * modernModule.getOffset().getValue();
                xOff = 0.0f;
            }
            if (xOff != 0.0f) {
                yOff += 34.0f;
            }
            xOff = 0.0f;
            yOff += 25.0f;
            if (modernCategory.getCategory() != MenuCategory.OTHER || !(yOff - prev < this.menuWindow.getHeight())) continue;
            yOff = prev + this.menuWindow.getHeight();
        }
        squircleBatching.draw();
        RoundedRectBatching roundedRectBatching = new RoundedRectBatching();
        for (ModernCategory categoryx : this.categories) {
            for (ModernModule modernModule : categoryx.getModules()) {
                if (this.visibleCheck(modernModule) || !GuiUtility.isHovered((double)x, (double)(y - modernModule.getHeight()), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + modernModule.getHeight()), modernModule.getX(), modernModule.getY())) continue;
                modernModule.renderRounds(context);
            }
        }
        roundedRectBatching.draw();
        RoundedRectBatching roundedRectBatching2 = new RoundedRectBatching();
        for (ModernCategory modernCategory : this.categories) {
            for (ModernModule modulexx : modernCategory.getModules()) {
                if (this.visibleCheck(modulexx) || !GuiUtility.isHovered((double)x, (double)(y - modulexx.getHeight()), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + modulexx.getHeight()), modulexx.getX(), modulexx.getY())) continue;
                modulexx.renderInto(context);
            }
        }
        roundedRectBatching2.draw();
        FontBatching mediumBatching = new FontBatching(class_290.field_1575, Fonts.MEDIUM);
        for (ModernCategory modernCategory : this.categories) {
            for (ModernModule modernModule : modernCategory.getModules()) {
                if (this.visibleCheck(modernModule) || !GuiUtility.isHovered((double)x, (double)(y - modernModule.getHeight()), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + modernModule.getHeight()), modernModule.getX(), modernModule.getY())) continue;
                modernModule.renderMedium(context);
            }
        }
        mediumBatching.draw();
        FadeOutBatching fadeOutBatching = new FadeOutBatching(class_290.field_1575, Fonts.REGULAR, 0.9f, 1.0f, moduleWidth - 30.0f, x + 127.0f);
        for (ModernCategory categoryx : this.categories) {
            for (ModernModule modernModule : categoryx.getModules()) {
                if (this.visibleCheck(modernModule) || !GuiUtility.isHovered((double)x, (double)(y - modernModule.getHeight()), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + modernModule.getHeight()), modernModule.getX(), modernModule.getY()) || modernModule.getX() != x + 127.0f) continue;
                modernModule.renderRegular(context);
            }
        }
        fadeOutBatching.draw();
        FadeOutBatching fadeOutBatching2 = new FadeOutBatching(class_290.field_1575, Fonts.REGULAR, 0.9f, 1.0f, moduleWidth - 30.0f, x + 127.0f + moduleWidth + 6.5f);
        for (ModernCategory modernCategory : this.categories) {
            for (ModernModule modernModule : modernCategory.getModules()) {
                if (this.visibleCheck(modernModule) || !GuiUtility.isHovered((double)x, (double)(y - modernModule.getHeight()), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + modernModule.getHeight()), modernModule.getX(), modernModule.getY()) || modernModule.getX() == x + 127.0f) continue;
                modernModule.renderRegular(context);
            }
        }
        fadeOutBatching2.draw();
        FontBatching fontBatching2 = new FontBatching(class_290.field_1575, Fonts.SEMIBOLD);
        for (ModernCategory modernCategory : this.categories) {
            if (!GuiUtility.isHovered((double)x, (double)(y - 20.0f), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + 20.0f), x + 142.0f, y + 16.0f + modernCategory.getY())) continue;
            context.drawText(Fonts.SEMIBOLD.getFont(12.0f), modernCategory.getCategory().getName(), x + 143.0f, y + 16.0f + modernCategory.getY(), Experiment.getInstance().getThemeManager().getCurrentTheme().getTextColor());
        }
        fontBatching2.draw();
        IconBatching iconBatching2 = new IconBatching(class_290.field_1575, context.method_51448());
        for (ModernCategory modernCategory : this.categories) {
            if (!GuiUtility.isHovered((double)x, (double)(y - 20.0f), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + 20.0f), x + 142.0f, y + 16.0f + modernCategory.getY()) || modernCategory.getPenis() != null) continue;
            context.drawSprite(modernCategory.getCategory().getBigMenuSprite(), x + 129.0f, y + 15.0f + modernCategory.getY(), 10.0f, 10.0f, Colors.getTextColor());
        }
        iconBatching2.draw();
        IconBatching iconBatching3 = new IconBatching(class_290.field_1575, context.method_51448());
        for (ModernCategory categoryxxx : this.categories) {
            if (!GuiUtility.isHovered((double)x, (double)(y - 20.0f), (double)this.menuWindow.getWidth(), (double)(this.menuWindow.getHeight() + 20.0f), x + 142.0f, y + 16.0f + categoryxxx.getY()) || categoryxxx.getPenis() == null) continue;
            DrawUtility.drawAnimationSprite(context.method_51448(), categoryxxx.getPenis().getCurrentSprite(), x + 129.0f, y + 15.0f + categoryxxx.getY(), 10.0f, 10.0f, Colors.getTextColor());
        }
        iconBatching3.draw();
        float f = yOff - scroll;
        float visibleHeight = this.menuWindow.getHeight() - 10.0f;
        float maxScroll = -Math.max(0.0f, f - visibleHeight);
        this.scrollHandler.setMax(maxScroll - 10.0f);
        ScissorUtility.pop();
        RenderUtility.end(context.method_51448());
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        for (ModernSettings window2 : this.windows) {
            window2.render(context);
        }
        for (ColorPicker colorPicker : this.colorPickers) {
            colorPicker.render(context);
        }
        this.windows.removeIf(window -> window.getAnimation().getValue() == 0.0f && !window.isShowing());
        this.colorPickers.removeIf(colorPickerx -> colorPickerx.getAnimation().getValue() == 0.0f && !colorPickerx.isShowing());
    }

    @Compile
    private void handleMovementKeys() {
        if (ModernScreen.mc.field_1724 != null && !this.isTyping()) {
            class_304[] movementKeys;
            long windowHandle = mc.method_22683().method_4490();
            for (class_304 key : movementKeys = new class_304[]{ModernScreen.mc.field_1690.field_1894, ModernScreen.mc.field_1690.field_1881, ModernScreen.mc.field_1690.field_1913, ModernScreen.mc.field_1690.field_1849, ModernScreen.mc.field_1690.field_1903}) {
                int keyCode = class_3675.method_15981((String)key.method_1428()).method_1444();
                key.method_23481(class_3675.method_15987((long)windowHandle, (int)keyCode));
            }
            if (ModernScreen.mc.field_1724.method_31549().field_7479) {
                int keyCode = class_3675.method_15981((String)ModernScreen.mc.field_1690.field_1832.method_1428()).method_1444();
                ModernScreen.mc.field_1690.field_1832.method_23481(class_3675.method_15987((long)windowHandle, (int)keyCode));
            }
        }
    }

    private boolean isTyping() {
        return ModernScreen.mc.field_1755 != null && TextField.LAST_FIELD != null && TextField.LAST_FIELD.isFocused();
    }

    @Override
    @Compile
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (!Experiment.getInstance().getHud().getIsland().handleClick((float)mouseX, (float)mouseY, button.getButtonIndex())) {
            for (ColorPicker colorPicker : this.colorPickers) {
                boolean isPick = colorPicker.isPick();
                colorPicker.onMouseClicked(mouseX, mouseY, button);
                if (colorPicker.isHovered(mouseX, mouseY) || isPick) {
                    return;
                }
                colorPicker.setShowing(false);
            }
            for (ModernSettings window : this.windows) {
                window.onMouseClicked(mouseX, mouseY, button);
                if (window.isHovered(mouseX, mouseY)) {
                    return;
                }
                if (GuiUtility.isHovered(this.menuWindow, mouseX, mouseY)) continue;
                boolean can = true;
                for (ModernSettings window1 : this.windows) {
                    if (!GuiUtility.isHovered(window1, mouseX, mouseY)) continue;
                    can = false;
                }
                if (!can) continue;
                window.setShowing(false);
            }
            float x = this.menuWindow.getX();
            float y = this.menuWindow.getY();
            float yOff = 0.0f;
            float xOff = 0.0f;
            for (ModernCategory category : this.categories) {
                if (GuiUtility.isHovered((double)(x + 12.0f), (double)(y + 43.0f + yOff), 95.0, 16.0, mouseX, mouseY) && category.getCategory() != this.current) {
                    this.scrollHandler.scroll((-this.scrollHandler.getValue() - ((double)category.getY() - this.scrollHandler.getValue())) / 20.0);
                    if (category.getPenis() != null) {
                        category.getPenis().playOnce();
                    }
                    return;
                }
                yOff += 18.0f;
            }
            for (ModernCategory category : this.categories) {
                for (ModernModule module : category.getModules()) {
                    if (this.visibleCheck(module) || !GuiUtility.isHovered(this.menuWindow, mouseX, mouseY) && (button == MouseButton.LEFT || button == MouseButton.RIGHT) || !GuiUtility.isHovered((double)module.getX(), (double)module.getY(), (double)module.getWidth(), (double)module.getHeight(), mouseX, mouseY)) continue;
                    module.onMouseClicked(mouseX, mouseY, button);
                    return;
                }
            }
            if (button != MouseButton.MIDDLE) {
                this.searchField.onMouseClicked(mouseX, mouseY, button);
            }
            if (GuiUtility.isHovered(this.menuWindow, mouseX, mouseY)) {
                this.drag = true;
                this.dragX = (float)(mouseX - (double)this.menuWindow.getX());
                this.dragY = (float)(mouseY - (double)this.menuWindow.getY());
            }
            super.onMouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    @Compile
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        this.drag = false;
        for (ModernSettings window : this.windows) {
            window.onMouseReleased(mouseX, mouseY, button);
        }
        for (ColorPicker colorPicker : this.colorPickers) {
            colorPicker.onMouseReleased(mouseX, mouseY, button);
        }
        if (this.searchField.isFocused()) {
            this.searchField.onMouseReleased(mouseX, mouseY, button);
        }
        super.onMouseReleased(mouseX, mouseY, button);
    }

    @Compile
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (ModernSettings window : this.windows) {
            window.onScroll(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        if (GuiUtility.isHovered(this.menuWindow, mouseX, mouseY)) {
            this.scrollHandler.scroll(verticalAmount);
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Compile
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (!this.searchField.isFocused() && class_437.method_25441() && keyCode == 70) {
            this.searchField.setFocused(true);
        }
        this.scrollHandler.onKeyPressed(keyCode);
        for (ModernSettings window : this.windows) {
            window.onKeyPressed(keyCode, scanCode, modifiers);
        }
        for (ColorPicker colorPicker : this.colorPickers) {
            colorPicker.onKeyPressed(keyCode, scanCode, modifiers);
        }
        if (this.searchField.isFocused() && !this.isBindingModule()) {
            this.searchField.onKeyPressed(keyCode, scanCode, modifiers);
        }
        for (ModernCategory category : this.categories) {
            for (ModernModule module : category.getModules()) {
                if (this.visibleCheck(module)) continue;
                module.onKeyPressed(keyCode, scanCode, modifiers);
            }
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Compile
    public boolean method_25400(char chr, int modifiers) {
        if (this.searchField.isFocused() && !this.isBindingModule()) {
            this.searchField.charTyped(chr, modifiers);
        }
        for (ModernSettings window : this.windows) {
            window.charTyped(chr, modifiers);
        }
        for (ModernCategory category : this.categories) {
            for (ModernModule module : category.getModules()) {
                if (this.visibleCheck(module)) continue;
                module.charTyped(chr, modifiers);
            }
        }
        return super.method_25400(chr, modifiers);
    }

    @Compile
    public void method_25419() {
        this.closing = true;
        Experiment.getInstance().getModuleManager().getModule(MenuModule.class).disable();
        Sounds soundsModule = Experiment.getInstance().getModuleManager().getModule(Sounds.class);
        if (soundsModule.isEnabled()) {
            ClientSounds.CLICKGUI_OPEN.play(soundsModule.getVolume().getCurrentValue(), 1.0f);
        }
        Experiment.getInstance().getFileManager().writeFile("client");
        if (TextField.LAST_FIELD != null) {
            TextField.LAST_FIELD.setFocused(false);
        }
        super.method_25419();
    }

    private boolean searchCheck(ModernModule component) {
        TextField search = this.searchField;
        return search != null && !search.getBuiltText().isBlank() && !component.getModule().getName().toLowerCase().contains(search.getBuiltText().toLowerCase()) && !component.getModule().getName().replace(" ", "").toLowerCase().contains(search.getBuiltText().toLowerCase());
    }

    private boolean visibleCheck(ModernModule component) {
        return component.getOffset().getValue() == 0.0f || this.searchCheck(component) || component.getModule().isHidden();
    }

    private boolean opened(ModernModule component) {
        return this.windows.stream().anyMatch(window -> window.getModule() == component);
    }

    public boolean isBindingModule() {
        return this.categories.stream().flatMap(panel -> panel.getModules().stream()).anyMatch(ModernModule::isBinding);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    public boolean method_25422() {
        return true;
    }

    public Rect getMenuWindow() {
        return this.menuWindow;
    }

    public float getDragX() {
        return this.dragX;
    }

    public float getDragY() {
        return this.dragY;
    }

    public boolean isDrag() {
        return this.drag;
    }

    public ScrollHandler getScrollHandler() {
        return this.scrollHandler;
    }

    public MenuCategory getCurrent() {
        return this.current;
    }

    public List<ColorPicker> getColorPickers() {
        return this.colorPickers;
    }

    public List<ModernCategory> getCategories() {
        return this.categories;
    }

    public List<ModernSettings> getWindows() {
        return this.windows;
    }

    public Animation getCurrentCategory() {
        return this.currentCategory;
    }

    public TextField getSearchField() {
        return this.searchField;
    }

    public PenisPlayer getSearchPenis() {
        return this.searchPenis;
    }

    public boolean isPrevFocused() {
        return this.prevFocused;
    }

    public Timer getTimer() {
        return this.timer;
    }

    static {
        new MenuPanel(null);
        new BezierSettingComponent(null, null);
        new BindSettingComponent(null, null);
        new BooleanSettingComponent(null, null);
        new ModeSettingComponent(null, null);
        new ButtonSettingComponent(null, null);
        new ColorSettingComponent(null, null);
        new StringSettingComponent(null, null);
        new RangeSettingComponent(null, null);
        new SliderSettingComponent(null, null);
    }
}

