/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.api;

import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.api.ModuleCategory;
import micronix.experiment.utility.render.obj.CustomSprite;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum MenuCategory {
    COMBAT(Localizator.translate("Combat"), ModuleCategory.COMBAT, CustomSprite.COMBAT, CustomSprite.BIG_COMBAT),
    MOVEMENT(Localizator.translate("Movement"), ModuleCategory.MOVEMENT, CustomSprite.MOVEMENT, CustomSprite.BIG_MOVEMENT),
    VISUALS(Localizator.translate("Visuals"), ModuleCategory.VISUALS, CustomSprite.VISUALS, CustomSprite.BIG_VISUALS),
    PLAYER(Localizator.translate("Player"), ModuleCategory.PLAYER, CustomSprite.PLAYER, CustomSprite.BIG_PLAYER),
    OTHER(Localizator.translate("Other"), ModuleCategory.OTHER, CustomSprite.OTHER, CustomSprite.BIG_OTHER);

    private final String name;
    private final ModuleCategory category;
    private final CustomSprite menuSprite;
    private final CustomSprite bigMenuSprite;

    public String getName() {
        return this.name;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    public CustomSprite getMenuSprite() {
        return this.menuSprite;
    }

    public CustomSprite getBigMenuSprite() {
        return this.bigMenuSprite;
    }

    private MenuCategory(String name, ModuleCategory category, CustomSprite menuSprite, CustomSprite bigMenuSprite) {
        this.name = name;
        this.category = category;
        this.menuSprite = menuSprite;
        this.bigMenuSprite = bigMenuSprite;
    }
}

