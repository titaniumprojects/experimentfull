/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_310
 */
package micronix.experiment.ui.menu.api;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.systems.event.EventListener;
import micronix.experiment.systems.event.impl.render.HudRenderEvent;
import micronix.experiment.systems.modules.modules.visuals.MenuModule;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.ui.menu.dropdown.DropDownScreen;
import micronix.experiment.utility.interfaces.IMinecraft;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(value=EnvType.CLIENT)
public class MenuCloseListener
implements IMinecraft {
    private final EventListener<HudRenderEvent> onHudRender = event -> {
        MenuScreen menuScreen = Experiment.getInstance().getMenuScreen();
        if (MenuCloseListener.mc.field_1755 == null && !(menuScreen instanceof DropDownScreen)) {
            Experiment.getInstance().setMenuScreen(new DropDownScreen());
        }
        if (menuScreen == null) {
            return;
        }
        menuScreen.getMenuAnimation().update(menuScreen.isClosing() ? 0.0f : 1.0f);
        if (!(MenuCloseListener.mc.field_1755 instanceof MenuScreen) && Experiment.getInstance().getModuleManager().getModule(MenuModule.class).isEnabled()) {
            Experiment.getInstance().getModuleManager().getModule(MenuModule.class).setEnabled(false);
        }
        if (menuScreen.getMenuAnimation().getValue() > 0.1f && !(MenuCloseListener.mc.field_1755 instanceof MenuScreen) && menuScreen.isClosing()) {
            UIContext context = UIContext.of(event.getContext(), -1, -1, class_310.method_1551().method_61966().method_60637(false));
            menuScreen.render(context);
        }
    };

    public MenuCloseListener() {
        Experiment.getInstance().getEventManager().subscribe(this);
    }
}

