/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu;

import micronix.experiment.framework.base.CustomScreen;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public abstract class MenuScreen
extends CustomScreen {
    protected final Animation menuAnimation = new Animation(500L, Easing.LINEAR);
    protected boolean closing = true;

    public Animation getMenuAnimation() {
        return this.menuAnimation;
    }

    public boolean isClosing() {
        return this.closing;
    }

    public void setClosing(boolean closing) {
        this.closing = closing;
    }
}

