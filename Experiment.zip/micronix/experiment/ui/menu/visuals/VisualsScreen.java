/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_304
 *  net.minecraft.class_332
 *  net.minecraft.class_3675
 */
package micronix.experiment.ui.menu.visuals;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.framework.objects.gradient.impl.VerticalGradient;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.modules.modules.visuals.MenuModule;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.components.textfield.TextField;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.ui.menu.api.MenuCategory;
import micronix.experiment.ui.menu.visuals.components.HudSettings;
import micronix.experiment.ui.menu.visuals.components.HudToggle;
import micronix.experiment.ui.menu.visuals.components.VisualCategory;
import micronix.experiment.ui.menu.visuals.components.VisualSettings;
import micronix.experiment.ui.menu.visuals.components.VisualToggle;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.gui.ScrollHandler;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.ScissorUtility;
import micronix.experiment.utility.render.obj.Rect;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import ru.kotopushka.compiler.sdk.annotations.Compile;

@Environment(value=EnvType.CLIENT)
public class VisualsScreen
extends MenuScreen
implements IMinecraft,
IScaledResolution {
    private final Rect menuWindow;
    private final ScrollHandler scrollHandler = new ScrollHandler();
    private final List<VisualCategory> categories = new ArrayList<VisualCategory>();
    private final List<VisualSettings> windows = new LinkedList<VisualSettings>();
    private final List<HudSettings> hudWindows = new LinkedList<HudSettings>();
    private final TextField searchField;
    private VisualCategory currentCategory;
    private final Animation categoryLineAnimation = new Animation(300L, Easing.BAKEK);

    public VisualsScreen() {
        float width = 450.0f;
        float height = 320.0f;
        this.menuWindow = new Rect(sr.getScaledWidth() / 2.0f - width / 2.0f, sr.getScaledHeight() / 2.0f - height / 2.0f, width, height);
        this.categories.add(new VisualCategory("Visuals", MenuCategory.VISUALS));
        this.categories.add(new VisualCategory("HUD", null));
        this.categories.add(new VisualCategory("Utilities", null));
        this.currentCategory = this.categories.get(0);
        this.searchField = new TextField(Fonts.REGULAR.getFont(9.0f));
        this.searchField.setPreview("Search");
    }

    @Compile
    protected void method_25426() {
        this.closing = false;
        for (VisualCategory category : this.categories) {
            category.init();
        }
        super.method_25426();
    }

    public void method_25393() {
        this.handleMovementKeys();
        super.method_25393();
    }

    @Override
    public void render(UIContext context) {
        this.menuAnimation.update(this.closing ? 0.0f : 1.0f);
        this.menuAnimation.setEasing(!this.closing ? Easing.BAKEK : Easing.BAKEK_BACK);
        this.menuAnimation.setDuration(400L);
        this.scrollHandler.update();
        float alpha = Math.min(1.0f, this.menuAnimation.getValue());
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        RenderUtility.scale(context.method_51448(), this.menuWindow.getX() + this.menuWindow.getWidth() / 2.0f, this.menuWindow.getY() + this.menuWindow.getHeight() / 2.0f, 0.5f + 0.5f * this.menuAnimation.getValue());
        context.drawBlurredRect(this.menuWindow.getX(), this.menuWindow.getY(), this.menuWindow.getWidth(), this.menuWindow.getHeight(), 45.0f, 5.0f, BorderRadius.all(16.0f), Colors.WHITE.withAlpha(255.0f * alpha));
        ColorRGBA darkBg = new ColorRGBA(15.0f, 15.0f, 20.0f).withAlpha(255.0f * alpha);
        context.drawRoundedRect(this.menuWindow.getX(), this.menuWindow.getY(), this.menuWindow.getWidth(), this.menuWindow.getHeight(), BorderRadius.all(16.0f), darkBg);
        context.drawRoundedRect(this.menuWindow.getX(), this.menuWindow.getY(), this.menuWindow.getWidth(), this.menuWindow.getHeight(), BorderRadius.all(16.0f), new VerticalGradient(new ColorRGBA(20.0f, 30.0f, 120.0f).withAlpha(40.0f * alpha), new ColorRGBA(40.0f, 20.0f, 80.0f).withAlpha(60.0f * alpha)));
        float x = this.menuWindow.getX();
        float y = this.menuWindow.getY();
        this.renderTopBar(context, x, y, alpha, dark);
        this.renderSearchField(context, x, y, alpha, dark);
        this.renderContent(context, x, y, alpha, dark);
        RenderUtility.end(context.method_51448());
        for (VisualSettings visualSettings : this.windows) {
            visualSettings.render(context);
        }
        for (HudSettings hudSettings : this.hudWindows) {
            hudSettings.render(context);
        }
        this.windows.removeIf(windowx -> windowx.getAnimation().getValue() == 0.0f && !windowx.isShowing());
        this.hudWindows.removeIf(windowx -> windowx.getAnimation().getValue() == 0.0f && !windowx.isShowing());
    }

    private void renderTopBar(UIContext context, float x, float y, float alpha, boolean dark) {
        float tabWidth = 80.0f;
        float tabHeight = 25.0f;
        float tabSpacing = 8.0f;
        float startX = x + 20.0f;
        int currentIndex = this.categories.indexOf(this.currentCategory);
        float targetLineX = startX + (float)currentIndex * (tabWidth + tabSpacing);
        this.categoryLineAnimation.update(targetLineX);
        float lineWidth = 60.0f;
        float lineHeight = 2.0f;
        float lineY = y + 35.0f;
        context.drawRoundedRect(this.categoryLineAnimation.getValue() + (tabWidth - lineWidth) / 2.0f, lineY, lineWidth, lineHeight, BorderRadius.all(1.0f), Colors.WHITE.withAlpha(255.0f * alpha));
        for (int i = 0; i < this.categories.size(); ++i) {
            VisualCategory category = this.categories.get(i);
            float tabX = startX + (float)i * (tabWidth + tabSpacing);
            boolean isSelected = category == this.currentCategory;
            category.getSelectedAnimation().update(isSelected);
            ColorRGBA textColor = isSelected ? Colors.WHITE.withAlpha(255.0f * alpha) : new ColorRGBA(120.0f, 120.0f, 130.0f).withAlpha(255.0f * alpha);
            context.drawText(Fonts.MEDIUM.getFont(9.0f), category.getName(), tabX, y + 18.0f, textColor);
            if (i >= this.categories.size() - 1) continue;
            float separatorX = tabX + tabWidth + tabSpacing / 2.0f - 1.0f;
            context.drawRect(separatorX, y + 15.0f, 1.0f, 20.0f, new ColorRGBA(60.0f, 60.0f, 70.0f).withAlpha(255.0f * alpha));
        }
    }

    private void renderSearchField(UIContext context, float x, float y, float alpha, boolean dark) {
        float searchWidth = 120.0f;
        float searchHeight = 22.0f;
        float searchX = x + this.menuWindow.getWidth() - searchWidth - 15.0f;
        float searchY = y + 13.0f;
        context.drawRoundedRect(searchX, searchY, searchWidth, searchHeight, BorderRadius.all(5.0f), dark ? Colors.getAdditionalColor().mulAlpha(0.6f * alpha) : Colors.getBackgroundColor().mulAlpha(0.6f * alpha));
        this.searchField.set(searchX + 8.0f, searchY + 2.0f, searchWidth - 16.0f, searchHeight - 4.0f);
        this.searchField.setTextColor(Colors.getTextColor().withAlpha(255.0f * alpha));
        this.searchField.setAlpha(alpha);
        this.searchField.render(context);
    }

    private void renderContent(UIContext context, float x, float y, float alpha, boolean dark) {
        float scroll;
        float contentX = x + 15.0f;
        float contentY = y + 50.0f;
        float contentWidth = this.menuWindow.getWidth() - 30.0f;
        float contentHeight = this.menuWindow.getHeight() - 65.0f;
        ScissorUtility.push(context.method_51448(), contentX, contentY, contentWidth, contentHeight);
        float yOffset = scroll = (float)(-this.scrollHandler.getValue());
        float toggleWidth = (contentWidth - 10.0f) / 2.0f;
        float toggleHeight = 32.0f;
        float spacing = 8.0f;
        if (this.currentCategory.isHudCategory()) {
            List<HudToggle> hudToggles = this.currentCategory.getHudToggles();
            for (int i = 0; i < hudToggles.size(); ++i) {
                HudToggle toggle = hudToggles.get(i);
                int column = i % 2;
                int row = i / 2;
                float toggleX = contentX + (float)column * (toggleWidth + spacing);
                float toggleY = contentY + yOffset + (float)row * (toggleHeight + spacing);
                toggle.set(toggleX, toggleY, toggleWidth, toggleHeight);
                toggle.render(context, alpha);
            }
            float totalHeight = (float)((hudToggles.size() + 1) / 2) * (toggleHeight + spacing);
            float maxScroll = -Math.max(0.0f, totalHeight - contentHeight);
            this.scrollHandler.setMax(maxScroll);
        } else {
            List<VisualToggle> toggles = this.currentCategory.getToggles();
            for (int i = 0; i < toggles.size(); ++i) {
                VisualToggle toggle = toggles.get(i);
                int column = i % 2;
                int row = i / 2;
                float toggleX = contentX + (float)column * (toggleWidth + spacing);
                float toggleY = contentY + yOffset + (float)row * (toggleHeight + spacing);
                toggle.set(toggleX, toggleY, toggleWidth, toggleHeight);
                toggle.render(context, alpha);
            }
            float totalHeight = (float)((toggles.size() + 1) / 2) * (toggleHeight + spacing);
            float maxScroll = -Math.max(0.0f, totalHeight - contentHeight);
            this.scrollHandler.setMax(maxScroll);
        }
        ScissorUtility.pop();
    }

    @Compile
    private void handleMovementKeys() {
        if (VisualsScreen.mc.field_1724 != null && !this.isTyping()) {
            class_304[] movementKeys;
            long windowHandle = mc.method_22683().method_4490();
            for (class_304 key : movementKeys = new class_304[]{VisualsScreen.mc.field_1690.field_1894, VisualsScreen.mc.field_1690.field_1881, VisualsScreen.mc.field_1690.field_1913, VisualsScreen.mc.field_1690.field_1849, VisualsScreen.mc.field_1690.field_1903}) {
                int keyCode = class_3675.method_15981((String)key.method_1428()).method_1444();
                key.method_23481(class_3675.method_15987((long)windowHandle, (int)keyCode));
            }
            if (VisualsScreen.mc.field_1724.method_31549().field_7479) {
                int keyCode = class_3675.method_15981((String)VisualsScreen.mc.field_1690.field_1832.method_1428()).method_1444();
                VisualsScreen.mc.field_1690.field_1832.method_23481(class_3675.method_15987((long)windowHandle, (int)keyCode));
            }
        }
    }

    private boolean isTyping() {
        return VisualsScreen.mc.field_1755 != null && TextField.LAST_FIELD != null && TextField.LAST_FIELD.isFocused();
    }

    @Override
    @Compile
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (!Experiment.getInstance().getHud().getIsland().handleClick((float)mouseX, (float)mouseY, button.getButtonIndex())) {
            boolean can;
            for (VisualSettings visualSettings : this.windows) {
                visualSettings.onMouseClicked(mouseX, mouseY, button);
                if (visualSettings.isHovered(mouseX, mouseY)) {
                    return;
                }
                if (GuiUtility.isHovered(this.menuWindow, mouseX, mouseY)) continue;
                can = true;
                for (VisualSettings window1 : this.windows) {
                    if (!GuiUtility.isHovered(window1, mouseX, mouseY)) continue;
                    can = false;
                }
                if (!can) continue;
                visualSettings.setShowing(false);
            }
            for (HudSettings hudSettings : this.hudWindows) {
                hudSettings.onMouseClicked(mouseX, mouseY, button);
                if (hudSettings.isHovered(mouseX, mouseY)) {
                    return;
                }
                if (GuiUtility.isHovered(this.menuWindow, mouseX, mouseY)) continue;
                can = true;
                for (HudSettings window1x : this.hudWindows) {
                    if (!GuiUtility.isHovered(window1x, mouseX, mouseY)) continue;
                    can = false;
                }
                if (!can) continue;
                hudSettings.setShowing(false);
            }
            float tabWidth = 80.0f;
            float f = 25.0f;
            float tabSpacing = 8.0f;
            float startX = this.menuWindow.getX() + 20.0f;
            float y = this.menuWindow.getY();
            for (int i = 0; i < this.categories.size(); ++i) {
                VisualCategory category = this.categories.get(i);
                float tabX = startX + (float)i * (tabWidth + tabSpacing);
                if (!GuiUtility.isHovered((double)(tabX - 5.0f), (double)(y + 12.0f), (double)tabWidth, (double)f, mouseX, mouseY)) continue;
                this.currentCategory = category;
                this.scrollHandler.setValue(0.0);
                return;
            }
            if (this.currentCategory.isHudCategory()) {
                for (HudToggle toggle : this.currentCategory.getHudToggles()) {
                    if (!toggle.isHovered(mouseX, mouseY)) continue;
                    toggle.onMouseClicked(mouseX, mouseY, button, this);
                    return;
                }
            } else {
                for (VisualToggle togglex : this.currentCategory.getToggles()) {
                    if (!togglex.isHovered(mouseX, mouseY)) continue;
                    togglex.onMouseClicked(mouseX, mouseY, button, this);
                    return;
                }
            }
            if (button != MouseButton.MIDDLE) {
                this.searchField.onMouseClicked(mouseX, mouseY, button);
            }
            super.onMouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    @Compile
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (VisualSettings visualSettings : this.windows) {
            visualSettings.onMouseReleased(mouseX, mouseY, button);
        }
        for (HudSettings hudSettings : this.hudWindows) {
            hudSettings.onMouseReleased(mouseX, mouseY, button);
        }
        if (this.currentCategory.isHudCategory()) {
            for (HudToggle hudToggle : this.currentCategory.getHudToggles()) {
                hudToggle.onMouseReleased(mouseX, mouseY, button);
            }
        } else {
            for (VisualToggle visualToggle : this.currentCategory.getToggles()) {
                visualToggle.onMouseReleased(mouseX, mouseY, button);
            }
        }
        if (this.searchField.isFocused()) {
            this.searchField.onMouseReleased(mouseX, mouseY, button);
        }
        super.onMouseReleased(mouseX, mouseY, button);
    }

    @Compile
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (VisualSettings visualSettings : this.windows) {
            visualSettings.onScroll(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        for (HudSettings hudSettings : this.hudWindows) {
            hudSettings.onScroll(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        if (GuiUtility.isHovered(this.menuWindow, mouseX, mouseY)) {
            this.scrollHandler.scroll(verticalAmount);
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Compile
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        for (VisualSettings visualSettings : this.windows) {
            visualSettings.onKeyPressed(keyCode, scanCode, modifiers);
        }
        for (HudSettings hudSettings : this.hudWindows) {
            hudSettings.onKeyPressed(keyCode, scanCode, modifiers);
        }
        if (this.searchField.isFocused()) {
            this.searchField.onKeyPressed(keyCode, scanCode, modifiers);
        }
        this.scrollHandler.onKeyPressed(keyCode);
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Compile
    public boolean method_25400(char chr, int modifiers) {
        for (VisualSettings visualSettings : this.windows) {
            visualSettings.charTyped(chr, modifiers);
        }
        for (HudSettings hudSettings : this.hudWindows) {
            hudSettings.charTyped(chr, modifiers);
        }
        if (this.searchField.isFocused()) {
            this.searchField.charTyped(chr, modifiers);
        }
        return super.method_25400(chr, modifiers);
    }

    @Compile
    public void method_25419() {
        this.closing = true;
        Experiment.getInstance().getModuleManager().getModule(MenuModule.class).disable();
        Sounds soundsModule = Experiment.getInstance().getModuleManager().getModule(Sounds.class);
        if (soundsModule.isEnabled()) {
            ClientSounds.CLICKGUI_OPEN.play(soundsModule.getVolume().getCurrentValue(), 1.0f);
        }
        Experiment.getInstance().getFileManager().writeFile("client");
        if (TextField.LAST_FIELD != null) {
            TextField.LAST_FIELD.setFocused(false);
        }
        super.method_25419();
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    public boolean method_25422() {
        return true;
    }

    public Rect getMenuWindow() {
        return this.menuWindow;
    }

    public ScrollHandler getScrollHandler() {
        return this.scrollHandler;
    }

    public List<VisualCategory> getCategories() {
        return this.categories;
    }

    public TextField getSearchField() {
        return this.searchField;
    }

    public VisualCategory getCurrentCategory() {
        return this.currentCategory;
    }

    public List<VisualSettings> getWindows() {
        return this.windows;
    }

    public List<HudSettings> getHudWindows() {
        return this.hudWindows;
    }
}

