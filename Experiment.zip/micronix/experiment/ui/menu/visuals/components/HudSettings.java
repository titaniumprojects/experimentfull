/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.visuals.components;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.framework.objects.gradient.impl.VerticalGradient;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.menu.dropdown.components.settings.MenuSettingComponent;
import micronix.experiment.ui.menu.visuals.VisualsScreen;
import micronix.experiment.ui.menu.visuals.components.HudToggle;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.animation.types.ColorAnimation;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.gui.ScrollHandler;
import micronix.experiment.utility.math.MathUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.ScissorUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class HudSettings
extends CustomComponent {
    private final HudToggle toggle;
    private List<MenuSettingComponent> components = new ArrayList<MenuSettingComponent>();
    private final Animation animation = new Animation(300L, 0.0f, Easing.BAKEK_SIZE);
    private boolean showing;
    private final ScrollHandler scrollHandler = new ScrollHandler();
    private float dragX;
    private float dragY;
    private boolean drag;
    private final Animation hoverAnimation = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final Animation circleOpacityAnimation = new Animation(300L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private final Animation enableAnimation = new Animation(300L, Easing.BAKEK);
    private final ColorAnimation backgroundColorAnimation = new ColorAnimation(300L, new ColorRGBA(24.0f, 24.0f, 27.0f), Easing.FIGMA_EASE_IN_OUT);

    public HudSettings(HudToggle toggle, float x, float y, float width) {
        this.toggle = toggle;
        this.x = x;
        this.y = y;
        this.width = width;
        this.showing = true;
        for (Setting setting : toggle.getElement().getSettings()) {
            MenuSettingComponent settingComponent = GuiUtility.settinge(setting, this);
            if (settingComponent == null) continue;
            this.components.add(settingComponent);
        }
    }

    @Override
    protected void renderComponent(UIContext context) {
        this.animation.setDuration(this.showing ? 500L : 300L);
        this.animation.update(this.showing && HudSettings.mc.field_1755 instanceof VisualsScreen);
        this.scrollHandler.update();
        if (this.drag) {
            this.x = (float)context.getMouseX() - this.dragX;
            this.y = (float)context.getMouseY() - this.dragY;
        }
        float alpha = Math.min(1.0f, this.animation.getValue());
        boolean check = Experiment.getInstance().getMenuScreen().getMenuAnimation().getValue() == Experiment.getInstance().getMenuScreen().getMenuAnimation().getTargetValue();
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        this.animation.setEasing(this.showing ? Easing.QUARTIC_OUT : Easing.BAKEK_BACK);
        float x = MathUtility.interpolate(this.toggle.getX(), this.x, alpha);
        float y = MathUtility.interpolate(this.toggle.getY(), this.y, alpha);
        float width = MathUtility.interpolate(this.toggle.getWidth(), this.width, alpha);
        float height = MathUtility.interpolate(this.toggle.getHeight(), this.height, alpha);
        if (!(this.showing && check && HudSettings.mc.field_1755 instanceof VisualsScreen)) {
            x = this.x;
            y = this.y;
            width = this.width;
            height = this.height;
        }
        if (!this.showing || !check) {
            RenderUtility.scale(context.method_51448(), x + width / 2.0f, y + height / 2.0f, 0.5f + 0.5f * this.animation.getValue());
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        }
        context.drawBlurredRect(x, y, width, height, 11.25f, 5.0f, BorderRadius.all(11.0f), Colors.WHITE);
        context.drawRoundedRect(x, y, width, height, BorderRadius.all(11.0f), new ColorRGBA(15.0f, 15.0f, 20.0f).withAlpha(255.0f * alpha));
        context.drawRoundedRect(x, y, width, height, BorderRadius.all(11.0f), new VerticalGradient(new ColorRGBA(60.0f, 30.0f, 120.0f).withAlpha(40.0f * alpha), new ColorRGBA(40.0f, 20.0f, 80.0f).withAlpha(60.0f * alpha)));
        if (this.showing) {
            context.drawText(Fonts.MEDIUM.getFont(7.0f + 2.0f * alpha), Localizator.translate(this.toggle.getElement().getName()), x + 7.0f + 2.0f * alpha, y + 8.0f + 2.0f * alpha, Colors.getTextColor());
        } else {
            context.drawText(Fonts.MEDIUM.getFont(9.0f), Localizator.translate(this.toggle.getElement().getName()), x + 9.0f, y + 10.0f, Colors.getTextColor());
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        context.drawTexture(Experiment.id("icons/close.png"), x + width - 17.0f, y + 9.0f, 8.0f, 8.0f, Colors.getTextColor());
        if (GuiUtility.isHovered(x + width - 17.0f, y + 9.0f, 8.0, 8.0, context)) {
            CursorUtility.set(CursorType.HAND);
        }
        if (Interface.showMinimalizm()) {
            context.drawRect(x, y + 24.0f, width, 4.0f, Colors.getSeparatorColor().withAlpha(Colors.getSeparatorColor().getAlpha() * Interface.minimalizm()));
        }
        float settingsY = 28.0f;
        float offset = 0.0f;
        ScissorUtility.push(context.method_51448(), x, y + 28.0f, width, height - 28.0f - 5.0f);
        this.circleOpacityAnimation.update(this.toggle.getElement().isShowing() ? 1.0f : 0.75f);
        this.enableAnimation.update(this.toggle.getElement().isShowing() ? 1.0f : 0.0f);
        this.backgroundColorAnimation.update(this.toggle.getElement().isShowing() ? new ColorRGBA(151.0f, 71.0f, 255.0f) : Experiment.getInstance().getThemeManager().getCurrentTheme().getAdditionalColor());
        this.hoverAnimation.update(this.isHovered(context.getMouseX(), context.getMouseY()));
        if (this.isHovered(context.getMouseX(), context.getMouseY())) {
            CursorUtility.set(CursorType.HAND);
        }
        float settingY = (float)((double)(y + 28.0f) - this.scrollHandler.getValue());
        float checkWidth = 13.0f;
        float checkHeight = 8.0f;
        Font nameFont = Fonts.REGULAR.getFont(8.0f);
        float leftPadding = 10.0f;
        float headerHeight = 19.0f;
        String name = Localizator.translate("enabled");
        context.drawFadeoutText(nameFont, name.substring(0, 1).toUpperCase() + name.substring(1), x + leftPadding, settingY + GuiUtility.getMiddleOfBox(nameFont.height(), headerHeight) - 0.5f, Colors.getTextColor().withAlpha(255.0f * (0.75f + 0.25f * this.enableAnimation.getValue() + 0.25f * this.hoverAnimation.getValue())), 0.7f, 0.99f, width - checkWidth - 20.0f);
        context.drawRoundedRect(x + width - checkWidth - 9.0f, settingY + 5.0f, checkWidth, checkHeight, BorderRadius.all(3.0f), this.backgroundColorAnimation.getColor().withAlpha(!this.toggle.getElement().isShowing() ? 255.0f - 100.0f * Interface.glass() : 255.0f));
        context.drawRoundedRect(x + width - checkWidth - 8.0f + 5.0f * this.enableAnimation.getValue(), settingY + 6.0f, 6.0f, 6.0f, BorderRadius.all(4.0f), new ColorRGBA(255.0f, 255.0f, 255.0f).withAlpha(this.circleOpacityAnimation.getValue() * 255.0f));
        float separatorHeight = 0.5f;
        context.drawRect(x, settingY + 18.0f, width, separatorHeight, Colors.getTextColor().withAlpha(5.1f));
        offset += 18.0f;
        for (MenuSettingComponent settingComponent : this.components) {
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(settingComponent.getOpacity() * alpha));
            settingComponent.getVisibilityAnimation().update(settingComponent.getSetting().isVisible() ? 1.0f : 0.0f);
            settingComponent.setX(x);
            settingComponent.setY((float)((double)(y + settingsY + offset) - this.scrollHandler.getValue()));
            settingComponent.setWidth(width);
            if (GuiUtility.isHovered((double)x, (double)(y - settingComponent.getHeight()), (double)width, (double)(height + settingComponent.getHeight()), settingComponent.getX(), settingComponent.getY())) {
                context.pushMatrix();
                context.method_51448().method_46416(0.0f, (-settingComponent.getHeight() + settingComponent.getHeight() * settingComponent.getOpacity()) / 2.0f, 0.0f);
                settingComponent.render(context);
                context.popMatrix();
            }
            offset += settingComponent.getHeight() * settingComponent.getOpacity();
        }
        ScissorUtility.pop();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        this.height = Math.min(200.0f, offset + 28.0f + 5.0f);
        this.scrollHandler.setMax(-offset + height - 24.0f - 4.0f - 5.0f);
        if (!this.showing || !check) {
            RenderUtility.end(context.method_51448());
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        for (MenuSettingComponent component : this.components) {
            if (component.getOpacity() == 0.0f || !this.isHovered(mouseX, mouseY) && button == MouseButton.LEFT) continue;
            component.onMouseClicked(mouseX, mouseY, button);
        }
        if (GuiUtility.isHovered((double)this.x, (double)(this.y + 24.0f) - this.scrollHandler.getValue(), (double)this.width, 18.0, mouseX, mouseY) && button == MouseButton.LEFT) {
            this.toggle.getElement().setShowing(!this.toggle.getElement().isShowing());
            Experiment.getInstance().getFileManager().writeFile("client");
        }
        if (GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, 24.0, mouseX, mouseY)) {
            this.drag = true;
            this.dragX = (float)(mouseX - (double)this.x);
            this.dragY = (float)(mouseY - (double)this.y);
        }
        if (GuiUtility.isHovered((double)(this.x + this.width - 17.0f), (double)(this.y + 9.0f), 8.0, 8.0, mouseX, mouseY)) {
            this.showing = false;
        }
        super.onMouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (MenuSettingComponent component : this.components) {
            if (component.getOpacity() == 0.0f) continue;
            component.onMouseReleased(mouseX, mouseY, button);
        }
        this.drag = false;
        super.onMouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void onScroll(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (MenuSettingComponent component : this.components) {
            if (component.getOpacity() == 0.0f) continue;
            component.onScroll(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        if (this.isHovered(mouseX, mouseY)) {
            this.scrollHandler.scroll(verticalAmount);
        }
        super.onScroll(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void onKeyPressed(int keyCode, int scanCode, int modifiers) {
        for (MenuSettingComponent component : this.components) {
            if (component.getOpacity() == 0.0f) continue;
            component.onKeyPressed(keyCode, scanCode, modifiers);
        }
        super.onKeyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        for (MenuSettingComponent component : this.components) {
            if (component.getOpacity() == 0.0f) continue;
            component.charTyped(chr, modifiers);
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public float getHeight() {
        float offset = 18.0f;
        for (MenuSettingComponent settingComponent : this.components) {
            offset += settingComponent.getHeight() * settingComponent.getOpacity();
        }
        this.height = Math.min(200.0f, offset + 28.0f + 5.0f);
        return this.height;
    }

    public HudToggle getToggle() {
        return this.toggle;
    }

    public List<MenuSettingComponent> getComponents() {
        return this.components;
    }

    public Animation getAnimation() {
        return this.animation;
    }

    public boolean isShowing() {
        return this.showing;
    }

    public void setShowing(boolean showing) {
        this.showing = showing;
    }
}

