/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.visuals.components;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.framework.objects.gradient.impl.VerticalGradient;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.menu.visuals.VisualsScreen;
import micronix.experiment.ui.menu.visuals.components.VisualSettings;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.gui.GuiUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class VisualToggle {
    private final Module module;
    private final Animation toggleAnimation = new Animation(300L, Easing.BAKEK);
    private final Animation hoverAnimation = new Animation(200L, Easing.LINEAR);
    private float x;
    private float y;
    private float width;
    private float height;

    public VisualToggle(Module module) {
        this.module = module;
    }

    public void set(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void render(UIContext context, float alpha) {
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        this.toggleAnimation.update(this.module.isEnabled());
        boolean hovered = GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, context.getMouseX(), context.getMouseY());
        this.hoverAnimation.update(hovered);
        ColorRGBA bgColor = this.module.isEnabled() ? new ColorRGBA(30.0f, 25.0f, 40.0f).withAlpha(200.0f * alpha) : new ColorRGBA(25.0f, 25.0f, 30.0f).withAlpha(150.0f * alpha);
        if (this.hoverAnimation.getValue() > 0.0f) {
            bgColor = bgColor.mix(new ColorRGBA(255.0f, 255.0f, 255.0f).withAlpha(20.0f), this.hoverAnimation.getValue());
        }
        context.drawRoundedRect(this.x, this.y, this.width, this.height, BorderRadius.all(12.0f), bgColor);
        if (this.module.isEnabled()) {
            context.drawRoundedRect(this.x, this.y, this.width, this.height, BorderRadius.all(12.0f), new VerticalGradient(new ColorRGBA(30.0f, 30.0f, 100.0f).withAlpha(60.0f * alpha), new ColorRGBA(30.0f, 20.0f, 140.0f).withAlpha(80.0f * alpha)));
        }
        context.drawText(Fonts.MEDIUM.getFont(8.0f), Localizator.translate(this.module.getName()), this.x + 10.0f, this.y + this.height / 2.0f - 3.5f, Colors.WHITE.withAlpha(255.0f * alpha));
        float switchWidth = 28.0f;
        float switchHeight = 14.0f;
        float switchX = this.x + this.width - switchWidth - 10.0f;
        float switchY = this.y + this.height / 2.0f - switchHeight / 2.0f;
        if (this.module.isEnabled()) {
            context.drawRoundedRect(switchX, switchY, switchWidth, switchHeight, BorderRadius.all(switchHeight / 2.0f), new VerticalGradient(new ColorRGBA(140.0f, 80.0f, 240.0f).withAlpha(255.0f * alpha), new ColorRGBA(100.0f, 50.0f, 200.0f).withAlpha(255.0f * alpha)));
        } else {
            context.drawRoundedRect(switchX, switchY, switchWidth, switchHeight, BorderRadius.all(switchHeight / 2.0f), new ColorRGBA(50.0f, 50.0f, 60.0f).withAlpha(255.0f * alpha));
        }
        float knobSize = 10.0f;
        float knobPadding = 2.0f;
        float knobX = switchX + knobPadding + (switchWidth - knobSize - knobPadding * 2.0f) * this.toggleAnimation.getValue();
        float knobY = switchY + (switchHeight - knobSize) / 2.0f;
        context.drawRoundedRect(knobX, knobY, knobSize, knobSize, BorderRadius.all(knobSize / 2.0f), Colors.WHITE.withAlpha(255.0f * alpha));
    }

    public void onMouseClicked(double mouseX, double mouseY, MouseButton button, VisualsScreen screen) {
        if (button == MouseButton.LEFT) {
            this.module.toggle();
        } else if (button == MouseButton.RIGHT && this.module.getSettings().size() > 0) {
            VisualSettings settings = new VisualSettings(this, screen.getMenuWindow().getX() + screen.getMenuWindow().getWidth() + 10.0f, screen.getMenuWindow().getY(), 200.0f);
            screen.getWindows().add(settings);
        }
    }

    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, mouseX, mouseY);
    }

    public Module getModule() {
        return this.module;
    }

    public Animation getToggleAnimation() {
        return this.toggleAnimation;
    }

    public Animation getHoverAnimation() {
        return this.hoverAnimation;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }
}

