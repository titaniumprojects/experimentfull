/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.visuals.components;

import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.ui.menu.api.MenuCategory;
import micronix.experiment.ui.menu.visuals.components.HudToggle;
import micronix.experiment.ui.menu.visuals.components.VisualToggle;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class VisualCategory {
    private final String name;
    private final MenuCategory menuCategory;
    private final List<VisualToggle> toggles = new ArrayList<VisualToggle>();
    private final List<HudToggle> hudToggles = new ArrayList<HudToggle>();
    private final Animation selectedAnimation = new Animation(300L, Easing.BAKEK);

    public VisualCategory(String name, MenuCategory menuCategory) {
        this.name = name;
        this.menuCategory = menuCategory;
    }

    public void init() {
        this.toggles.clear();
        this.hudToggles.clear();
        if (this.menuCategory != null) {
            for (Module module : Experiment.getInstance().getModuleManager().getModules()) {
                if (module.getCategory() != this.menuCategory.getCategory() || module.isHidden()) continue;
                this.toggles.add(new VisualToggle(module));
            }
        } else if (this.name.equals("HUD")) {
            for (HudElement element : Experiment.getInstance().getHud().getElements()) {
                this.hudToggles.add(new HudToggle(element));
            }
        } else if (this.name.equals("Utilities")) {
            // empty if block
        }
    }

    public boolean isHudCategory() {
        return this.name.equals("HUD");
    }

    public String getName() {
        return this.name;
    }

    public List<VisualToggle> getToggles() {
        return this.toggles;
    }

    public List<HudToggle> getHudToggles() {
        return this.hudToggles;
    }

    public Animation getSelectedAnimation() {
        return this.selectedAnimation;
    }

    public MenuCategory getMenuCategory() {
        return this.menuCategory;
    }
}

