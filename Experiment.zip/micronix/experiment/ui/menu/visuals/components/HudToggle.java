/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.visuals.components;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.framework.objects.gradient.impl.VerticalGradient;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.hud.HudElement;
import micronix.experiment.ui.menu.visuals.VisualsScreen;
import micronix.experiment.ui.menu.visuals.components.HudSettings;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.interfaces.IScaledResolution;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class HudToggle {
    private final HudElement element;
    private final Animation toggleAnimation = new Animation(300L, Easing.BAKEK);
    private final Animation hoverAnimation = new Animation(200L, Easing.LINEAR);
    private float x;
    private float y;
    private float width;
    private float height;

    public HudToggle(HudElement element) {
        this.element = element;
    }

    public void set(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void render(UIContext context, float alpha) {
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        this.toggleAnimation.update(this.element.isShowing());
        boolean hovered = GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, context.getMouseX(), context.getMouseY());
        this.hoverAnimation.update(hovered);
        ColorRGBA bgColor = this.element.isShowing() ? new ColorRGBA(30.0f, 25.0f, 40.0f).withAlpha(200.0f * alpha) : new ColorRGBA(25.0f, 25.0f, 30.0f).withAlpha(150.0f * alpha);
        if (this.hoverAnimation.getValue() > 0.0f) {
            bgColor = bgColor.mix(new ColorRGBA(255.0f, 255.0f, 255.0f).withAlpha(20.0f), this.hoverAnimation.getValue());
        }
        context.drawRoundedRect(this.x, this.y, this.width, this.height, BorderRadius.all(12.0f), bgColor);
        if (this.element.isShowing()) {
            context.drawRoundedRect(this.x, this.y, this.width, this.height, BorderRadius.all(12.0f), new VerticalGradient(new ColorRGBA(30.0f, 30.0f, 100.0f).withAlpha(60.0f * alpha), new ColorRGBA(30.0f, 20.0f, 140.0f).withAlpha(80.0f * alpha)));
        }
        if (this.element.getIcon() != null && !this.element.getIcon().isEmpty()) {
            context.drawTexture(Experiment.id(this.element.getIcon()), this.x + 10.0f, this.y + this.height / 2.0f - 6.0f, 12.0f, 12.0f, Colors.WHITE.withAlpha(255.0f * alpha));
        }
        float textX = this.element.getIcon() != null && !this.element.getIcon().isEmpty() ? this.x + 28.0f : this.x + 10.0f;
        context.drawText(Fonts.MEDIUM.getFont(8.0f), Localizator.translate(this.element.getName()), textX, this.y + this.height / 2.0f - 3.5f, Colors.WHITE.withAlpha(255.0f * alpha));
        float switchWidth = 28.0f;
        float switchHeight = 14.0f;
        float switchX = this.x + this.width - switchWidth - 10.0f;
        float switchY = this.y + this.height / 2.0f - switchHeight / 2.0f;
        if (this.element.isShowing()) {
            context.drawRoundedRect(switchX, switchY, switchWidth, switchHeight, BorderRadius.all(switchHeight / 2.0f), new VerticalGradient(new ColorRGBA(140.0f, 80.0f, 240.0f).withAlpha(255.0f * alpha), new ColorRGBA(100.0f, 50.0f, 200.0f).withAlpha(255.0f * alpha)));
        } else {
            context.drawRoundedRect(switchX, switchY, switchWidth, switchHeight, BorderRadius.all(switchHeight / 2.0f), new ColorRGBA(50.0f, 50.0f, 60.0f).withAlpha(255.0f * alpha));
        }
        float knobSize = 10.0f;
        float knobPadding = 2.0f;
        float knobX = switchX + knobPadding + (switchWidth - knobSize - knobPadding * 2.0f) * this.toggleAnimation.getValue();
        float knobY = switchY + (switchHeight - knobSize) / 2.0f;
        context.drawRoundedRect(knobX, knobY, knobSize, knobSize, BorderRadius.all(knobSize / 2.0f), Colors.WHITE.withAlpha(255.0f * alpha));
    }

    public void onMouseClicked(double mouseX, double mouseY, MouseButton button, VisualsScreen screen) {
        if (button == MouseButton.LEFT) {
            boolean wasShowing = this.element.isShowing();
            this.element.setShowing(!wasShowing);
            if (!wasShowing && this.element.isShowing()) {
                int showingCount = 0;
                for (HudElement el : Experiment.getInstance().getHud().getElements()) {
                    if (!el.isShowing() || el == this.element) continue;
                    ++showingCount;
                }
                float baseX = IScaledResolution.sr.getScaledWidth() / 2.0f - this.element.getWidth() / 2.0f;
                float baseY = IScaledResolution.sr.getScaledHeight() / 2.0f - this.element.getHeight() / 2.0f;
                float offsetX = (float)(showingCount % 3) * 50.0f - 50.0f;
                float offsetY = (float)(showingCount / 3) * 50.0f;
                this.element.pos(baseX + offsetX, baseY + offsetY);
            }
            Experiment.getInstance().getFileManager().writeFile("client");
        } else if (button == MouseButton.RIGHT && !this.element.getSettings().isEmpty()) {
            HudSettings settings = new HudSettings(this, screen.getMenuWindow().getX() + screen.getMenuWindow().getWidth() + 10.0f, screen.getMenuWindow().getY(), 200.0f);
            screen.getHudWindows().add(settings);
        }
    }

    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return GuiUtility.isHovered((double)this.x, (double)this.y, (double)this.width, (double)this.height, mouseX, mouseY);
    }

    public HudElement getElement() {
        return this.element;
    }

    public Animation getToggleAnimation() {
        return this.toggleAnimation;
    }

    public Animation getHoverAnimation() {
        return this.hoverAnimation;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }
}

