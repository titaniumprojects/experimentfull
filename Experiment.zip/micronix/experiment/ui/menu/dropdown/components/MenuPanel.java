/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.dropdown.components;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.modules.modules.visuals.Interface;
import micronix.experiment.systems.theme.Theme;
import micronix.experiment.ui.components.textfield.TextField;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.ui.menu.api.MenuCategory;
import micronix.experiment.ui.menu.dropdown.DropDownScreen;
import micronix.experiment.ui.menu.dropdown.components.module.ModuleComponent;
import micronix.experiment.ui.menu.dropdown.components.settings.MenuSettingComponent;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.gui.ScrollHandler;
import micronix.experiment.utility.interfaces.IScaledResolution;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.ScissorUtility;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class MenuPanel
extends CustomComponent
implements IScaledResolution {
    private final MenuCategory category;
    private final Animation swapping = new Animation(500L, Easing.BAKEK_PAGES);
    private final Animation sizing = new Animation(500L, Easing.BAKEK_SMALLER);
    private final List<ModuleComponent> moduleComponents = new ArrayList<ModuleComponent>();
    private final ScrollHandler modulesScroll = new ScrollHandler();
    private final ScrollHandler settingsScroll = new ScrollHandler();
    private Font titleFont;
    private ModuleComponent lastSelected;
    private ModuleComponent selectedModuleComponent;

    public MenuPanel(MenuCategory category) {
        this.category = category;
    }

    @Override
    public void onInit() {
        List<Module> filteredModules = Experiment.getInstance().getModuleManager().getModules().stream().sorted(Comparator.comparing(Module::getName)).filter(module -> module.getCategory().equals((Object)this.category.getCategory())).toList();
        for (Module module2 : filteredModules) {
            ModuleComponent component = new ModuleComponent(module2, this);
            component.setWidth(this.width);
            component.setHeight(23.0f);
            this.moduleComponents.add(component);
            component.onInit();
        }
        this.titleFont = Fonts.SYSTEMDLC.getFont(8.0f);
        this.modulesScroll.reset();
        this.settingsScroll.reset();
        super.onInit();
    }

    @Override
    public void update(UIContext context) {
        super.update(context);
    }

    private void updateScale(UIContext context) {
        if (Interface.glassSelected()) {
            this.sizing.setEasing(Easing.BAKEK_MANY);
        } else {
            this.sizing.setEasing(Easing.BAKEK_SMALLER);
        }
        this.sizing.setDuration(500L);
        this.sizing.update(Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f : (Math.abs(sr.getScaledWidth() / 2.0f - this.x) / 1500.0f * 3.0f < Experiment.getInstance().getMenuScreen().getMenuAnimation().getValue() ? 1.0f : 0.0f));
    }

    public void scale(UIContext context) {
        if (Interface.glassSelected()) {
            RenderUtility.scale(context.method_51448(), sr.getScaledWidth() / 2.0f, this.y + this.height / 2.0f, 2.0f - this.sizing.getValue());
        } else {
            RenderUtility.scale(context.method_51448(), this.x + this.width / 2.0f, this.y + this.height / 2.0f, 2.0f - this.sizing.getValue());
        }
    }

    public void renderBackground(UIContext context) {
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? Experiment.getInstance().getMenuScreen().getMenuAnimation().getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        this.scale(context);
        context.drawRoundedRect(this.x + 1.0f, this.y + 1.0f, this.width - 2.0f, this.height - 2.0f, BorderRadius.all(10.0f), Colors.getBackgroundColor().withAlpha(235.0f * (Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK ? 0.55f : 0.7f)));
        RenderUtility.end(context.method_51448());
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void renderShadow(UIContext context) {
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? Experiment.getInstance().getMenuScreen().getMenuAnimation().getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        this.scale(context);
        context.drawShadow(this.x, this.y, this.width, this.height, 25.0f, BorderRadius.all(10.0f), ColorRGBA.BLACK.withAlpha(51.0f));
        RenderUtility.end(context.method_51448());
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void renderBlur(UIContext context) {
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f - this.sizing.getValue() : this.sizing.getValue();
        this.scale(context);
        context.drawShadow(this.x - 1.5f, this.y - 1.5f, this.width + 3.0f, this.height + 3.0f, 12.0f, BorderRadius.all(5.0f), ColorRGBA.BLACK.withAlpha(40.0f * alpha));
        if (Interface.showMinimalizm()) {
            context.drawBlurredRect(this.x, this.y, this.width, this.height, 45.0f, 10.0f, BorderRadius.all(5.0f), ColorRGBA.WHITE.withAlpha(255.0f * alpha));
            context.drawRoundedBorder(this.x, this.y, this.width, this.height, 0.0f, BorderRadius.all(5.0f), ColorRGBA.WHITE.withAlpha(80.0f * alpha));
        }
        if (Interface.showGlass()) {
            context.drawLiquidGlass(this.x, this.y, this.width, this.height, 10.0f, 0.08f, BorderRadius.all(5.0f), ColorRGBA.WHITE.withAlpha(255.0f * alpha));
        }
        RenderUtility.end(context.method_51448());
    }

    public void push(UIContext context) {
        float headerHeight = 24.0f;
        float separatorHeight = 4.0f;
        float offset = Interface.glass() * 2.0f;
        if (this.selectedModuleComponent != null) {
            ScissorUtility.push(context.method_51448(), this.x + offset, this.y + headerHeight * 2.0f + separatorHeight + offset, this.width - offset * 2.0f, this.height - headerHeight * 2.0f - separatorHeight - 0.5f - offset * 2.0f);
        } else {
            ScissorUtility.push(context.method_51448(), this.x + offset, this.y + headerHeight + separatorHeight + offset, this.width - offset * 2.0f, this.height - headerHeight - separatorHeight - 0.5f - offset * 2.0f);
        }
    }

    @Override
    protected void renderComponent(UIContext context) {
        float x;
        this.modulesScroll.update();
        this.settingsScroll.update();
        float headerHeight = 24.0f;
        this.updateScale(context);
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f - this.sizing.getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        this.scale(context);
        boolean dark = Experiment.getInstance().getThemeManager().getCurrentTheme() == Theme.DARK;
        context.drawSquircle(this.x, this.y, this.width, this.height, 10.0f, BorderRadius.all(5.0f), Colors.getBackgroundColor().withAlpha(200.0f * (dark ? 0.95f - 0.65f * Interface.glass() : 0.8f)));
        float separatorHeight = 4.0f;
        float titleLeftPadding = 22.0f;
        float titleHeight = this.titleFont.height();
        context.drawText(this.titleFont, this.category.getName(), this.x + titleLeftPadding, this.y + GuiUtility.getMiddleOfBox(titleHeight, headerHeight) + 0.5f, Colors.getTextColor());
        float lineY = this.y + headerHeight + separatorHeight / 2.0f - 0.5f;
        float lineWidth = this.width - 20.0f;
        float lineX = this.x + 10.0f;
        float lineAlpha = Math.min(1.0f, alpha * 1.2f);
        float expandProgress = Math.min(1.0f, alpha * 1.5f);
        float currentLineWidth = lineWidth * expandProgress;
        float currentLineX = lineX + (lineWidth - currentLineWidth) / 2.0f;
        context.drawRoundedRect(currentLineX, lineY, currentLineWidth, 1.0f, BorderRadius.all(0.5f), Colors.getTextColor().withAlpha(40.0f * lineAlpha));
        if (this.selectedModuleComponent != null) {
            this.lastSelected = this.selectedModuleComponent;
        }
        this.swapping.update(this.selectedModuleComponent != null ? 1.0f : 0.0f);
        if (this.swapping.getValue() != 1.0f) {
            x = this.x + -this.width * this.swapping.getValue();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(alpha * (1.0f - this.swapping.getValue())));
            ScissorUtility.push(context.method_51448(), this.x, this.y + headerHeight + separatorHeight, this.width, this.height - headerHeight - separatorHeight - 0.5f);
            float offset = 0.0f;
            for (ModuleComponent moduleComponent : this.moduleComponents) {
                if (this.searchCheck(moduleComponent)) continue;
                moduleComponent.setX(x);
                moduleComponent.setY((float)((double)(this.y + offset) - this.modulesScroll.getValue()) + headerHeight + separatorHeight - 1.0f);
                moduleComponent.render(context);
                this.modulesScroll.setMax(-(offset += moduleComponent.getHeight()) + this.height - headerHeight - separatorHeight);
            }
            ScissorUtility.pop();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        }
        if (this.swapping.getValue() != 0.0f) {
            x = this.x + this.width * (1.0f - this.swapping.getValue());
            float y = this.y + headerHeight + separatorHeight;
            float leftPadding = 6.0f;
            float arrowIconSize = 8.0f;
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(alpha * this.swapping.getValue()));
            ScissorUtility.push(context.method_51448(), this.x, this.y, this.width, this.height);
            if (GuiUtility.isHovered((double)x, (double)(this.y + 28.0f), (double)this.width, 20.0, context.getMouseX(), context.getMouseY())) {
                CursorUtility.set(CursorType.HAND);
            }
            context.drawTexture(Experiment.id("icons/arrow.png"), x + leftPadding, y + GuiUtility.getMiddleOfBox(arrowIconSize, headerHeight) - 2.0f, arrowIconSize, arrowIconSize, Colors.getTextColor());
            context.drawText(Fonts.REGULAR.getFont(8.0f), this.lastSelected.getModule().getName(), x + arrowIconSize + 8.0f, y + GuiUtility.getMiddleOfBox(arrowIconSize, headerHeight) - 1.0f, Colors.getTextColor().withAlpha(255.0f));
            ScissorUtility.pop();
            ScissorUtility.push(context.method_51448(), this.x, y + headerHeight, this.width, this.height - headerHeight * 2.0f - separatorHeight - 0.5f - Interface.glass() * 5.0f);
            float settingsY = y + headerHeight;
            float offset = 0.0f;
            for (MenuSettingComponent<?> settingComponent : this.lastSelected.getSettingComponents()) {
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(settingComponent.getOpacity() * this.swapping.getValue()));
                settingComponent.getVisibilityAnimation().update(settingComponent.getSetting().isVisible() ? 1.0f : 0.0f);
                settingComponent.setX(x);
                settingComponent.setY((float)((double)(settingsY + offset) - this.settingsScroll.getValue()));
                settingComponent.setWidth(this.width);
                context.pushMatrix();
                context.method_51448().method_46416(0.0f, (-settingComponent.getHeight() + settingComponent.getHeight() * settingComponent.getOpacity()) / 2.0f, 0.0f);
                settingComponent.render(context);
                context.popMatrix();
                offset += settingComponent.getHeight() * settingComponent.getOpacity();
            }
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
            this.settingsScroll.setMax(-offset + this.height - headerHeight * 2.0f - separatorHeight - (float)(Interface.glassSelected() ? 5 : 0));
            ScissorUtility.pop();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        }
        RenderUtility.end(context.method_51448());
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void drawHoverBackgrounds(UIContext context) {
        float headerHeight = 24.0f;
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f - this.sizing.getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        float separatorHeight = 4.0f;
        if (this.selectedModuleComponent != null) {
            this.lastSelected = this.selectedModuleComponent;
        }
        if (this.swapping.getValue() != 1.0f) {
            float x = this.x + -this.width * this.swapping.getValue();
            for (ModuleComponent moduleComponent : this.moduleComponents) {
                if (this.searchCheck(moduleComponent) || !GuiUtility.isHovered((double)x, (double)this.y, (double)this.width, (double)this.height, moduleComponent.getX(), moduleComponent.getY()) && !GuiUtility.isHovered((double)x, (double)this.y, (double)this.width, (double)this.height, moduleComponent.getX(), moduleComponent.getY() + moduleComponent.getHeight()) || !(moduleComponent.getHoverAnimation().getValue() > 0.01f)) continue;
                context.drawRoundedRect(moduleComponent.getX() + 3.0f, moduleComponent.getY() + 1.5f, moduleComponent.getWidth() - 6.0f, moduleComponent.getHeaderHeight() - 3.0f, BorderRadius.all(5.0f), Colors.getTextColor().withAlpha(RenderSystem.getShaderColor()[3] * 255.0f * 0.06f * moduleComponent.getHoverAnimation().getValue()));
                context.drawRoundedBorder(moduleComponent.getX() + 3.0f, moduleComponent.getY() + 1.5f, moduleComponent.getWidth() - 6.0f, moduleComponent.getHeaderHeight() - 3.0f, 0.01f, BorderRadius.all(5.0f), new ColorRGBA(255.0f, 255.0f, 255.0f).withAlpha(RenderSystem.getShaderColor()[3] * 255.0f * 0.06f * moduleComponent.getHoverAnimation().getValue()));
            }
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void drawRegular8(UIContext context) {
        float x;
        float headerHeight = 24.0f;
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f - this.sizing.getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        float separatorHeight = 4.0f;
        if (this.selectedModuleComponent != null) {
            this.lastSelected = this.selectedModuleComponent;
        }
        if (this.swapping.getValue() != 1.0f) {
            x = this.x + -this.width * this.swapping.getValue();
            for (ModuleComponent moduleComponent : this.moduleComponents) {
                if (this.searchCheck(moduleComponent) || !GuiUtility.isHovered((double)x, (double)this.y, (double)this.width, (double)this.height, moduleComponent.getX(), moduleComponent.getY()) && !GuiUtility.isHovered((double)x, (double)this.y, (double)this.width, (double)this.height, moduleComponent.getX(), moduleComponent.getY() + moduleComponent.getHeight())) continue;
                moduleComponent.drawRegular8(context);
            }
        }
        if (this.swapping.getValue() != 0.0f) {
            x = this.x + this.width * (1.0f - this.swapping.getValue());
            float y = this.y + headerHeight + separatorHeight;
            for (MenuSettingComponent<?> settingComponent : this.lastSelected.getSettingComponents()) {
                if (!settingComponent.getSetting().isVisible() || !GuiUtility.isHovered((double)x, (double)y, (double)this.width, (double)this.height, settingComponent.getX(), settingComponent.getY()) && !GuiUtility.isHovered((double)x, (double)y, (double)this.width, (double)this.height, settingComponent.getX(), settingComponent.getY() + settingComponent.getHeight())) continue;
                settingComponent.drawRegular8(context);
            }
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void drawIcons(UIContext context) {
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f - this.sizing.getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        if (this.selectedModuleComponent != null) {
            this.lastSelected = this.selectedModuleComponent;
        }
        if (this.swapping.getValue() != 1.0f) {
            float x = this.x + -this.width * this.swapping.getValue();
            for (ModuleComponent moduleComponent : this.moduleComponents) {
                if (this.searchCheck(moduleComponent) || !GuiUtility.isHovered((double)x, (double)this.y, (double)this.width, (double)this.height, moduleComponent.getX(), moduleComponent.getY()) && !GuiUtility.isHovered((double)x, (double)this.y, (double)this.width, (double)this.height, moduleComponent.getX(), moduleComponent.getY() + moduleComponent.getHeight())) continue;
                moduleComponent.drawIcons(context);
            }
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void drawType(UIContext context) {
        float headerHeight = 24.0f;
        float alpha = Experiment.getInstance().getMenuScreen().isClosing() ? 2.0f - this.sizing.getValue() : this.sizing.getValue();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        this.scale(context);
        float iconScale = 9.0f;
        float rightPadding = 10.0f;
        float iconX = this.x + 8.0f;
        float iconY = this.y + GuiUtility.getMiddleOfBox(iconScale, headerHeight) + 0.5f;
        context.drawSprite(this.category.getMenuSprite(), iconX, iconY, iconScale, iconScale, Colors.getAccentColor().withAlpha(255.0f * alpha * 0.85f));
        RenderUtility.end(context.method_51448());
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public void drawSplit(UIContext context) {
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        block5: {
            block4: {
                float y;
                if (this.selectedModuleComponent == null) break block4;
                if (GuiUtility.isHovered((double)this.x, (double)(this.y + 52.0f), (double)this.width, (double)(this.height - 52.0f), mouseX, mouseY)) {
                    for (MenuSettingComponent<?> settingComponent : this.selectedModuleComponent.getSettingComponents()) {
                        if (!settingComponent.getSetting().isVisible()) continue;
                        settingComponent.onMouseClicked(mouseX, mouseY, button);
                    }
                }
                if (!GuiUtility.isHovered((double)this.x, (double)(y = this.y + 28.0f), (double)this.width, 20.0, mouseX, mouseY) || button != MouseButton.LEFT) break block5;
                this.selectedModuleComponent = null;
                if (!Experiment.getInstance().getModuleManager().getModule(Sounds.class).isEnabled()) break block5;
                ClientSounds.CLICKGUI_OPEN.play(0.8f, 1.2f);
                break block5;
            }
            if (GuiUtility.isHovered((double)this.x, (double)(this.y + 28.0f), (double)this.width, (double)(this.height - 28.0f), mouseX, mouseY)) {
                for (ModuleComponent moduleComponent : this.moduleComponents) {
                    if (this.searchCheck(moduleComponent)) continue;
                    moduleComponent.onMouseClicked(mouseX, mouseY, button);
                }
            }
        }
        super.onMouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        if (this.selectedModuleComponent != null) {
            for (MenuSettingComponent<?> settingComponent : this.selectedModuleComponent.getSettingComponents()) {
                if (!settingComponent.getSetting().isVisible()) continue;
                settingComponent.onMouseReleased(mouseX, mouseY, button);
            }
        } else {
            for (ModuleComponent moduleComponent : this.moduleComponents) {
                moduleComponent.onMouseReleased(mouseX, mouseY, button);
            }
        }
        super.onMouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void onKeyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.isHovered(GuiUtility.getMouse().method_32118(), GuiUtility.getMouse().method_32119())) {
            if (this.selectedModuleComponent != null) {
                this.settingsScroll.onKeyPressed(keyCode);
            } else {
                this.modulesScroll.onKeyPressed(keyCode);
            }
        }
        if (this.selectedModuleComponent != null) {
            for (MenuSettingComponent<?> settingComponent : this.selectedModuleComponent.getSettingComponents()) {
                if (!settingComponent.getSetting().isVisible()) continue;
                settingComponent.onKeyPressed(keyCode, scanCode, modifiers);
            }
        } else {
            for (ModuleComponent moduleComponent : this.moduleComponents) {
                moduleComponent.onKeyPressed(keyCode, scanCode, modifiers);
            }
        }
        super.onKeyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (this.selectedModuleComponent != null) {
            for (MenuSettingComponent<?> settingComponent : this.selectedModuleComponent.getSettingComponents()) {
                if (!settingComponent.getSetting().isVisible()) continue;
                settingComponent.charTyped(chr, modifiers);
            }
        }
        return super.charTyped(chr, modifiers);
    }

    private boolean searchCheck(ModuleComponent component) {
        MenuScreen menuScreen = Experiment.getInstance().getMenuScreen();
        if (menuScreen instanceof DropDownScreen) {
            DropDownScreen dropDownScreen = (DropDownScreen)menuScreen;
            TextField search = dropDownScreen.getSearchField();
            return search != null && !search.getBuiltText().isBlank() && !component.getModule().getName().toLowerCase().contains(search.getBuiltText().toLowerCase()) && !component.getModule().getName().replace(" ", "").toLowerCase().contains(search.getBuiltText().toLowerCase());
        }
        return false;
    }

    @Override
    public void onScroll(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.isHovered(mouseX, mouseY)) {
            if (this.selectedModuleComponent != null) {
                this.settingsScroll.scroll(verticalAmount);
            } else {
                this.modulesScroll.scroll(verticalAmount);
            }
        }
    }

    public MenuCategory getCategory() {
        return this.category;
    }

    public Animation getSwapping() {
        return this.swapping;
    }

    public Animation getSizing() {
        return this.sizing;
    }

    public List<ModuleComponent> getModuleComponents() {
        return this.moduleComponents;
    }

    public ScrollHandler getModulesScroll() {
        return this.modulesScroll;
    }

    public ScrollHandler getSettingsScroll() {
        return this.settingsScroll;
    }

    public Font getTitleFont() {
        return this.titleFont;
    }

    public ModuleComponent getLastSelected() {
        return this.lastSelected;
    }

    public ModuleComponent getSelectedModuleComponent() {
        return this.selectedModuleComponent;
    }

    public void setTitleFont(Font titleFont) {
        this.titleFont = titleFont;
    }

    public void setLastSelected(ModuleComponent lastSelected) {
        this.lastSelected = lastSelected;
    }

    public void setSelectedModuleComponent(ModuleComponent selectedModuleComponent) {
        this.selectedModuleComponent = selectedModuleComponent;
    }
}

