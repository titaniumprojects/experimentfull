/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.dropdown.components.module;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.modules.Module;
import micronix.experiment.systems.modules.modules.other.Sounds;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.ui.menu.MenuScreen;
import micronix.experiment.ui.menu.dropdown.DropDownScreen;
import micronix.experiment.ui.menu.dropdown.components.MenuPanel;
import micronix.experiment.ui.menu.dropdown.components.settings.MenuSettingComponent;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.animation.types.ColorAnimation;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.TextUtility;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.penis.PenisPlayer;
import micronix.experiment.utility.sounds.ClientSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ModuleComponent
extends CustomComponent {
    private final Module module;
    private final MenuPanel parent;
    private final Animation hoverAnimation = new Animation(200L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation enableAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation shakeAnimation = new Animation(100L, Easing.FIGMA_EASE_IN_OUT);
    private final Animation blockingAnimation = new Animation(500L, Easing.FIGMA_EASE_IN_OUT);
    private final ColorAnimation blockingColorAnimation = new ColorAnimation(500L, ColorRGBA.WHITE, Easing.FIGMA_EASE_IN_OUT);
    private boolean blocking;
    private boolean shakeValue;
    private final PenisPlayer enablePenis;
    private final PenisPlayer disablePenis;
    private PenisPlayer currentPenis;
    private boolean lastModuleState;
    private Font nameFont;
    private float headerHeight;
    private final List<MenuSettingComponent<?>> settingComponents = new ArrayList();
    private boolean bindingMode;

    public ModuleComponent(Module module, MenuPanel parent) {
        this.module = module;
        this.parent = parent;
        this.enablePenis = new PenisPlayer(Experiment.id("penises/check_enable.penis"));
        this.disablePenis = new PenisPlayer(Experiment.id("penises/check_disable.penis"));
        this.lastModuleState = module.isEnabled();
        this.currentPenis = this.lastModuleState ? this.enablePenis : this.disablePenis;
        PenisPlayer penisPlayer = this.currentPenis;
        if (this.lastModuleState) {
            this.enablePenis.playOnce();
            this.currentPenis = this.enablePenis;
        } else {
            this.disablePenis.setFrame(0);
            this.disablePenis.stop();
            this.currentPenis = this.disablePenis;
        }
    }

    @Override
    public void onInit() {
        this.nameFont = Fonts.REGULAR.getFont(9.0f);
        this.headerHeight = 23.0f;
        this.settingComponents.clear();
        for (Setting setting : this.module.getSettings()) {
            MenuSettingComponent settingComponent = GuiUtility.settinge(setting, this);
            if (settingComponent == null) continue;
            this.settingComponents.add(settingComponent);
        }
        this.settingComponents.forEach(MenuSettingComponent::onInit);
        for (MenuSettingComponent menuSettingComponent : this.settingComponents) {
            menuSettingComponent.getVisibilityAnimation().setValue(menuSettingComponent.getSetting().isVisible() ? 1.0f : 0.0f);
        }
        super.onInit();
    }

    @Override
    protected void renderComponent(UIContext context) {
        this.enableAnimation.update(this.module.isEnabled() ? 1.0f : 0.0f);
        boolean currentState = this.module.isEnabled();
        if (currentState != this.lastModuleState) {
            this.currentPenis = currentState ? this.enablePenis : this.disablePenis;
            this.currentPenis.playOnce();
            this.lastModuleState = currentState;
        }
        this.currentPenis.update();
        this.blockingAnimation.update(this.blocking);
        this.blockingColorAnimation.update(this.blocking ? new ColorRGBA(255.0f, 150.0f, 150.0f) : Experiment.getInstance().getThemeManager().getCurrentTheme().getTextColor());
        this.shakeAnimation.update(this.blocking ? (this.shakeValue ? 1.0f : -1.0f) : 0.0f);
        if (this.blockingAnimation.getValue() == 1.0f) {
            this.blocking = false;
        }
        if (this.shakeAnimation.getValue() == 1.0f) {
            this.shakeValue = false;
        }
        if (this.shakeAnimation.getValue() == -1.0f) {
            this.shakeValue = true;
        }
        if (this.parent.isHovered(context) && this.isHovered(context)) {
            CursorUtility.set(CursorType.HAND);
            MenuScreen menuScreen = Experiment.getInstance().getMenuScreen();
            if (menuScreen instanceof DropDownScreen) {
                DropDownScreen dropDownScreen = (DropDownScreen)menuScreen;
                dropDownScreen.setDesc(this.module.getDescription());
            }
        }
    }

    public void drawRegular8(UIContext context) {
        float nameLeftPadding = 11.0f + 2.0f * this.enableAnimation.getValue();
        float nameHeight = this.nameFont.height();
        int key = this.module.getKey();
        this.hoverAnimation.update(this.isHovered(context.getMouseX(), context.getMouseY()));
        String bindingText = key == -1 ? Localizator.translate("menu.binding") : Localizator.translate("key") + ": " + TextUtility.getKeyName(key);
        float textAlpha = RenderSystem.getShaderColor()[3] * 255.0f * (0.82f + 0.18f * this.enableAnimation.getValue() + 0.08f * this.hoverAnimation.getValue());
        float textScale = 1.0f + 0.02f * this.hoverAnimation.getValue();
        context.pushMatrix();
        context.method_51448().method_46416(this.x + nameLeftPadding + this.shakeAnimation.getValue(), this.y + GuiUtility.getMiddleOfBox(nameHeight, this.headerHeight) - 0.5f, 0.0f);
        context.method_51448().method_22905(textScale, textScale, 1.0f);
        context.drawText(this.nameFont, this.bindingMode && this.parent.getSelectedModuleComponent() == null ? bindingText : this.module.getName(), 0.0f, 0.0f, this.blockingColorAnimation.getColor().withAlpha(textAlpha));
        context.popMatrix();
    }

    public void drawIcons(UIContext context) {
        float alpha = this.enableAnimation.getValue() * RenderSystem.getShaderColor()[3];
        if (this.enableAnimation.getValue() > 0.0f || this.currentPenis.isPlaying()) {
            float iconX = this.x + this.width - 16.0f - this.enableAnimation.getValue() * 1.5f;
            float iconY = this.y + 7.5f;
            float iconSize = 6.0f;
            if (this.enableAnimation.getValue() > 0.5f) {
                float glowAlpha = (this.enableAnimation.getValue() - 0.5f) * 2.0f * alpha * 0.3f;
                DrawUtility.drawAnimationSprite(context.method_51448(), this.currentPenis.getCurrentSprite(), iconX - 1.0f, iconY - 1.0f, iconSize + 2.0f, iconSize + 2.0f, Colors.getTextColor().mulAlpha(glowAlpha));
            }
            DrawUtility.drawAnimationSprite(context.method_51448(), this.currentPenis.getCurrentSprite(), iconX, iconY, iconSize, iconSize, Colors.getTextColor().mulAlpha(0.2f + 0.8f * alpha));
        }
    }

    public void drawSplit(UIContext context) {
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (!this.isHovered(mouseX, mouseY)) {
            return;
        }
        if (this.bindingMode && button != MouseButton.LEFT && button != MouseButton.RIGHT) {
            this.module.setKey(button.getButtonIndex());
            this.bindingMode = false;
            return;
        }
        switch (button) {
            case LEFT: {
                this.module.toggle();
                break;
            }
            case MIDDLE: {
                for (ModuleComponent comp : this.parent.getModuleComponents()) {
                    comp.setBindingMode(false);
                }
                this.bindingMode = true;
                break;
            }
            case RIGHT: {
                this.open();
            }
        }
        super.onMouseClicked(mouseX, mouseY, button);
    }

    public void open() {
        if (this.module.getSettings().isEmpty()) {
            if (Experiment.getInstance().getModuleManager().getModule(Sounds.class).isEnabled() && !this.blocking) {
                ClientSounds.CRITICAL.play(1.0f, 1.0f);
            }
            this.blocking = true;
            this.shakeValue = true;
        } else {
            this.parent.setSelectedModuleComponent(this);
            this.onInit();
            if (Experiment.getInstance().getModuleManager().getModule(Sounds.class).isEnabled()) {
                ClientSounds.CLICKGUI_OPEN.play(0.8f, 1.3f);
            }
        }
    }

    @Override
    public void onKeyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.bindingMode) {
            if (keyCode == 256 || keyCode == 261) {
                this.module.setKey(-1);
            } else {
                this.module.setKey(keyCode);
            }
            this.bindingMode = false;
            MenuScreen menuScreen = Experiment.getInstance().getMenuScreen();
            if (menuScreen instanceof DropDownScreen) {
                DropDownScreen dropDownScreen = (DropDownScreen)menuScreen;
                dropDownScreen.getSearchField().setFocused(false);
            }
        }
        super.onKeyPressed(keyCode, scanCode, modifiers);
    }

    public Module getModule() {
        return this.module;
    }

    public MenuPanel getParent() {
        return this.parent;
    }

    public Animation getHoverAnimation() {
        return this.hoverAnimation;
    }

    public Animation getEnableAnimation() {
        return this.enableAnimation;
    }

    public Animation getShakeAnimation() {
        return this.shakeAnimation;
    }

    public Animation getBlockingAnimation() {
        return this.blockingAnimation;
    }

    public ColorAnimation getBlockingColorAnimation() {
        return this.blockingColorAnimation;
    }

    public boolean isBlocking() {
        return this.blocking;
    }

    public boolean isShakeValue() {
        return this.shakeValue;
    }

    public PenisPlayer getEnablePenis() {
        return this.enablePenis;
    }

    public PenisPlayer getDisablePenis() {
        return this.disablePenis;
    }

    public PenisPlayer getCurrentPenis() {
        return this.currentPenis;
    }

    public boolean isLastModuleState() {
        return this.lastModuleState;
    }

    public Font getNameFont() {
        return this.nameFont;
    }

    public float getHeaderHeight() {
        return this.headerHeight;
    }

    public List<MenuSettingComponent<?>> getSettingComponents() {
        return this.settingComponents;
    }

    public boolean isBindingMode() {
        return this.bindingMode;
    }

    public void setBindingMode(boolean bindingMode) {
        this.bindingMode = bindingMode;
    }
}

