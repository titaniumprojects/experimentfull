/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.dropdown.components.settings;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.setting.Setting;
import micronix.experiment.ui.components.popup.Popup;
import micronix.experiment.ui.menu.dropdown.DropDownScreen;
import micronix.experiment.ui.menu.dropdown.components.module.ModuleComponent;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public abstract class MenuSettingComponent<T extends Setting>
extends CustomComponent {
    private final CustomComponent parent;
    protected final T setting;
    private final Animation visibilityAnimation = new Animation(300L, Easing.BAKEK_PAGES);
    protected final Animation hoverAnimation = new Animation(300L, Easing.FIGMA_EASE_IN_OUT);

    public MenuSettingComponent(T setting, CustomComponent parent) {
        this.parent = parent;
        this.setting = setting;
    }

    @Override
    public void update(UIContext context) {
        ModuleComponent component;
        String translatedDescription = Localizator.translateOrEmpty(this.setting.getDescription());
        CustomComponent customComponent = this.parent;
        if (customComponent instanceof ModuleComponent && ((component = (ModuleComponent)customComponent).getParent().isHovered(context) && this.isHovered(context) || Experiment.getInstance().getMenuScreen() instanceof DropDownScreen)) {
            ((DropDownScreen)Experiment.getInstance().getMenuScreen()).setDesc(Localizator.translate(translatedDescription));
        }
        if (this.parent instanceof Popup && this.isHovered(context)) {
            Experiment.getInstance().getHud().setDesc(Localizator.translate(translatedDescription));
        }
        super.update(context);
    }

    @Override
    public void onInit() {
        super.onInit();
    }

    public float getOpacity() {
        return this.visibilityAnimation.getValue();
    }

    public void drawRegular8(UIContext context) {
    }

    public void drawSplit(UIContext context) {
    }

    public CustomComponent getParent() {
        return this.parent;
    }

    public T getSetting() {
        return this.setting;
    }

    public Animation getVisibilityAnimation() {
        return this.visibilityAnimation;
    }

    public Animation getHoverAnimation() {
        return this.hoverAnimation;
    }
}

