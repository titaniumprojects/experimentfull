/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.menu.dropdown.components.settings.impl;

import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomComponent;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.systems.localization.Localizator;
import micronix.experiment.systems.setting.settings.ModeSetting;
import micronix.experiment.ui.menu.dropdown.components.settings.MenuSettingComponent;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.cursor.CursorType;
import micronix.experiment.utility.game.cursor.CursorUtility;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.penis.PenisPlayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class ModeSettingComponent
extends MenuSettingComponent<ModeSetting> {
    private boolean initialized;

    public ModeSettingComponent(ModeSetting setting, CustomComponent parent) {
        super(setting, parent);
    }

    @Override
    protected void renderComponent(UIContext context) {
        if (!this.initialized) {
            for (ModeSetting.Value value : ((ModeSetting)this.setting).getValues()) {
                value.setEnablePenis(new PenisPlayer(Experiment.id("penises/check_enable.penis")));
                value.setDisablePenis(new PenisPlayer(Experiment.id("penises/check_disable.penis")));
                value.setLastState(value.isSelected());
                value.setCurrentPenis(value.isLastState() ? value.getEnablePenis() : value.getDisablePenis());
                if (value.isLastState()) {
                    value.getEnablePenis().playOnce();
                    continue;
                }
                value.getDisablePenis().setFrame(0);
                value.getDisablePenis().stop();
            }
            this.initialized = true;
        }
        float x = this.x + 9.0f;
        float y = this.y + 1.0f;
        float width = this.width - 18.0f;
        Font nameFont = Fonts.REGULAR.getFont(8.0f);
        float leftPadding = 10.0f;
        float headerHeight = 19.0f;
        this.hoverAnimation.update(this.isHovered(context.getMouseX(), context.getMouseY()));
        context.drawFadeoutText(nameFont, Localizator.translate(((ModeSetting)this.getSetting()).getName()), this.x + leftPadding, y - 1.0f + GuiUtility.getMiddleOfBox(nameFont.height(), headerHeight), Colors.getTextColor().withAlpha(255.0f * (0.75f + 0.25f * this.hoverAnimation.getValue())), 0.8f, 1.0f, this.getParent().getWidth() - leftPadding);
        context.drawRoundedRect(x - 1.0f, y + 17.0f, width + 2.0f, (float)(8 + ((ModeSetting)this.setting).getValues().size() * 12), BorderRadius.all(6.0f), Colors.getBackgroundColor().withAlpha(76.5f));
        float offset = 0.0f;
        for (ModeSetting.Value value : ((ModeSetting)this.setting).getValues()) {
            if (value.isHidden()) continue;
            boolean currentState = value.isSelected();
            if (currentState != value.isLastState()) {
                if (currentState) {
                    value.setCurrentPenis(value.getEnablePenis());
                } else {
                    value.setCurrentPenis(value.getDisablePenis());
                }
                value.getCurrentPenis().playOnce();
                value.setLastState(currentState);
            }
            value.getCurrentPenis().update();
            boolean hover = GuiUtility.isHovered((double)(x - 1.0f), (double)(y + 20.0f + offset), (double)(width + 2.0f), 12.0, context.getMouseX(), context.getMouseY());
            if (hover) {
                CursorUtility.set(CursorType.HAND);
            }
            value.getHoverAnimation().update(hover);
            value.getActiveAnimation().update(value.isSelected());
            context.drawFadeoutText(Fonts.REGULAR.getFont(7.0f), Localizator.translate(value.getName()), x + 7.0f, y + 24.5f + offset, Colors.getTextColor().withAlpha(255.0f * (0.75f + 0.25f * value.getHoverAnimation().getValue() + 0.25f * value.getActiveAnimation().getValue())), 0.8f, 1.0f, width - 12.0f - value.getActiveAnimation().getValue() * 10.0f);
            if (value.getActiveAnimation().getValue() > 0.0f || value.getCurrentPenis().isPlaying()) {
                DrawUtility.drawAnimationSprite(context.method_51448(), value.getCurrentPenis().getCurrentSprite(), x + width - 11.0f - value.getActiveAnimation().getValue() * 2.0f, y + 24.0f + offset, 6.0f, 6.0f, Colors.getTextColor().mulAlpha(0.1f + 0.9f * value.getActiveAnimation().getValue()));
            }
            offset += 12.0f;
        }
    }

    @Override
    public void drawSplit(UIContext context) {
        float separatorHeight = 0.5f;
        context.drawRect(this.x, this.y + this.height, this.width, separatorHeight, Colors.getTextColor().withAlpha(5.1f));
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (button != MouseButton.LEFT) {
            return;
        }
        float offset = 0.0f;
        for (ModeSetting.Value value : ((ModeSetting)this.setting).getValues()) {
            if (value.isHidden()) continue;
            boolean hover = GuiUtility.isHovered((double)(this.x - 1.0f), (double)(this.y + 20.0f + offset), (double)(this.width - 2.0f), 12.0, mouseX, mouseY);
            if (hover) {
                value.select();
            }
            offset += 12.0f;
        }
        super.onMouseClicked(mouseX, mouseY, button);
    }

    @Override
    public float getHeight() {
        this.height = 31 + ((ModeSetting)this.setting).getValues().size() * 12;
        return this.height;
    }
}

