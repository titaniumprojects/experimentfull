/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1068
 *  net.minecraft.class_241
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 */
package micronix.experiment.ui.account;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import micronix.experiment.Experiment;
import micronix.experiment.framework.base.CustomScreen;
import micronix.experiment.framework.base.UIContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.framework.objects.MouseButton;
import micronix.experiment.framework.objects.gradient.impl.VerticalGradient;
import micronix.experiment.ui.account.Account;
import micronix.experiment.ui.account.AccountManager;
import micronix.experiment.utility.animation.base.Animation;
import micronix.experiment.utility.animation.base.Easing;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.render.DrawUtility;
import micronix.experiment.utility.render.RenderUtility;
import micronix.experiment.utility.render.obj.Rect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1068;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Environment(value=EnvType.CLIENT)
public class AccountSwitcherScreen
extends CustomScreen {
    private final Animation openAnim = new Animation(400L, 0.0f, Easing.FIGMA_EASE_IN_OUT);
    private boolean usernameSelected = false;
    private boolean searchSelected = false;
    private float scrollOffset = 0.0f;
    private float targetScroll = 0.0f;
    private float maxScroll = 0.0f;
    private float[] hoverAnimations;
    private float[] favoriteAnimations;
    private float[] activeAnimations;
    private float[] starHoverAnimations;
    private float[] deleteHoverAnimations;
    private static final ColorRGBA STAR_YELLOW = new ColorRGBA(255.0f, 200.0f, 50.0f);
    private static final ColorRGBA STAR_GRAY = new ColorRGBA(120.0f, 120.0f, 120.0f);
    private static final ColorRGBA ACCENT_BLUE = new ColorRGBA(220.0f, 50.0f, 50.0f);
    private static final ColorRGBA ACCENT_GREEN = new ColorRGBA(80.0f, 200.0f, 120.0f);
    private static final ColorRGBA DELETE_RED = new ColorRGBA(255.0f, 80.0f, 80.0f);
    private static final ColorRGBA PANEL_BG = new ColorRGBA(22.0f, 22.0f, 22.0f);
    private static final ColorRGBA CARD_BG = new ColorRGBA(32.0f, 32.0f, 32.0f);
    private static final ColorRGBA CARD_HOVER = new ColorRGBA(52.0f, 32.0f, 32.0f);
    private static final ColorRGBA CARD_ACTIVE = new ColorRGBA(150.0f, 50.0f, 50.0f);
    private static final ColorRGBA SELECTION_BG = new ColorRGBA(255.0f, 90.0f, 90.0f, 100.0f);
    private final class_437 parent;
    private final AccountManager manager;
    private String searchQuery = "";
    private boolean focusedSearch = false;
    private boolean addingAccount = false;
    private String usernameInput = "";
    private boolean focusedUsername = false;

    public AccountSwitcherScreen(class_437 parent, AccountManager manager) {
        this.parent = parent;
        this.manager = manager;
        this.initAnimationArrays();
    }

    private void initAnimationArrays() {
        int maxAccounts = Math.max(50, this.manager.getAccounts().size() + 20);
        this.hoverAnimations = new float[maxAccounts];
        this.favoriteAnimations = new float[maxAccounts];
        this.activeAnimations = new float[maxAccounts];
        this.starHoverAnimations = new float[maxAccounts];
        this.deleteHoverAnimations = new float[maxAccounts];
    }

    protected void method_25426() {
        this.openAnim.setValue(0.0f);
        this.initAnimationArrays();
        super.method_25426();
    }

    private List<Account> getSortedAccounts() {
        ArrayList<Account> filtered = new ArrayList<Account>();
        for (Account acc : this.manager.getAccounts()) {
            if (!this.searchQuery.isEmpty() && !acc.getUsername().toLowerCase().contains(this.searchQuery.toLowerCase())) continue;
            filtered.add(acc);
        }
        filtered.sort(Comparator.comparing(Account::isFavorite, Comparator.reverseOrder()).thenComparing(Account::getLastUsed, Comparator.reverseOrder()).thenComparing(Account::getUsername));
        return filtered;
    }

    private float lerp(float current, float target, float speed) {
        return current + (target - current) * speed;
    }

    private ColorRGBA lerpColor(ColorRGBA from, ColorRGBA to, float t) {
        return new ColorRGBA((int)(from.getRed() + (to.getRed() - from.getRed()) * t), (int)(from.getGreen() + (to.getGreen() - from.getGreen()) * t), (int)(from.getBlue() + (to.getBlue() - from.getBlue()) * t), (int)(from.getAlpha() + (to.getAlpha() - from.getAlpha()) * t));
    }

    private void drawTextWithSelection(UIContext context, Font font, String text, float x, float y, float alpha, boolean selected, boolean focused) {
        if (selected && !text.isEmpty()) {
            float textWidth = font.width(text);
            context.drawRoundedRect(x - 2.0f, y - 2.0f, textWidth + 4.0f, font.height() + 4.0f, BorderRadius.all(3.0f), SELECTION_BG.withAlpha(alpha));
        }
        Object displayText = text;
        if (focused && !selected) {
            displayText = text + "_";
        }
        ColorRGBA textColor = text.isEmpty() ? new ColorRGBA(100.0f, 100.0f, 110.0f, alpha) : ColorRGBA.WHITE.withAlpha(alpha);
        context.drawText(font, (String)displayText, x, y, textColor);
    }

    @Override
    public void render(UIContext context) {
        this.openAnim.update(true);
        Font titleFont = Fonts.ROUND_BOLD.getFont(26.0f);
        Font subtitleFont = Fonts.REGULAR.getFont(13.0f);
        Font textFont = Fonts.REGULAR.getFont(14.0f);
        Font smallFont = Fonts.REGULAR.getFont(12.0f);
        Font iconFont = Fonts.ROUND_BOLD.getFont(18.0f);
        Font starFont = Fonts.ROUND_BOLD.getFont(18.0f);
        float alpha = 255.0f * this.openAnim.getValue();
        float panelW = 400.0f;
        float panelH = 500.0f;
        float x = (float)this.field_22789 / 2.0f - panelW / 2.0f;
        float y = (float)this.field_22790 / 2.0f - panelH / 2.0f;
        ColorRGBA accent = Colors.getAccentColor();
        ColorRGBA darker = new ColorRGBA(accent.getRed() * 0.5f, accent.getGreen() * 0.5f, accent.getBlue() * 0.5f, accent.getAlpha());
        Rect bgRect = new Rect((float)(-this.field_22789) / 2.0f, (float)(-this.field_22789) / 3.0f, (float)this.field_22789 * 1.5f, this.field_22789);
        context.drawRoundedRect(0.0f, 0.0f, (float)this.field_22789, (float)this.field_22790, BorderRadius.ZERO, new VerticalGradient(darker, new ColorRGBA(0.0f, 0.0f, 0.0f)));
        RenderUtility.scale(context.method_51448(), (float)this.field_22789 / 2.0f, (float)this.field_22790 / 2.0f, 1.1f);
        context.drawTexture(Experiment.id("image/mainmenu/background.png"), bgRect.getX(), bgRect.getY(), bgRect.getWidth(), bgRect.getHeight());
        RenderUtility.end(context.method_51448());
        context.drawRoundedRect(0.0f, 0.0f, (float)this.field_22789, (float)this.field_22790, BorderRadius.ZERO, new ColorRGBA(0.0f, 0.0f, 0.0f, (int)(150.0f * this.openAnim.getValue())));
        DrawUtility.blurProgram.draw();
        context.drawRoundedRect(x, y, panelW, panelH, BorderRadius.all(16.0f), PANEL_BG.withAlpha(alpha * 0.95f));
        context.drawRoundedRect(x, y, panelW, 70.0f, new BorderRadius(16.0f, 16.0f, 0.0f, 0.0f), new VerticalGradient(ACCENT_BLUE.withAlpha(alpha * 0.35f), ACCENT_BLUE.withAlpha(alpha * 0.05f)));
        context.drawRoundedRect(x, y + 69.0f, panelW, 1.0f, BorderRadius.ZERO, new ColorRGBA(255.0f, 255.0f, 255.0f, alpha * 0.08f));
        context.drawText(titleFont, "Account Manager", x + 20.0f, y + 16.0f, ColorRGBA.WHITE.withAlpha(alpha));
        int accountCount = this.manager.getAccounts().size();
        int favoriteCount = (int)this.manager.getAccounts().stream().filter(Account::isFavorite).count();
        String statsText = accountCount + " account" + (accountCount != 1 ? "s" : "");
        if (favoriteCount > 0) {
            statsText = statsText + "  \u00b7  " + favoriteCount + " favorite" + (favoriteCount != 1 ? "s" : "");
        }
        context.drawText(subtitleFont, statsText, x + 20.0f, y + 45.0f, new ColorRGBA(160.0f, 160.0f, 170.0f, alpha));
        float searchY = y + 85.0f;
        Rect searchField = new Rect(x + 16.0f, searchY, panelW - 32.0f, 38.0f);
        boolean searchHovered = searchField.hovered(context.getMouseX(), context.getMouseY());
        ColorRGBA searchBg = this.focusedSearch ? new ColorRGBA(45.0f, 45.0f, 55.0f, alpha) : (searchHovered ? new ColorRGBA(40.0f, 40.0f, 50.0f, alpha) : new ColorRGBA(35.0f, 35.0f, 45.0f, alpha));
        context.drawRoundedRect(searchField.getX(), searchField.getY(), searchField.getWidth(), searchField.getHeight(), BorderRadius.all(10.0f), searchBg);
        if (this.focusedSearch) {
            context.drawRoundedRect(searchField.getX(), searchField.getY(), searchField.getWidth(), searchField.getHeight(), BorderRadius.all(10.0f), ACCENT_BLUE.withAlpha(alpha * 0.3f));
        }
        context.drawText(smallFont, "Q", searchField.getX() + 14.0f, searchField.getY() + 12.0f, new ColorRGBA(100.0f, 100.0f, 110.0f, alpha));
        if (this.searchQuery.isEmpty()) {
            context.drawText(textFont, "Search accounts...", searchField.getX() + 36.0f, searchField.getY() + 11.0f, new ColorRGBA(100.0f, 100.0f, 110.0f, alpha));
        } else {
            this.drawTextWithSelection(context, textFont, this.searchQuery, searchField.getX() + 36.0f, searchField.getY() + 11.0f, alpha, this.searchSelected, this.focusedSearch);
        }
        float contentOffsetY = y + 135.0f;
        float contentHeight = panelH - 210.0f;
        this.scrollOffset = this.lerp(this.scrollOffset, this.targetScroll, 0.15f);
        List<Account> sortedAccounts = this.getSortedAccounts();
        float offsetY = contentOffsetY - this.scrollOffset;
        float cardHeight = 60.0f;
        float cardSpacing = 8.0f;
        if (sortedAccounts.isEmpty()) {
            String emptyText = this.searchQuery.isEmpty() ? "No accounts yet" : "No accounts found";
            context.drawCenteredText(subtitleFont, emptyText, x + panelW / 2.0f, contentOffsetY + contentHeight / 2.0f - 10.0f, new ColorRGBA(100.0f, 100.0f, 110.0f, alpha));
        }
        for (int i = 0; i < sortedAccounts.size(); ++i) {
            Account acc = sortedAccounts.get(i);
            if (i >= this.hoverAnimations.length) break;
            float cardX = x + 16.0f;
            float cardW = panelW - 32.0f;
            if (offsetY + cardHeight >= contentOffsetY - 10.0f && offsetY <= contentOffsetY + contentHeight + 10.0f) {
                boolean inViewport = offsetY >= contentOffsetY - cardHeight && offsetY <= contentOffsetY + contentHeight;
                boolean hovered = inViewport && (float)context.getMouseX() >= cardX && (float)context.getMouseX() <= cardX + cardW && (float)context.getMouseY() >= Math.max(offsetY, contentOffsetY) && (float)context.getMouseY() <= Math.min(offsetY + cardHeight, contentOffsetY + contentHeight);
                boolean active = this.manager.getCurrent() == acc;
                boolean favorite = acc.isFavorite();
                this.hoverAnimations[i] = this.lerp(this.hoverAnimations[i], hovered ? 1.0f : 0.0f, 0.2f);
                this.favoriteAnimations[i] = this.lerp(this.favoriteAnimations[i], favorite ? 1.0f : 0.0f, 0.15f);
                this.activeAnimations[i] = this.lerp(this.activeAnimations[i], active ? 1.0f : 0.0f, 0.15f);
                float starBtnX = cardX + cardW - 75.0f;
                float starBtnY = offsetY + (cardHeight - 24.0f) / 2.0f;
                boolean starHovered = inViewport && (float)context.getMouseX() >= starBtnX && (float)context.getMouseX() <= starBtnX + 28.0f && (float)context.getMouseY() >= Math.max(starBtnY, contentOffsetY) && (float)context.getMouseY() <= Math.min(starBtnY + 24.0f, contentOffsetY + contentHeight);
                this.starHoverAnimations[i] = this.lerp(this.starHoverAnimations[i], starHovered ? 1.0f : 0.0f, 0.25f);
                float deleteBtnX = cardX + cardW - 40.0f;
                float deleteBtnY = offsetY + (cardHeight - 24.0f) / 2.0f;
                boolean deleteHovered = inViewport && (float)context.getMouseX() >= deleteBtnX && (float)context.getMouseX() <= deleteBtnX + 28.0f && (float)context.getMouseY() >= Math.max(deleteBtnY, contentOffsetY) && (float)context.getMouseY() <= Math.min(deleteBtnY + 24.0f, contentOffsetY + contentHeight);
                this.deleteHoverAnimations[i] = this.lerp(this.deleteHoverAnimations[i], deleteHovered ? 1.0f : 0.0f, 0.25f);
                float visibleTop = Math.max(offsetY, contentOffsetY);
                float visibleBottom = Math.min(offsetY + cardHeight, contentOffsetY + contentHeight);
                if (visibleBottom > visibleTop) {
                    float scale = 1.0f + this.hoverAnimations[i] * 0.02f + this.activeAnimations[i] * 0.02f;
                    RenderUtility.scale(context.method_51448(), cardX + cardW / 2.0f, offsetY + cardHeight / 2.0f, scale);
                    ColorRGBA baseBg = this.lerpColor(CARD_BG.withAlpha(alpha), CARD_HOVER.withAlpha(alpha), this.hoverAnimations[i]);
                    ColorRGBA cardBg = this.lerpColor(baseBg, CARD_ACTIVE.withAlpha(alpha), this.activeAnimations[i]);
                    context.drawRoundedRect(cardX, offsetY, cardW, cardHeight, BorderRadius.all(10.0f), cardBg);
                    if (favorite) {
                        ColorRGBA stripColor = this.lerpColor(STAR_YELLOW.withAlpha(alpha * 0.5f), STAR_YELLOW.withAlpha(alpha * 0.9f), this.favoriteAnimations[i]);
                        context.drawRoundedRect(cardX, offsetY, 4.0f, cardHeight, new BorderRadius(10.0f, 0.0f, 0.0f, 10.0f), stripColor);
                    }
                    float avatarSize = 42.0f;
                    float avatarX = cardX + 12.0f;
                    float avatarY = offsetY + (cardHeight - avatarSize) / 2.0f;
                    try {
                        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + acc.getUsername()).getBytes(StandardCharsets.UTF_8));
                        class_2960 skin = class_1068.method_4649();
                        DrawUtility.drawRoundedTextureWithUV(context.method_51448(), skin, avatarX, avatarY, avatarSize, avatarSize, BorderRadius.all(8.0f), ColorRGBA.WHITE.withAlpha(alpha), 0.125f, 0.125f, 0.25f, 0.25f);
                        DrawUtility.drawRoundedTextureWithUV(context.method_51448(), skin, avatarX, avatarY, avatarSize, avatarSize, BorderRadius.all(8.0f), ColorRGBA.WHITE.withAlpha(alpha), 0.625f, 0.125f, 0.75f, 0.25f);
                    }
                    catch (Exception e) {
                        ColorRGBA avatarBg = active ? new ColorRGBA(255.0f, 255.0f, 255.0f, alpha * 0.2f) : new ColorRGBA(60.0f, 80.0f, 140.0f, alpha * 0.8f);
                        context.drawRoundedRect(avatarX, avatarY, avatarSize, avatarSize, BorderRadius.all(8.0f), avatarBg);
                        String initial = acc.getUsername().isEmpty() ? "?" : acc.getUsername().substring(0, 1).toUpperCase();
                        context.drawCenteredText(iconFont, initial, avatarX + avatarSize / 2.0f, avatarY + avatarSize / 2.0f - 9.0f, ColorRGBA.WHITE.withAlpha(alpha));
                    }
                    float textStartX = cardX + 66.0f;
                    float maxTextWidth = starBtnX - textStartX - 10.0f;
                    String username = acc.getUsername();
                    context.drawText(textFont, username, textStartX, offsetY + 15.0f, ColorRGBA.WHITE.withAlpha(alpha));
                    String status = active ? "Active" : this.getLastUsedText(acc.getLastUsed());
                    ColorRGBA statusColor = active ? ACCENT_GREEN.withAlpha(alpha) : new ColorRGBA(120.0f, 120.0f, 130.0f, alpha);
                    context.drawText(smallFont, status, textStartX, offsetY + 35.0f, statusColor);
                    ColorRGBA starColor = favorite ? STAR_YELLOW.withAlpha(alpha) : this.lerpColor(STAR_GRAY.withAlpha(alpha * 0.4f), STAR_GRAY.withAlpha(alpha * 0.9f), this.starHoverAnimations[i]);
                    float starCx = starBtnX + 14.0f;
                    float starCy = starBtnY + 12.0f;
                    float starSz = 6.0f;
                    if (favorite) {
                        DrawUtility.drawRoundedRect(context.method_51448(), starCx - starSz, starCy - starSz, starSz * 2.0f, starSz * 2.0f, BorderRadius.all(starSz), starColor);
                    } else {
                        DrawUtility.drawRoundedBorder(context.method_51448(), starCx - starSz, starCy - starSz, starSz * 2.0f, starSz * 2.0f, 2.0f, BorderRadius.all(starSz), starColor);
                    }
                    float deleteBgAlpha = this.deleteHoverAnimations[i] * alpha * 0.6f;
                    if (deleteBgAlpha > 1.0f) {
                        context.drawRoundedRect(deleteBtnX, deleteBtnY, 28.0f, 24.0f, BorderRadius.all(6.0f), DELETE_RED.withAlpha(deleteBgAlpha));
                    }
                    ColorRGBA deleteColor = this.lerpColor(new ColorRGBA(150.0f, 150.0f, 160.0f, alpha * 0.5f), DELETE_RED.withAlpha(alpha), this.deleteHoverAnimations[i]);
                    float delCx = deleteBtnX + 14.0f;
                    float delCy = deleteBtnY + 12.0f;
                    float delSz = 5.0f;
                    DrawUtility.drawLine(context.method_51448(), new class_241(delCx - delSz, delCy - delSz), new class_241(delCx + delSz, delCy + delSz), deleteColor);
                    DrawUtility.drawLine(context.method_51448(), new class_241(delCx + delSz, delCy - delSz), new class_241(delCx - delSz, delCy + delSz), deleteColor);
                    RenderUtility.end(context.method_51448());
                }
            }
            offsetY += cardHeight + cardSpacing;
        }
        context.drawRoundedRect(x, y + panelH - 75.0f, panelW, 75.0f, new BorderRadius(0.0f, 0.0f, 16.0f, 16.0f), PANEL_BG.withAlpha(alpha * 0.98f));
        context.drawRoundedRect(x, y + panelH - 75.0f, panelW, 1.0f, BorderRadius.ZERO, new ColorRGBA(255.0f, 255.0f, 255.0f, alpha * 0.05f));
        float addBtnY = y + panelH - 58.0f;
        Rect addBtn = new Rect(x + 16.0f, addBtnY, panelW - 32.0f, 44.0f);
        boolean addHovered = addBtn.hovered(context.getMouseX(), context.getMouseY());
        if (!this.addingAccount) {
            ColorRGBA btnColor = addHovered ? ACCENT_GREEN.withAlpha(alpha * 0.9f) : ACCENT_GREEN.withAlpha(alpha * 0.75f);
            ColorRGBA btnColorBottom = addHovered ? new ColorRGBA(50.0f, 170.0f, 90.0f, alpha * 0.9f) : new ColorRGBA(50.0f, 160.0f, 90.0f, alpha * 0.75f);
            context.drawRoundedRect(addBtn.getX(), addBtn.getY(), addBtn.getWidth(), addBtn.getHeight(), BorderRadius.all(10.0f), new VerticalGradient(btnColor, btnColorBottom));
            context.drawCenteredText(textFont, "+ Add New Account", addBtn.getX() + addBtn.getWidth() / 2.0f, addBtn.getY() + 15.0f, ColorRGBA.WHITE.withAlpha(alpha));
        }
        if (this.addingAccount) {
            this.renderAddAccountForm(context, alpha, textFont, smallFont);
        }
        this.maxScroll = Math.max(0.0f, (float)sortedAccounts.size() * (cardHeight + cardSpacing) - contentHeight + 10.0f);
        if (this.targetScroll > this.maxScroll) {
            this.targetScroll = this.maxScroll;
        }
    }

    private void renderAddAccountForm(UIContext context, float alpha, Font textFont, Font smallFont) {
        boolean canAdd;
        float formW = 340.0f;
        float formH = 170.0f;
        float formX = (float)this.field_22789 / 2.0f - formW / 2.0f;
        float formY = (float)this.field_22790 / 2.0f - formH / 2.0f;
        context.drawRoundedRect(0.0f, 0.0f, (float)this.field_22789, (float)this.field_22790, BorderRadius.ZERO, new ColorRGBA(0.0f, 0.0f, 0.0f, alpha * 0.6f));
        DrawUtility.blurProgram.draw();
        context.drawRoundedRect(formX, formY, formW, formH, BorderRadius.all(14.0f), PANEL_BG.withAlpha(alpha * 0.98f));
        context.drawRoundedRect(formX, formY, formW, 50.0f, new BorderRadius(14.0f, 14.0f, 0.0f, 0.0f), new VerticalGradient(ACCENT_BLUE.withAlpha(alpha * 0.25f), ACCENT_BLUE.withAlpha(alpha * 0.05f)));
        Font formTitle = Fonts.ROUND_BOLD.getFont(18.0f);
        context.drawCenteredText(formTitle, "Add New Account", formX + formW / 2.0f, formY + 16.0f, ColorRGBA.WHITE.withAlpha(alpha));
        float fieldW = formW - 32.0f;
        float randomBtnW = 70.0f;
        float inputW = fieldW - randomBtnW - 8.0f;
        Rect usernameField = new Rect(formX + 16.0f, formY + 60.0f, inputW, 42.0f);
        boolean fieldHovered = usernameField.hovered(context.getMouseX(), context.getMouseY());
        ColorRGBA fieldBg = this.focusedUsername ? new ColorRGBA(50.0f, 50.0f, 60.0f, alpha) : (fieldHovered ? new ColorRGBA(45.0f, 45.0f, 55.0f, alpha) : new ColorRGBA(38.0f, 38.0f, 48.0f, alpha));
        context.drawRoundedRect(usernameField.getX(), usernameField.getY(), usernameField.getWidth(), usernameField.getHeight(), BorderRadius.all(10.0f), fieldBg);
        if (this.focusedUsername) {
            context.drawRoundedRect(usernameField.getX(), usernameField.getY(), usernameField.getWidth(), usernameField.getHeight(), BorderRadius.all(10.0f), ACCENT_BLUE.withAlpha(alpha * 0.3f));
        }
        if (this.usernameInput.isEmpty()) {
            context.drawText(textFont, "Username...", usernameField.getX() + 10.0f, usernameField.getY() + 13.0f, new ColorRGBA(130.0f, 100.0f, 100.0f, alpha));
        } else {
            String display = this.usernameInput;
            if (textFont.width(display) > inputW - 20.0f) {
                while (display.length() > 0 && textFont.width(display + "...") > inputW - 20.0f) {
                    display = display.substring(1);
                }
            }
            this.drawTextWithSelection(context, textFont, display, usernameField.getX() + 10.0f, usernameField.getY() + 13.0f, alpha, this.usernameSelected, this.focusedUsername);
        }
        Rect randomBtn = new Rect(formX + 16.0f + inputW + 8.0f, formY + 60.0f, randomBtnW, 42.0f);
        boolean randomHovered = randomBtn.hovered(context.getMouseX(), context.getMouseY());
        ColorRGBA randomBg = randomHovered ? new ColorRGBA(60.0f, 60.0f, 70.0f, alpha) : new ColorRGBA(50.0f, 50.0f, 60.0f, alpha);
        context.drawRoundedRect(randomBtn.getX(), randomBtn.getY(), randomBtn.getWidth(), randomBtn.getHeight(), BorderRadius.all(10.0f), randomBg);
        context.drawCenteredText(textFont, "Rand", randomBtn.getX() + randomBtnW / 2.0f, randomBtn.getY() + 13.0f, ColorRGBA.WHITE.withAlpha(alpha));
        float buttonW = (formW - 48.0f) / 2.0f;
        float buttonY = formY + 118.0f;
        Rect addButton = new Rect(formX + 16.0f, buttonY, buttonW, 38.0f);
        boolean addHovered = addButton.hovered(context.getMouseX(), context.getMouseY());
        boolean bl = canAdd = !this.usernameInput.isEmpty();
        ColorRGBA addBtnColor = canAdd ? (addHovered ? ACCENT_BLUE.withAlpha(alpha * 0.95f) : ACCENT_BLUE.withAlpha(alpha * 0.8f)) : new ColorRGBA(60.0f, 60.0f, 70.0f, alpha * 0.6f);
        context.drawRoundedRect(addButton.getX(), addButton.getY(), addButton.getWidth(), addButton.getHeight(), BorderRadius.all(8.0f), addBtnColor);
        context.drawCenteredText(textFont, "Add", addButton.getX() + buttonW / 2.0f, addButton.getY() + 11.0f, ColorRGBA.WHITE.withAlpha(canAdd ? alpha : alpha * 0.5f));
        Rect cancelButton = new Rect(formX + 32.0f + buttonW, buttonY, buttonW, 38.0f);
        boolean cancelHovered = cancelButton.hovered(context.getMouseX(), context.getMouseY());
        context.drawRoundedRect(cancelButton.getX(), cancelButton.getY(), cancelButton.getWidth(), cancelButton.getHeight(), BorderRadius.all(8.0f), new ColorRGBA(55.0f, 55.0f, 65.0f, cancelHovered ? alpha * 0.95f : alpha * 0.75f));
        context.drawCenteredText(textFont, "Cancel", cancelButton.getX() + buttonW / 2.0f, cancelButton.getY() + 11.0f, ColorRGBA.WHITE.withAlpha(alpha));
    }

    private String getLastUsedText(long lastUsed) {
        if (lastUsed == 0L) {
            return "Never used";
        }
        long diff = System.currentTimeMillis() - lastUsed;
        long seconds = diff / 1000L;
        long minutes = seconds / 60L;
        long hours = minutes / 60L;
        long days = hours / 24L;
        if (days > 0L) {
            return days + "d ago";
        }
        if (hours > 0L) {
            return hours + "h ago";
        }
        if (minutes > 0L) {
            return minutes + "m ago";
        }
        return "Just now";
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (button != MouseButton.LEFT) {
            return;
        }
        float panelW = 400.0f;
        float panelH = 500.0f;
        float x = (float)this.field_22789 / 2.0f - panelW / 2.0f;
        float y = (float)this.field_22790 / 2.0f - panelH / 2.0f;
        if (this.addingAccount) {
            float formW = 340.0f;
            float formX = (float)this.field_22789 / 2.0f - formW / 2.0f;
            float formH = 170.0f;
            float formY = (float)this.field_22790 / 2.0f - formH / 2.0f;
            float fieldW = formW - 32.0f;
            float randomBtnW = 70.0f;
            float inputW = fieldW - randomBtnW - 8.0f;
            Rect usernameField = new Rect(formX + 16.0f, formY + 60.0f, inputW, 42.0f);
            if (usernameField.hovered(mouseX, mouseY)) {
                this.focusedUsername = true;
                this.usernameSelected = false;
                return;
            }
            Rect randomBtn = new Rect(formX + 16.0f + inputW + 8.0f, formY + 60.0f, randomBtnW, 42.0f);
            if (randomBtn.hovered(mouseX, mouseY)) {
                this.usernameInput = this.generateRandomName();
                this.focusedUsername = false;
                return;
            }
            float buttonY = formY + 118.0f;
            float buttonW = (formW - 48.0f) / 2.0f;
            Rect addButton = new Rect(formX + 16.0f, buttonY, buttonW, 38.0f);
            if (addButton.hovered(mouseX, mouseY)) {
                if (!this.usernameInput.isEmpty()) {
                    this.manager.addAccount(this.usernameInput);
                    this.addingAccount = false;
                    this.usernameInput = "";
                    this.focusedUsername = false;
                    this.usernameSelected = false;
                    this.initAnimationArrays();
                }
                return;
            }
            Rect cancelButton = new Rect(formX + 32.0f + buttonW, buttonY, buttonW, 38.0f);
            if (cancelButton.hovered(mouseX, mouseY)) {
                this.addingAccount = false;
                this.usernameInput = "";
                this.focusedUsername = false;
                this.usernameSelected = false;
                return;
            }
            this.focusedUsername = false;
            this.usernameSelected = false;
            return;
        }
        float searchY = y + 85.0f;
        Rect searchField = new Rect(x + 16.0f, searchY, panelW - 32.0f, 38.0f);
        if (searchField.hovered(mouseX, mouseY)) {
            this.focusedSearch = true;
            this.focusedUsername = false;
            this.searchSelected = false;
            return;
        }
        this.focusedSearch = false;
        this.searchSelected = false;
        float contentOffsetY = y + 135.0f;
        float contentHeight = panelH - 210.0f;
        float cardHeight = 60.0f;
        float cardSpacing = 8.0f;
        if (mouseY < (double)contentOffsetY || mouseY > (double)(contentOffsetY + contentHeight)) {
            float addBtnY = y + panelH - 58.0f;
            Rect addBtn = new Rect(x + 16.0f, addBtnY, panelW - 32.0f, 44.0f);
            if (addBtn.hovered(mouseX, mouseY) && !this.addingAccount) {
                this.addingAccount = true;
                this.focusedUsername = true;
                this.focusedSearch = false;
                this.usernameSelected = false;
                return;
            }
            return;
        }
        List<Account> sortedAccounts = this.getSortedAccounts();
        float offsetY = contentOffsetY - this.scrollOffset;
        for (Account acc : sortedAccounts) {
            float cardX = x + 16.0f;
            float cardW = panelW - 32.0f;
            if (offsetY + cardHeight >= contentOffsetY && offsetY <= contentOffsetY + contentHeight) {
                float starBtnX = cardX + cardW - 75.0f;
                float starBtnY = offsetY + (cardHeight - 24.0f) / 2.0f;
                if (mouseX >= (double)starBtnX && mouseX <= (double)(starBtnX + 28.0f) && mouseY >= (double)starBtnY && mouseY <= (double)(starBtnY + 24.0f)) {
                    this.manager.toggleFavorite(acc);
                    return;
                }
                float deleteBtnX = cardX + cardW - 40.0f;
                float deleteBtnY = offsetY + (cardHeight - 24.0f) / 2.0f;
                if (mouseX >= (double)deleteBtnX && mouseX <= (double)(deleteBtnX + 28.0f) && mouseY >= (double)deleteBtnY && mouseY <= (double)(deleteBtnY + 24.0f)) {
                    this.manager.removeAccount(acc);
                    return;
                }
                if (mouseX >= (double)cardX && mouseX <= (double)(cardX + cardW) && mouseY >= (double)offsetY && mouseY <= (double)(offsetY + cardHeight)) {
                    this.manager.select(acc);
                    return;
                }
            }
            offsetY += cardHeight + cardSpacing;
        }
        super.onMouseClicked(mouseX, mouseY, button);
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.addingAccount) {
            return false;
        }
        float scrollSpeed = 25.0f;
        this.targetScroll = (float)((double)this.targetScroll - verticalAmount * (double)scrollSpeed);
        this.targetScroll = Math.max(0.0f, Math.min(this.targetScroll, this.maxScroll));
        return true;
    }

    private String generateRandomName() {
        String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";
        StringBuilder sb = new StringBuilder();
        int length = 4 + (int)(Math.random() * 12.0);
        for (int i = 0; i < length; ++i) {
            sb.append(chars.charAt((int)(Math.random() * (double)chars.length())));
        }
        return sb.toString();
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        boolean ctrl;
        boolean bl = ctrl = (modifiers & 2) != 0;
        if (ctrl && keyCode == 86) {
            try {
                String clipboard = class_310.method_1551().field_1774.method_1460();
                if (clipboard != null && !clipboard.isEmpty()) {
                    if (this.addingAccount && this.focusedUsername) {
                        if (this.usernameSelected) {
                            this.usernameInput = clipboard;
                            this.usernameSelected = false;
                        } else {
                            this.usernameInput = this.usernameInput + clipboard;
                        }
                    } else if (this.focusedSearch) {
                        if (this.searchSelected) {
                            this.searchQuery = clipboard;
                            this.searchSelected = false;
                        } else {
                            this.searchQuery = this.searchQuery + clipboard;
                        }
                    }
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }
        if (ctrl && keyCode == 67) {
            if (this.addingAccount && this.focusedUsername && !this.usernameInput.isEmpty()) {
                class_310.method_1551().field_1774.method_1455(this.usernameInput);
            } else if (this.focusedSearch && !this.searchQuery.isEmpty()) {
                class_310.method_1551().field_1774.method_1455(this.searchQuery);
            }
            return true;
        }
        if (this.addingAccount && this.focusedUsername) {
            if (keyCode == 256) {
                this.addingAccount = false;
                this.usernameInput = "";
                this.focusedUsername = false;
                this.usernameSelected = false;
                return true;
            }
            if (ctrl && keyCode == 65) {
                if (!this.usernameInput.isEmpty()) {
                    this.usernameSelected = true;
                }
                return true;
            }
            if (keyCode == 257) {
                if (!this.usernameInput.isEmpty()) {
                    this.manager.addAccount(this.usernameInput);
                    this.addingAccount = false;
                    this.usernameInput = "";
                    this.focusedUsername = false;
                    this.usernameSelected = false;
                }
                return true;
            }
            if (keyCode == 259) {
                if (this.usernameSelected) {
                    this.usernameInput = "";
                    this.usernameSelected = false;
                } else if (!this.usernameInput.isEmpty()) {
                    this.usernameInput = this.usernameInput.substring(0, this.usernameInput.length() - 1);
                }
                return true;
            }
            return true;
        }
        if (this.focusedSearch) {
            if (keyCode == 256) {
                this.searchQuery = "";
                this.focusedSearch = false;
                this.searchSelected = false;
                return true;
            }
            if (ctrl && keyCode == 65) {
                if (!this.searchQuery.isEmpty()) {
                    this.searchSelected = true;
                }
                return true;
            }
            if (keyCode == 259) {
                if (this.searchSelected) {
                    this.searchQuery = "";
                    this.searchSelected = false;
                } else if (!this.searchQuery.isEmpty()) {
                    this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
                }
                return true;
            }
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25400(char chr, int modifiers) {
        if (this.addingAccount && this.focusedUsername) {
            if (this.usernameSelected) {
                this.usernameInput = String.valueOf(chr);
                this.usernameSelected = false;
            } else {
                this.usernameInput = this.usernameInput + chr;
            }
            return true;
        }
        if (this.focusedSearch) {
            if (this.searchSelected) {
                this.searchQuery = String.valueOf(chr);
                this.searchSelected = false;
            } else {
                this.searchQuery = this.searchQuery + chr;
            }
            this.targetScroll = 0.0f;
            return true;
        }
        return super.method_25400(chr, modifiers);
    }

    public boolean method_25422() {
        if (this.addingAccount) {
            this.addingAccount = false;
            this.usernameInput = "";
            this.focusedUsername = false;
            this.usernameSelected = false;
            return false;
        }
        if (this.focusedSearch) {
            this.searchQuery = "";
            this.focusedSearch = false;
            this.searchSelected = false;
            return false;
        }
        return true;
    }
}

