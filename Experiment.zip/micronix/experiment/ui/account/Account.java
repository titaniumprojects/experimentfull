/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package micronix.experiment.ui.account;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class Account {
    private String username;
    private boolean favorite;
    private long lastUsed;

    public Account(String username) {
        this.username = username;
        this.favorite = false;
        this.lastUsed = 0L;
    }

    public Account(String username, boolean favorite, long lastUsed) {
        this.username = username;
        this.favorite = favorite;
        this.lastUsed = lastUsed;
    }

    public String getUsername() {
        return this.username;
    }

    public boolean isFavorite() {
        return this.favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public long getLastUsed() {
        return this.lastUsed;
    }

    public void setLastUsed(long lastUsed) {
        this.lastUsed = lastUsed;
    }
}

