/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_2561
 *  net.minecraft.class_266
 *  net.minecraft.class_268
 *  net.minecraft.class_269
 *  net.minecraft.class_270
 *  net.minecraft.class_332
 *  net.minecraft.class_5250
 *  net.minecraft.class_5611
 *  net.minecraft.class_9011
 *  net.minecraft.class_9022
 *  net.minecraft.class_9025
 *  org.lwjgl.glfw.GLFW
 */
package micronix.experiment.ui.overlay;

import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.List;
import micronix.experiment.framework.base.CustomDrawContext;
import micronix.experiment.framework.msdf.Font;
import micronix.experiment.framework.msdf.Fonts;
import micronix.experiment.framework.objects.BorderRadius;
import micronix.experiment.utility.colors.ColorRGBA;
import micronix.experiment.utility.colors.Colors;
import micronix.experiment.utility.game.LegacyTextHelper;
import micronix.experiment.utility.gui.GuiUtility;
import micronix.experiment.utility.interfaces.IMinecraft;
import micronix.experiment.utility.interfaces.IScaledResolution;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_270;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_5611;
import net.minecraft.class_9011;
import net.minecraft.class_9022;
import net.minecraft.class_9025;
import org.lwjgl.glfw.GLFW;

@Environment(value=EnvType.CLIENT)
public class ScoreboardOverlay
implements IMinecraft,
IScaledResolution {
    private static final ScoreboardOverlay INSTANCE = new ScoreboardOverlay();
    private float x = -1.0f;
    private float y = -1.0f;
    private float width;
    private float height;
    private boolean dragging;
    private float dragOffsetX;
    private float dragOffsetY;
    private boolean wasMouseDown;

    public static ScoreboardOverlay getInstance() {
        return INSTANCE;
    }

    public void render(class_332 context, class_266 objective) {
        if (objective == null || ScoreboardOverlay.mc.field_1724 == null || ScoreboardOverlay.mc.field_1687 == null) {
            return;
        }
        class_269 scoreboard = objective.method_1117();
        List<class_9011> entries = scoreboard.method_1184(objective).stream().filter(entry -> entry != null && !entry.method_55385()).sorted(Comparator.comparingInt(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String::compareToIgnoreCase)).limit(15L).toList();
        Font titleFont = Fonts.MEDIUM.getFont(8.5f);
        Font lineFont = Fonts.REGULAR.getFont(7.5f);
        float padX = 10.0f;
        float padY = 6.0f;
        float lineGap = 4.0f;
        float valueGap = 10.0f;
        float shadowExpand = 5.0f;
        int defaultTextColor = Colors.getTextColor().getRGB() & 0xFFFFFF;
        class_2561 title = LegacyTextHelper.resolve(objective.method_1114(), defaultTextColor);
        float maxWidth = titleFont.width(title);
        for (class_9011 entry2 : entries) {
            class_2561 nameText = LegacyTextHelper.resolve(this.resolveNameText(scoreboard, entry2), defaultTextColor);
            class_2561 valueText = LegacyTextHelper.resolve(this.resolveValueText(objective, entry2), defaultTextColor);
            float rowWidth = lineFont.width(nameText) + lineFont.width(valueText) + valueGap;
            maxWidth = Math.max(maxWidth, rowWidth);
        }
        float headerHeight = titleFont.height() + padY * 2.0f;
        float lineHeight = lineFont.height() + lineGap;
        float totalHeight = headerHeight + (float)entries.size() * lineHeight + padY;
        float totalWidth = maxWidth + padX * 2.0f + 12.0f;
        this.updateDrag(totalWidth, totalHeight);
        float x = this.x;
        float y = this.y;
        this.width = totalWidth;
        this.height = totalHeight;
        CustomDrawContext drawContext = CustomDrawContext.of(context);
        drawContext.drawShadow(x - shadowExpand, y - shadowExpand, totalWidth + shadowExpand * 2.0f, totalHeight + shadowExpand * 2.0f, 15.0f, BorderRadius.all(6.0f), ColorRGBA.BLACK.withAlpha(60.0f));
        drawContext.drawClientRect(x, y, totalWidth, totalHeight, 1.0f, 0.0f, 7.0f);
        drawContext.drawRect(x, y + headerHeight - 1.0f, totalWidth, 1.0f, Colors.getSeparatorColor());
        float titleY = y + padY;
        drawContext.drawText(titleFont, title, x + padX, titleY);
        float lineY = y + headerHeight;
        for (class_9011 entry3 : entries) {
            class_2561 nameText = LegacyTextHelper.resolve(this.resolveNameText(scoreboard, entry3), defaultTextColor);
            class_2561 valueText = LegacyTextHelper.resolve(this.resolveValueText(objective, entry3), defaultTextColor);
            float rowY = lineY + (lineHeight - lineFont.height()) / 2.0f;
            float valueWidth = lineFont.width(valueText);
            drawContext.drawText(lineFont, nameText, x + padX, rowY);
            drawContext.drawText(lineFont, valueText, x + totalWidth - padX - valueWidth, rowY);
            lineY += lineHeight;
        }
    }

    private void updateDrag(float targetWidth, float targetHeight) {
        float maxX = Math.max(0.0f, sr.getScaledWidth() - targetWidth);
        float maxY = Math.max(0.0f, sr.getScaledHeight() - targetHeight);
        if (this.x < 0.0f || this.y < 0.0f) {
            this.x = maxX;
            this.y = 6.0f;
        }
        this.x = Math.max(0.0f, Math.min(this.x, maxX));
        this.y = Math.max(0.0f, Math.min(this.y, maxY));
        boolean mouseDown = GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)0) == 1;
        class_5611 mouse = GuiUtility.getMouse();
        float mouseX = mouse.method_32118();
        float mouseY = mouse.method_32119();
        if (mouseDown && !this.wasMouseDown && this.isHovered(mouseX, mouseY, targetWidth, targetHeight)) {
            this.dragging = true;
            this.dragOffsetX = mouseX - this.x;
            this.dragOffsetY = mouseY - this.y;
        }
        if (!mouseDown) {
            this.dragging = false;
        }
        if (this.dragging) {
            this.x = Math.max(0.0f, Math.min(mouseX - this.dragOffsetX, maxX));
            this.y = Math.max(0.0f, Math.min(mouseY - this.dragOffsetY, maxY));
        }
        this.wasMouseDown = mouseDown;
    }

    private boolean isHovered(float mouseX, float mouseY, float targetWidth, float targetHeight) {
        return mouseX >= this.x && mouseX < this.x + targetWidth && mouseY >= this.y && mouseY < this.y + targetHeight;
    }

    private class_2561 resolveNameText(class_269 scoreboard, class_9011 entry) {
        class_2561 display = entry.comp_2129();
        if (display != null) {
            return display;
        }
        String owner = entry.comp_2127();
        if (owner == null) {
            return class_2561.method_43473();
        }
        class_268 team = this.resolveTeam(scoreboard, owner);
        class_5250 base = class_2561.method_43470((String)owner);
        return team != null ? class_268.method_1142((class_270)team, (class_2561)base) : base;
    }

    private class_2561 resolveValueText(class_266 objective, class_9011 entry) {
        class_5250 formatted = entry.method_55386(objective.method_55380((class_9022)class_9025.field_47566));
        if (formatted != null) {
            return formatted;
        }
        return class_2561.method_43470((String)Integer.toString(entry.comp_2128()));
    }

    private class_268 resolveTeam(class_269 scoreboard, String owner) {
        Object result;
        Method method2;
        if (scoreboard == null || owner == null) {
            return null;
        }
        try {
            method2 = scoreboard.getClass().getMethod("getScoreHolderTeam", String.class);
            result = method2.invoke((Object)scoreboard, owner);
            if (result instanceof class_268) {
                class_268 team = (class_268)result;
                return team;
            }
        }
        catch (Throwable method2) {
            // empty catch block
        }
        try {
            method2 = scoreboard.getClass().getMethod("getPlayerTeam", String.class);
            result = method2.invoke((Object)scoreboard, owner);
            if (result instanceof class_268) {
                class_268 team = (class_268)result;
                return team;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}

